import XCTest
import SpriteKit
@testable import Stack_to_Six

@MainActor final class NativeSourceTutorialHUDTests:XCTestCase {
    @MainActor private final class Fixture {
        var wall=0.0,current=true
        let parent=SKNode(),root=SKNode(),ordinary=SKNode(),loader=SKNode(),extra=SKNode(),child=SKNode()
        let fifo=NativeSourceMicrotaskFIFO(),timeouts=NativeSourceAppTimeoutOwner()
        var service:NativeSourceAnimationClockService!,owner:NativeSourceTutorialHUDOwner!
        init()throws {
            parent.addChild(root);root.addChild(ordinary);root.addChild(loader);parent.addChild(extra);ordinary.addChild(child)
            ordinary.alpha=0.8;loader.alpha=0.6;loader.name="wildLoader";extra.alpha=1
            ordinary.isUserInteractionEnabled=true;child.isUserInteractionEnabled=true
            let tasks=NativeSourceMicrotaskAdapters(fifo:fifo);timeouts.sourceMicrotaskTasks=tasks
            service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{[weak self] in self?.wall ?? 0},sourceFrameTransportEnabled:true);service.sourceMicrotaskTasks=tasks
            owner=try XCTUnwrap(NativeSourceTutorialHUDOwner(root:root,extraTargets:[extra],service:service,timeouts:timeouts,generation:1,current:{[weak self] in self?.current==true}))
        }
        func deliver(_ time:Double){wall=time;service.deliver(wallMilliseconds:time)}
        func dispose(){owner.dispose();timeouts.cancelAll();service.dispose();fifo.dispose()}
    }
    func testActualFadeThenOriginalWall120ClampCancelsRootsAndPreservesLoader()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.owner.start());XCTAssertFalse(f.owner.start())
        XCTAssertFalse(f.ordinary.isUserInteractionEnabled);XCTAssertFalse(f.child.isUserInteractionEnabled)
        f.deliver(16);f.deliver(64)
        XCTAssertLessThan(f.ordinary.alpha,0.8);XCTAssertGreaterThan(f.ordinary.alpha,0.2)
        XCTAssertEqual(f.loader.alpha,0.6,accuracy:1e-6)
        try await Task.sleep(for:.milliseconds(150))
        XCTAssertGreaterThanOrEqual(f.owner.intervalDeliveries,1);XCTAssertEqual(f.ordinary.alpha,0.2,accuracy:1e-6)
        XCTAssertEqual(f.loader.alpha,0.6,accuracy:1e-6);XCTAssertEqual(f.extra.alpha,0.2,accuracy:1e-6)
        XCTAssertEqual(f.service.activeParticipantCount,0);XCTAssertEqual(f.timeouts.pendingCount,1)
        f.ordinary.alpha=0.9;f.root.alpha=0.4;f.root.isHidden=true
        try await Task.sleep(for:.milliseconds(150))
        XCTAssertEqual(f.ordinary.alpha,0.2,accuracy:1e-6);XCTAssertEqual(f.root.alpha,1);XCTAssertFalse(f.root.isHidden)
    }
    func testWallClampRemainsIndependentOfGlobalPauseAndForeground()async throws {
        let f=try Fixture();defer{f.dispose()};f.service.setSourceForeground(false);_=f.service.setSourceGlobalPaused(true)
        XCTAssertTrue(f.owner.start());XCTAssertEqual(f.ordinary.alpha,0.8,accuracy:1e-6)
        try await Task.sleep(for:.milliseconds(150));XCTAssertEqual(f.ordinary.alpha,0.2,accuracy:1e-6)
        XCTAssertEqual(f.service.activeParticipantCount,0);XCTAssertFalse(f.service.hasActiveClock)
    }
    func testDisposalKeepsPaintCancelsExactTimerAndDoesNotTouchOtherOwner()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.owner.start());f.deliver(32)
        var unrelated=false
        _=f.timeouts.schedule(sourceID:"unrelated",generation:2,delayMilliseconds:140,elapsed:{unrelated=true})
        let alpha=f.ordinary.alpha;f.owner.dispose();f.owner.dispose()
        XCTAssertEqual(f.timeouts.pendingCount,1);XCTAssertEqual(f.service.activeParticipantCount,0)
        try await Task.sleep(for:.milliseconds(170));f.deliver(200)
        XCTAssertEqual(f.ordinary.alpha,alpha);XCTAssertTrue(unrelated)
    }
    func testReparentedHUDChildIsNeverClampedByOldCapture()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.owner.start())
        f.ordinary.removeFromParent();f.parent.addChild(f.ordinary);f.ordinary.alpha=0.9
        try await Task.sleep(for:.milliseconds(150));f.deliver(300)
        XCTAssertEqual(f.ordinary.alpha,0.9,accuracy:1e-6);XCTAssertEqual(f.extra.alpha,0.2,accuracy:1e-6)
    }
    func testRetiredScopeStopsBeforeNextWallMutation()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.owner.start());f.current=false
        let alpha=f.ordinary.alpha;try await Task.sleep(for:.milliseconds(150))
        XCTAssertEqual(f.ordinary.alpha,alpha);XCTAssertFalse(f.owner.pendingInterval)
        XCTAssertEqual(f.timeouts.pendingCount,0);XCTAssertEqual(f.service.activeParticipantCount,0)
    }
}
