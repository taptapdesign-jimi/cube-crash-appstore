import XCTest
import UIKit
import SpriteKit
import StackToSixGameplay
import StackToSixNativeState
@testable import Stack_to_Six

@MainActor final class NativeSourceTutorialBootstrapTests:XCTestCase {
    func testActualFreshTutorialRouteUsesSourceDemoAndWaitsForGenuinePreparation() async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("source-initial-bootstrap-\(UUID().uuidString)")
        defer{try? FileManager.default.removeItem(at:directory)}
        let store=NativeSaveStore(directory:directory)
        var envelope=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false))
        envelope.progression.firstPlayTutorialComplete=false;try store.save(envelope)
        let fifo=NativeSourceMicrotaskFIFO(),tasks=NativeSourceMicrotaskAdapters(fifo:fifo)
        let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
        service.sourceMicrotaskTasks=tasks
        var count=0
        let context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{count+=1;return Double((count*37)%97)/97},sourceMicrotaskTasks:tasks)
        let bootstrap=try NativeBootstrap(root:NativeTestResources.root,store:store,sourceContext:context)
        bootstrap.sourceInitialFreshStartupEnabled=true;bootstrap.sourceBoardEntryEnabled=true;bootstrap.sourceTutorialActivationEnabled=true;bootstrap.sourceTutorialIntroEnabled=true;bootstrap.sourceTutorialHUDEnabled=true
        let host=UIViewController(),window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844))
        let previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
        window.rootViewController=host;window.makeKeyAndVisible();bootstrap.start(in:host)
        defer{bootstrap.dispose();context.dispose();service.dispose();window.isHidden=true;previous?.makeKeyAndVisible()}
        let app=try XCTUnwrap(host.children.first as? NativeAppController)
        app.navigate(.gameplay,interrupt:true)
        try await waitUntil{app.children.contains{$0 is NativeGameplayViewController}}
        let game=try XCTUnwrap(app.children.first as? NativeGameplayViewController),scene=try XCTUnwrap(game.boardScene),construction=try XCTUnwrap(game.sourceInitialConstruction)
        XCTAssertTrue(scene.sourceInitialStartupReady);XCTAssertTrue(game.sourceScope?.service === service)
        XCTAssertFalse(game.sourceSmallStackPresentationEnabled)
        for holder in construction.recipe?.holders ?? [] {XCTAssertTrue(scene.sourceNativeTileNode(holder.tileID) === construction.nodes[holder.tileID])}
        XCTAssertTrue(scene.sourceBoardEntryAdmissionOpen)
        XCTAssertNotNil(game.engine.pendingSourceTutorialDemoActivation)
        XCTAssertFalse(game.view.subviews.contains{$0 is NativeTutorialOverlay})
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-1)<1e-6})
        XCTAssertFalse(scene.sourceTutorialHUDActive)
        let initialTiles=game.engine.state.tiles
        let deadline=Date().addingTimeInterval(10);var wall=0.0
        while scene.completedSourceBoardEntry==nil && Date()<deadline {
            wall+=16;service.deliver(wallMilliseconds:wall)
            try await Task.sleep(nanoseconds:20_000_000)
        }
        XCTAssertEqual(scene.completedSourceBoardEntry?.outcome,.normal)
        while !scene.sourceTutorialPreparationReady && Date()<deadline {
            wall+=16;service.deliver(wallMilliseconds:wall)
            try await Task.sleep(nanoseconds:20_000_000)
        }
        XCTAssertTrue(scene.sourceTutorialPreparationReady)
        XCTAssertTrue(scene.sourceTutorialHUDActive)
        try await Task.sleep(for:.milliseconds(150))
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-0.2)<1e-6})
        scene.synchronize()
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-0.2)<1e-6})
        XCTAssertNil(game.engine.pendingSourceTutorialDemoActivation)
        XCTAssertEqual(game.engine.state.tutorial?.guidedPair.count,2)
        XCTAssertEqual(game.engine.state.tiles.map(\.value),initialTiles.map(\.value))
        let overlay=try XCTUnwrap(game.view.subviews.first{$0 is NativeTutorialOverlay} as? NativeTutorialOverlay)
        let intro=try XCTUnwrap(overlay.sourceIntroOwner)
        XCTAssertEqual(overlay.sourceSheetTranslation,overlay.sourceSheetHeight)
        XCTAssertFalse(overlay.sourcePointerVisible)
        service.setSourceForeground(false)
        try await Task.sleep(for:.milliseconds(1300))
        XCTAssertTrue(intro.sheetStarted);XCTAssertTrue(intro.pointerStarted)
        XCTAssertTrue(overlay.sourcePointerVisible)
        XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)
        service.setSourceForeground(true)
        for _ in 0..<60 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertEqual(overlay.sourceSheetTranslation,0,accuracy:1e-6)
        XCTAssertEqual(overlay.sourcePointerAlpha,1,accuracy:1e-6)
        let hint=overlay.sourceHintTransform
        for _ in 0..<30 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertNotEqual(overlay.sourceHintTransform,hint)
        overlay.hidePointer();XCTAssertFalse(overlay.sourcePointerVisible)
        let stopped=overlay.sourceHintTransform
        for _ in 0..<30 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertEqual(overlay.sourceHintTransform,stopped)
        overlay.restorePointer();XCTAssertTrue(overlay.sourcePointerVisible)
        XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)

        let saved=try XCTUnwrap(store.load()?.arcadeRun)
        XCTAssertEqual(saved.tiles,game.engine.state.tiles)
        // Actual APP callbacks may already have arrived by this awaited test
        // task. No fabricated arrival, fixed sleep or extra face draw is used.
        service.deliver(wallMilliseconds:wall+16)
        XCTAssertEqual(construction.pendingFaceCount,0);XCTAssertEqual(game.engine.state.tiles,saved.tiles)
    }
    private func waitUntil(_ predicate:()->Bool)async throws {
        let deadline=Date().addingTimeInterval(8)
        while !predicate() {if Date()>deadline {throw NSError(domain:"SourceInitialBoardTimeout",code:1)};try await Task.sleep(nanoseconds:20_000_000)}
    }
}
