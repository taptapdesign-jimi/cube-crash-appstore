import Foundation
import SpriteKit

/// First guided-phase HUD only. Source starts .42 sine.inOut alpha roots,
/// then each independently phased wall120 interval kills them and clamps .2.
/// Later authored restore/scale/random recipes require a separate caller.
@MainActor final class NativeSourceTutorialHUDOwner {
    @MainActor private final class Target {
        let node:SKNode,originalAlpha:CGFloat,preservesAlpha:Bool
        weak var parent:SKNode?
        let interactions:[(SKNode,Bool)]
        init(_ node:SKNode,preservesAlpha:Bool){self.node=node;parent=node.parent;originalAlpha=node.alpha;self.preservesAlpha=preservesAlpha
            func capture(_ node:SKNode)->[(SKNode,Bool)]{[(node,node.isUserInteractionEnabled)]+node.children.flatMap{capture($0)}}
            interactions=capture(node)
        }
        var current:Bool{node.parent === parent && parent != nil}
    }
    @MainActor private final class Fade:NativeSourceAnimationParticipant {
        let update:(Double)->Void
        init(_ update:@escaping(Double)->Void){self.update=update}
        func advanceSourceAnimation(seconds:Double){update(seconds)}
    }
    private let service:NativeSourceAnimationClockService,timeouts:NativeSourceAppTimeoutOwner,generation:UInt64,current:()->Bool
    private let root:SKNode,rootOriginalAlpha:CGFloat,targets:[Target]
    private weak var rootParent:SKNode?
    private var fades:[Fade]=[],leases:[NativeSourceAnimationClockService.Lease]=[]
    private var timer:NativeSourceAppTimeoutOwner.Receipt?,deadline:UInt64=0,started=false,disposed=false
    private(set) var intervalDeliveries=0
    var pendingInterval:Bool{timer != nil}
    init?(root:SKNode,extraTargets:[SKNode]=[],service:NativeSourceAnimationClockService,timeouts:NativeSourceAppTimeoutOwner,
        generation:UInt64,current:@escaping()->Bool) {
        guard generation>0,root.parent != nil,service.sourceMicrotaskRAFBoundaryInstalled,
            let tasks=service.sourceMicrotaskTasks,timeouts.sourceMicrotaskTasks === tasks,current() else{return nil}
        self.root=root;rootParent=root.parent;rootOriginalAlpha=root.alpha
        self.service=service;self.timeouts=timeouts;self.generation=generation;self.current=current
        targets=(root.children+extraTargets).map{Target($0,preservesAlpha:$0.name=="wildLoader")}
    }
    private func admitted()->Bool{guard !disposed,root.parent === rootParent,rootParent != nil else{return false};let valid=current();return valid && !disposed}
    func owns(_ node:SKNode)->Bool{!disposed && targets.contains{$0.node === node && $0.current}}
    @discardableResult func start()->Bool {
        guard !started,admitted() else{return false};started=true
        root.isHidden=false;root.alpha=rootOriginalAlpha
        for target in targets where target.current {
            for (node,_) in target.interactions{node.isUserInteractionEnabled=false}
            let from=Double(target.node.alpha),to=target.preservesAlpha ? Double(target.originalAlpha):0.2
            let fade=Fade{[weak self,weak target] seconds in
                guard let self else{return};guard self.admitted() else{self.dispose();return}
                guard let target,target.current else{return}
                target.node.alpha=CGFloat(from+(to-from)*(0.5-0.5*cos(min(1,max(0,seconds/0.42))*Double.pi)))
            }
            fades.append(fade)
            guard let lease=service.register(participant:fade,duration:0.42,domain:.sourceGSAP(.defaultLazyTween),cleanup:{_ in}) else{dispose();return false}
            leases.append(lease)
        }
        deadline=DispatchTime.now().uptimeNanoseconds+120_000_000;scheduleInterval()
        return admitted()
    }
    private func scheduleInterval(){
        guard admitted(),timer==nil else{return}
        timer=timeouts.schedule(sourceID:"tutorial-hud-interval120",generation:generation,delayMilliseconds:0,
            from:DispatchTime(uptimeNanoseconds:deadline),elapsed:{[weak self] in
                guard let self else{return};self.timer=nil
                guard self.admitted() else{self.dispose();return}
                // Obtain next original-phase deadline before executing callback.
                let now=DispatchTime.now().uptimeNanoseconds
                self.deadline += 120_000_000
                if self.deadline<=now{self.deadline += ((now-self.deadline)/120_000_000+1)*120_000_000}
                self.scheduleInterval();guard self.admitted() else{return}
                self.intervalDeliveries+=1;self.cancelFades()
                self.root.isHidden=false;self.root.alpha=self.rootOriginalAlpha
                for target in self.targets where target.current {
                    for (node,_) in target.interactions{node.isUserInteractionEnabled=false}
                    target.node.alpha=target.preservesAlpha ? target.originalAlpha:0.2
                }
            })
    }
    private func cancelFades(){let old=leases;leases.removeAll();fades.removeAll();for lease in old{lease.cancel(success:false)}}
    /// Disposal retires captured work and leaves current paint. A later Source
    /// stopHudDim(restore/animateRestore) needs its original random/scale owner.
    func dispose(){guard !disposed else{return};disposed=true;let old=timer;timer=nil;if let old{_=timeouts.cancel(old)};cancelFades()}
    isolated deinit{dispose()}
}
