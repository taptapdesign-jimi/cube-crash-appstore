import XCTest
import UIKit
import SpriteKit
import StackToSixGameplay
@testable import Stack_to_Six
@MainActor final class NativeSourceRegularResumeConstructionTests:XCTestCase {
 @MainActor private final class Counter {var count=0;var onDraw:(()->Void)?;func next()->Double {count+=1;onDraw?();return Double((count*37)%97)/97}}
 private func saved()->NativeBoardState {.init(tiles:[.init(id:"five",cell:.init(column:4,row:8),value:5,stackDepth:4,visible:false,alpha:0.7),.init(id:"zero",cell:.init(column:0,row:0),value:0,locked:true,visible:false,alpha:0.7),.init(id:"three-locked",cell:.init(column:2,row:3),value:3,stackDepth:3,locked:true,visible:false,alpha:0.7)],mode:.journey,board:7,stage:7,generation:9,revision:4,moves:23,score:123,wildMeter:0.4,rngState:777)}
 @MainActor private final class Fixture {
  let counter=Counter(),service:NativeSourceAnimationClockService,construction:NativeSourceInitialBoardConstruction,scene:NativeBoardScene
  var repairContext:NativeGameplaySourceContext?
  init(_ state:NativeBoardState,sourceOuterForRepair:Bool=false)throws {
   service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
   construction=try XCTUnwrap(NativeSourceInitialBoardConstruction.makeRestoredRegular(root:NativeTestResources.root,service:service,saved:state,random:{[counter] in counter.next()}))
   let engine=NativeGameplayEngine(state:try XCTUnwrap(construction.recipe?.state))
   scene=NativeBoardScene(engine:engine,resourceRoot:NativeTestResources.root,size:CGSize(width:390,height:844),sourceInitialConstruction:construction)
   scene.synchronize()
   if sourceOuterForRepair {
    let context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{[counter] in counter.next()})
    let captured=scene
    let scope=try XCTUnwrap(context.beginScene(engine:scene.engine,retire:{[weak captured] in captured?.retireSourceAnimationBindings()}))
    repairContext=context;scene.sourceOuterTimelineDriver=scope.timeline;scene.sourceDragTweenDriver=scope.tween
    scene.synchronize()
    XCTAssertTrue(construction.nodes.values.allSatisfy{$0.sourcePhysicalMarkersCovered})
   }
  }
  func dispose(){counter.onDraw=nil;scene.dispose();repairContext?.dispose();construction.dispose();service.dispose()}
 }
 func testGenuineSparseSavedCellsReuseOnlyTheirSameCapturedObjectsWithoutFreshShuffle()throws {
  let state=saved(),f=try Fixture(state);defer{f.dispose()}
  XCTAssertTrue(f.scene.sourceInitialStartupReady);XCTAssertEqual(f.counter.count,3)
  XCTAssertEqual(f.service.pendingSourceAnimationFrameCount,4);XCTAssertEqual(f.construction.nodes.count,3)
  XCTAssertEqual(f.scene.engine.state.tiles.map(\.id),["zero","three-locked","five"])
  XCTAssertEqual(f.scene.engine.state.revision,4);XCTAssertEqual(f.scene.engine.state.score,123);XCTAssertEqual(f.scene.engine.state.moves,23)
  for holder in try XCTUnwrap(f.construction.recipe).holders {
   let node=try XCTUnwrap(f.scene.sourceNativeTileNode(holder.tileID))
   XCTAssertTrue(node === f.construction.nodes[holder.tileID]);XCTAssertTrue(node.isHidden)
   XCTAssertEqual(node.depth,1);XCTAssertEqual(Double(node.dragInnerTilt),holder.rotation,accuracy:2e-5)
   XCTAssertTrue(node.sourcePaintedNumbersTexture === f.construction.textures.texture("assets/tile.png",densityAware:false))
  }
  XCTAssertEqual(state.tiles[0].stackDepth,4);XCTAssertEqual(state.tiles[0].alpha,0.7)
 }
 func testActualZeroRawFaceDoesNotChooseSkinAndLockedPositiveFaceDoesWithoutPips()throws {
  let f=try Fixture(saved());defer{f.dispose()};let before=f.scene.engine.state
  var sawBatchBeforeSkin=false
  f.counter.onDraw={ [weak construction=f.construction,weak counter=f.counter] in
   guard counter?.count==4,let construction else{return};sawBatchBeforeSkin=true
   XCTAssertEqual(construction.nodes["five"]?.sourcePipNodes.count,5)
   XCTAssertTrue(construction.nodes["zero"]?.sourcePipNodes.isEmpty==true)
   XCTAssertTrue(construction.nodes["three-locked"]?.sourcePipNodes.isEmpty==true)
  }
  f.service.deliver(wallMilliseconds:16)
  XCTAssertTrue(sawBatchBeforeSkin);XCTAssertEqual(f.counter.count,5);XCTAssertEqual(f.construction.pendingFaceCount,0)
  XCTAssertEqual(f.service.pendingSourceAnimationFrameCount,0);XCTAssertEqual(f.scene.engine.state,before)
  let zero=try XCTUnwrap(f.construction.nodes["zero"]),locked=try XCTUnwrap(f.construction.nodes["three-locked"]),five=try XCTUnwrap(f.construction.nodes["five"])
  XCTAssertTrue(zero.sourcePaintedNumbersTexture === f.construction.textures.texture("assets/tile.png",densityAware:false))
  XCTAssertEqual(locked.sourceCurrentRegularSkin,.second);XCTAssertEqual(five.sourceCurrentRegularSkin,.fourth)
  XCTAssertTrue(locked.sourcePipNodes.isEmpty);XCTAssertEqual(five.sourcePipNodes.count,5)
  XCTAssertEqual(zero.sourceEventMode,"none");XCTAssertEqual(locked.sourceEventMode,"none");XCTAssertEqual(five.sourceEventMode,"static")
  XCTAssertEqual(Double(zero.alpha),0.25,accuracy:1e-6);XCTAssertEqual(Double(locked.alpha),1,accuracy:1e-6)
 }
 func testGlobalPauseDoesNotPauseRawRestoreWhileActualBackgroundRetainsExactQueuedFaces()throws {
  let f=try Fixture(saved());defer{f.dispose()};let before=f.scene.engine.state
  f.scene.setSuspended(true);f.service.setSourceGlobalPaused(true);f.service.setSourceForeground(false)
  f.service.deliver(wallMilliseconds:1000);XCTAssertEqual(f.counter.count,3);XCTAssertEqual(f.construction.pendingFaceCount,3)
  f.service.setSourceForeground(true);f.service.deliver(wallMilliseconds:1016)
  XCTAssertEqual(f.counter.count,5);XCTAssertEqual(f.construction.pendingFaceCount,0);XCTAssertEqual(f.scene.engine.state,before)
 }
 func testRouteMissingAdoptionCannotDeliverFaceRNGOrRecreateObjects()throws {
  let c=Counter(),service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
  defer{service.dispose()}
  let construction=try XCTUnwrap(NativeSourceInitialBoardConstruction.makeRestoredRegular(root:NativeTestResources.root,service:service,saved:saved(),random:{c.next()}))
  service.deliver(wallMilliseconds:16)
  XCTAssertEqual(c.count,3);XCTAssertFalse(construction.readyToAdopt);XCTAssertTrue(construction.nodes.isEmpty);XCTAssertEqual(service.pendingSourceAnimationFrameCount,0)
  service.deliver(wallMilliseconds:32);XCTAssertEqual(c.count,3)
 }
 func testGenerationRetirementCancelsCapturedEmptyAndPositiveFacesWithoutChangingNewBoard()throws {
  let f=try Fixture(saved());defer{f.dispose()}
  let zero=try XCTUnwrap(f.construction.nodes["zero"]),texture=zero.sourcePaintedNumbersTexture
  f.scene.retireSourceAnimationBindings()
  f.scene.engine.restart(state:.init(tiles:[.init(id:"replacement",cell:.init(column:0,row:0),value:2)]))
  let state=f.scene.engine.state;f.service.deliver(wallMilliseconds:16)
  XCTAssertEqual(f.counter.count,3);XCTAssertEqual(f.scene.engine.state,state)
  XCTAssertTrue(zero.sourcePaintedNumbersTexture === texture);XCTAssertTrue(zero.sourceContactNodeAlive)
 }
 func testUnmappedSpecialTutorialAndMissingTransportRefuseBeforeAnyConstructorDraw() {
  let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceFrameTransportEnabled:true)
  defer{service.dispose()};var draws=0
  var special=saved();special.tiles[0].archetype = .star;special.tiles[0].value=6
  XCTAssertNil(NativeSourceInitialBoardConstruction.makeRestoredRegular(root:NativeTestResources.root,service:service,saved:special,random:{draws+=1;return 0.5}))
  var tutorial=saved();tutorial.tutorial=NativeTutorialState()
  XCTAssertNil(NativeSourceInitialBoardConstruction.makeRestoredRegular(root:NativeTestResources.root,service:service,saved:tutorial,random:{draws+=1;return 0.5}))
  let unavailable=NativeSourceAnimationClockService(wallOriginMilliseconds:0);defer{unavailable.dispose()}
  XCTAssertNil(NativeSourceInitialBoardConstruction.makeRestoredRegular(root:NativeTestResources.root,service:unavailable,saved:saved(),random:{draws+=1;return 0.5}))
  XCTAssertEqual(draws,0)
 }
 func testActualRegularVisualRepairRestoresLocalPoseAndFaceWithoutChangingCanonicalStateOrSkin()throws {
  let f=try Fixture(saved(),sourceOuterForRepair:true);defer{f.dispose()};f.service.deliver(wallMilliseconds:16)
  let node=try XCTUnwrap(f.construction.nodes["five"]),before=f.scene.engine.state,draws=f.counter.count
  let skin=node.sourceCurrentRegularSkin,texture=node.sourcePaintedNumbersTexture
  node.isHidden=false;node.paintSourceOuterScale(.init(x:3,y:2));node.paintSourceIdleRotation(0.5)
  node.visual.setScale(1.4);node.visual.zRotation=0.3;node.alpha=0.04
  XCTAssertTrue(node.repairSourceRegularBoardVisuals(outerTransformOwned:false,activeDrag:false,innerImpactOwned:false,wildDropping:false,retireUnownedInnerTransform:{XCTAssertFalse(node.visual.hasActions());return true}))
  XCTAssertEqual(node.sourceLocalScale.x,1,accuracy:1e-6);XCTAssertEqual(node.sourceLocalScale.y,1,accuracy:1e-6)
  XCTAssertEqual(node.sourceRotation,0,accuracy:1e-6);XCTAssertEqual(node.visual.xScale,1)
  XCTAssertEqual(node.sourceStarOrbitMetrics.width,128,accuracy:1e-5);XCTAssertEqual(node.sourceStarOrbitMetrics.height,128,accuracy:1e-5)
  XCTAssertEqual(node.alpha,1);XCTAssertEqual(node.sourceCurrentRegularSkin,skin);XCTAssertTrue(node.sourcePaintedNumbersTexture === texture)
  XCTAssertTrue(node.repairSourceRegularBoardVisuals(outerTransformOwned:false,activeDrag:false,innerImpactOwned:false,wildDropping:false,retireUnownedInnerTransform:{true}))
  XCTAssertEqual(node.sourceStarOrbitMetrics.width,128,accuracy:1e-5,"repeat repair must not inflate authored face")
  XCTAssertEqual(f.counter.count,draws);XCTAssertEqual(f.scene.engine.state,before)
 }
 func testActualRegularRepairPreservesOwnedOuterAndInnerPoseAndLockedOpacityRule()throws {
  let f=try Fixture(saved(),sourceOuterForRepair:true);defer{f.dispose()};f.service.deliver(wallMilliseconds:16)
  let node=try XCTUnwrap(f.construction.nodes["five"]),zero=try XCTUnwrap(f.construction.nodes["zero"])
  node.isHidden=false;node.paintSourceOuterScale(.init(x:1.12,y:0.94));node.visual.setScale(1.4)
  XCTAssertTrue(node.repairSourceRegularBoardVisuals(outerTransformOwned:true,activeDrag:true,innerImpactOwned:true,wildDropping:false,retireUnownedInnerTransform:{XCTFail("owned transform must not retire");return false}))
  XCTAssertEqual(node.sourceLocalScale.x,1.12,accuracy:1e-6);XCTAssertEqual(node.sourceLocalScale.y,0.94,accuracy:1e-6);XCTAssertEqual(node.visual.xScale,1.4,accuracy:1e-6)
  zero.isHidden=false;zero.alpha=0.01;XCTAssertTrue(zero.repairSourceRegularSpawnOpacity(wildDropping:true));XCTAssertEqual(zero.alpha,0.01,accuracy:1e-6)
  XCTAssertTrue(zero.repairSourceRegularSpawnOpacity(wildDropping:false));XCTAssertEqual(zero.alpha,0.2,accuracy:1e-6)
  node.isHidden=true;node.alpha=0.01;XCTAssertTrue(node.repairSourceRegularSpawnOpacity(wildDropping:false));XCTAssertEqual(node.alpha,1)
 }
 func testActualInnerRepairMissingRetirementAuthorityRefusesInsteadOfPaintingOverOrphan()throws {
  let f=try Fixture(saved(),sourceOuterForRepair:true);defer{f.dispose()};f.service.deliver(wallMilliseconds:16)
  let node=try XCTUnwrap(f.construction.nodes["five"]);node.isHidden=false;node.visual.setScale(1.4)
  XCTAssertFalse(node.repairSourceRegularBoardVisuals(outerTransformOwned:true,activeDrag:false,innerImpactOwned:false,wildDropping:false,retireUnownedInnerTransform:{false}))
  XCTAssertEqual(node.visual.xScale,1.4,accuracy:1e-6)
 }

 func testActualPickupOwnerProtectsScaleEvenWhenExternalFlagsAreFalse()throws {
  let f=try Fixture(saved(),sourceOuterForRepair:true);defer{f.dispose()};f.service.deliver(wallMilliseconds:16)
  let node=try XCTUnwrap(f.construction.nodes["five"]);node.isHidden=false
  XCTAssertTrue(node.beginSourcePickup());f.service.deliver(wallMilliseconds:40)
  XCTAssertTrue(node.sourceOuterOwners.pickupScale)
  let scale=node.sourceLocalScale
  XCTAssertTrue(node.repairSourceRegularBoardVisuals(outerTransformOwned:false,activeDrag:false,innerImpactOwned:false,wildDropping:false,retireUnownedInnerTransform:{true}))
  XCTAssertEqual(node.sourceLocalScale.x,scale.x,accuracy:1e-6);XCTAssertEqual(node.sourceLocalScale.y,scale.y,accuracy:1e-6)
  XCTAssertTrue(node.sourceOuterOwners.pickupScale)
 }

}
