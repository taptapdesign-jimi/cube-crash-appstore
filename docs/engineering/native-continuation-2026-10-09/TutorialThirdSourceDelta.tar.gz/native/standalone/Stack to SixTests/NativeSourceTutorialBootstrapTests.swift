import XCTest
import UIKit
import SpriteKit
import StackToSixGameplay
import StackToSixNativeState
@testable import Stack_to_Six

@MainActor final class NativeSourceTutorialBootstrapTests:XCTestCase {
    func testActualFreshTutorialRouteUsesSourceDemoAndWaitsForGenuinePreparation() async throws {try await run(monitored:false,retireDuringExit:false)}
    func testActualFirstMergeKeepsSourceSheetAndInputUntilRealMonitorCompletions()async throws {try await run(monitored:true,retireDuringExit:false)}
    func testActualScopeRetirementDuringFirstExitCancelsMonitorAndInputBarrier()async throws {try await run(monitored:true,retireDuringExit:true)}
    func testActualSecondMergeWaitsForSourceThirdRestoreAndKeepsSameIntroOwner()async throws {try await run(monitored:true,retireDuringExit:false,third:true)}
    private func run(monitored:Bool,retireDuringExit:Bool,third:Bool=false)async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("source-initial-bootstrap-\(UUID().uuidString)")
        defer{try? FileManager.default.removeItem(at:directory)}
        let store=NativeSaveStore(directory:directory)
        var envelope=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false))
        envelope.progression.firstPlayTutorialComplete=false;try store.save(envelope)
        let fifo=NativeSourceMicrotaskFIFO(),tasks=NativeSourceMicrotaskAdapters(fifo:fifo)
        let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
        service.sourceMicrotaskTasks=tasks
        var count=0
        let context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{count+=1;return Double((count*37)%97)/97},sourceMicrotaskTasks:tasks)
        let bootstrap=try NativeBootstrap(root:NativeTestResources.root,store:store,sourceContext:context)
        bootstrap.sourceInitialFreshStartupEnabled=true;bootstrap.sourceBoardEntryEnabled=true;bootstrap.sourceTutorialActivationEnabled=true;bootstrap.sourceTutorialIntroEnabled=true;bootstrap.sourceTutorialHUDEnabled=true;bootstrap.sourceTutorialFirstStepMonitorEnabled=monitored;bootstrap.sourceTutorialSubsequentPresentationEnabled=third
        let host=UIViewController(),window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844))
        let previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
        window.rootViewController=host;window.makeKeyAndVisible();bootstrap.start(in:host)
        defer{bootstrap.dispose();context.dispose();service.dispose();window.isHidden=true;previous?.makeKeyAndVisible()}
        let app=try XCTUnwrap(host.children.first as? NativeAppController)
        app.navigate(.gameplay,interrupt:true)
        try await waitUntil{app.children.contains{$0 is NativeGameplayViewController}}
        let game=try XCTUnwrap(app.children.first as? NativeGameplayViewController),scene=try XCTUnwrap(game.boardScene),construction=try XCTUnwrap(game.sourceInitialConstruction)
        XCTAssertTrue(scene.sourceInitialStartupReady);XCTAssertTrue(game.sourceScope?.service === service)
        XCTAssertFalse(game.sourceSmallStackPresentationEnabled)
        for holder in construction.recipe?.holders ?? [] {XCTAssertTrue(scene.sourceNativeTileNode(holder.tileID) === construction.nodes[holder.tileID])}
        XCTAssertTrue(scene.sourceBoardEntryAdmissionOpen)
        XCTAssertNotNil(game.engine.pendingSourceTutorialDemoActivation)
        XCTAssertFalse(game.view.subviews.contains{$0 is NativeTutorialOverlay})
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-1)<1e-6})
        XCTAssertFalse(scene.sourceTutorialHUDActive)
        let initialTiles=game.engine.state.tiles
        let deadline=Date().addingTimeInterval(10);var wall=0.0
        while scene.completedSourceBoardEntry==nil && Date()<deadline {
            wall+=16;service.deliver(wallMilliseconds:wall)
            try await Task.sleep(nanoseconds:20_000_000)
        }
        XCTAssertEqual(scene.completedSourceBoardEntry?.outcome,.normal)
        while !scene.sourceTutorialPreparationReady && Date()<deadline {
            wall+=16;service.deliver(wallMilliseconds:wall)
            try await Task.sleep(nanoseconds:20_000_000)
        }
        XCTAssertTrue(scene.sourceTutorialPreparationReady)
        let actualGeometry=try XCTUnwrap(scene.boardGeometry)
        for tile in game.engine.state.tiles {
            let node=try XCTUnwrap(scene.sourceNativeTileNode(tile.id))
            let face=try XCTUnwrap(node.visual.children.compactMap{$0 as? SKSpriteNode}.first{$0.texture === node.sourcePaintedNumbersTexture})
            let width=abs(face.frame.width*node.visual.xScale*node.xScale)
            XCTAssertLessThanOrEqual(width,actualGeometry.tileSize*1.05,"oversized actual face \(tile.id): faceFrame=\(face.frame) root=\(node.xScale), visual=\(node.visual.xScale), expected=\(actualGeometry.tileSize)")
        }
        if let texture=scene.view?.texture(from:scene) {
            let shot=XCTAttachment(image:UIImage(cgImage:texture.cgImage()));shot.name="actual-native-tutorial-board-scale";shot.lifetime = .keepAlways;add(shot)
        }
        XCTAssertTrue(scene.sourceTutorialHUDActive)
        try await Task.sleep(for:.milliseconds(150))
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-0.2)<1e-6})
        scene.synchronize()
        XCTAssertTrue(scene.sourceTutorialHUDAlphas.allSatisfy{abs($0-0.2)<1e-6})
        XCTAssertNil(game.engine.pendingSourceTutorialDemoActivation)
        XCTAssertEqual(game.engine.state.tutorial?.guidedPair.count,2)
        XCTAssertEqual(game.engine.state.tiles.map(\.value),initialTiles.map(\.value))
        let overlay=try XCTUnwrap(game.view.subviews.first{$0 is NativeTutorialOverlay} as? NativeTutorialOverlay)
        let intro=try XCTUnwrap(overlay.sourceIntroOwner)
        XCTAssertEqual(overlay.sourceSheetTranslation,overlay.sourceSheetHeight)
        XCTAssertFalse(overlay.sourcePointerVisible)
        service.setSourceForeground(false)
        try await Task.sleep(for:.milliseconds(1300))
        XCTAssertTrue(intro.sheetStarted);XCTAssertTrue(intro.pointerStarted)
        XCTAssertTrue(overlay.sourcePointerVisible)
        XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)
        service.setSourceForeground(true)
        for _ in 0..<60 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertEqual(overlay.sourceSheetTranslation,0,accuracy:1e-6)
        XCTAssertEqual(overlay.sourcePointerAlpha,1,accuracy:1e-6)
        let hint=overlay.sourceHintTransform
        for _ in 0..<30 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertNotEqual(overlay.sourceHintTransform,hint)
        overlay.hidePointer();XCTAssertFalse(overlay.sourcePointerVisible)
        let stopped=overlay.sourceHintTransform
        for _ in 0..<30 {wall+=16;service.deliver(wallMilliseconds:wall)}
        XCTAssertEqual(overlay.sourceHintTransform,stopped)
        overlay.restorePointer();XCTAssertTrue(overlay.sourcePointerVisible)
        XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)

        if monitored {
            XCTAssertTrue(scene.sourceTutorialFirstStepPresentationActive)
            let pair=try XCTUnwrap(game.engine.state.tutorial?.guidedPair),oneID=try XCTUnwrap(game.engine.state.tutorial?.oneTileID)
            let source=try XCTUnwrap(scene.sourceNativeTileNode(pair[0])),target=try XCTUnwrap(scene.sourceNativeTileNode(pair[1]))
            func point(_ node:NativeDiceNode)->CGPoint{scene.convert(node.position,from:try! XCTUnwrap(node.parent))}
            XCTAssertTrue(scene.beginDrag(at:point(source)))
            let destination=point(target)
            scene.moveDrag(to:destination,now:1)
            for _ in 0..<10{wall+=16;service.deliver(wallMilliseconds:wall)}
            let moved=try XCTUnwrap(scene.finishDrag(at:destination,now:1.2));XCTAssertTrue(moved.accepted)
            XCTAssertEqual(game.engine.state.tutorial?.step,.mergeSix)
            let receipt=try XCTUnwrap(game.engine.pendingSourceTutorialPresentationBarrier)
            XCTAssertEqual(receipt.mergedID,target.tileID);XCTAssertTrue(scene.sourceTutorialFirstStepPresentationActive)
            XCTAssertFalse(game.engine.beginDrag(tileID:oneID));XCTAssertFalse(scene.sourceTutorialSecondPreparationReady)
            _=service.setSourceGlobalPaused(true)
            try await Task.sleep(for:.milliseconds(180))
            for _ in 0..<60{wall+=16;service.deliver(wallMilliseconds:wall)}
            XCTAssertNotNil(game.engine.pendingSourceTutorialPresentationBarrier)
            XCTAssertFalse(scene.sourceTutorialSecondPreparationReady)
            if retireDuringExit {
                // This bounded Bootstrap fixture deliberately retains the
                // default Native contact/debit owner. Drain its genuine debit
                // before auditing Source Scope retirement; tutorial exit stays
                // globally paused throughout, and no completion is fabricated.
                let debitDeadline=Date().addingTimeInterval(2)
                while game.engine.state.moves==50 && Date()<debitDeadline{try await Task.sleep(for:.milliseconds(20))}
                XCTAssertEqual(game.engine.state.moves,49)
                XCTAssertNotNil(game.engine.pendingSourceTutorialPresentationBarrier)
                let snapshot=game.engine.state,draws=count
                game.sourceScope?.dispose()
                XCTAssertNil(game.engine.pendingSourceTutorialPresentationBarrier)
                XCTAssertNil(overlay.sourceIntroOwner);XCTAssertFalse(scene.sourceTutorialFirstStepPresentationActive)
                XCTAssertFalse(scene.sourceTutorialSecondPreparationReady)
                _=service.setSourceGlobalPaused(false)
                for _ in 0..<100{wall+=16;service.deliver(wallMilliseconds:wall)}
                try await Task.sleep(for:.milliseconds(220))
                XCTAssertEqual(game.engine.state,snapshot);XCTAssertEqual(count,draws)
                return
            }
            _=service.setSourceGlobalPaused(false)
            for _ in 0..<45{wall+=16;service.deliver(wallMilliseconds:wall)}
            // Only wall90 after the two real finite roots may prepare step two.
            service.setSourceForeground(false)
            try await Task.sleep(for:.milliseconds(130))
            XCTAssertTrue(scene.sourceTutorialSecondPreparationReady)
            XCTAssertFalse(scene.sourceTutorialFirstStepPresentationActive)
            XCTAssertNil(game.engine.pendingSourceTutorialPresentationBarrier)
            XCTAssertTrue(game.engine.beginDrag(tileID:oneID));game.engine.cancelDrag()
            XCTAssertTrue(overlay.sourceIntroOwner === intro)
            service.setSourceForeground(true)
            for _ in 0..<90{wall+=16;service.deliver(wallMilliseconds:wall)}
            XCTAssertEqual(overlay.sourceSheetTranslation,0,accuracy:1e-6)
            XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)
            if third {
                XCTAssertTrue(scene.sourceTutorialSecondPresentationActive)
                let five=try XCTUnwrap(scene.sourceNativeTileNode(receipt.mergedID)),one=try XCTUnwrap(scene.sourceNativeTileNode(oneID))
                XCTAssertTrue(scene.beginDrag(at:point(one)));let secondDestination=point(five)
                scene.moveDrag(to:secondDestination,now:3)
                for _ in 0..<10{wall+=16;service.deliver(wallMilliseconds:wall)}
                XCTAssertTrue(try XCTUnwrap(scene.finishDrag(at:secondDestination,now:3.2)).accepted)
                // The existing Native Six transaction commits later than its
                // accepted gesture; wait for that genuine producer while Source
                // exit roots stay paused, rather than asserting at acceptance.
                _=service.setSourceGlobalPaused(true)
                let sixDeadline=Date().addingTimeInterval(6)
                while game.engine.state.tutorial?.step != .freePlay && Date()<sixDeadline {
                    wall+=16;service.deliver(wallMilliseconds:wall);try await Task.sleep(for:.milliseconds(20))
                }
                XCTAssertEqual(game.engine.state.tutorial?.step,.freePlay)
                let second=try XCTUnwrap(game.engine.pendingSourceTutorialPresentationBarrier);XCTAssertEqual(second.phase,.secondMerge)
                XCTAssertTrue(scene.sourceTutorialSecondPresentationActive);XCTAssertFalse(scene.sourceTutorialThirdPresentationActive)
                _=service.setSourceGlobalPaused(true);try await Task.sleep(for:.milliseconds(100))
                for _ in 0..<60{wall+=16;service.deliver(wallMilliseconds:wall)}
                XCTAssertEqual(game.engine.pendingSourceTutorialPresentationBarrier,second)
                _=service.setSourceGlobalPaused(false)
                let thirdDeadline=Date().addingTimeInterval(5)
                while !scene.sourceTutorialThirdPresentationActive && Date()<thirdDeadline {
                    wall+=16;service.deliver(wallMilliseconds:wall);try await Task.sleep(for:.milliseconds(20))
                }
                XCTAssertTrue(scene.sourceTutorialThirdPresentationActive);XCTAssertFalse(scene.sourceTutorialSecondPresentationActive)
                XCTAssertNil(game.engine.pendingSourceTutorialPresentationBarrier)
                XCTAssertTrue(overlay.sourceIntroOwner === intro)
                for _ in 0..<110{wall+=16;service.deliver(wallMilliseconds:wall)}
                XCTAssertEqual(overlay.sourceSheetTranslation,0,accuracy:1e-6)
            }
        }
        if monitored{NotificationCenter.default.post(name:UIApplication.willResignActiveNotification,object:nil)}
        let saved=try XCTUnwrap(store.load()?.arcadeRun)
        XCTAssertEqual(saved.tiles,game.engine.state.tiles)
        // Actual APP callbacks may already have arrived by this awaited test
        // task. No fabricated arrival, fixed sleep or extra face draw is used.
        if monitored{NotificationCenter.default.post(name:UIApplication.didBecomeActiveNotification,object:nil)}
        service.deliver(wallMilliseconds:wall+16)
        XCTAssertEqual(construction.pendingFaceCount,0);XCTAssertEqual(game.engine.state.tiles,saved.tiles)
    }
    private func waitUntil(_ predicate:()->Bool)async throws {
        let deadline=Date().addingTimeInterval(8)
        while !predicate() {if Date()>deadline {throw NSError(domain:"SourceInitialBoardTimeout",code:1)};try await Task.sleep(nanoseconds:20_000_000)}
    }
}
