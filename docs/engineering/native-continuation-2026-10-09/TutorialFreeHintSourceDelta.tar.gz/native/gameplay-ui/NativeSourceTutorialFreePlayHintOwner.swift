import Foundation
import CoreGraphics

/// A visible, captured Source step-three timeline. Uses the existing APP
/// transport/FIFO and cancels its exact repeating root on hide/replacement.
@MainActor final class NativeSourceTutorialFreePlayHintOwner:NativeSourceAnimationParticipant {
    private let service:NativeSourceAnimationClockService,plan:NativeSourceTutorialFreePlayPlan,current:()->Bool
    private let fingertip:CGPoint,paint:(NativeSourceTutorialFreePlayPlan.Pose)->Void
    private var lease:NativeSourceAnimationClockService.Lease?,disposed=false,started=false
    var active:Bool{!disposed && lease?.active==true}
    init?(service:NativeSourceAnimationClockService,plan:NativeSourceTutorialFreePlayPlan,fingertip:CGPoint,current:@escaping()->Bool,paint:@escaping(NativeSourceTutorialFreePlayPlan.Pose)->Void) {
        guard service.sourceMicrotaskRAFBoundaryInstalled,(1...4).contains(plan.moves.count),current() else{return nil}
        self.service=service;self.plan=plan;self.fingertip=fingertip;self.current=current;self.paint=paint
    }
    @discardableResult func start()->Bool {
        guard !disposed,!started,current() else{return false};started=true
        let installed=service.registerTutorialFreePlayHint(participant:self,moves:plan.moves.count,cleanup:{[weak self] _ in self?.lease=nil})
        guard !disposed,current(),!disposed,let installed else{installed?.cancel(success:false);return false}
        lease=installed;return active
    }
    func advanceSourceAnimation(seconds:Double) {
        guard !disposed,current(),!disposed else{dispose();return}
        if let pose=plan.pose(seconds:seconds,fingertip:fingertip){paint(pose)}
    }
    func dispose(){guard !disposed else{return};disposed=true;let old=lease;lease=nil;old?.cancel(success:false)}
    isolated deinit{dispose()}
}
