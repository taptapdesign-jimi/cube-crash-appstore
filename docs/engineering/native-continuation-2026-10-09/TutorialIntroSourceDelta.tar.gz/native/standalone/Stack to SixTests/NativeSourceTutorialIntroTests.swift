import XCTest
import UIKit
@testable import Stack_to_Six

@MainActor final class NativeSourceTutorialIntroTests:XCTestCase {
    @MainActor private final class Fixture {
        var wall=0.0,current=true,sheet:[Double]=[],pointer:[NativeSourceTutorialIntroOwner.PointerPose]=[],reveals=0,focuses=0
        let fifo=NativeSourceMicrotaskFIFO(),timeouts=NativeSourceAppTimeoutOwner()
        var service:NativeSourceAnimationClockService!,owner:NativeSourceTutorialIntroOwner!
        init()throws {
            let tasks=NativeSourceMicrotaskAdapters(fifo:fifo);timeouts.sourceMicrotaskTasks=tasks
            service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{[weak self] in self?.wall ?? 0},sourceFrameTransportEnabled:true)
            service.sourceMicrotaskTasks=tasks
            owner=try XCTUnwrap(NativeSourceTutorialIntroOwner(service:service,timeouts:timeouts,generation:1,current:{[weak self] in self?.current==true},sheet:{[weak self] in self?.sheet.append($0)},pointer:{[weak self] in self?.pointer.append($0)},reveal:{[weak self] in self?.reveals+=1},focus:{[weak self] in self?.focuses+=1}))
        }
        func deliver(_ value:Double){wall=value;service.deliver(wallMilliseconds:value)}
        func dispose(){owner.dispose();timeouts.cancelAll();service.dispose();fifo.dispose()}
    }
    func testIndependentWall800SheetAndWall1200PointerWhileGSAPPaused()async throws {
        let f=try Fixture();defer{f.dispose()};_=f.service.setSourceGlobalPaused(true)
        XCTAssertTrue(f.owner.start());XCTAssertFalse(f.owner.start())
        XCTAssertEqual(f.timeouts.pendingReceipts.map(\.sourceID),["tutorial-pointer1200","tutorial-sheet800"])
        XCTAssertEqual(f.sheet,[1]);XCTAssertEqual(f.pointer,[.init(alpha:0,scale:0,rotation:-8)])
        try await Task.sleep(for:.milliseconds(900))
        XCTAssertTrue(f.owner.sheetStarted);XCTAssertFalse(f.owner.pointerStarted);XCTAssertEqual(f.owner.pendingTimerCount,1)
        try await Task.sleep(for:.milliseconds(400))
        XCTAssertTrue(f.owner.pointerStarted);XCTAssertEqual(f.reveals,1);XCTAssertEqual(f.sheet,[1]);XCTAssertEqual(f.owner.pendingTimerCount,0)
        // APP RAF focus is independent of paused GSAP.
        f.deliver(16);XCTAssertEqual(f.focuses,1);XCTAssertEqual(f.sheet,[1])
        _=f.service.setSourceGlobalPaused(false)
        for time in stride(from:32.0,through:800,by:16){f.deliver(time)}
        XCTAssertEqual(try XCTUnwrap(f.sheet.last),0,accuracy:1e-9)
        XCTAssertEqual(try XCTUnwrap(f.pointer.last).scale,1,accuracy:1e-9)
        XCTAssertEqual(try XCTUnwrap(f.pointer.last).rotation,0,accuracy:1e-9)
        XCTAssertEqual(f.service.activeParticipantCount,0)
    }
    func testDisposalCancelsBothTimersAndNeverReveals()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.owner.start());f.owner.dispose();f.owner.dispose()
        XCTAssertEqual(f.timeouts.pendingCount,0);try await Task.sleep(for:.milliseconds(1300));f.deliver(1400)
        XCTAssertEqual(f.reveals,0);XCTAssertEqual(f.focuses,0);XCTAssertEqual(f.sheet,[1]);XCTAssertEqual(f.service.activeParticipantCount,0)
    }
    func testReplacementDuringRevealCannotCreateLateImageRootOrFocusRAF()async throws {
        let f=try Fixture();defer{f.dispose()}
        f.owner.dispose()
        f.owner=try XCTUnwrap(NativeSourceTutorialIntroOwner(service:f.service,timeouts:f.timeouts,generation:2,current:{f.current},sheet:{f.sheet.append($0)},pointer:{f.pointer.append($0)},reveal:{f.current=false;f.owner.dispose()},focus:{f.focuses+=1}))
        XCTAssertTrue(f.owner.start());try await Task.sleep(for:.milliseconds(1300));f.deliver(1400)
        XCTAssertEqual(f.service.activeParticipantCount,0);XCTAssertEqual(f.focuses,0);XCTAssertEqual(f.timeouts.pendingCount,0)
    }
    func testHiddenBackgroundRetainsIntroUntilRealForegroundRAF()async throws {
        let f=try Fixture();defer{f.dispose()};f.service.setSourceForeground(false);XCTAssertTrue(f.owner.start())
        try await Task.sleep(for:.milliseconds(1300))
        XCTAssertTrue(f.owner.sheetStarted);XCTAssertTrue(f.owner.pointerStarted);XCTAssertEqual(f.focuses,0);XCTAssertEqual(f.sheet,[1])
        f.service.setSourceForeground(true)
        for time in stride(from:16.0,through:800,by:16){f.deliver(time)}
        XCTAssertEqual(f.focuses,1);XCTAssertEqual(try XCTUnwrap(f.sheet.last),0,accuracy:1e-9)
    }
    func testMountedOverlayKeepsOffscreenSheetOnResizeAndRetiresForStepReplacement()async throws {
        let f=try Fixture();defer{f.dispose()}
        let previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
        let window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844)),host=UIViewController()
        window.rootViewController=host;window.makeKeyAndVisible();defer{window.isHidden=true;previous?.makeKeyAndVisible()}
        let overlay=NativeTutorialOverlay(resourceRoot:NativeTestResources.root);host.view.addSubview(overlay);defer{overlay.dispose()}
        overlay.frame=CGRect(x:0,y:0,width:390,height:844)
        XCTAssertTrue(overlay.showSourceIntro(from:CGPoint(x:100,y:300),to:CGPoint(x:260,y:500),service:f.service,timeouts:f.timeouts,boardGeneration:1,current:{f.current}))
        XCTAssertEqual(overlay.sourceSheetTranslation,overlay.sourceSheetHeight);XCTAssertFalse(overlay.sourcePointerVisible)
        overlay.frame=CGRect(x:0,y:0,width:430,height:932);overlay.setNeedsLayout();overlay.layoutIfNeeded()
        XCTAssertEqual(overlay.sourceSheetTranslation,overlay.sourceSheetHeight)
        XCTAssertEqual(overlay.sourcePointerAlpha,0)
        let captured=overlay.sourceSheetTranslation
        overlay.show(step:2,from:CGPoint(x:80,y:200),to:CGPoint(x:280,y:400))
        XCTAssertEqual(try XCTUnwrap(overlay.sourceSheetExitStart),Double(captured),accuracy:1e-6)
        XCTAssertNil(overlay.sourceIntroOwner);XCTAssertEqual(f.timeouts.pendingCount,0)
        try await Task.sleep(for:.milliseconds(1300));XCTAssertEqual(f.service.activeParticipantCount,0)
    }
    func testLiteralPointerPopChannelBoundariesAndSheetOvershoot() {
        XCTAssertEqual(NativeSourceTutorialIntroOwner.pointerPose(0),.init(alpha:0,scale:0,rotation:-8))
        let a=NativeSourceTutorialIntroOwner.pointerPose(0.22),b=NativeSourceTutorialIntroOwner.pointerPose(0.33),c=NativeSourceTutorialIntroOwner.pointerPose(0.49)
        XCTAssertEqual(a.alpha,1,accuracy:1e-9);XCTAssertEqual(a.scale,1.14,accuracy:1e-9);XCTAssertEqual(a.rotation,2,accuracy:1e-9)
        XCTAssertEqual(b.scale,0.94,accuracy:1e-9);XCTAssertEqual(b.rotation,-2,accuracy:1e-9)
        XCTAssertEqual(c.scale,1,accuracy:1e-9);XCTAssertEqual(c.rotation,0,accuracy:1e-9)
        XCTAssertLessThan(NativeSourceTutorialIntroOwner.sheetProgress(0.3),0)
    }
    func testActualAPPHintRepeatsBeyondFiniteCyclePausesAndCancelsOnHide()throws {
        let f=try Fixture();defer{f.dispose()};var values:[Double]=[]
        XCTAssertTrue(f.owner.startGuidedHint{values.append($0)})
        for time in stride(from:16.0,through:5200,by:16){f.deliver(time)}
        XCTAssertGreaterThan(values.count,100);XCTAssertEqual(f.service.activeParticipantCount,1)
        let before=values.count;_=f.service.setSourceGlobalPaused(true)
        for time in stride(from:5216.0,through:6000,by:16){f.deliver(time)}
        XCTAssertEqual(values.count,before)
        _=f.service.setSourceGlobalPaused(false);f.deliver(6016);XCTAssertGreaterThan(values.count,before)
        f.owner.cancelPointer();XCTAssertEqual(f.service.activeParticipantCount,0)
        let stopped=values.count;f.deliver(6032);XCTAssertEqual(values.count,stopped)
    }
    func testCapturedCurrentRetirementReleasesHintOnNextActualFrame()throws {
        let f=try Fixture();defer{f.dispose()};var values:[Double]=[]
        XCTAssertTrue(f.owner.startGuidedHint{values.append($0)});f.deliver(16)
        let old=values.count;f.current=false;f.deliver(32)
        XCTAssertEqual(values.count,old);XCTAssertEqual(f.service.activeParticipantCount,0)
        XCTAssertFalse(f.owner.startGuidedHint{_ in XCTFail("retired hint")})
    }
    func testHintKeepsYoyoAndRepeatDelayBoundaries() {
        for (seconds,expected) in [(0.0,0.0),(0.59,0.5),(1.18,1.0),(1.24,1.0),(1.3,1.0),(1.89,0.5),(2.48,0.0),(2.54,0.0),(2.6,0.0),(5.2,0.0)] {
            XCTAssertEqual(NativeSourceTutorialIntroOwner.hintProgress(seconds),expected,accuracy:1e-9)
        }
    }

    func testOriginalGSAPRecipesMatchAll1039NumericChannels()throws {
        struct Pop:Decodable{let seconds:Double,alpha:Double,scale:Double,rotation:Double}
        struct Scalar:Decodable{let seconds:Double,progress:Double}
        struct Oracle:Decodable{let popSamples:[Pop],sheetSamples:[Scalar],hintSamples:[Scalar]}
        let url=try XCTUnwrap(Bundle(for:Self.self).url(forResource:"SourceTutorialIntroV9Oracle",withExtension:"json"))
        let oracle=try JSONDecoder().decode(Oracle.self,from:Data(contentsOf:url))
        for sample in oracle.popSamples {
            let pose=NativeSourceTutorialIntroOwner.pointerPose(sample.seconds)
            XCTAssertEqual(pose.alpha,sample.alpha,accuracy:1e-6);XCTAssertEqual(pose.scale,sample.scale,accuracy:1e-6);XCTAssertEqual(pose.rotation,sample.rotation,accuracy:1e-6)
        }
        for sample in oracle.sheetSamples{XCTAssertEqual(NativeSourceTutorialIntroOwner.sheetProgress(sample.seconds),sample.progress,accuracy:1e-6)}
        for sample in oracle.hintSamples{XCTAssertEqual(NativeSourceTutorialIntroOwner.hintProgress(sample.seconds),sample.progress,accuracy:1e-6)}
    }

    func testActualOverlayViewportRastersRetainSheetAndSourcePointer()async throws {
        let f=try Fixture();defer{f.dispose()};f.service.setSourceForeground(false)
        let overlay=NativeTutorialOverlay(resourceRoot:NativeTestResources.root);defer{overlay.dispose()}
        overlay.frame=CGRect(x:0,y:0,width:390,height:844)
        XCTAssertTrue(overlay.showSourceIntro(from:CGPoint(x:100,y:300),to:CGPoint(x:260,y:500),service:f.service,timeouts:f.timeouts,boardGeneration:1,current:{f.current}))
        try await Task.sleep(for:.milliseconds(1300));f.service.setSourceForeground(true)
        for time in stride(from:16.0,through:800,by:16){f.deliver(time)}
        for size in [CGSize(width:390,height:844),CGSize(width:430,height:932)] {
            overlay.frame=CGRect(origin:.zero,size:size);overlay.setNeedsLayout();overlay.layoutIfNeeded()
            XCTAssertEqual(overlay.sourceSheetTranslation,0,accuracy:1e-6)
            XCTAssertTrue(overlay.sourcePointerVisible);XCTAssertFalse(overlay.sourceHintUsesCoreAnimation)
            let image=UIGraphicsImageRenderer(size:size).image{context in
                UIColor(red:1,green:247/255,blue:239/255,alpha:1).setFill();context.fill(CGRect(origin:.zero,size:size))
                overlay.layer.render(in:context.cgContext)
            }
            let attachment=XCTAttachment(image:image);attachment.name="Source tutorial intro \(Int(size.width))x\(Int(size.height))";attachment.lifetime = .keepAlways;add(attachment)
        }
        overlay.dispose();XCTAssertEqual(f.service.activeParticipantCount,0);XCTAssertEqual(f.timeouts.pendingCount,0)
    }

}
