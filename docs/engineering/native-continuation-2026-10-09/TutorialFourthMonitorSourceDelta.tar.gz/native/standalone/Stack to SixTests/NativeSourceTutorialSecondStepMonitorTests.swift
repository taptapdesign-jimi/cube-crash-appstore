import XCTest
import SpriteKit
import StackToSixGameplay
@testable import Stack_to_Six

@MainActor final class NativeSourceTutorialSecondStepMonitorTests:XCTestCase {
    @MainActor private final class Fixture {
        var wall=0.0,current=true,activated=0,hasSix=false
        let fifo=NativeSourceMicrotaskFIFO(),timeouts=NativeSourceAppTimeoutOwner()
        var service:NativeSourceAnimationClockService!,construction:NativeSourceInitialBoardConstruction!,intro:NativeSourceTutorialIntroOwner!,monitor:NativeSourceTutorialSecondStepMonitor!
        var scene:NativeBoardScene!,driver:NativeSourceOuterTimelineAdapter!
        var targets:[NativeDiceNode]=[]
        init()throws {
            let tasks=NativeSourceMicrotaskAdapters(fifo:fifo);timeouts.sourceMicrotaskTasks=tasks
            service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{[weak self] in self?.wall ?? 0},sourceFrameTransportEnabled:true);service.sourceMicrotaskTasks=tasks
            construction=try XCTUnwrap(NativeSourceInitialBoardConstruction.make(root:NativeTestResources.root,service:service,mode:.arcade,board:1,tutorialDemo:true,random:{0.25}))
            let state=try XCTUnwrap(construction.recipe?.state)
            scene=NativeBoardScene(engine:NativeGameplayEngine(state:state),resourceRoot:NativeTestResources.root,size:.init(width:390,height:844),sourceInitialConstruction:construction)
            driver=NativeSourceOuterTimelineAdapter(service:service);scene.sourceOuterTimelineDriver=driver
            scene.layout(size:scene.size,insets:.init(top:47,left:0,bottom:34,right:0));deliver(16)
            let capturedState=state,cells=NativeTutorialRules.guidedCells(columns:capturedState.columns,rows:capturedState.rows)
            targets=try [cells.three,cells.two].map{try XCTUnwrap(construction.nodes[try XCTUnwrap(state.tile(at:$0)).id])}
            intro=try XCTUnwrap(NativeSourceTutorialIntroOwner(service:service,timeouts:timeouts,generation:state.generation,current:{[weak self] in self?.current==true},sheet:{_ in},pointer:{_ in},reveal:{},focus:{}))
            intro.restorePointer();for t in stride(from:32.0,through:600,by:16){deliver(t)}
            XCTAssertTrue(targets[0].forceSourceTutorialInitialValue(5));XCTAssertTrue(targets[1].forceSourceTutorialInitialValue(1))
            monitor=try XCTUnwrap(NativeSourceTutorialSecondStepMonitor(service:service,timeouts:timeouts,generation:state.generation,five:targets[0],one:targets[1],parent:construction.canvas,current:{[weak self] in self?.current==true},hasUnlockedSix:{[weak self] in self?.hasSix==true},nodeCurrent:{[weak self] node in self?.construction.nodes[node.tileID] === node},pointerExit:{[weak self] callback in self?.intro.popOutPointer(completed:callback)==true},sheetExit:{[weak self] callback in self?.intro.exitSheet(completed:callback)==true},activate:{[weak self] in self?.activated+=1;return true}))
        }
        func deliver(_ ms:Double){wall=ms;service.deliver(wallMilliseconds:ms)}
        func finishRoots(){for t in stride(from:608.0,through:1400,by:16){deliver(t)}}
        func dispose(){monitor.dispose();intro.dispose();timeouts.cancelAll();scene.dispose();construction.dispose();driver.dispose();service.dispose();fifo.dispose()}
    }
    func testUnlockedSixCompletesWithoutInteractionThroughActualExitsAndSeparateWall90()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.monitor.start());XCTAssertFalse(f.monitor.start())
        _=f.service.setSourceGlobalPaused(true);f.hasSix=true
        try await Task.sleep(for:.milliseconds(70));XCTAssertEqual(f.monitor.phase,.pointerExit);XCTAssertEqual(f.activated,0)
        f.finishRoots();XCTAssertEqual(f.monitor.phase,.pointerExit)
        _=f.service.setSourceGlobalPaused(false)
        for t in stride(from:1408.0,through:2200,by:16){f.deliver(t)}
        XCTAssertEqual(f.monitor.phase,.activationWait);XCTAssertEqual(f.activated,0)
        f.service.setSourceForeground(false);try await Task.sleep(for:.milliseconds(130))
        XCTAssertEqual(f.monitor.phase,.finished);XCTAssertEqual(f.activated,1)
    }
    func testChangedPairRequiresCapturedInteractionAndIntactPairNeverCompletes()async throws {
        let f=try Fixture();defer{f.dispose()};XCTAssertTrue(f.monitor.start())
        f.monitor.pointerDown(f.targets[0]);try await Task.sleep(for:.milliseconds(70));XCTAssertEqual(f.monitor.phase,.polling)
        XCTAssertTrue(f.targets[0].forceSourceTutorialInitialValue(4))
        try await Task.sleep(for:.milliseconds(70));XCTAssertEqual(f.monitor.phase,.pointerExit)
    }
    func testUnrelatedInteractionCannotCompleteChangedPairAndRetirementKeepsOtherTimer()async throws {
        let f=try Fixture();defer{f.dispose()};var unrelated=0
        _=f.timeouts.schedule(sourceID:"another-owner",generation:1,delayMilliseconds:180,elapsed:{unrelated+=1})
        XCTAssertTrue(f.monitor.start())
        let other=try XCTUnwrap(f.construction.nodes.values.first{node in !f.targets.contains(where:{$0 === node})})
        f.monitor.pointerDown(other);XCTAssertTrue(f.targets[0].forceSourceTutorialInitialValue(4))
        try await Task.sleep(for:.milliseconds(70));XCTAssertEqual(f.monitor.phase,.polling)
        f.current=false;f.monitor.dispose();f.finishRoots();try await Task.sleep(for:.milliseconds(160))
        XCTAssertEqual(f.monitor.phase,.retired);XCTAssertEqual(f.activated,0);XCTAssertEqual(unrelated,1)
    }
    func testFourthActualWall120Then900RequiresSheetCompletionAndDrop80()async throws {
        let f=try Fixture();defer{f.dispose()}
        var candidate:NativeDiceNode?,dropping=true,activated=0,prepared=0,sheet:(()->Void)?
        let node=f.targets[0]
        let monitor=try XCTUnwrap(NativeSourceTutorialFourthStepMonitor(service:f.service,timeouts:f.timeouts,generation:1,
            current:{f.current},findWild:{candidate},nodeCurrent:{$0 === node && $0.sourceContactNodeAlive},dropping:{_ in dropping},
            activate:{captured in XCTAssertTrue(captured === node);activated+=1;return true},
            transitionSheet:{sheet=$0;return true},prepare:{captured in XCTAssertTrue(captured === node);prepared+=1;return true}))
        defer{monitor.dispose()};XCTAssertTrue(monitor.start());XCTAssertFalse(monitor.start())
        try await Task.sleep(for:.milliseconds(150));XCTAssertEqual(monitor.phase,.polling);XCTAssertEqual(activated,0)
        candidate=node;f.service.setSourceGlobalPaused(true)
        try await Task.sleep(for:.milliseconds(150));XCTAssertEqual(monitor.phase,.sheetDelay);XCTAssertEqual(activated,1)
        XCTAssertEqual(prepared,0);XCTAssertNil(sheet)
        try await Task.sleep(for:.milliseconds(980));XCTAssertEqual(monitor.phase,.sheetTransition);XCTAssertEqual(prepared,0)
        let entered=try XCTUnwrap(sheet);entered();XCTAssertEqual(monitor.phase,.waitingForDrop)
        try await Task.sleep(for:.milliseconds(110));XCTAssertEqual(prepared,0)
        dropping=false;try await Task.sleep(for:.milliseconds(110))
        XCTAssertEqual(monitor.phase,.prepared);XCTAssertEqual(prepared,1)
        entered();try await Task.sleep(for:.milliseconds(100));XCTAssertEqual(prepared,1)
    }
    func testFourthSourceFiveSecondEscapeUsesCapturedWildAndCannotPrepareRetiredOwner()async throws {
        let f=try Fixture();defer{f.dispose()};let node=f.targets[0]
        var now=0.0,prepared=0,sheet:(()->Void)?
        let monitor=try XCTUnwrap(NativeSourceTutorialFourthStepMonitor(service:f.service,timeouts:f.timeouts,generation:1,
            current:{f.current},findWild:{node},nodeCurrent:{$0 === node},dropping:{_ in true},activate:{_ in true},
            transitionSheet:{sheet=$0;return true},prepare:{_ in prepared+=1;return true},wallNow:{now}))
        defer{monitor.dispose()};XCTAssertTrue(monitor.start())
        try await Task.sleep(for:.milliseconds(1120));let entered=try XCTUnwrap(sheet);entered()
        now=4999;try await Task.sleep(for:.milliseconds(100));XCTAssertEqual(prepared,0)
        now=5000;try await Task.sleep(for:.milliseconds(100));XCTAssertEqual(prepared,1);XCTAssertEqual(monitor.phase,.prepared)
        monitor.dispose();entered();XCTAssertEqual(prepared,1)
    }
    func testFourthRetirementDuringActivationCancelsOnlyOwnPendingWork()async throws {
        let f=try Fixture();defer{f.dispose()};var activated=0,sheet=0,other=0
        var monitor:NativeSourceTutorialFourthStepMonitor!
        monitor=try XCTUnwrap(NativeSourceTutorialFourthStepMonitor(service:f.service,timeouts:f.timeouts,generation:1,
            current:{f.current},findWild:{f.targets[0]},nodeCurrent:{_ in true},dropping:{_ in true},
            activate:{_ in activated+=1;monitor.dispose();return true},transitionSheet:{_ in sheet+=1;return true},prepare:{_ in XCTFail("retired prepare");return false}))
        defer{monitor.dispose()};_=f.timeouts.schedule(sourceID:"another-fourth-owner",generation:1,delayMilliseconds:180,elapsed:{other+=1})
        XCTAssertTrue(monitor.start());try await Task.sleep(for:.milliseconds(240))
        XCTAssertEqual(monitor.phase,.retired);XCTAssertEqual(activated,1);XCTAssertEqual(sheet,0);XCTAssertEqual(other,1)
        XCTAssertFalse(f.timeouts.pendingReceipts.contains{$0.sourceID=="tutorial-fourth-sheet900"})
    }

}
