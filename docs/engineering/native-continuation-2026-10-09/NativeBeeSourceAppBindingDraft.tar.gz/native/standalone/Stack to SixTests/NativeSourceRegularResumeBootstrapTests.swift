import XCTest
import UIKit
import StackToSixGameplay
import StackToSixNativeState
@testable import Stack_to_Six
@MainActor final class NativeSourceRegularResumeBootstrapTests:XCTestCase {
 private func run()->NativeBoardState {.init(tiles:[.init(id:"saved-five",cell:.init(column:4,row:8),value:5,stackDepth:4),.init(id:"saved-zero",cell:.init(column:0,row:0),value:0,locked:true,alpha:0.7),.init(id:"saved-two",cell:.init(column:2,row:3),value:2,stackDepth:3)],mode:.arcade,board:1,stage:1,generation:9,revision:4,moves:23,score:123,wildMeter:0.4,rngState:777)}
 func testGenuineSavedArcadeRouteUsesCapturedResumeFactoryAndRetainsRunAccounting()async throws {
  let directory=FileManager.default.temporaryDirectory.appendingPathComponent("source-resume-bootstrap-\(UUID().uuidString)")
  defer{try? FileManager.default.removeItem(at:directory)}
  let store=NativeSaveStore(directory:directory)
  var envelope=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false));envelope.progression.firstPlayTutorialComplete=true;envelope.arcadeRun=run();try store.save(envelope)
  let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
  var draws=0
  let context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{draws+=1;return Double((draws*37)%97)/97})
  let bootstrap=try NativeBootstrap(root:NativeTestResources.root,store:store,sourceContext:context);bootstrap.sourceInitialRegularResumeEnabled=true
  let host=UIViewController(),window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844))
  let previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
  window.rootViewController=host;window.makeKeyAndVisible();bootstrap.start(in:host)
  defer{bootstrap.dispose();context.dispose();service.dispose();window.isHidden=true;previous?.makeKeyAndVisible()}
  let app=try XCTUnwrap(host.children.first as? NativeAppController);app.navigate(.gameplay,interrupt:true)
  try await waitUntil{app.children.contains{$0 is NativeGameplayViewController}}
  let game=try XCTUnwrap(app.children.first as? NativeGameplayViewController),scene=try XCTUnwrap(game.boardScene),construction=try XCTUnwrap(game.sourceInitialConstruction)
  XCTAssertTrue(scene.sourceInitialStartupReady);XCTAssertTrue(game.sourceScope?.service === service)
  XCTAssertFalse(game.sourceSmallStackPresentationEnabled);XCTAssertEqual(construction.nodes.count,3)
  XCTAssertEqual(game.engine.state.tiles.map(\.id),["saved-zero","saved-two","saved-five"])
  XCTAssertEqual(game.engine.state.generation,10);XCTAssertEqual(game.engine.state.revision,5)
  XCTAssertEqual(game.engine.state.score,123);XCTAssertEqual(game.engine.state.moves,23);XCTAssertEqual(game.engine.state.wildMeter,0.4)
  XCTAssertEqual(game.engine.state.rngState,777);XCTAssertTrue(game.engine.state.tiles.allSatisfy{$0.stackDepth==1})
  for holder in construction.recipe?.holders ?? [] {XCTAssertTrue(scene.sourceNativeTileNode(holder.tileID) === construction.nodes[holder.tileID])}
  service.deliver(wallMilliseconds:16)
  XCTAssertEqual(construction.pendingFaceCount,0);XCTAssertEqual(draws,5)
  let durable=try XCTUnwrap(store.load()?.arcadeRun);XCTAssertEqual(durable.tiles,game.engine.state.tiles)
  XCTAssertEqual(durable.score,123);XCTAssertEqual(durable.moves,23)
 }
 func testDefaultResumeStillRetainsExistingRawPhysicalDepthAndDoesNotConstructSourceObjects()async throws {
  let directory=FileManager.default.temporaryDirectory.appendingPathComponent("source-resume-default-\(UUID().uuidString)")
  defer{try? FileManager.default.removeItem(at:directory)}
  let store=NativeSaveStore(directory:directory);var envelope=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false));envelope.progression.firstPlayTutorialComplete=true;envelope.arcadeRun=run();try store.save(envelope)
  let bootstrap=try NativeBootstrap(root:NativeTestResources.root,store:store)
  let host=UIViewController(),window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844)),previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
  window.rootViewController=host;window.makeKeyAndVisible();bootstrap.start(in:host)
  defer{bootstrap.dispose();window.isHidden=true;previous?.makeKeyAndVisible()}
  let app=try XCTUnwrap(host.children.first as? NativeAppController);app.navigate(.gameplay,interrupt:true)
  try await waitUntil{app.children.contains{$0 is NativeGameplayViewController}}
  let game=try XCTUnwrap(app.children.first as? NativeGameplayViewController)
  XCTAssertNil(game.sourceInitialConstruction);XCTAssertFalse(game.sourceSmallStackPresentationEnabled)
  XCTAssertEqual(game.engine.state.tiles.first{$0.id=="saved-five"}?.stackDepth,4)
  XCTAssertEqual(game.engine.state.tiles.first{$0.id=="saved-zero"}?.alpha,0.7)
 }
 func testActualSavedBeeAppRouteBindsTypedIdleAndForegroundKeepsSingleRegistration()async throws {
  let directory=FileManager.default.temporaryDirectory.appendingPathComponent("source-bee-app-\(UUID().uuidString)")
  defer{try? FileManager.default.removeItem(at:directory)}
  let store=NativeSaveStore(directory:directory)
  var envelope=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false))
  envelope.progression.firstPlayTutorialComplete=true
  envelope.arcadeRun = .init(tiles:[.init(id:"saved-bee",cell:.init(column:0,row:0),value:6,archetype:.star,variant:"bee"),.init(id:"other",cell:.init(column:4,row:8),value:2)],mode:.arcade,board:1,stage:1,generation:9,score:123,wildMeter:0.4)
  try store.save(envelope)
  let fifo=NativeSourceMicrotaskFIFO(),tasks=NativeSourceMicrotaskAdapters(fifo:fifo)
  let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
  service.sourceMicrotaskTasks=tasks
  let context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{0.5},sourceMicrotaskTasks:tasks)
  let bootstrap=try NativeBootstrap(root:NativeTestResources.root,store:store,sourceContext:context)
  bootstrap.sourceSpecialIdlePresentationEnabled=true
  let host=UIViewController(),window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844))
  let previous=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
  window.rootViewController=host;window.makeKeyAndVisible();bootstrap.start(in:host)
  defer{bootstrap.dispose();context.dispose();service.dispose();fifo.dispose();window.isHidden=true;previous?.makeKeyAndVisible()}
  let app=try XCTUnwrap(host.children.first as? NativeAppController);app.navigate(.gameplay,interrupt:true)
  try await waitUntil{app.children.contains{$0 is NativeGameplayViewController}}
  let game=try XCTUnwrap(app.children.first as? NativeGameplayViewController),scene=try XCTUnwrap(game.boardScene)
  try await waitUntil{scene.sourceNativeTileNode("saved-bee")?.sourceWildSkinReceiptCurrent==true && scene.sourceNativeTileNode("saved-bee")?.hasAnimatedArtwork==true}
  let node=try XCTUnwrap(scene.sourceNativeTileNode("saved-bee")),scope=try XCTUnwrap(game.sourceScope)
  XCTAssertTrue(scene.sourceSpecialIdleAdmissionOpen);XCTAssertEqual(scope.specialIdle.snapshot.registered,1)
  XCTAssertNil(game.sourceInitialConstruction) // Wild original constructor still open.
  XCTAssertEqual(game.engine.state.score,123);XCTAssertEqual(game.engine.state.wildMeter,0.4)
  NotificationCenter.default.post(name:UIApplication.willResignActiveNotification,object:nil)
  XCTAssertTrue(scene.sourceNativeTileNode("saved-bee") === node)
  NotificationCenter.default.post(name:UIApplication.didBecomeActiveNotification,object:nil)
  XCTAssertTrue(scene.sourceNativeTileNode("saved-bee") === node)
  XCTAssertTrue(node.sourceWildSkinReceiptCurrent);XCTAssertEqual(scope.specialIdle.snapshot.registered,1)
  XCTAssertEqual(scope.specialIdle.snapshot.running,1)
 }
 private func waitUntil(_ predicate:()->Bool)async throws {
  let deadline=Date().addingTimeInterval(8)
  while !predicate() {if Date()>deadline{throw NSError(domain:"SourceResumeTimeout",code:1)};try await Task.sleep(nanoseconds:20_000_000)}
 }
}
