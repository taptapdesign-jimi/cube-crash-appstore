import Foundation
import SpriteKit

/// Original independent wall40 monitor. An actual unlocked six may complete
/// the step even without another pointerdown; otherwise the captured pair must
/// have been interacted with and must no longer be a surviving Five/One pair.
@MainActor final class NativeSourceTutorialSecondStepMonitor {
    enum Phase:Equatable {case idle,polling,pointerExit,sheetExit,activationWait,finished,retired}
    private let timeouts:NativeSourceAppTimeoutOwner,generation:UInt64,five:NativeDiceNode,one:NativeDiceNode,parent:SKNode
    private let current:()->Bool,hasUnlockedSix:()->Bool,nodeCurrent:(NativeDiceNode)->Bool
    private let pointerExit:(@escaping()->Void)->Bool,sheetExit:(@escaping()->Void)->Bool,activate:()->Bool
    private var timer:NativeSourceAppTimeoutOwner.Receipt?,deadline:UInt64=0,interacted=false
    private(set) var phase=Phase.idle
    var pendingTimer:Bool{timer != nil}
    init?(service:NativeSourceAnimationClockService,timeouts:NativeSourceAppTimeoutOwner,generation:UInt64,five:NativeDiceNode,one:NativeDiceNode,parent:SKNode,
        current:@escaping()->Bool,hasUnlockedSix:@escaping()->Bool,nodeCurrent:@escaping(NativeDiceNode)->Bool,
        pointerExit:@escaping(@escaping()->Void)->Bool,sheetExit:@escaping(@escaping()->Void)->Bool,activate:@escaping()->Bool) {
        guard generation>0,five !== one,service.sourceMicrotaskRAFBoundaryInstalled,
            let tasks=service.sourceMicrotaskTasks,timeouts.sourceMicrotaskTasks === tasks,
            five.parent === parent,one.parent === parent,five.sourceContactNodeAlive,one.sourceContactNodeAlive,
            five.sourceGeneration==generation,one.sourceGeneration==generation,current() else{return nil}
        self.timeouts=timeouts;self.generation=generation;self.five=five;self.one=one;self.parent=parent
        self.current=current;self.hasUnlockedSix=hasUnlockedSix;self.nodeCurrent=nodeCurrent;self.pointerExit=pointerExit;self.sheetExit=sheetExit;self.activate=activate
    }
    private func admitted()->Bool{guard phase != .retired,phase != .finished else{return false};let valid=current();return valid && phase != .retired && phase != .finished}
    @discardableResult func start()->Bool {
        guard phase == .idle,admitted() else{return false};phase = .polling
        deadline=DispatchTime.now().uptimeNanoseconds+40_000_000;schedulePoll();return admitted() && timer != nil
    }
    private func bound(_ node:NativeDiceNode)->Bool{node.parent === parent && node.sourceContactNodeAlive && node.sourceGeneration==generation && nodeCurrent(node)}
    func pointerDown(_ node:NativeDiceNode){guard phase == .polling,admitted(),(node === five || node === one),bound(node) else{return};interacted=true}
    private func schedulePoll(){
        guard phase == .polling,admitted(),timer==nil else{return}
        timer=timeouts.schedule(sourceID:"tutorial-second-monitor40",generation:generation,delayMilliseconds:0,from:DispatchTime(uptimeNanoseconds:deadline),elapsed:{[weak self] in
            guard let self else{return};self.timer=nil
            guard self.admitted(),self.phase == .polling else{self.dispose();return}
            let now=DispatchTime.now().uptimeNanoseconds;self.deadline += 40_000_000
            if self.deadline<=now{self.deadline += ((now-self.deadline)/40_000_000+1)*40_000_000}
            let hasSix=self.hasUnlockedSix();guard self.admitted() else{self.dispose();return}
            let pairIntact=self.bound(self.five) && self.five.sourceValue==5 && self.bound(self.one) && self.one.sourceValue==1
            guard hasSix || (self.interacted && !pairIntact) else{self.schedulePoll();return}
            self.phase = .pointerExit
            guard self.pointerExit({[weak self] in
                guard let self else{return};guard self.admitted() else{self.dispose();return};guard self.phase == .pointerExit else{return}
                self.phase = .sheetExit
                guard self.sheetExit({[weak self] in
                    guard let self else{return};guard self.admitted() else{self.dispose();return};guard self.phase == .sheetExit else{return}
                    self.phase = .activationWait
                    self.timer=self.timeouts.schedule(sourceID:"tutorial-second-activate90",generation:self.generation,delayMilliseconds:90,elapsed:{[weak self] in
                        guard let self else{return};self.timer=nil
                        guard self.admitted(),self.phase == .activationWait else{self.dispose();return}
                        if self.activate(),self.phase != .retired{self.phase = .finished}else{self.dispose()}
                    })
                    if self.timer==nil{self.dispose()}
                }) else{self.dispose();return}
            }) else{self.dispose();return}
        })
    }
    func dispose(){guard phase != .retired else{return};phase = .retired;let old=timer;timer=nil;if let old{_=timeouts.cancel(old)}}
    isolated deinit{dispose()}
}
