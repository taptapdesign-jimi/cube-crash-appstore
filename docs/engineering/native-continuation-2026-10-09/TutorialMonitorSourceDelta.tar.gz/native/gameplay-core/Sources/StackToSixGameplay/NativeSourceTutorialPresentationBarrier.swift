import Foundation

/// Transient presentation boundary after a committed first merge. Canonical
/// save already describes step two, so relaunch never persists a wall timer or
/// an input lock. Only the captured UI completion may release this live run.
public struct NativeSourceTutorialPresentationBarrier:Equatable,Sendable {
    public let id:String,generation:UInt64,mergedID:String,oneID:String
    init(id:String,generation:UInt64,mergedID:String,oneID:String){self.id=id;self.generation=generation;self.mergedID=mergedID;self.oneID=oneID}
}
