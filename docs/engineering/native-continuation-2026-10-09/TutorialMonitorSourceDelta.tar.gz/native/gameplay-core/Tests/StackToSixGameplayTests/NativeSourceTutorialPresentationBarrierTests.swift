import XCTest
@testable import StackToSixGameplay
final class NativeSourceTutorialPresentationBarrierTests:XCTestCase {
    func make()throws->NativeGameplayEngine {
        let engine=NativeGameplayEngine(state:NativeTutorialTests().board(),recordedRandomChoices:Array(repeating:0,count:200))
        XCTAssertTrue(engine.startTutorial().accepted);engine.sourceTutorialPresentationBarrierEnabled=true
        let pair=try XCTUnwrap(engine.state.tutorial?.guidedPair)
        XCTAssertTrue(engine.beginDrag(tileID:pair[0]));XCTAssertTrue(engine.drop(target:try XCTUnwrap(engine.state.tiles.first{$0.id==pair[1]}).cell).accepted)
        return engine
    }
    func testCanonicalSaveContainsNoLiveBarrierAndNextGestureWaitsForCapturedCompletion()throws {
        let engine=try make(),receipt=try XCTUnwrap(engine.pendingSourceTutorialPresentationBarrier)
        XCTAssertEqual(engine.state.tutorial?.step,.mergeSix);XCTAssertFalse(engine.beginDrag(tileID:receipt.oneID))
        let snapshot=engine.state,decoded=try JSONDecoder().decode(NativeBoardState.self,from:JSONEncoder().encode(snapshot))
        let relaunched=NativeGameplayEngine(state:decoded);XCTAssertTrue(relaunched.beginDrag(tileID:receipt.oneID))
        XCTAssertTrue(engine.completeSourceTutorialPresentationBarrier(receipt));XCTAssertEqual(engine.state,snapshot)
        XCTAssertFalse(engine.completeSourceTutorialPresentationBarrier(receipt));XCTAssertTrue(engine.beginDrag(tileID:receipt.oneID))
    }
    func testStaleReceiptCannotUnlockAnotherOwnerOrRestartedBoard()throws {
        let engine=try make(),receipt=try XCTUnwrap(engine.pendingSourceTutorialPresentationBarrier)
        engine.setInputLock("another-owner",active:true);XCTAssertTrue(engine.completeSourceTutorialPresentationBarrier(receipt))
        XCTAssertFalse(engine.beginDrag(tileID:receipt.oneID));engine.setInputLock("another-owner",active:false)
        XCTAssertTrue(engine.beginDrag(tileID:receipt.oneID));engine.cancelDrag();engine.restart(state:engine.state)
        XCTAssertNil(engine.pendingSourceTutorialPresentationBarrier);XCTAssertFalse(engine.completeSourceTutorialPresentationBarrier(receipt))
    }
    func testRetirementIsExactAndDoesNotRewriteSavedStep()throws {
        let engine=try make(),receipt=try XCTUnwrap(engine.pendingSourceTutorialPresentationBarrier),saved=engine.state
        XCTAssertTrue(engine.retireSourceTutorialPresentationBarrier(receipt));XCTAssertFalse(engine.retireSourceTutorialPresentationBarrier(receipt));XCTAssertEqual(engine.state,saved)
    }
}
