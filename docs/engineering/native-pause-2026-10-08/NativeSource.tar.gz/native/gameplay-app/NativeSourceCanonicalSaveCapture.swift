import Foundation
import StackToSixGameplay

/// Source-only snapshot capability. Every field must come from its genuine
/// owner; absent lifecycle/spawn flags are reported, never defaulted false.
/// Core's conservative coherence refusal is additional Native protection,
/// separate from literal Source's transient flags.
struct NativeSourceCanonicalSaveCapture {
    let guardFields:NativeSourceCanonicalSaveGuard
    /// Construct lazy hooks only; do not query Date registries during capture.
    let transient:NativeSourceCanonicalSaveTransient.Hooks
    let missingOwners:[String]
    /// Actual same-object physical model observations. A divergent Core/physical
    /// board cannot be serialized via this Native schema until its receipt lands.
    let physicalState:NativeBoardState
}
