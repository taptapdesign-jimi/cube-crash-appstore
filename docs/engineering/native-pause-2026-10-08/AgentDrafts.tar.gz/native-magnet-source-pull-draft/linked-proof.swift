import Foundation
struct Oracle:Decodable {let cases:[Row]}
struct Point:Decodable {let x:Double,y:Double}
struct Tile:Decodable {let x:Double,y:Double,rotation:Double,sx:Double,sy:Double,arrived:Bool}
struct Initial:Decodable {let x:Double,y:Double;let rotG:Rot,scale:Point;struct Rot:Decodable{let rotation:Double}}
struct Frame:Decodable {let t:Double,tiles:[Tile]}
struct Row:Decodable {let count:Int,seed:Int,zero:Bool,initial:[Initial],random:[Double],draws:Int,delays:[Double],durations:[Double],samples:[Frame]}
@MainActor final class OracleParticipant:NativeSourceAnimationParticipant {
  let paint:(Double)->Void
  init(_ paint:@escaping(Double)->Void){self.paint=paint}
  func advanceSourceAnimation(seconds:Double){paint(seconds)}
}
@main struct Proof {
 @MainActor static func main()throws {
  let oracle=try JSONDecoder().decode(Oracle.self,from:Data(contentsOf:URL(fileURLWithPath:"/tmp/native-magnet-source-pull-draft/SourceMagnetPullV9.json")))
  var comparisons=0
  for row in oracle.cases {
   var draw=0;let motions=row.initial.enumerated().map{i,t in NativeSourceMagnetPullMotion(start:.init(x:t.x,y:t.y),destination:.init(x:148,y:64),rotation:t.rotG.rotation,scaleX:t.scale.x,scaleY:t.scale.y,index:i,count:row.count,random:{defer{draw+=1};return row.random[draw]})!}
   precondition(draw==row.draws)
   let runtime=NativeSourceAnimationRuntime(wallOriginMilliseconds:0)
   var arrivals=Array(repeating:false,count:row.count)
   var painted=row.initial.map{NativeSourceMagnetPullMotion.Pose(point:.init(x:$0.x,y:$0.y),rotation:$0.rotG.rotation,scaleX:$0.scale.x,scaleY:$0.scale.y,converged:false)}
   let participants=motions.enumerated().map{i,motion in OracleParticipant{seconds in
    let pose=motion.sample(seconds:seconds);painted[i]=pose;if pose.converged{arrivals[i]=true}
   }}
   for (i,motion) in motions.enumerated(){
    precondition(abs(motion.delay-row.delays[i])<1e-12);precondition(abs(motion.duration-row.durations[i])<1e-12)
    precondition(runtime.attach(participant:participants[i],family:.timeline,duration:motion.duration,delay:motion.delay,cleanup:{_ in}) != nil)
   }
   for frame in row.samples {
    // Numeric exporter root times all align integer ms; same source ticker
    // arithmetic is delivered to the actual admitted linked root traversal.
    runtime.deliverSourceTicker(seconds:frame.t,wallMilliseconds:frame.t*1000)
    for i in motions.indices {
     let pose=painted[i],tile=frame.tiles[i]
     for (label,a,b) in [("x",pose.point.x,tile.x),("y",pose.point.y,tile.y),("rotation",pose.rotation,tile.rotation),("sx",pose.scaleX,tile.sx),("sy",pose.scaleY,tile.sy)] {
      guard abs(a-b)<1e-6 else{fatalError("linked count\(row.count) zero\(row.zero) tile\(i) t\(frame.t) \(label) \(a) !=\(b)")};comparisons+=1
     }
     precondition(arrivals[i]==tile.arrived);comparisons+=1
    }
   }
   runtime.dispose()
  }
  print("PASS \(oracle.cases.count) literal GSAP root cases / \(comparisons) pose/arrival fields")
 }
}
