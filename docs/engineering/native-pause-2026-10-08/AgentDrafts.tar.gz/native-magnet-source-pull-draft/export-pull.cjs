const fs=require('fs'),vm=require('vm'),ts=require('/Users/user/cube-crash/node_modules/typescript');
// Pin actual GSAP creation wall so its synchronous wake cannot advance a
// sibling root birth between constructor calls. Numeric root-time sampling
// below is explicit and is not a claim about browser/Date transport.
const originalNow=Date.now;Date.now=()=>10000;
const {gsap}=require('/Users/user/cube-crash/node_modules/gsap/dist/gsap.js');gsap.ticker.sleep();
const root='/tmp/native-magnet-source-pull-draft',source=fs.readFileSync(root+'/OriginalAppCore.ts','utf8');
const first=source.indexOf('        nearestTiles.forEach((tile: any, index: number) => {');
const end=source.indexOf('        // Store callback to trigger merge',first);
if(first<0||end<0)throw Error('literal pull loop missing');
const code=ts.transpile(source.slice(first,end),{target:ts.ScriptTarget.ES2020});
const cases=[];
for(const count of [1,2,3,4])for(const seed of [3,19])for(const zero of [false,true]){
 gsap.globalTimeline.clear();gsap.globalTimeline.time(0,false);gsap.ticker.sleep();
 const tiles=Array.from({length:count},(_,i)=>({x:zero&&i===0?148:64+i*148,y:zero&&i===0?64:64+(i%2)*148,rotG:{rotation:.025*(i-1)},scale:{x:1+i*.03,y:.96-i*.02}}));
 const initial=JSON.parse(JSON.stringify(tiles));let draws=0;const random=[];const math=Object.create(Math);math.random=()=>{const r=((draws++*17+seed)%97)/97;random.push(r);return r};
 const trace=[];let seconds=0;
 const ctx={nearestTiles:tiles,Math:math,mergeX:148,mergeY:64,TILE:128,totalTiles:count,animationManager:{trackExternalTimeline:x=>x},gsap,activeTimelines:[],mergeStarted:false,arrivedCount:0,allTilesArrived:false,multiplierShown:false,magnetVariantAtMergeEntry:null,devLog(){},devWarn(){},devError(){},cleanupPulledTile(){trace.push({at:seconds,type:'cleanup'})},playMagnetPullForceSounds:()=>{trace.push({at:seconds,type:'sound'});return true},playHoneyPullMergeSounds(){throw Error('unexpected honey')},playBottlePullMergeSounds(){throw Error('unexpected bottle')},tryMergePulledTiles:async()=>{ctx.mergeStarted=true;trace.push({at:seconds,type:'body'})}};
 vm.createContext(ctx);vm.runInContext(code,ctx);gsap.ticker.sleep();
 const samples=[];
 const times=[0,.001,.049,.05,.064,.065,.07,.134,.135,.414,.415,.484,.485,.6,.7,.8,.9];
 const timeline=ctx.activeTimelines;
 for(let ms=0;ms<=850;ms+=7)times.push(ms/1000);
 for(const t of [...new Set(times)].sort((a,b)=>a-b)){
  seconds=t;gsap.globalTimeline.time(t,false);samples.push({t,tiles:tiles.map(x=>({x:x.x,y:x.y,rotation:x.rotG.rotation,sx:x.scale.x,sy:x.scale.y,arrived:x._mergeTriggered75===true}))});
 }
 cases.push({count,seed,zero,initial,random,draws,delays:timeline.map(x=>x.delay()),durations:timeline.map(x=>x.duration()),samples,trace});
 timeline.forEach(x=>x.kill());gsap.globalTimeline.clear();gsap.ticker.sleep();
}
fs.writeFileSync(root+'/SourceMagnetPullV9.json',JSON.stringify({reference:'immutable v9 actual nearestTiles pull loop with real installed GSAP timeline children/global root traversal; numeric root clock pose/callback proof only, actual Date/CADI transport tested separately',cases},null,2));
Date.now=originalNow;
console.log('PASS '+cases.length+' original GSAP pull root cases; '+cases.reduce((n,c)=>n+c.samples.length*c.count*6,0)+' pose/arrival fields');
