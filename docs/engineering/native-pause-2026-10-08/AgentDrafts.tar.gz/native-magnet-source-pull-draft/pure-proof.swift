import Foundation
struct Oracle:Decodable {let cases:[Row]}
struct Point:Decodable {let x:Double,y:Double}
struct Tile:Decodable {let x:Double,y:Double,rotation:Double,sx:Double,sy:Double,arrived:Bool}
struct Initial:Decodable {let x:Double,y:Double;let rotG:Rot,scale:Point;struct Rot:Decodable{let rotation:Double}}
struct Frame:Decodable {let t:Double,tiles:[Tile]}
struct Row:Decodable {let count:Int,seed:Int,zero:Bool,initial:[Initial],random:[Double],draws:Int,delays:[Double],durations:[Double],samples:[Frame]}
@main struct Proof {
 static func main()throws {
  let oracle=try JSONDecoder().decode(Oracle.self,from:Data(contentsOf:URL(fileURLWithPath:"/tmp/native-magnet-source-pull-draft/SourceMagnetPullV9.json")))
  var comparisons=0
  for row in oracle.cases {
   var draw=0;let motions=row.initial.enumerated().map{i,t in NativeSourceMagnetPullMotion(start:.init(x:t.x,y:t.y),destination:.init(x:148,y:64),rotation:t.rotG.rotation,scaleX:t.scale.x,scaleY:t.scale.y,index:i,count:row.count,random:{defer{draw+=1};return row.random[draw]})!}
   precondition(draw==row.draws);var arrived=Array(repeating:false,count:row.count)
   for (i,motion) in motions.enumerated(){precondition(abs(motion.delay-row.delays[i])<1e-12);precondition(abs(motion.duration-row.durations[i])<1e-12)}
   for frame in row.samples {for (i,motion) in motions.enumerated(){
    let local=(frame.t-motion.delay)*10_000_000
    let seconds=floor(local+0.5)/10_000_000
    let pose=motion.sample(seconds:seconds),tile=frame.tiles[i]
    if seconds>0 && pose.converged {arrived[i]=true}
    for (label,a,b) in [("x",pose.point.x,tile.x),("y",pose.point.y,tile.y),("rotation",pose.rotation,tile.rotation),("sx",pose.scaleX,tile.sx),("sy",pose.scaleY,tile.sy)] {
     guard abs(a-b)<1e-6 else{fatalError("count\(row.count) zero\(row.zero) tile\(i) t\(frame.t) \(label) \(a) !=\(b)")};comparisons+=1
    }
    precondition(arrived[i]==tile.arrived);comparisons+=1
   }}
  }
  print("PASS \(oracle.cases.count) literal GSAP root cases / \(comparisons) pose/arrival fields")
 }
}
