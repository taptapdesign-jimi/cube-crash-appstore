# PRIVATE Source Magnet pull roots — bounded component

No PRIMARY/CLOSED or asset writes. No phone/PWA operations. No whole Source flag activation.

Prerequisites: current Root Core332 + Source main80/lazy/same-object survivor, app Math object identity, admitted Source clockv5/RAF/FIFO/timeout producers, actual constructor/physical coverage on each selected target, actual Source Special preclaim/guard scope. Source main80 and lazy flags remain false by default. `configureSourceMagnetPull` is an explicit additional opt-in; Raw/other Special families are unchanged.

Install only `Patches/*` narrowly against captured BASE hashes plus listed new files. Candidate wholefiles are review evidence, never overwrite a newer Root Scene/Node/Engine. Node tutorial additions and Scene token ledger are preserved in captured bases. Runtime files belong existing gameplay-app synchronized group; test Swift + JSON belong standalone synchronized tests. Core new type/test automatically discovered. No resource/asset/preload changes.

## Behavior and ownership

Core borrows actual complete eligible ID order after the actual Special claim and before plan/RNG/model mutation. Scene sorts actual painted canvas positions, stable STATE-array order for ties; Core validates the complete identity roster and selects at most four. Nil retains Raw grid-distance selection. Unexpected concurrent physical markers remain refusal; this does not declare whole STATE/grid authority closed.

Each selected target protects an exact Node UUID/parent/generation, retires Wild registry idle, then captures ONE magnet-pull100 before any per-target creation RNG. Two APP draws construct each actual linked timeline. Per-target SourceGSAP.timeline roots retain Source delay, actual child/init order, .485 duration, nonuniform scale, rotation and 75% convergence. No new timer/displaylink/render lease. After convergence the real app FIFO receives the literal import/await continuation; tombstone roots preserve remaining Source duration without repainting a retired/new node.

Main body acquires merge6-resolution100 + actual Special-idle suspension before cue/pull construction. Actual captured helper handler cleanup retains committed sound, closes pull roots/activity, and ownsLifecycle finally ends the main-body lease. markBoardCommitted alone does not close it. Source singleton replacement unhooks old body captures before external cleanup. Per-node token prevents old A restore repainting new C. Existing generic PNG smoke is absent from this Source pull branch: actual Source vector pull FX remain OPEN, not replaced.

Actual app-wall2000 receipt is independent of Source pause and schedules genuine recovery120. This packet explicitly refuses post-main model recovery; it never fabricates rollback/commit/save success. Pre-main destructive cancellation uses previously admitted captured Core receipt. Accounting, initial shortfall retry, post-main partial abort, complete Source Special/Wild target eligibility, actual vector FX and meter-holder constructor coverage are separate remaining packets. Whole feature remains default-off until these are complete.

## Force sound callback

`configureSourceMagnetPull(scope:captureForceStop:)` requires the factory. It is called immediately after existing actual `onSpecialMoment("magnet","pull",count)`. Bind to State packet `/tmp/native-magnet-force-stop-draft` API `audio.captureMagnetPullStop(generation:)`. Capture actual foundation4 + boiing voice identities; preserve Honey/Bottle layers. Explicit mute may return an empty handle. Enabled unsupported transport must refuse configuration, never invent a synthetic moment or stopAll. Entry unhooks stop handle before invocation; a factory that disposes scope returns a late handle which is stopped immediately, without publishing A. cleanup(true) leaves committed audio playing. Scene tests are explicitly muted.

## Proof

- `OriginalAppCore.ts`, `OriginalAppMerge.ts`, `OriginalFinalMergeRules.ts` are git-show immutable production-benchmark-v9 bytes.
- `export-pull.cjs` executes the literal nearestTiles loop with installed GSAP3.13. Date.now is pinned BEFORE GSAP import so synchronous wake cannot move sibling birth between constructor calls. This is explicit numeric root-time context, not browser RAF/hitch proof.
- 16 count1...4/seed/zero-distance graphs, 32,400 pose/arrival fields: strict 1e-6 JS property round6 comparison. Actual admitted NativeSourceAnimationRuntime linked traversal PASS; no blanket Float32 bound or curve approximation.
- Owner Foundation9 PASS: actual runtime natural tails/real finally, paused Source + actual wall timeout, acquisition/protection/RNG/paint/convergence reentry, synchronous late scheduler, A/C cancellation.
- Current isolated Core337/337 PASS includes new physical selection5; nil Raw compatibility and claim/current reentry are covered.
- Whole new UIKit/Scene code parse PASS only. Actual SDK pending Root. No Simulator/physical acceptance claimed yet.

## Root next SDK, focused only

New UI tests: NativeSourceMagnetPullOracleTests1, NativeSourceMagnetPullOwnerTests9, NativeSourceMagnetPullSceneTests4 (14 total). Resource `SourceMagnetPullV9.json` test-bundle copied. Optionally combine State captured Force5 only after that packet is separately reviewed. Preserve failure evidence; use existing isolated simulator, no phone flag/install.

The mounted tests use a genuine restored regular constructor, actual ordinary contact earns meter, real hidden/travel/render/FIFO meter spawns Magnet, actual accepted main80, actual painted target sorting, real per-root convergence/FIFO/lazy respawn/retained survivor. They do not set marker flags, clear Core guards or synthesize an arrival. Convergence Force factory cancellation asserts no import/model commit, all captured roots retired, late sound handle once. Postcommit checker bindings explicitly refuse missing full Source endgame/FX producers; no whole NO MOVES/save claim.
