// swift-tools-version: 5.9
import PackageDescription
let package=Package(name:"NativeSourceTutorialFocus",products:[.library(name:"NativeSourceTutorialFocus",targets:["NativeSourceTutorialFocus"])],targets:[.target(name:"NativeSourceTutorialFocus"),.testTarget(name:"NativeSourceTutorialFocusTests",dependencies:["NativeSourceTutorialFocus"],resources:[.copy("Resources/SourceTutorialFocusV9Oracle.json")])])
