import XCTest
@testable import NativeSourceTutorialFocus

final class NativeSourceTutorialFocusTests:XCTestCase {
    struct Oracle:Decodable {let cases:[Case]}
    struct Case:Decodable {let focused:Bool,from:Double,duration:Double,delay:Double,draws:Int,to:Double,samples:[Sample]}
    struct Sample:Decodable {let seconds:Double,alpha:Double}
    func testLiteralSource603RealGSAPAlphaSamplesAndExactDrawOrder()throws {
        let url=try XCTUnwrap(Bundle.module.url(forResource:"SourceTutorialFocusV9Oracle",withExtension:"json"))
        let oracle=try JSONDecoder().decode(Oracle.self,from:Data(contentsOf:url));var tested=0
        for item in oracle.cases {
            var draws=0;let plan=NativeSourceTutorialFocusPlan(focused:item.focused,random:{draws+=1;return draws==1 ? 0.25:0.5})
            XCTAssertEqual(draws,item.draws);XCTAssertEqual(plan.duration,item.duration,accuracy:1e-12);XCTAssertEqual(plan.delay,item.delay,accuracy:1e-12);XCTAssertEqual(plan.target,item.to)
            for sample in item.samples {XCTAssertEqual(plan.alpha(from:item.from,seconds:sample.seconds),sample.alpha,accuracy:0.00000051);tested+=1}
        }
        XCTAssertEqual(tested,603)
    }
    func testFocusedBranchesNeverBorrowSharedMathAndFiniteEndpointsClamp() {
        let plan=NativeSourceTutorialFocusPlan(focused:true,random:{XCTFail("focused source must draw zero");return 0})
        XCTAssertEqual(plan.alpha(from:0.25,seconds:-1),0.25);XCTAssertEqual(plan.alpha(from:0.25,seconds:99),1)
    }
}
