# Captured authored Magnet Force stop

PRIVATE scoped patch only; exact current audio-owner base SHA is BASES.json.
Original production-benchmark-v9 src/modules/magnet-pull-force-sound.ts119/130
playMagnetPullForceSounds /stopMagnetPullForceSounds. Original cleanup stops
regular foundation four voices and boiing; authored Honey and Bottle pull layers
are separate and are not stopped by this module. Normal committed pull success
preserves tails; genuine current failed/aborted pull cleanup invokes stop.

PASS8 literal original Force variants/Settings traces via TypeScript AST methods.
Native5 tests authored (four actual AV transport scheduled-identity fixtures plus
one injected reentrant capture-provider fixture), uncompiled/unrun; Root SDK next.
Original-file decoder readiness/gains were independently admitted earlier; these
tests verify exact scheduled Voice identity cleanup before asynchronous player
start, not physical audible mix. NEEDS PHYSICAL TEST.

Apply captured-force-stop-scoped.patch only NativeGameplayAudioOwner.swift. No
new transport/session/voice/audio file/timer or Source Scene mutation. Existing
pull groups and catalog/source bytes are unchanged. `captureMagnetPullStop(
generation:) -> (() -> Void)?` borrows and consumes a closure captured at the
actual admitted pull group's play, not a later stable-ID lookup. Root/Board bind
immediately AFTER existing onSpecialMoment('magnet','pull',count); use it for
captured cleanup(false)/interruption only, and release without stop for success.

Reuses actual transport.captureFade(ids) captured Voice objects at progress1 to
stop immediately. It never uses stopVoices compatibility fallback (stopAll),
never stops all cues, and cannot stop replacement C with the same IDs or unrelated
voices. Captures include four original regular foundation IDs+boiing. Honey/Bottle
pull layers remain. No synthetic pull-stop semantic sound moment is introduced.

Stale generation/repeated receipt cannot clear C's capture. Real current pull
consumes prior unborrowed handle even muted; mute/background/generation/dispose
clear pending handle alongside existing full lifecycle stop. Unsupported injected
transport capture/actual unplayed muted contact returns nil; caller may explicitly
use an empty cleanup only for the already-silent Settings case. Missing capture
when enabled is not whole Source audio capability. External capture reentry is
sealed after return; a new current cue cannot be overwritten by old A.

AppTests/NativeMagnetForceCapturedStopTests.swift is the only test add. Oracle
TS/exporter is proof-only, not app/test bundle source. The additive existing
audio-runtime record proposal is audio-runtime-owner-record-proposal.json; Root
merges its event/voice/test changes into the canonical record when integrating,
and runs qa:audio-runtime/feature/full. Other Source variant phase wiring (including
Spaceship) remains explicit separate owner admission, not inferred by this API.
