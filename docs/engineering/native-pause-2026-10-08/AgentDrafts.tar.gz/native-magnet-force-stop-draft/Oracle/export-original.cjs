const fs=require('fs'),assert=require('assert'),ts=require('/Users/user/cube-crash/node_modules/typescript');
const source=fs.readFileSync(__dirname+'/magnet-pull-force-sound.ts','utf8'),sf=ts.createSourceFile('source.ts',source,ts.ScriptTarget.Latest,true);
const names=['areSoundsEnabled','playAccent','playMagnetPullForceSounds','resolveMagnetPullForceBoiingVolume','stopMagnetPullForceSounds'];
const code=names.map(name=>{const n=sf.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);assert(n,name);return n.getText(sf).replace(/^export /,'')}).join('\n');
const rows=[];
for(const enabled of [false,true])for(const variant of [null,'honey','bottle','spaceship']){
 const trace=[],env={window:{_settings:{gameSoundsEnabled:enabled}},MAGNET_PULL_FORCE_SOUND_SOURCES:['./assets/sound/magnet pul lforce/boiing.wav'],MAGNET_PULL_FORCE_SOUND_VOLUMES:[0.6],HONEY_PULL_FORCE_BOIING_VOLUME:0.36,BOTTLE_PULL_FORCE_BOIING_VOLUME:0.24,MAGNET_PULL_FORCE_VOICE_IDS:['magnet-pull-force-boiing'],fallbackAudio:null,
 getDecodedGameplaySoundsState(){return 'ready'},playDecodedGameplaySound(source,options){trace.push({kind:'accent-play',source,voice:options.voiceId,gain:options.volume});return 'played'},stopRegularMerge6Sounds(){trace.push({kind:'foundation-stop'})},stopDecodedGameplayVoices(ids){trace.push({kind:'accent-stop',ids})},playSpecialMerge6FoundationSound(){trace.push({kind:'foundation-play'});return true},getFallbackAudio(){throw Error('unexpected fallback')},logger:{warn(){}}};
 const api=new Function('env',`with(env){${ts.transpile(code)};return {playMagnetPullForceSounds,stopMagnetPullForceSounds}}`)(env);
 const began=api.playMagnetPullForceSounds(variant),beforeCleanup=trace.slice();api.stopMagnetPullForceSounds();
 if(enabled){assert.equal(beforeCleanup.length,4);assert.equal(beforeCleanup[0].kind,'foundation-stop');assert.equal(beforeCleanup[1].kind,'accent-stop');assert.equal(beforeCleanup[2].kind,'foundation-play');assert.equal(beforeCleanup[3].kind,'accent-play')}else assert.equal(beforeCleanup.length,0);
 rows.push({enabled,variant,began,beforeCleanup,trace});
}
fs.writeFileSync(__dirname+'/SourceMagnetForceStopOracle.json',JSON.stringify({rows},null,2));console.log('PASS8 literal v9 Force play/stop variants+Settings traces: authored foundation then boiing, exact1/.6/.4 base gains*master. Native captured identity extends same-current-run cleanup protection, no stopAll.');
