    // Default-OFF genuine fresh/restored-regular sweetPopIn caller. The
    // constructor objects, APP clock/Math/FIFO and authored sound are mandatory.
    var sourceBoardEntryEnabled=false
    private weak var sourceBoardEntryScope:NativeGameplaySourceContext.Scope?
    private var sourceBoardEntrySound:((Double,UInt64,UInt64)->(()->Void)?)?
    private var sourceBoardEntryCompleted:((NativeSourceBoardEntryOwner.Completion)->Void)?
    private var sourceBoardEntryOwner:NativeSourceBoardEntryOwner?
    private var sourceBoardEntryNodes:[String:NativeDiceNode]=[:]
    private var sourceBoardEntryEpoch:UInt64=0,sourceBoardEntrySoundReceipt:UInt64=0
    private(set) var completedSourceBoardEntry:NativeSourceBoardEntryOwner.Completion?
    var sourceBoardEntryAdmissionOpen:Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceBoardEntryEnabled,let scope=sourceBoardEntryScope,
            scope.current,sourceOuterTimelineDriver === scope.timeline,sourceDragTweenDriver === scope.tween,
            scope.service.sourceFrameTransportAdmissionOpen,
            let installation=sourceMicrotaskInstallation,installation.isCurrent,
            installation.tasks === scope.sourceMicrotaskTasks,sourceBoardEntrySound != nil else{return false}
        return sourceAnimationBindingAdmissionOpen && sourceBoardEntryScope === scope && scope.current
    }
    @discardableResult func configureSourceBoardEntry(scope:NativeGameplaySourceContext.Scope,
        sound:@escaping(Double,UInt64,UInt64)->(()->Void)?,
        completed:@escaping(NativeSourceBoardEntryOwner.Completion)->Void)->Bool {
        guard sourceBoardEntryEnabled,sourceAnimationBindingAdmissionOpen,scope.current,
            sourceBoardEntryScope==nil,sourceBoardEntryOwner==nil,sourceInitialConstruction?.isCurrent==true,
            sourceOuterTimelineDriver === scope.timeline,sourceDragTweenDriver === scope.tween,
            scope.service.sourceFrameTransportAdmissionOpen,
            let installation=sourceMicrotaskInstallation,installation.isCurrent,
            installation.tasks === scope.sourceMicrotaskTasks else{return false}
        sourceBoardEntryScope=scope;sourceBoardEntrySound=sound;sourceBoardEntryCompleted=completed
        sourceDisposalSealingEnabled=true
        return sourceBoardEntryAdmissionOpen
    }
    private func sourceBoardEntryOwns(_ node:NativeDiceNode)->Bool {
        guard let owner=sourceBoardEntryOwner,owner.phase == .running,
            sourceBoardEntryNodes[node.tileID] === node,nodesByID[node.tileID] === node,
            node.sourceContactNodeAlive,node.sourceGeneration==owner.generation,node.parent === canvasRoot,
            node.sourceBoardEntryBinding==owner.id else{return false}
        return sourceBoardEntryAdmissionOpen
    }
    private func startSourceBoardEntry(tiles:[NativeTile],geometry:NativeBoardGeometry)->Bool {
        guard sourceBoardEntryAdmissionOpen,sourceBoardEntryOwner==nil,let scope=sourceBoardEntryScope,
            let installation=sourceMicrotaskInstallation,let initial=sourceInitialConstruction,initial.isCurrent,
            tiles.count==engine.state.tiles.count,tiles.allSatisfy({$0.variant==nil && $0.gameplayArchetype==nil && !$0.pendingRemoval}),
            let sound=sourceBoardEntrySound else{return false}
        let generation=engine.state.generation,epoch=sourceBoardEntryEpoch
        var captures:[NativeSourceBoardEntryOwner.Capture]=[],nodes:[String:NativeDiceNode]=[:]
        for tile in tiles {
            guard let node=nodesByID[tile.id],node.parent === canvasRoot,node.sourceGeneration==generation,
                node.sourceContactNodeAlive,node.value==tile.value,node.locked==tile.locked,
                node.position==geometry.center(row:tile.cell.row,column:tile.cell.column) else{return false}
            nodes[tile.id]=node
            captures.append(.init(node:node,parent:canvasRoot,generation:generation,
                sourcePosition:CGPoint(x:tile.cell.column*148+64,y:tile.cell.row*148+64),
                nativePosition:node.position,sourceRotation:-Double(node.zRotation),geometryScale:Double(geometry.scale),
                locked:node.locked,value:node.value))
        }
        let current:()->Bool = {[weak self,weak scope,weak installation,weak initial] in
            guard let self,let scope,let installation,let initial,self.sourceBoardEntryAdmissionOpen,
                self.sourceBoardEntryScope === scope,self.sourceBoardEntryEpoch==epoch,
                self.sourceMicrotaskInstallation === installation,installation.isCurrent,
                self.sourceInitialConstruction === initial,initial.isCurrent,self.engine.state.generation==generation else{return false}
            return self.sourceBoardEntryAdmissionOpen && self.sourceBoardEntryEpoch==epoch && self.engine.state.generation==generation
        }
        sourceBoardEntrySoundReceipt &+= 1;let audioReceipt=sourceBoardEntrySoundReceipt
        guard let owner=NativeSourceBoardEntryOwner(service:scope.service,captures:captures,generation:generation,
            timeouts:sourceAppTimeouts,random:{[weak scope] in guard let scope,current() else{return nil};return scope.mathRandom.next()},
            current:current,acquireFrames:{[weak self] in self?.beginSourceMotion(.boardPopIn,id:"source-board-entry:\(epoch)",generation:generation)},
            sound:{duration in guard current() else{return nil};return sound(duration,audioReceipt,generation)},
            half:{[weak self] in guard let self,current(),let receipt=self.hudEntryReceipt else{return};self.hudEntryReveal.midpoint(receipt)},
            haptic:{[weak self] in guard current() else{return};self?.onHaptic?("light")},
            syncZ:{node,animating in guard current(),nodes[node.tileID] === node,node.parent === captures.first?.parent else{return};node.zPosition=node.locked ? (animating ? 80:5):(animating ? 120:20)},
            drawBG:{[weak self] in guard let self,current() else{return};self.renderGhosts(state:self.engine.state,geometry:geometry)},
            finished:{[weak self,weak installation] completion in
                guard let self,self.sourceBoardEntryOwner?.id==completion.id,self.sourceBoardEntryEpoch==epoch else{return}
                self.sourceBoardEntryOwner=nil;self.sourceBoardEntryNodes.removeAll()
                self.entryInProgress=false;self.entryOwners=0;self.finishSourceEntry()
                guard completion.outcome == .normal || completion.outcome == .forced else{self.inputAdmitted=false;return}
                guard current(),let installation,self.sourceMicrotaskInstallation === installation,
                    installation.enqueue({[weak self] in
                        guard let self,current(),self.sourceBoardEntryOwner==nil,self.sourceBoardEntryEpoch==epoch else{return}
                        self.completedSourceBoardEntry=completion;self.inputAdmitted=true
                        self.sourceBoardEntryCompleted?(completion)
                        guard current(),self.sourceBoardEntryEpoch==epoch else{return}
                        self.evaluate()
                    }) else{self.inputAdmitted=false;return}
            }),current() else{return false}
        sourceBoardEntryOwner=owner;sourceBoardEntryNodes=nodes;completedSourceBoardEntry=nil
        entryInProgress=true;entryOwners=tiles.count;inputAdmitted=false
        let hudReceipt=hudEntryReveal.begin(generation:generation,tileCount:tiles.count)
        hudEntryReceipt=hudReceipt;isHUDRevealPending=true
        hud.removeAction(forKey:"hud-enter");hud.position.y=140;hud.alpha=0;roundIndicator.primeEntry()
        let started=owner.start(groupedHaptics:true)
        guard started,current(),sourceBoardEntryOwner === owner || owner.phase == .finished else {
            if sourceBoardEntryOwner === owner {sourceBoardEntryOwner=nil;sourceBoardEntryNodes.removeAll()}
            owner.retire();entryInProgress=false;inputAdmitted=false;return false
        }
        // No yield or extra frame: reveal only after the real captured main is
        // installed; queued original constructor/face RAFs retain their order.
        initial.releaseToExistingNativeEntry()
        return true
    }
    private func retireSourceBoardEntry() {
        sourceBoardEntryEpoch &+= 1
        let captured=sourceBoardEntryOwner;sourceBoardEntryOwner=nil
        sourceBoardEntryNodes.removeAll();completedSourceBoardEntry=nil
        sourceBoardEntryScope=nil;sourceBoardEntrySound=nil;sourceBoardEntryCompleted=nil
        if captured != nil {entryInProgress=false;entryOwners=0;inputAdmitted=false}
        captured?.retire() // Paint-preserving route retirement, not abort settle.
    }
