import XCTest
import SpriteKit
import UIKit
import StackToSixGameplay
@testable import Stack_to_Six

@MainActor final class NativeSourceMergeSixSpawnOwnerMountedTests:XCTestCase {
 @MainActor private final class Counter {var now:Double=1000,dateCalls=0,acquired=0,released=0,companionTrace:[String]=[]}
 @MainActor private final class Fixture {
  let counter=Counter(),service:NativeSourceAnimationClockService,context:NativeGameplaySourceContext,scope:NativeGameplaySourceContext.Scope,scene:NativeBoardScene,view:SKView
  init(enabled:Bool=true,final:Bool=false)throws {
   let c=counter
   service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true)
   context=NativeGameplaySourceContext(service:service,appOriginMilliseconds:0,visualRandom:{0.5},sourceDateMilliseconds:{c.dateCalls+=1;return c.now})
   let tiles:[NativeTile]=[.init(id:"a",cell:.init(column:0,row:0),value:2),.init(id:"b",cell:.init(column:1,row:0),value:4)]+(final ? []:[.init(id:"other",cell:.init(column:4,row:8),value:3)])
   scene=NativeBoardScene(engine:NativeGameplayEngine(state:.init(columns:5,rows:9,tiles:tiles)),resourceRoot:NativeTestResources.root,size:.init(width:390,height:844))
   let captured=scene;scope=try XCTUnwrap(context.beginScene(engine:scene.engine,retire:{[weak captured] in captured?.retireSourceAnimationBindings()}))
   scene.sourceOuterTimelineDriver=scope.timeline;scene.sourceDragTweenDriver=scope.tween
   scene.sourceSameNodeStackAbsorbsEnabled=true;scene.sourceOrdinarySixSameNodeEnabled=true
   scene.sourceContactVisualRandom={0.5};scene.sourceStackAbsorbAdmission={_,_ in true}
   scene.configureSourceRegularStackHandoff(service:service,admitted:{true})
   scene.layout(size:scene.size,insets:.init(top:47,left:0,bottom:34,right:0),animateEntry:false)
   view=SKView(frame:.init(x:0,y:0,width:390,height:844));view.presentScene(scene)
   let target=try XCTUnwrap(scene.sourceNativeTileNode("b"));XCTAssertTrue(target.queueSourceStackValue(4,addStack:0,service:service,random:{0.5},current:{true}));service.deliver(wallMilliseconds:16)
   XCTAssertTrue(scene.configureSourceOrdinarySixMain(scope:scope,acquireIdle:{_ in c.acquired+=1;var ended=false;return{guard !ended else{return};ended=true;c.released+=1}}))
   scene.sourceEndgameMutationLedgerEnabled=true;XCTAssertTrue(scene.configureSourceEndgameMutationLedger(scope:scope))
   scene.sourceOrdinarySixSpawnOwnerEnabled=enabled
   if enabled {XCTAssertTrue(scene.configureSourceOrdinarySixSpawnOwner(scope:scope,resets:{_,_ in
    // Explicit test-only ordinary null-Special / queue endpoint. No product
    // capability is published by these controlled companion callbacks.
    .init(releaseSpecialTransaction:{c.companionTrace.append("release-special")},queueWildAfterGuardRelease:{c.companionTrace.append("queue")})
   }))}
  }
  func contact()throws->NativeOrdinaryMovePlan {
   let geometry=try XCTUnwrap(scene.boardGeometry),a=geometry.center(row:0,column:0),b=geometry.center(row:0,column:1)
   XCTAssertTrue(scene.beginDrag(at:a));service.deliver(wallMilliseconds:25);scene.moveDrag(to:b,now:0.025)
   XCTAssertTrue(try XCTUnwrap(scene.finishDrag(at:b,now:0.025)).accepted);return try XCTUnwrap(scene.engine.pendingOrdinarySix)
  }
  func dispose(){scene.dispose();context.dispose();service.dispose();view.presentScene(nil)}
 }
 func testActualMainPrefixAllocatesTokenAndStampsDateBeforePreparationWithoutNativeHandoffReset()throws {
  let f=try Fixture();defer{f.dispose()};let p=try f.contact()
  XCTAssertEqual(f.counter.dateCalls,0);XCTAssertFalse(f.context.endgameMutations.mergeSixSpawns.inProgress)
  f.counter.now=2222;f.service.deliver(wallMilliseconds:109)
  let claim=try XCTUnwrap(f.context.endgameMutations.mergeSixSpawns.active)
  XCTAssertEqual(claim.ownerID,p.id);XCTAssertEqual(claim.generation,p.generation);XCTAssertEqual(claim.token,1)
  XCTAssertEqual(f.counter.dateCalls,1);XCTAssertEqual(f.context.endgameMutations.snapshot.lastMutationAt,2222)
  XCTAssertTrue(f.scene.engine.ordinarySpawnPreparationPending);XCTAssertTrue(f.scene.engine.pendingSourceOrdinarySixSpawnBeginReceipts.isEmpty)
  XCTAssertEqual(f.counter.released,0);XCTAssertTrue(f.counter.companionTrace.isEmpty)
  XCTAssertFalse(f.context.endgameMutations.allFourWritersConnected)
 }
 func testRealCapturedScopeRetirementResetsTokenCompanionsWithoutDateAndCannotRevive()throws {
  let f=try Fixture();defer{f.dispose()};_=try f.contact();f.service.deliver(wallMilliseconds:109)
  let before=f.context.endgameMutations.snapshot;XCTAssertTrue(f.context.endgameMutations.mergeSixSpawns.inProgress)
  _=try XCTUnwrap(f.context.beginScene(retire:{}));XCTAssertFalse(f.scope.current)
  XCTAssertFalse(f.context.endgameMutations.mergeSixSpawns.inProgress);XCTAssertEqual(f.context.endgameMutations.snapshot,before)
  XCTAssertEqual(f.counter.released,1);XCTAssertEqual(f.counter.companionTrace,["release-special","queue"])
  f.service.deliver(wallMilliseconds:350);XCTAssertEqual(f.context.endgameMutations.snapshot,before)
 }
 func testFinalAndUnselectedRawDoNotRequestOrAllocateSourceSpawnToken()throws {
  for f in [try Fixture(final:true),try Fixture(enabled:false)] {
   defer{f.dispose()};_=try f.contact();f.service.deliver(wallMilliseconds:109)
   XCTAssertFalse(f.context.endgameMutations.mergeSixSpawns.inProgress);XCTAssertEqual(f.counter.dateCalls,0)
   XCTAssertEqual(f.context.endgameMutations.mergeSixSpawns.allocationSequence,0)
  }
 }
}
