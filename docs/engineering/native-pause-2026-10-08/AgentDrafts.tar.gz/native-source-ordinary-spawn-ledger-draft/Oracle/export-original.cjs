const fs=require('fs'),assert=require('assert'),ts=require('/Users/user/cube-crash/node_modules/typescript');
const source=fs.readFileSync(__dirname+'/app-core.ts','utf8'),sf=ts.createSourceFile('app-core.ts',source,ts.ScriptTarget.Latest,true);
const functions=['clearMerge6SpawnResetTimer','resetMerge6SpawnState'].map(name=>{const n=sf.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);assert(n,name);return n.getText(sf)}).join('\n');
let acquisition,invalid;
function walk(n){
 if(ts.isIfStatement(n)&&n.expression.getText(sf)==='merge6SpawnInProgress'&&n.getText(sf).includes('merge6SpawnOwnerToken = ++merge6SpawnOwnerSequence'))acquisition=n.getText(sf);
 if(ts.isIfStatement(n)&&n.expression.getText(sf)==='!spawnMult || spawnMult <= 0'&&n.getText(sf).includes('merge6-invalid-spawn-mult'))invalid=n.getText(sf);
 ts.forEachChild(n,walk);
}walk(sf);assert(acquisition);assert(invalid);
function run(steps){
 let now=0,dateCalls=0;
 const timers=[],trace=[],env={Date:{now(){dateCalls++;trace.push('date');return now}},merge6SpawnOwnerToken:null,merge6SpawnOwnerSequence:0,activeMerge6SpawnOwnerToken:null,merge6SpawnInProgress:false,merge6SpawnResetTimer:null,lastEndgameBoardMutationAt:0,dst:{destroyed:false},specialTransactionToken:null,spawnMult:2,mult:2,
 devLog(){},devWarn(){},removeTile(){trace.push('remove-dst')},scheduleOwnedMergeRecoveryCheck(){trace.push('recovery120')},endMerge6ResolutionFrames(){trace.push('end-frames')},releaseSpecialDiceTransaction(){trace.push('release-special')},queueWildSpawnAfterGuardRelease(){trace.push('queue')},trackDelayedCall(seconds,callback){assert.equal(seconds,2.5);trace.push('install-gsap2500');const timer={callback,kill(){trace.push('kill-diagnostic')}};timers.push(timer);return timer}};
 const api=new Function('env',`with(env){${ts.transpile(functions)};return {begin(){${ts.transpile(invalid)};${ts.transpile(acquisition)}},reset(options){return resetMerge6SpawnState('fixture',options)}}}`)(env),snapshots=[];
 for(const step of steps){now=step.at;let result=null;
  if(step.kind==='begin'){env.spawnMult=step.mult??2;api.begin()}
  else if(step.kind==='diagnostic'){timers[step.index??0]?.callback()}
  else if(step.kind==='reset')result=api.reset({merge6SpawnOwnerToken:step.token,force:step.force===true,releaseSpecialTransaction:step.releaseSpecial!==false});
  else assert.equal(step.kind,'read');
  snapshots.push({sequence:env.merge6SpawnOwnerSequence,active:env.activeMerge6SpawnOwnerToken,inProgress:env.merge6SpawnInProgress,lastMutationAt:env.lastEndgameBoardMutationAt,dateCalls,result,trace:trace.slice()});
 }
 return {steps,snapshots};
}
const rows=[
 run([{kind:'read',at:0},{kind:'begin',at:1000},{kind:'read',at:1500},{kind:'diagnostic',at:3500},{kind:'reset',token:1,at:3600}]),
 run([{kind:'begin',at:1000},{kind:'begin',at:1100},{kind:'reset',token:99,at:1200},{kind:'reset',token:1,at:1300},{kind:'begin',at:1400},{kind:'reset',token:1,at:1500},{kind:'reset',token:2,releaseSpecial:false,at:1600}]),
 run([{kind:'begin',mult:0,at:1000},{kind:'begin',mult:-1,at:1100},{kind:'begin',at:1200},{kind:'reset',token:99,force:true,at:1300},{kind:'read',at:1400}])
];
assert.equal(rows[0].snapshots[3].inProgress,true);assert.equal(rows[0].snapshots[4].dateCalls,1);
assert.equal(rows[1].snapshots[5].active,2);assert.equal(rows[2].snapshots[1].dateCalls,0);
fs.writeFileSync(__dirname+'/SourceMergeSixSpawnOwnerOracle.json',JSON.stringify({rows},null,2));
console.log('PASS literal v9 acquisition/invalid-multiplier/late-owner/reset/diagnostic functions:',rows.length,'lifecycles',rows.reduce((n,r)=>n+r.snapshots.length,0),'captured states. Diagnostic never resets ownership, reads/resets never write Date.');
