# Selected Source ordinary-six spawn token begin/reset subset

PRIVATE packet only. No Primary/CLOSED/SDK/device operations. Current captured
Core325 +Scene actual main80/pre-debit/lazy/handoff ledger bases are BASES.json.
Original production-benchmark-v9 fc085599e759369900d5dc4135246a9f1355a897;
Oracle/app-core.ts SHA284d104e4f20b7b30fd5dad2361c1edfb822a6b96a38c64efc2793033cbc09e3.

PASS original acquisition/reset/invalid-multiplier/late-owner/diagnostic functions:
3 lifecycles /17 captured states. Node executes literal original AST blocks and
the real reset function. Original outer guards/cleanup are Source trace proof,
not claims that Native now implements their entire topology. No Swift compiler
was run; authored Core4 +runtime5 +mounted3 =12 tests await Root SDK. Core four
tests can also be copied to existing SwiftPM package; expected325+4=329 subject
to any other Root additions. No resource from Oracle/ is bundled automatically.

Apply ordinary-spawn-token-scoped.patch to its exact four bases. Add new
Candidate Core NativeSourceOrdinarySixSpawnBeginReceipt.swift and app
NativeSourceMergeSixSpawnOwner.swift. Add AppTests three classes to actual SDK
test target. Existing app/gameplay-ui/core owners/tests stay unchanged otherwise.

Core mints only a BEGIN REQUEST at the actual nonfinal entered staged ordinary
replacement continuation AFTER pre-spawn caller early-return; genuine
continue-merge6 resumption has the second exact route. No request at pending plan,
contact, final, blocked pre-spawn, Native handoff, primary or visual completion.
The request is not a Source owner/token/Date and remains transient/unpersisted.

Source Scene explicit sourceOrdinarySixSpawnOwnerEnabled=false by default;
configureSourceOrdinarySixSpawnOwner(scope:resets:) requires actual selected
Source same-object Six driver/scope, existing current handoff-ledger binding and
mandatory captured Special-null release/queue companions. The factory is sealed
after return. The genuine Core event dispatches after existing merged/FX prefix
and before preparation, internally before generic observers can consume it.
App-lived ledger mergeSixSpawns then allocates a real monotonically increasing
token, stores its actual active identity/flag, stamps Date once and installs
the captured GSAP delayedCall2.5 diagnostic on existing Source service. It adds
no timer/clock, renderer lease or expiry-based mutation authority.

Diagnostic does not reset token or ownership, including across global pause.
Captured reset removes owner/timer before external end-frames/idle, release-
Special, queue callbacks, and stops old callbacks if a replacement owner appears.
Actual Scope/Scene retirement clears only its currently bound token without a
Date write. Source owner acquisition sequence is app-lived, distinct from the
Core request sequence and the meter ledger. A dispatched request is accepted
once; request replay after reset cannot allocate another Source token.

Native releaseOrdinarySixIfReady is specifically NOT a Source Promise finally.
Selected genuine Source token keeps captured Source frame/idle owners while that
Native bookkeeping drains. sourceOrdinarySixSpawnCoroutineFinally(ownerID:
generation:) is a narrow captured reset endpoint but is INTENTIONALLY UNCALLED:
there is no admitted literal regular/endgame spawn coroutine completion producer
yet. Mounted tests prove actual main→token→Date and actual teardown; they do not
manufacture Promise completion or claim source full frame/idle/input/save parity.

OPEN before whole route/third-writer capability: actual regular coroutine
FLOW.openLockedBounceParallel Promise, forced opens/remainder, minimum-active
repair and opacity safety then/catch/finally; endgame hard repair/single6 guard;
Direct/Magnet/TNT shared acquisition and true reset/first-primary distinctions.
Token ownership is deliberately not published into whole Source runtime marker
capabilities or native resolver/input flags. allFourWritersConnected remains false
(2/4 admitted handoff producers; this token-begin subset is not complete writer
coverage). Existing Native revision checks remain compatibility guards, never
Source authority/signature inference. Actual Date signature writer after awaited
tutorial, mandatory repair, final runtime, TNT/stability and ordinary cleanup1200
remain separate unfinished producers. Defaults OFF preserve Raw behavior.

Physical acceptance: NEEDS PHYSICAL TEST. Original artwork/audio/save bytes,
existing PWA/phone/remote/main/index unchanged by this packet.
