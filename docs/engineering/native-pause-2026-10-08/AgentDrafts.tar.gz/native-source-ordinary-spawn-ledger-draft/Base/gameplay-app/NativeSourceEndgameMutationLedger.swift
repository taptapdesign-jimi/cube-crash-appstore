import Foundation

/// App-lived lastEndgameBoardMutationAt is DISTINCT from lastBoardMutationAt.
/// Date reads happen only at genuine writers, never snapshot/age/coverage reads.
/// There is no timer, revision proxy, wall-clock lease or persisted save field.
@MainActor final class NativeSourceEndgameMutationLedger {
    nonisolated struct Snapshot:Equatable {let lastMutationAt:Double,lastSignature:String;let sequence:UInt64}
    private let sourceDateMilliseconds:()->Double
    private var lastMutationAt:Double=0,lastSignature="",sequence:UInt64=0
    private var epoch:UInt64=0,disposed=false
    private var active:[UUID:UUID]=[:] // captured handoff id -> exact binding id
    init(sourceDateMilliseconds:@escaping()->Double){self.sourceDateMilliseconds=sourceDateMilliseconds}
    var snapshot:Snapshot {.init(lastMutationAt:lastMutationAt,lastSignature:lastSignature,sequence:sequence)}
    func sinceMutation(at actualDateMilliseconds:Double)->Double {lastMutationAt != 0 ? actualDateMilliseconds-lastMutationAt:Double.infinity}
    func bind(current:@escaping()->Bool)->Binding? {
        guard !disposed else{return nil};let e=epoch,accepted=current()
        guard accepted,!disposed,epoch==e else{return nil}
        return Binding(owner:self,current:current)
    }
    private func record(_ receipt:NativeSourceRegularHandoffMutationReceipt,phase:NativeSourceRegularHandoffMutationReceipt.Phase,binding:Binding)->Bool {
        guard binding.admitted, !disposed else{return false}
        if phase == .began {guard active[receipt.id]==nil else{return false};active[receipt.id]=binding.id}
        else {guard active[receipt.id]==binding.id else{return false};active.removeValue(forKey:receipt.id)}
        // Ownership is accepted/removed before Date injection. A reentrant C may
        // mutate/dispose; old A must not overwrite C's later genuine timestamp.
        epoch &+= 1;let captured=epoch,date=sourceDateMilliseconds()
        guard !disposed,epoch==captured,binding.admitted,!disposed,epoch==captured,
              phase == .released || active[receipt.id]==binding.id else{return false}
        lastMutationAt=date;sequence &+= 1;return true
    }
    private func retire(_ binding:Binding) {active=active.filter{$0.value != binding.id};epoch &+= 1}
    func dispose(){guard !disposed else{return};disposed=true;epoch &+= 1;active=[:]}
    /// No capability for unconnected spawn acquisition or physical signature is
    /// published by these two handoff endpoints. Full levelEnd remains refused.
    var allFourWritersConnected:Bool {false}
    @MainActor final class Binding {
        fileprivate let id=UUID()
        private weak var owner:NativeSourceEndgameMutationLedger?
        private let current:()->Bool
        private(set) var retired=false
        fileprivate init(owner:NativeSourceEndgameMutationLedger,current:@escaping()->Bool){self.owner=owner;self.current=current}
        fileprivate var admitted:Bool {
            guard !retired,owner != nil else{return false};let accepted=current()
            return accepted && !retired && owner != nil
        }
        var snapshot:Snapshot? {guard admitted,let owner else{return nil};return owner.snapshot}
        @discardableResult func handoff(_ receipt:NativeSourceRegularHandoffMutationReceipt,phase:NativeSourceRegularHandoffMutationReceipt.Phase)->Bool {
            guard admitted,let owner else{return false};return owner.record(receipt,phase:phase,binding:self)
        }
        func retire(){guard !retired else{return};retired=true;let captured=owner;owner=nil;captured?.retire(self)}
    }
}
