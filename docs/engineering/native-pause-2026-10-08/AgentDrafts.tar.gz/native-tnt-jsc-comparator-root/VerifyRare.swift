import Foundation
struct Sample:Decodable {let n:Int,seed:UInt32,selected:[Int],draws:Int,state:UInt32}
@main struct Verify {static func main()throws {
 let samples=try JSONDecoder().decode([Sample].self,from:Data(contentsOf:URL(fileURLWithPath:"/tmp/native-tnt-jsc-comparator-root/mac-rare320.json")))
 for c in samples {var state=c.seed,draws=0;let actual=NativeSourceTntTargetSort.select(candidateIDs:(0..<c.n).map(String.init),random:{state=state &* 1664525 &+ 1013904223;draws+=1;return Double(state)/4294967296},current:{true});precondition(actual==c.selected.map(String.init) && draws==c.draws && state==c.state,"n=\(c.n) seed=\(c.seed)")}
 print("Swift literal selector matches mac JSC320 selections/draw counts/final RNG state; iOS pending")
}}
