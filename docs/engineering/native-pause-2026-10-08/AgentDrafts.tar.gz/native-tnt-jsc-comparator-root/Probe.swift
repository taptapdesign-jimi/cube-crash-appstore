import Foundation
import JavaScriptCore
let context=JSContext()!
let script = """
(function(){
const results=[];
for(const n of [0,1,2,3,4,5,7,8,9,16,25,35,48,63])for(const seed of [1,7,42,1337,99991]){
 let state=seed>>>0,trace=[];
 const candidates=Array.from({length:n},(_,i)=>({id:i}));
 const count=Math.min(4,candidates.length);
 const old=Math.random;
 Math.random=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
 let selected,order;
 try{order=[...candidates].sort((a,b)=>{const value=Math.random()-0.5;trace.push([a.id,b.id,value<0]);return value;});selected=order.slice(0,count);}
 finally{Math.random=old;}
 results.push({n,seed,order:order.map(x=>x.id),selected:selected.map(x=>x.id),trace,draws:trace.length,state});
}
return JSON.stringify(results);
})()
"""
guard let result=context.evaluateScript(script)?.toString(),context.exception==nil else{fatalError("JSC exception")}
try result.write(toFile:"/tmp/native-tnt-jsc-comparator-root/mac-discovery.json",atomically:true,encoding:.utf8)
print("JSC discovery cases:70; target verification remains pending")
