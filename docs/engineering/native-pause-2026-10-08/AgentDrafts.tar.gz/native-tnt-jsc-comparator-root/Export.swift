import Foundation
import JavaScriptCore
let context=JSContext()!
let script=try String(contentsOfFile:"/tmp/native-tnt-jsc-comparator-root/OriginalSelection.js",encoding:.utf8)
guard let result=context.evaluateScript(script)?.toString(),context.exception==nil else{fatalError("JSC exception")}
try result.write(toFile:"/tmp/native-tnt-jsc-comparator-root/mac-original320.json",atomically:true,encoding:.utf8)
print("Literal original comparator exported320 cases, mac reference only")
