(function(){
 const results=[];
 for(let n=0;n<=63;n++)for(const seed of [920, 1681, 1945, 1954, 3543]){
  let state=seed>>>0,draws=0;
  const candidates=Array.from({length:n},(_,i)=>({id:i})),count=Math.min(4,candidates.length);
  const old=Math.random;
  Math.random=()=>{draws++;state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
  let selected;
  try{selected=[...candidates].sort(() => Math.random() - 0.5).slice(0, count);}
  finally{Math.random=old;}
  results.push({n,seed,selected:selected.map(x=>x.id),draws,state});
 }
 return JSON.stringify(results);
})()
