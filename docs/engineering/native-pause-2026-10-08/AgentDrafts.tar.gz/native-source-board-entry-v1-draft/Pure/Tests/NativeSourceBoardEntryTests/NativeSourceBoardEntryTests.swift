import XCTest
import CoreGraphics
@testable import NativeSourceBoardEntry
final class NativeSourceBoardEntryTests:XCTestCase {
    struct Oracle:Decodable{let cases:[Case]}
    struct Case:Decodable{let name:String,draws:Int,plan:[Plan],samples:[Sample]}
    struct Plan:Decodable{let preset:String,tileIndex:Int,enterDelay:Double,endTime:Double,startOffsetX:Double,startOffsetY:Double,startRotation:Double}
    struct Sample:Decodable{let seconds:Double,tiles:[Pose]}
    struct Pose:Decodable{let x:Double,y:Double,rotation:Double,scale:Double,alpha:Double}
    func testActualOriginalParentTimeline1890ChannelsAndAllSpatialMath()throws {
        let url=try XCTUnwrap(Bundle.module.url(forResource:"SourceBoardEntryV9Oracle",withExtension:"json")),oracle=try JSONDecoder().decode(Oracle.self,from:Data(contentsOf:url)),item=try XCTUnwrap(oracle.cases.first{$0.name=="normal"})
        let positions=(0..<3).map{CGPoint(x:$0*148+64,y:64)},numbers=[0.12,0.74,0.19,0.81,0.43];var draws=0
        let plans=try XCTUnwrap(NativeSourceBoardEntryPlan.make(positions:positions,maxOffset:128*0.42,random:{defer{draws+=1};return numbers[draws%5]}))
        XCTAssertEqual(draws,item.draws)
        for (a,b) in zip(plans,item.plan){XCTAssertEqual(a.preset.rawValue,b.preset);XCTAssertEqual(a.tileIndex,b.tileIndex);XCTAssertEqual(a.delay,b.enterDelay,accuracy:1e-12);XCTAssertEqual(a.end,b.endTime,accuracy:1e-12);XCTAssertEqual(a.offset.x,b.startOffsetX,accuracy:1e-12);XCTAssertEqual(a.offset.y,b.startOffsetY,accuracy:1e-12);XCTAssertEqual(a.rotation,b.startRotation,accuracy:1e-12)}
        var checked=0
        for sample in item.samples {for plan in plans {let i=plan.tileIndex,b=sample.tiles[i],a=NativeSourceBoardEntryPose.sample(plan,rest:positions[i],rotation:Double(i)*0.01,locked:i != 0,value:[3,0,2][i],seconds:sample.seconds)
            XCTAssertEqual(a.x,b.x,accuracy:0.00000051);XCTAssertEqual(a.y,b.y,accuracy:0.00000051);XCTAssertEqual(a.rotation,b.rotation,accuracy:0.00000051);XCTAssertEqual(a.scale,b.scale,accuracy:0.00000051);XCTAssertEqual(a.alpha,b.alpha,accuracy:0.00000051);checked+=5
        }};XCTAssertEqual(checked,1890)
    }
    func testActualEmptyPlanStillConsumesPresetAndCornerAndRetiredStreamRefuses() {
        var draws=0;let plan=NativeSourceBoardEntryPlan.make(positions:[],maxOffset:128*0.42,random:{draws+=1;return 0.5});XCTAssertEqual(plan,[]);XCTAssertEqual(draws,2)
        var attempts=0;XCTAssertNil(NativeSourceBoardEntryPlan.make(positions:[.zero],maxOffset:53.76,random:{attempts+=1;return attempts==2 ? nil:0.5}));XCTAssertEqual(attempts,2)
    }
}
