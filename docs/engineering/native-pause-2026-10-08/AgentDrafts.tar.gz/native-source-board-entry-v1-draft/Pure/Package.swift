// swift-tools-version:5.9
import PackageDescription
let package=Package(name:"NativeSourceBoardEntry",products:[.library(name:"NativeSourceBoardEntry",targets:["NativeSourceBoardEntry"])],targets:[.target(name:"NativeSourceBoardEntry"),.testTarget(name:"NativeSourceBoardEntryTests",dependencies:["NativeSourceBoardEntry"],resources:[.copy("Resources/SourceBoardEntryV9Oracle.json")])])
