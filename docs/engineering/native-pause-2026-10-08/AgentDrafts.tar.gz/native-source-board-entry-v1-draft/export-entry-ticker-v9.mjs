import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';import {createRequire} from 'node:module';import {createHash} from 'node:crypto';
const repo='/Users/user/cube-crash',out=new URL('.',import.meta.url).pathname.replace(/\/$/,''),tag='production-benchmark-v9',require=createRequire(repo+'/package.json'),ts=require('typescript'),P=require('pixi.js'),gsapFile=require.resolve('gsap/dist/gsap'),gsapRaw=fs.readFileSync(gsapFile,'utf8');
const files=['app-board.ts','board-popin-scheduler.ts','board-popin-transform.ts'],source=Object.fromEntries(files.map(file=>[file,execFileSync('git',['show',tag+':src/modules/'+file],{cwd:repo,encoding:'utf8'})]));
function selected(file,names){const sf=ts.createSourceFile(file,source[file],ts.ScriptTarget.Latest,true),found=[];function visit(n){if(ts.isFunctionDeclaration(n)&&n.name&&names.includes(n.name.text))found.push(n.getText(sf).replace(/^export /,''));if(ts.isVariableStatement(n)&&n.declarationList.declarations.some(d=>names.includes(d.name.getText(sf))))found.push(n.getText(sf));ts.forEachChild(n,visit)}visit(sf);assert.equal(found.length,names.length);return found.join('\n')}
const code=selected('board-popin-scheduler.ts',['POP_IN_PRESETS','clampUnit','createBoardPopInPlan','createBoardPopInHapticSchedule'])+'\n'+selected('board-popin-transform.ts',['settleBoardPopInTileTransform'])+'\n'+selected('app-board.ts',['settleBoardPopInTile','sweetPopIn']);
const cases=[];
for(const awake of [false,true])for(const scenario of ['normal','globalPauseWatchdog','abort']) {
 let wall=0,timerID=0,rafID=0,requests=new Map(),watchdog,draws=0,events=[],halfPose,root,abort,settled=false;
 class FakeDate extends Date{static now(){return wall}}
 const box={Date:FakeDate,Math,console,module:{exports:{}},exports:{},requestAnimationFrame:fn=>{requests.set(++rafID,fn);return rafID},cancelAnimationFrame:id=>requests.delete(id),setTimeout:fn=>{requests.set(++rafID,fn);return rafID},clearTimeout:id=>requests.delete(id)};box.module.exports=box.exports;vm.createContext(box);vm.runInContext(gsapRaw,box);const gsap=box.exports.gsap;
 if(awake){gsap.to({v:0},{v:1,duration:2,ease:'none'});wall=16;gsap.ticker.tick()}else{gsap.ticker.sleep()}
 const values=[3,0,2],tiles=values.map((value,index)=>{const t=new P.Container();t.x=index*148+64;t.y=64;t.rotation=index*.01;t.value=value;t.locked=index!==0;t.rotG=new P.Container();t.base=new P.Container();t.overlay=new P.Container();t.pips=new P.Container();t.rotG.addChild(t.base,t.overlay,t.pips);t.addChild(t.rotG);return t});
 const pose=()=>tiles.map(t=>({x:t.x,y:t.y,rotation:t.rotation,scale:t.scale.x,alpha:t.alpha}));
 const event=name=>events.push({name,wall,tickerSeconds:gsap.ticker.time,animationSeconds:gsap.globalTimeline.time()});
 const math=Object.create(Math);math.random=()=>{const value=[.12,.74,.19,.81,.43][draws%5];draws++;return value};
 const ctx={TILE:128,STATE:{board:1},window:{__ccEnterAnimationActive:true,triggerHapticImpact(){}},Math:math,gsap,console:{log(){},warn(){}},markBoardLifecycle:event,startBoardLifecycleFrameWindow:()=>()=>event('frame-stop'),startBoardEntryPoseDiagnostic:()=>()=>event('diagnostic-stop'),acquirePixiMobileActivityLease:(name,tail)=>{event('acquire:'+name+':'+tail);return()=>event('release')},makeBoard:{syncTileZIndex:(tile,board,entry)=>event('z:'+tiles.indexOf(tile)+':'+!!entry)},drawBoardBG:()=>event('bg'),playBoardPopInSound:duration=>{event('sound:'+duration);return()=>event('sound-stop')},triggerBoardPopInHaptic:()=>event('haptic'),setTimeout:(fn,ms)=>{watchdog={fn,at:wall+ms,id:++timerID};return watchdog.id},clearTimeout:id=>{assert.equal(id,watchdog.id);watchdog=null},trackTimeline:opts=>{root=gsap.timeline(opts);return root},trackDelayedCall:(delay,callback)=>gsap.delayedCall(delay,callback)};
 vm.createContext(ctx);vm.runInContext(ts.transpileModule(code+';globalThis.run=sweetPopIn;', {compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText,ctx);
 const signal={aborted:false,addEventListener(name,fn){abort=fn},removeEventListener(name,fn){assert.equal(fn,abort);abort=null}},promise=ctx.run(tiles,{signal,onHalf:()=>{halfPose=pose();event('half')}});promise.then(()=>{settled=true;event('resolved')});
 const registeredAt=wall,samples=[];
 for(let i=1;i<=95;i++) {
  wall=registeredAt+i*16;
  if(scenario==='globalPauseWatchdog'&&i===6){gsap.globalTimeline.pause();event('global-pause')}
  if(scenario==='abort'&&i===12){assert.ok(abort);abort()}
  if(watchdog&&wall>=watchdog.at){const run=watchdog.fn;event('watchdog');run()}
  gsap.ticker.tick();await Promise.resolve();samples.push({wall,seconds:root.time(),tickerSeconds:gsap.ticker.time,animationSeconds:gsap.globalTimeline.time(),settled,tiles:pose()});
 }
 await promise;assert.equal(events.filter(e=>e.name==='release').length,1);assert.equal(events.filter(e=>e.name==='resolved').length,1);assert.equal(draws,5);
 cases.push({awake,scenario,registeredAt,draws,halfPose,events,samples});gsap.ticker.sleep();for(const tile of tiles)tile.destroy({children:true});
}
fs.writeFileSync(out+'/SourceBoardEntryTickerV9Oracle.json',JSON.stringify({tag,gsapSHA256:createHash('sha256').update(gsapRaw).digest('hex'),hashes:Object.fromEntries(Object.entries(source).map(([file,raw])=>[file,createHash('sha256').update(raw).digest('hex')])),engine:'Isolated real GSAP UMD ticker/globalTimeline with integer Date.now; real Pixi Source targets; literal v9 sweetPopIn/full callbacks. Source wall watchdog/haptic/audio/lifecycle are captured finite observers, no CSSPlugin.',cases},null,2));console.log('PINNED Source parent entry actual ticker6 cases ×95frames =570 +actual half/final .03/watchdog/abort callback ownership PASS');
