import SpriteKit
import UIKit
import StackToSixGameplay

@MainActor
final class NativeDiceNode: SKNode, NativeTileOuterPoseHost, NativeDragShadowHost, NativeRegularStackFrameHost {
    let tileID: String
    private(set) var value: Int
    private(set) var kind: String
    private(set) var variant: String?
    private(set) var sourceWildStateCleared=false
    private(set) var sourceResidualWildPresence=false
    private var sourceWildDestinationFrames:NativeSourceWildDestinationFaceSequence?
    var sourceWildDestinationFrameCount:Int {sourceWildDestinationFrames?.pendingCount ?? 0}
    private(set) var depth: Int
    private(set) var locked: Bool
    private var sourceRegularFrameBinding:NativeRegularStackFrameBinding?
    private weak var sourceRegularFrameService:NativeSourceAnimationClockService?
    private weak var sourceRegularFrameParent:SKNode?
    private var sourceRegularFrameGeneration:UInt64?
    private(set) var sourceCurrentRegularSkin:NativeRegularStackLayout.Skin?
    var sourceMaxStackDepth=1
    var sourceRegularFramePending:Bool {(sourceRegularFrameBinding?.pendingFrameCount ?? 0) > 0 || sourceRestoreEmptyFaceFrame?.active==true}
    var sourcePendingStackFrameCount:Int {sourceRegularFrameBinding?.pendingFrameCount ?? 0}
    var sourceAlive:Bool {!disposed && sourceRegularFrameGeneration==sourceGeneration && parent === sourceRegularFrameParent && parent != nil}
    var sourceValue:Int {get{value}set{guard !disposed else{return};value=newValue}}
    var sourceAlpha:Double {get{Double(alpha)}set{guard !disposed else{return};alpha=CGFloat(newValue)}}
    var sourceLocked:Bool {locked}
    var sourceStackDepth:Int {get{depth}set{guard !disposed else{return};depth=newValue}}
    var sourceBaseScaleX:Double {Double(face.xScale)}
    var sourceBaseScaleY:Double {Double(face.yScale)}
    var sourceBaseAnchorX:Double {Double(face.anchorPoint.x)}
    var sourceBaseAnchorY:Double {Double(1-face.anchorPoint.y)}
    var sourceBaseX:Double {Double(face.position.x)}
    var sourceBaseY:Double {Double(-face.position.y)}
    var sourcePaintedNumbersTexture:SKTexture? {face.texture}
    private(set) var sourceStackRevision:UInt64=0
    var sourceStackContainer:SKNode {stack}
    var sourceStackLayerNodes:[SKNode] {stack.children}
    var sourcePipNodes:[SKNode] {pips.children}
    func sourceNumbersSkinsAvailable()->Set<NativeRegularStackLayout.Skin> {
        Set(NativeRegularStackLayout.Skin.allCases.filter{textures.texture(String($0.rawValue.dropFirst(2)),densityAware:false) != nil})
    }
    // Fresh Source constructor only; never consumes a replacement/hash draw.
    func prepareSourceInitialHolder(rotation:Double,generation:UInt64) -> Bool {
        guard !disposed,kind=="regular",variant==nil,value==0,locked,depth==1,parent != nil,
              let texture=textures.texture("assets/tile.png",densityAware:false) else{return false}
        sourceGeneration=generation;sourceMarkerCoverageGeneration=generation;sourceEventMode="auto"
        face.texture=texture;face.size=texture.size();face.setScale(128/max(1,face.size.width));face.alpha=1
        stack.removeAllChildren();pips.removeAllChildren()
        sourceInnerPosition = .zero;dragInnerTilt=CGFloat(rotation)
        return !disposed && sourceGeneration==generation && parent != nil
    }
    /// Literal fillNullCellsWithLockedPlaceholders applies alpha independently
    /// to the root, rotG and base after the actual zero-holder constructor.
    func prepareSourceMagnetReservedHolder(rotation:Double,generation:UInt64)->Bool {
        guard prepareSourceInitialHolder(rotation:rotation,generation:generation),!disposed else{return false}
        alpha=0.20;visual.alpha=0.20;face.alpha=0.20
        return !disposed && sourceGeneration==generation && parent != nil
    }
    func openSourceInitialHolder(_ value:Int,service:NativeSourceAnimationClockService,
        random:@escaping()->Double,current:@escaping()->Bool,onFinished:@escaping()->Void,
        onCancelled:@escaping()->Void) -> Bool {
        guard !disposed,locked,self.value==0,depth==1,!isSpecial else{return false}
        locked=false;sourceEventMode="static";face.alpha=1
        return queueSourceStackValue(value,addStack:0,service:service,random:random,current:current,
            onFinished:onFinished,onCancelled:onCancelled)
    }
    private var sourceRestoreEmptyFaceID:String?
    private var sourceRestoreEmptyFaceFrame:NativeSourceAnimationClockService.SourceFrameLease?
    /// Literal ordinary restore: constructor was already installed with the
    /// captured tilt. setValue schedules one raw RAF even for a zero holder.
    func restoreSourceRegularHolder(_ tile:NativeTile,service:NativeSourceAnimationClockService,
        random:@escaping()->Double,current:@escaping()->Bool,onFinished:@escaping()->Void,
        onCancelled:@escaping()->Void)->Bool {
        guard !disposed,parent != nil,tile.id==tileID,kind=="regular",variant==nil,
            !tile.isWild,(0...5).contains(tile.value),sourceRestoreEmptyFaceFrame==nil,
            sourceRegularFrameBinding==nil else{return false}
        locked=tile.locked;value=tile.value;depth=1;alpha=CGFloat(tile.alpha);isHidden = !tile.visible
        sourceEventMode=locked ? "none":"static"
        let generation=sourceGeneration,capturedParent=parent
        if tile.value>0 {
            let available=sourceNumbersSkinsAvailable()
            guard available.contains(.base),!disposed,parent === capturedParent else{return false}
            sourceRegularFrameParent=parent;sourceRegularFrameGeneration=generation;sourceMaxStackDepth=1;sourceRegularFrameService=service
            let binding=NativeRegularStackFrameBinding(host:self,service:service,available:available,random:random,current:current)
            sourceRegularFrameBinding=binding
            return binding.setValue(tile.value,addStack:0,onFinished:onFinished,onCancelled:onCancelled)
        }
        let id=UUID().uuidString;sourceRestoreEmptyFaceID=id
        let lease=service.requestSourceAnimationFrame(ownerID:"restore-empty:\(tileID):\(generation)",generation:generation,
            callback:{[weak self] in
                guard let self,self.sourceRestoreEmptyFaceID==id else{return};self.sourceRestoreEmptyFaceFrame=nil;self.sourceRestoreEmptyFaceID=nil
                guard !self.disposed,self.sourceGeneration==generation,self.parent === capturedParent else{onCancelled();return}
                let admitted=current()
                guard admitted,!self.disposed,self.sourceGeneration==generation,self.parent === capturedParent,
                    let texture=self.textures.texture("assets/tile.png",densityAware:false) else{onCancelled();return}
                self.value=0;self.depth=1;self.face.texture=texture;self.face.size=texture.size()
                self.face.xScale=128/max(1,self.face.size.width);self.face.yScale=128/max(1,self.face.size.height)
                self.stack.removeAllChildren();self.pips.removeAllChildren();onFinished()
            },onCancelled:{[weak self] in
                if self?.sourceRestoreEmptyFaceID==id {self?.sourceRestoreEmptyFaceFrame=nil;self?.sourceRestoreEmptyFaceID=nil}
                onCancelled()
            })
        guard let lease,!disposed,sourceGeneration==generation,parent === capturedParent else{lease?.cancel();return false}
        sourceRestoreEmptyFaceFrame=lease
        return lease.active
    }
    // Presentation ownership only; this is not a fabricated Source input,
    // save, idle or spawning marker. Exact captured Root id owns these channels.
    private(set) var sourceBoardEntryBinding:UUID?
    func beginSourceBoardEntryPaint(id:UUID)->Bool {
        guard !disposed,parent != nil,kind=="regular",variant==nil,!isSpecial,
            sourceBoardEntryBinding==nil,!dragging,!sourceResidualWildPresence,
            !sourceOuterOwners.pickupScale,!sourceOuterOwners.snapBack,
            !sourceOuterOwners.mergeImpact,!sourceOuterOwners.isBeingSpawned,
            !sourceOuterOwners.pendingRemoval,!sourceOuterOwners.beingRemoved,
            !sourceOuterOwners.cleanupQueued,!sourceOuterOwners.wildSpawnDropping else{return false}
        sourceBoardEntryBinding=id
        let generation=sourceGeneration,capturedParent=parent
        sourceOuterBridge?.interrupt()
        return !disposed && sourceBoardEntryBinding==id && sourceGeneration==generation && parent === capturedParent
    }
    func paintSourceBoardEntry(id:UUID,position:CGPoint,rotation:Double,scale:Double,alpha:Double) {
        guard !disposed,sourceBoardEntryBinding==id,parent != nil else{return}
        self.position=position;zRotation=CGFloat(rotation);paintSourceOuterScale(CGPoint(x:scale,y:scale));self.alpha=CGFloat(alpha);isHidden=false
    }
    func paintSourceBoardEntryRest(id:UUID,position:CGPoint,rotation:Double) {
        guard !disposed,sourceBoardEntryBinding==id,parent != nil else{return};self.position=position;zRotation=CGFloat(rotation)
    }
    func settleSourceBoardEntry(id:UUID,position:CGPoint,rotation:Double) {
        guard !disposed,sourceBoardEntryBinding==id,parent != nil else{return}
        self.position=position;zRotation=CGFloat(rotation);paintSourceOuterScale(CGPoint(x:1,y:1));isHidden=false
        alpha=locked ? (value>0 ? 0:0.25):1
        visual.alpha=1;face.alpha=1;pips.alpha=1
    }
    func endSourceBoardEntryPaint(id:UUID) {if sourceBoardEntryBinding==id{sourceBoardEntryBinding=nil}}

    func normalizeSourceTutorialInitialTile()->Bool {
        guard !disposed,kind=="regular",variant==nil,!isSpecial,!dragging,
            !sourceRegularFramePending,!sourceResidualWildPresence,parent != nil,
            !sourceOuterOwners.pickupScale,!sourceOuterOwners.snapBack,
            !sourceOuterOwners.mergeImpact,!sourceOuterOwners.isBeingSpawned,
            !sourceOuterOwners.pendingRemoval,!sourceOuterOwners.beingRemoved,
            !sourceOuterOwners.cleanupQueued,!sourceOuterOwners.wildSpawnDropping else{return false}
        let capturedGeneration=sourceGeneration,capturedParent=parent
        // Existing outer owner targets this tile/scale/rotation. Keep driver,
        // shadow and independent raw frames bound; generic retirement is wrong.
        sourceOuterBridge?.interrupt()
        guard !disposed,sourceGeneration==capturedGeneration,parent === capturedParent else{return false}
        depth=1;paintSourceOuterScale(CGPoint(x:1,y:1));visual.setScale(1)
        return !disposed && sourceGeneration==capturedGeneration && parent === capturedParent
    }
    private(set) var sourceTutorialInitialSpawned=false
    func setSourceTutorialInitialValue(_ next:Int)->Bool {
        guard !disposed,kind=="regular",variant==nil,!isSpecial,(1...6).contains(next),parent != nil else{return false}
        sourceTutorialInitialSpawned=true;sourceEventMode="static"
        return forceSourceTutorialInitialValue(next)
    }
    func forceSourceTutorialInitialValue(_ next:Int)->Bool {
        guard !disposed,kind=="regular",variant==nil,!isSpecial,(1...6).contains(next),parent != nil else{return false}
        value=next;locked=false;sourceWildStateCleared=false;sourceResidualWildPresence=false
        isHidden=false;alpha=1;face.isHidden=false;face.alpha=1
        return drawSourceTutorialPips(next)
    }
    @discardableResult func drawSourceTutorialPips(_ next:Int)->Bool {
        guard !disposed,kind=="regular",variant==nil,!isSpecial,parent != nil else{return false}
        pips.removeAllChildren();pips.position = .zero;pips.setScale(1);pips.zRotation=0
        pips.isHidden=false;pips.alpha=1;pips.zPosition=50
        let maps=[1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]]
        let half=128.0*0.42/2,size=15.0,radius=5.0
        for index in maps[max(1,min(6,next))] ?? [4] {
            let x=Double(index%3-1)*half,y = -Double(index/3-1)*half
            let pip=SKShapeNode(rect:CGRect(x:x-size/2,y:y-size/2,width:size,height:size),cornerRadius:radius)
            pip.fillColor=UIColor(red:143.0/255,green:106.0/255,blue:85.0/255,alpha:0.96);pip.strokeColor = .clear
            pips.addChild(pip)
        }
        return true
    }
    func setSourceTutorialInitialFocus(_ focused:Bool)->Bool {
        guard !disposed,kind=="regular",variant==nil,!isSpecial,parent != nil else{return false}
        isHidden=false;sourceEventMode=focused ? "static":"none"
        return !focused || drawSourceTutorialPips(value>0 ? value:1)
    }

    // Captured app-spawn bounce cancellation is a real timeline interruption,
    // not a synthetic Source `_isBeingSpawned`/`_spawnTween` marker.
    private var sourceAppSpawnInterruption:(id:String,pickup:()->Void,interrupted:()->Void)?
    @discardableResult func bindSourceAppSpawnInterruption(id:String,pickup:@escaping()->Void,interrupted:@escaping()->Void)->Bool {
        guard !disposed,sourceAppSpawnInterruption==nil else{return false}
        sourceAppSpawnInterruption=(id,pickup,interrupted);return true
    }
    func unbindSourceAppSpawnInterruption(id:String) {
        guard sourceAppSpawnInterruption?.id==id else{return};sourceAppSpawnInterruption=nil
    }
    private func interruptSourceAppSpawn() {
        let captured=sourceAppSpawnInterruption;sourceAppSpawnInterruption=nil
        captured?.interrupted()
    }
    func ensureSourceAppSpawnFullOpacity() {
        guard !disposed else{return}
        alpha=1;visual.alpha=1;face.alpha=1;pips.alpha=1;pips.isHidden=false
    }
    /// app-spawn.openAtCell normalizes/binds, then Core and immediate setValue,
    /// then the independent raw numbers/pips RAF. No decorative bounce wait.
    func openSourceAppSpawnHolder(_ value:Int,service:NativeSourceAnimationClockService,
        random:@escaping()->Double,current:@escaping()->Bool,frameCurrent:(()->Bool)?=nil,beforeSetValue:()->Bool,
        onCancelled:@escaping()->Void)->Bool {
        guard !disposed,!isSpecial,self.value==0,depth==1,parent != nil,value>0,value<6 else{return false}
        let capturedGeneration=sourceGeneration,capturedParent=parent
        locked=false;sourceEventMode="static";ensureSourceAppSpawnFullOpacity()
        guard beforeSetValue(),!disposed,sourceGeneration==capturedGeneration,parent === capturedParent,current(),
            !disposed,sourceGeneration==capturedGeneration,parent === capturedParent else{return false}
        // The finite Promise caller may retire after arrival. Its token still
        // guards admission above, while the actual retained Node/app-scope
        // frame context owns subsequent setValue/merge face RAFs. Nil keeps the
        // old primitive semantics for callers not genuinely mapped yet.
        return queueSourceStackValue(value,addStack:0,service:service,random:random,current:frameCurrent ?? current,
            onCancelled:onCancelled)
    }
    // Exact retained conversion token; an old cleanup never owns a later C
    // conversion on this same container. It is NOT a Source activity marker.
    private var sourceMagnetConversionRevision:UInt64=0
    var sourceRetainedMagnetConversionRevision:UInt64 {sourceMagnetConversionRevision}
    /// Literal v9 app-merge survivor conversion: this actual container is
    /// normalized/reset before setValue's separate raw numbers RAF. Resources
    /// must already be retained. No hash skin/replacement Node is constructed.
    func convertSourceMagnetSurvivor(position:CGPoint,depthZ:CGFloat,selectValue:()->Int?,
        service:NativeSourceAnimationClockService,driver:NativeTileOuterTimelineDriver,
        random:@escaping()->Double,current:@escaping()->Bool,frameCurrent:@escaping()->Bool,
        beforeSetValue:()->Bool,onCancelled:@escaping()->Void)->Bool {
        guard !disposed,parent != nil,sourcePhysicalMarkersCovered,
              textures.sourceRetainedRegularOpenTexturesReady,
              let tileTexture=textures.texture("assets/tile.png",densityAware:false) else{return false}
        sourceMagnetConversionRevision &+= 1;let revision=sourceMagnetConversionRevision
        let generation=sourceGeneration,capturedParent=parent
        func valid()->Bool {
            guard !disposed,sourceMagnetConversionRevision==revision,sourceGeneration==generation,parent === capturedParent else{return false}
            let accepted=current()
            return accepted && !disposed && sourceMagnetConversionRevision==revision && sourceGeneration==generation && parent === capturedParent
        }
        guard valid() else{return false}
        // Seal family/frame/outer owners before external captured retirement.
        // Suppression is established without rebuild/onResourceReady callbacks.
        sourceIdleDeferred=true;sourceRegistryPending=false;artworkGeneration &+= 1
        let idleScope=sourceSpecialIdle
        idleScope?.retire(self);guard valid() else{return false}
        retireSourceAnimationBindingsPreservingPaint();guard valid() else{return false}
        let phase=artworkPhaseID;artworkPhaseID=nil;artworkRunning=false;artworkElapsed=0
        if let phase {textures.releaseIdlePhase(phase)}
        guard valid() else{return false}
        let oldKanta=kantaIdle,oldMushroom=mushroomSmoke,oldEngine=spaceshipEngine,oldHoney=honeyIdle,oldFizz=idleFizz
        kantaIdle=nil;mushroomSmoke=nil;spaceshipEngine=nil;honeyIdle=nil;idleFizz=nil
        oldKanta?.dispose();guard valid() else{return false}
        oldMushroom?.dispose();guard valid() else{return false}
        oldEngine?.dispose();guard valid() else{return false}
        oldHoney?.dispose();guard valid() else{return false}
        oldFizz?.dispose();guard valid() else{return false}
        self.position=position;zRotation=0;paintSourceOuterScale(CGPoint(x:1,y:1))
        visual.position = .zero;visual.zRotation=0;visual.setScale(1);visual.alpha=1;visual.isHidden=false
        spaceshipRoot.position = .zero;spaceshipRoot.zRotation=0;spaceshipRoot.setScale(1)
        face.removeFromParent();visual.addChild(face)
        face.anchorPoint=CGPoint(x:0.5,y:0.5);face.position = .zero;face.zRotation=0
        face.texture=tileTexture;face.size=CGSize(width:128,height:128);face.setScale(1);face.alpha=1;face.isHidden=false
        shadow.zRotation=0;shadow.setScale(1);shadow.isHidden=false
        // Literal collapse/normalization precedes randomRegularTileValue.
        // Retirement/current hooks may synchronously deliver callbacks; the
        // shared APP draw therefore cannot be precomputed by the caller.
        stack.removeAllChildren();pips.removeAllChildren()
        guard valid(),let value=selectValue(),value>0,value<6,valid() else{return false}
        artwork.isHidden=true;flowerCanvas.isHidden=true;frames=[];paintedFrame = -1;fishMediaReady=false
        kind="regular";variant=nil;sourceWildStateCleared=false;sourceResidualWildPresence=false
        definition=NativeDiceArtwork.definition(kind:"regular",variant:nil,regularSkin:0)
        depth=1;sourceMaxStackDepth=1;locked=false;isHidden=false;alpha=1;sourceEventMode="static";zPosition=depthZ
        sourceCurrentRegularSkin=nil;sourceRegistryPaused=false;sourceIdleDeferred=false
        stack.removeAllChildren();pips.removeAllChildren();pips.position = .zero;pips.setScale(1);pips.zRotation=0;pips.alpha=1;pips.isHidden=false
        installSourceOuterDriver(driver,generation:generation,geometryScale:sourceNativeGeometryScale)
        guard valid() else{return false}
        let capturedFrameCurrent:()->Bool = {[weak self,weak capturedParent] in
            guard let self,let capturedParent,!self.disposed,self.sourceMagnetConversionRevision==revision,
                  self.sourceGeneration==generation,self.parent === capturedParent else{return false}
            let accepted=frameCurrent()
            return accepted && !self.disposed && self.sourceMagnetConversionRevision==revision && self.sourceGeneration==generation && self.parent === capturedParent
        }
        guard beforeSetValue(),valid() else{return false}
        return queueSourceStackValue(value,addStack:0,service:service,random:random,current:capturedFrameCurrent,onCancelled:onCancelled)
    }


    /// Original ONE shared drawStack/drawPips batch reads the immediate value,
    /// and never selects a numbers skin when all initial depths are one.
    func flushSourceInitialHolderVisuals() {
        guard !disposed,!isSpecial,depth==1 else{return}
        stack.removeAllChildren();pips.removeAllChildren()
        pips.position = .zero;pips.setScale(1);pips.zRotation=0;pips.alpha=1;pips.isHidden=false
        guard !locked,value>0 else{return}
        let maps=[1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8]]
        for index in maps[value] ?? [] {
            let x=CGFloat(index%3-1)*25.6,y = -CGFloat(index/3-1)*25.6
            let pip=SKShapeNode(rect:CGRect(x:x-7.5,y:y-7.5,width:15,height:15),cornerRadius:6)
            pip.fillColor=UIColor(red:129.0/255,green:90.0/255,blue:66.0/255,alpha:0.9);pip.strokeColor = .clear
            pips.addChild(pip)
        }
    }
    @discardableResult func queueSourceStackValue(_ value:Int,addStack:Int,service:NativeSourceAnimationClockService,random:@escaping()->Double,current:@escaping()->Bool,onPhysicalCommit:(()->Bool)?=nil,onFinished:(()->Void)?=nil,onCancelled:(()->Void)?=nil)->Bool {
        guard !disposed,!isSpecial,!locked,value>0,value<6,parent != nil else{onCancelled?();return false}
        if sourceRegularFrameBinding==nil {
            let available=sourceNumbersSkinsAvailable()
            guard available.contains(.base),!disposed,parent != nil else{onCancelled?();return false}
            sourceRegularFrameParent=parent;sourceRegularFrameGeneration=sourceGeneration;sourceMaxStackDepth=max(1,depth)
            sourceRegularFrameService=service
            sourceRegularFrameBinding=NativeRegularStackFrameBinding(host:self,service:service,available:available,random:random,current:current)
        }
        return sourceRegularFrameBinding?.setValue(value,addStack:addStack,onPhysicalCommit:onPhysicalCommit,onFinished:onFinished,onCancelled:onCancelled)==true
    }
    func retireSourceStackFrames() {
        if let empty=sourceRestoreEmptyFaceFrame {
            let captured=sourceRegularFrameBinding
            sourceRestoreEmptyFaceFrame=nil;sourceRestoreEmptyFaceID=nil
            sourceRegularFrameBinding=nil;sourceRegularFrameService=nil;sourceRegularFrameParent=nil;sourceRegularFrameGeneration=nil
            retireSourceWildDestinationFrames();empty.cancel();captured?.dispose();return
        }
        retireSourceWildDestinationFrames()
        let captured=sourceRegularFrameBinding
        sourceRegularFrameBinding=nil;sourceRegularFrameService=nil;sourceRegularFrameParent=nil;sourceRegularFrameGeneration=nil
        captured?.dispose()
    }
    func prepareSourceStackSkin(_ skin:NativeRegularStackLayout.Skin) {
        guard sourceAlive,let texture=textures.texture(String(skin.rawValue.dropFirst(2)),densityAware:false) else{return}
        sourceCurrentRegularSkin=skin
        face.texture=texture;face.size=texture.size();face.xScale=128/max(1,face.size.width);face.yScale=128/max(1,face.size.height)
        face.isHidden=false;face.alpha=1
    }
    func installSourceStackFace(_ layout:NativeRegularStackLayout) {
        guard sourceAlive,!isSpecial,!locked else{return}
        installSourceStackLayers(layout)
        pips.removeAllChildren();pips.position = .zero;pips.setScale(1);pips.zRotation=0;pips.alpha=1;pips.isHidden=false
        let maps=[1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]]
        for index in maps[value] ?? [] {
            let x=CGFloat(index%3-1)*25.6,y = -CGFloat(index/3-1)*25.6
            let pip=SKShapeNode(rect:CGRect(x:x-7.5,y:y-7.5,width:15,height:15),cornerRadius:6)
            pip.fillColor=UIColor(red:129.0/255,green:90.0/255,blue:66.0/255,alpha:0.9);pip.strokeColor = .clear
            pips.addChild(pip)
        }
    }
    private func installSourceStackLayers(_ layout:NativeRegularStackLayout) {
        guard sourceAlive,!isSpecial,!locked,let texture=face.texture else{return}
        sourceStackRevision &+= 1;stack.removeAllChildren()
        for layer in layout.layers {
            let container=SKNode();container.name="source-stack-layer-\(layer.index)"
            container.position=CGPoint(x:layer.x,y:-layer.y);container.zRotation = -layer.rotation;container.zPosition=CGFloat(layer.z)
            let sprite=SKSpriteNode(texture:texture);sprite.anchorPoint=CGPoint(x:layer.anchorX,y:1-layer.anchorY)
            sprite.xScale=layer.spriteScaleX;sprite.yScale=layer.spriteScaleY;sprite.alpha=layer.spriteAlpha
            container.addChild(sprite)
            let rectangle=CGRect(x:-layer.size/2,y:-layer.size/2,width:layer.size,height:layer.size)
            let overlay=SKShapeNode(rect:rectangle,cornerRadius:layer.overlayRadius)
            overlay.fillColor=UIColor(red:139.0/255,green:90.0/255,blue:43.0/255,alpha:1);overlay.strokeColor = .clear;overlay.alpha=layer.overlayAlpha
            container.addChild(overlay);stack.addChild(container)
        }
    }
    func sourceMergeSixFaceReady(service:NativeSourceAnimationClockService)->Bool {sourceAlive && sourceRegularFrameService === service && sourceRegularFrameBinding?.sourceAdmissionOpen==true && !isSpecial && !locked && sourceCurrentRegularSkin != nil && service.sourceFrameTransportAdmissionOpen && sourceNumbersSkinsAvailable().contains(.base)}
    /// Original setValue6 queues its skin draw; immediate drawStack uses the
    /// already painted skin and changes no pips before that genuine RAF.
    func prepareSourceMergeSixFace(depth:Int,final:Bool,usesSourceDestinationParentState:Bool=false,service:NativeSourceAnimationClockService,
        random:@escaping()->Double,onFaceCancelled:@escaping()->Void)->Bool {
        guard sourceMergeSixFaceReady(service:service),let binding=sourceRegularFrameBinding,let skin=sourceCurrentRegularSkin else{return false}
        guard binding.setValue(6,addStack:0,onCancelled:onFaceCancelled),sourceAlive else{return false}
        sourceStackDepth=final ? 1:min(4,max(1,depth))
        let layout=NativeRegularStackLayout.captureLayers(depth:sourceStackDepth,skin:skin,baseX:sourceBaseX,baseY:sourceBaseY,
            baseScaleX:sourceBaseScaleX,baseScaleY:sourceBaseScaleY,anchorX:sourceBaseAnchorX,anchorY:sourceBaseAnchorY,random:random)
        guard sourceAlive else{return false}
        installSourceStackLayers(layout);sourceEventMode="none";zPosition=10000
        if usesSourceDestinationParentState {
            alpha=1
            if final {visual.isHidden=true;shadow.isHidden=true}
        } else if final {isHidden=true}
        return sourceAlive
    }
    /// Narrow literal normal core-Magnet→regular-dst prefix. The authentic
    /// protected face RAF keeps its old painted skin; no variant conversion or
    /// retained Wild backing is guessed here.
    func prepareSourceMagnetRegularDestination(_ plan:NativeSpecialMovePlan,
        service:NativeSourceAnimationClockService,random:@escaping()->Double,onFaceCancelled:@escaping()->Void)->Bool {
        guard plan.archetype == .magnet,plan.variant==nil,plan.source.gameplayArchetype == .magnet,
              !plan.destination.isWild,plan.destination.variant==nil,plan.destination.id==tileID,
              plan.generation==sourceGeneration,!sourceResidualWildPresence else{return false}
        guard prepareSourceMergeSixFace(depth:min(4,plan.source.stackDepth+plan.destination.stackDepth),final:false,
            usesSourceDestinationParentState:true,service:service,random:random,onFaceCancelled:onFaceCancelled) else{return false}
        sourceWildStateCleared=true;sourceResidualWildPresence=false
        return sourceAlive
    }
    var sourceFinalResultChildrenHidden:Bool {visual.isHidden && shadow.isHidden}
    /// Prefix for the already-bound actual regular destination. A Wild
    /// destination is refused until its genuine retained regular backing is
    /// available; retained metadata must never restart a family idle owner.
    func prepareSourceDirectWildRegularDestination(_ prefix:NativeSourceDirectWildPrefixReceipt,
        service:NativeSourceAnimationClockService,random:@escaping()->Double,
        onFaceCancelled:@escaping()->Void)->Bool {
        guard prefix.preparedDestination.id==tileID,prefix.generation==sourceGeneration,
              prefix.preparedDestination.sourceWildStateCleared,
              prefix.originalDestination.variant==nil,!prefix.originalDestination.isWild,
              sourceMergeSixFaceReady(service:service) else{return false}
        guard prepareSourceMergeSixFace(depth:prefix.preparedDestination.stackDepth,
            final:prefix.isFinal,service:service,random:random,
            onFaceCancelled:onFaceCancelled) else{return false}
        sourceWildStateCleared=true
        if prefix.isFinal {
            // Literal hideFinal suppresses children, never parent visibility.
            // The preceding regular helper's whole-node hide is legacy-only.
            isHidden = !prefix.preparedDestination.visible
            visual.isHidden=true;shadow.isHidden=true
        }
        return sourceAlive
    }

    /// Only actual variant-nil core Star/Juice backing; no numbers decode or
    /// synthetic regular skin. First-face preparation upload belongs to Scene.
    func sourceWildDestinationFaceReady(service:NativeSourceAnimationClockService)->Bool {
        !disposed && sourceOuterDriven && parent != nil && variant==nil && !locked &&
        (kind == "wild" || kind == "wild-juice") && !sourceWildStateCleared &&
        !sourceResidualWildPresence && sourceWildDestinationFrames==nil && face.texture != nil &&
        service.sourceFrameTransportAdmissionOpen
    }
    func retireSourceWildDestinationFrames() {
        let captured=sourceWildDestinationFrames;sourceWildDestinationFrames=nil
        captured?.dispose()
    }
    func hideSourceWildDestinationFinalChildren() {
        guard !disposed,sourceWildStateCleared else{return}
        depth=1;stack.removeAllChildren();pips.removeAllChildren();pips.isHidden=true
        visual.isHidden=true;shadow.isHidden=true
        sourceSpecialIdle?.retire(self)
    }
    @discardableResult func prepareSourceDirectWildDestination(
        prefix:NativeSourceDirectWildPrefixReceipt,faceReceipt:NativeSourceWildDestinationFaceReceipt,
        preparedStarTexture:SKTexture,service:NativeSourceAnimationClockService,
        random:@escaping()->Double,current:@escaping()->Bool,
        commitPhysical:@escaping()->Bool,onFacePainted:@escaping()->Void,onFaceCancelled:@escaping()->Void)->Bool {
        guard prefix.preparedDestination.id==tileID,prefix.generation==sourceGeneration,
              faceReceipt.transactionID==prefix.id,faceReceipt.beforeFace==prefix.preparedDestination,
              prefix.originalDestination.isWild,prefix.originalDestination.variant==nil,
              sourceWildDestinationFaceReady(service:service),current(),!disposed else{return false}
        let generation=sourceGeneration,capturedParent=parent
        let capturedTexture=face.texture,capturedWidth=face.size.width*face.xScale,capturedHeight=face.size.height*face.yScale
        guard let capturedTexture,capturedParent != nil else{return false}
        // Normalize SpriteKit logical .size into Source raw texture + scale;
        // the same actual Sprite/texture and painted dimensions are retained.
        face.size=capturedTexture.size()
        face.xScale=capturedWidth/max(1,face.size.width);face.yScale=capturedHeight/max(1,face.size.height)
        value=6;depth=prefix.preparedDestination.stackDepth;kind="regular";sourceWildStateCleared=true
        sourceResidualWildPresence=false;sourceEventMode="none";alpha=1;isHidden = !prefix.preparedDestination.visible
        zPosition=10000
        // Layer installation borrows existing base geometry, not a skin draw.
        sourceRegularFrameParent=parent;sourceRegularFrameGeneration=generation
        weak var capturedOwner:NativeSourceWildDestinationFaceSequence?
        let valid:() -> Bool = { [weak self] in
            guard let self,!self.disposed,self.sourceWildDestinationFrames === capturedOwner,
                  self.sourceGeneration==generation,self.parent === capturedParent else{return false}
            let accepted=current()
            return accepted && !self.disposed && self.sourceWildDestinationFrames === capturedOwner &&
                self.sourceGeneration==generation && self.parent === capturedParent
        }
        let owner=NativeSourceWildDestinationFaceSequence(request:{name,callback,cancelled in
            guard let lease=service.requestSourceAnimationFrame(ownerID:faceReceipt.id+":"+name,
                generation:generation,callback:callback,onCancelled:cancelled) else{return nil}
            return {lease.cancel()}
        },hooks:.init(current:valid,firstFace:{[weak self] in
            guard let self,valid() else{return false}
            guard commitPhysical(),valid() else{onFaceCancelled();return false}
            self.face.texture=preparedStarTexture;self.face.size=preparedStarTexture.size()
            self.face.anchorPoint=CGPoint(x:0.5,y:0.5)
            self.face.xScale=128/max(1,self.face.size.width);self.face.yScale=128/max(1,self.face.size.height)
            self.face.alpha=1;self.face.isHidden=false;self.artwork.isHidden=true
            self.sourceResidualWildPresence=true;self.depth=1;self.stack.removeAllChildren()
            self.pips.removeAllChildren();self.pips.isHidden=true;self.shadow.isHidden=true
            onFacePainted();return valid()
        },immediateStack:{[weak self] in
            guard let self,valid() else{return false}
            let layout=NativeRegularStackLayout.captureLayers(depth:self.depth,skin:.base,
                baseX:self.sourceBaseX,baseY:self.sourceBaseY,baseScaleX:self.sourceBaseScaleX,
                baseScaleY:self.sourceBaseScaleY,anchorX:self.sourceBaseAnchorX,anchorY:self.sourceBaseAnchorY,random:random)
            guard valid() else{return false}
            self.installSourceStackLayers(layout);return valid()
        },nestedPipsCheck:{[weak self] in
            guard let self,valid(),self.value==6,!self.sourceResidualWildPresence else{return}
            if prefix.isFinal {self.hideSourceWildDestinationFinalChildren()}else{self.pips.isHidden=false}
        },hideFinal:{[weak self] in self?.hideSourceWildDestinationFinalChildren()},stopIdle:{[weak self] in
            guard let self,valid() else{return};self.sourceSpecialIdle?.retire(self)
        }))
        capturedOwner=owner;sourceWildDestinationFrames=owner
        let started=owner.start(final:prefix.isFinal,juice:prefix.originalDestination.gameplayArchetype == .juice)
        guard started,valid() else {if sourceWildDestinationFrames === owner {retireSourceWildDestinationFrames()};return false}
        return true
    }

    let visual = SKNode()
    private let face = SKSpriteNode()
    private let pips = SKNode()
    private let stack = SKNode()
    private let shadow = SKSpriteNode()
    private let sourceShadowContainer=SKNode()
    private var sourceShadowOwner:NativeDragShadowPresentationOwner?
    var sourceContactNodeAlive:Bool {!disposed}
    // Actual Source selected-locked-slot writer. The app-spawn wrapper never
    // creates _spawnTween/_isBeingSpawned; an action/lease is not a marker.
    private var sourceLockedSpawnMarkers:Set<String>=[]
    // Only actual Source constructors establish absence of the legacy spawn
    // aliases. A generic Native node/action cannot declare missing fields false.
    private var sourceMarkerCoverageGeneration:UInt64?
    var sourcePhysicalMarkersCovered:Bool {
        !disposed && sourceMarkerCoverageGeneration==sourceGeneration && sourceOuterDriven
    }
    func beginSourceLockedSpawnMarker(id:String)->Bool {
        guard sourcePhysicalMarkersCovered,!isSpecial,locked,value==0,parent != nil else{return false}
        return sourceLockedSpawnMarkers.insert(id).inserted
    }
    func clearSourceLockedSpawnMarker(id:String){sourceLockedSpawnMarkers.remove(id)}
    /// Save-only borrow. These are genuine Node/Core-owned marker fields;
    /// caller still requires a covered Source roster and global-owner capture.
    /// This does NOT mount the two global marker capabilities on its own.
    func captureSourceSaveTileMarkers(model:NativeTile,runtime:NativeNoMovesTileRuntime?)->NativeSourceSaveTileMarkers? {
        guard sourcePhysicalMarkersCovered,parent != nil,tileID==model.id else{return nil}
        var markers=NativeSourceSaveTileMarkers()
        markers.destroyed=runtime?.destroyed==true
        markers.wildSpawnDropping=runtime?.wildDropping==true
        markers.wildSpawnHandoffLock=runtime?.wildHandoff==true
        markers.isBeingSpawned = !sourceLockedSpawnMarkers.isEmpty
        markers.pendingRemoval=model.pendingRemoval
        markers.beingRemoved=runtime?.beingRemoved==true;markers.cleanupQueued=runtime?.cleanupQueued==true
        // Literal app-spawn / actual Source constructor and locked-open paths
        // do not assign the three aliases or _spawnTween. NativeSource physical
        // roster admission must not include unmapped animateTileSpawn/drag-anim.
        markers.ccSpawnAnimating=false;markers.spawnAnimating=false;markers.isSpawning=false;markers.hasSpawnTween=false
        return markers
    }
    /// Same retained object, actual immediate value/input/painted fields. Core
    /// metadata below is read from its actual lifecycle writers, never inferred
    /// from pendingSpecial/pendingDirectWild/animation lifetime.
    func captureSourceMagnetPhysical(model:NativeTile,runtime:NativeNoMovesTileRuntime?,lastMerge:Bool)->NativeSourceMagnetPhysicalTile? {
        guard sourcePhysicalMarkersCovered,parent != nil,tileID==model.id else{return nil}
        let archetype:NativeSourceMagnetPhysicalTile.Kind
        switch sourceResidualWildPresence ? "wild":(sourceWildStateCleared ? "regular":kind) {
        case "regular":archetype = .regular
        case "wild":archetype = .star
        case "wild-juice":archetype = .juice
        case "wild-magnet":archetype = .magnet
        case "wild-tnt":archetype = .tnt
        default:return nil
        }
        return .init(id:tileID,value:value,depth:depth,locked:locked,visible:!isHidden,
            alpha:Double(alpha),eventMode:sourceEventMode,kind:archetype,
            destroyed:runtime?.destroyed==true,magnetAffected:model.magnetOwned,
            pendingRemoval:model.pendingRemoval,beingRemoved:runtime?.beingRemoved==true,
            cleanupQueued:runtime?.cleanupQueued==true,wildHandoff:runtime?.wildHandoff==true,
            isBeingSpawned:!sourceLockedSpawnMarkers.isEmpty,spawnTweenActive:nil,lastMerge:lastMerge)
    }
    private var sourceMagnetPullNodeToken:UUID?
    var sourceMagnetPullProtected:Bool {sourceMagnetPullNodeToken != nil}
    @discardableResult func protectSourceMagnetPull(token:UUID,generation:UInt64,current:()->Bool)->Bool {
        guard sourcePhysicalMarkersCovered,sourceGeneration==generation,sourceMagnetPullNodeToken==nil,parent != nil else{return false}
        sourceMagnetPullNodeToken=token // seal identity BEFORE actual idle stop callbacks.
        locked=true;sourceEventMode="none";sourceSkipIdleScaleReset=true
        sourceSpecialIdle?.retire(self)
        guard !disposed,sourceMagnetPullNodeToken==token,sourceGeneration==generation else{return false}
        let accepted=current()
        return accepted && !disposed && sourceMagnetPullNodeToken==token && sourceGeneration==generation
    }
    @discardableResult func prepareSourceMagnetPullScale(token:UUID,generation:UInt64)->Bool {
        guard !disposed,sourceMagnetPullNodeToken==token,sourceGeneration==generation else{return false}
        // Literal pull child creation kills SCALE tweens only. Its ordinary
        // idle rotation/callback root is not replaced by a generic interrupt.
        killSourceActiveScaleChildren()
        return !disposed && sourceMagnetPullNodeToken==token && sourceGeneration==generation
    }
    @discardableResult func releaseSourceMagnetPull(token:UUID,generation:UInt64,restore:Bool)->Bool {
        guard !disposed,sourceMagnetPullNodeToken==token,sourceGeneration==generation else{return false}
        sourceMagnetPullNodeToken=nil;sourceSkipIdleScaleReset=false
        if restore {locked=false;sourceEventMode="static"}
        return true
    }
    var sourceContactLastStackLayer:SKNode? {stack.children.last}
    func sourceKillInnerContactTweens(){sourceShadowOwner?.cancelInnerTiltReturn()}
    var sourceEventMode="static"
    private let artwork = SKSpriteNode()
    private let flowerCanvas = SKNode()
    private let flowerRoot = SKNode()
    private let flowerScale = SKNode()
    private let flowerRotation = SKNode()
    private let flowerArt = SKSpriteNode()
    private var kantaIdle: NativeKantaDiceIdle?
    private var mushroomSmoke:NativeMushroomDiceSmoke?
    private var spaceshipEngine:NativeSpaceshipDiceIdle?
    private var honeyIdle:NativeHoneyDiceIdle?
    private(set) var sourceIdleDeferred:Bool
    private var fishMediaReady=false
    private var idleFizz:NativeIdleBubbleField?
    private let spaceshipRoot=SKNode()
    private let textures: NativeBoardTextures
    private var definition: NativeDiceArtwork
    private var frames: [SKTexture] = []
    private var paintedFrame = -1
    private var artworkGeneration = 0
    private var disposed = false
    private var cuberoElapsed:TimeInterval = 0
    private var bottleElapsed:TimeInterval = 0
    private var spaceshipElapsed:TimeInterval = 0
    private var elapsed: TimeInterval = 0
    private var dragging = false
    private var sourceRegistryPending=false,sourceRegistryPaused=false
    private weak var sourceSpecialIdle:NativeSourceSpecialIdleScope?
    private var artworkPhaseID:Int?
    private var artworkRunning=false,artworkElapsed:TimeInterval=0
    // PRIVATE injected outer owner: no Source driver creation here.
    private var sourceOuterBridge:NativeTileOuterNodeBridge?
    private var sourceOuterBindingID:UUID?,sourceBindingRevision:UInt64=0
    private var sourceNativeGeometryScale:CGFloat=1
    private(set) var sourceGeneration:UInt64=0
    var sourceSkipIdleScaleReset=false
    var sourceTileID:String {tileID}
    var sourceLocalScale:CGPoint {CGPoint(x:xScale/sourceNativeGeometryScale,y:yScale/sourceNativeGeometryScale)}
    var sourceLocalPosition:CGPoint {position}
    var sourceRotation:CGFloat {-zRotation}
    var sourceOuterDriven:Bool {sourceOuterBridge != nil}
    var sourceOuterReceipt:NativeTileOuterReceipt? {sourceOuterBridge?.receipt}
    var sourceOuterOwners:NativeTileOuterEligibility.Owners {sourceOuterBridge?.owners ?? .init()}
    var sourceIdleTimelinePresent:Bool {sourceOuterBridge?.idleTimelinePresent == true}
    var sourceActiveIdle:Bool {sourceOuterBridge?.activeIdle==true}
    func beginSourceMergeImpact(_ motion:NativeMergeImpactMotion)->Bool {sourceOuterBridge?.mergeImpact(motion) ?? false}
    func killSourceActiveScaleChildren(){sourceOuterBridge?.killActiveScaleChildren()}
    func paintSourceIdleRotation(_ rotation:CGFloat){guard !disposed else{return};zRotation = -rotation}
    func paintSourceOuterPositionRotation(_ pose:NativeTileOuterMotion.Pose){guard !disposed else{return};position=pose.position;zRotation = -pose.rotation}
    func installSourceOuterDriver(_ driver:NativeTileOuterTimelineDriver,generation:UInt64,geometryScale:CGFloat) {
        guard !disposed else{return}
        if sourceGeneration != generation {
            let outer=sourceOuterBridge,shadow=sourceShadowOwner
            sourceOuterBridge=nil;sourceShadowOwner=nil;sourceOuterBindingID=nil;sourceBindingRevision &+= 1
            let retiredRevision=sourceBindingRevision
            outer?.dispose();shadow?.dispose()
            guard !disposed,sourceBindingRevision==retiredRevision,sourceOuterBridge==nil,sourceShadowOwner==nil else{return}
        }
        let local=sourceOuterBridge == nil ? CGPoint(x:1,y:1):sourceLocalScale
        sourceGeneration=generation;sourceNativeGeometryScale=geometryScale;paintSourceOuterScale(local)
        if sourceOuterBridge==nil {
            let bindingID=UUID();sourceOuterBindingID=bindingID;sourceBindingRevision &+= 1
            sourceOuterBridge=NativeTileOuterNodeBridge(host:self,driver:driver,canonicalBase:CGPoint(x:1,y:1),bindingCurrent:{[weak self] in self?.disposed==false && self?.sourceOuterBindingID==bindingID})
        }
    }
    func retireSourceAnimationBindingsPreservingPaint() {
        guard !disposed,sourceOuterBridge != nil || sourceShadowOwner != nil || sourceRegularFrameBinding != nil || sourceWildDestinationFrames != nil || sourceRestoreEmptyFaceFrame != nil else{return}
        retireSourceStackFrames()
        guard !disposed else{return}
        let generation=sourceGeneration,parent=self.parent,position=self.position,x=xScale,y=yScale,rotation=zRotation,innerPosition=visual.position,innerRotation=visual.zRotation
        let outer=sourceOuterBridge,shadowOwner=sourceShadowOwner
        sourceOuterBridge=nil;sourceShadowOwner=nil;sourceOuterBindingID=nil;sourceBindingRevision &+= 1 // unhook before captured callbacks
        let retiredRevision=sourceBindingRevision
        outer?.dispose();shadowOwner?.dispose()
        guard !disposed,sourceGeneration==generation,self.parent === parent,sourceBindingRevision==retiredRevision,sourceOuterBridge==nil,sourceShadowOwner==nil else{return}
        self.position=position;xScale=x;yScale=y;zRotation=rotation;visual.position=innerPosition;visual.zRotation=innerRotation
    }
    func synchronizeSourceGeometry(_ scale:CGFloat) {
        guard sourceOuterDriven else{setScale(scale);return}
        let local=sourceLocalScale;sourceNativeGeometryScale=scale;paintSourceOuterScale(local)
    }
    func restoreSourceOuterForAcceptedDrop(){sourceOuterBridge?.restoreForAcceptedDrop()}
    func paintSourceOuter(_ pose:NativeTileOuterMotion.Pose) {
        guard !disposed else{return}
        position=pose.position;paintSourceOuterScale(pose.scale);zRotation = -pose.rotation
    }
    func paintSourceOuterPosition(_ position:CGPoint) {guard !disposed else{return};self.position=position}
    func paintSourceOuterScale(_ scale:CGPoint) {
        guard !disposed else{return}
        xScale=sourceNativeGeometryScale*scale.x;yScale=sourceNativeGeometryScale*scale.y
    }
    func paintSourceIdle(_ pose:NativeRegularIdleMotion.Pose) {
        guard !disposed else{return}
        paintSourceOuterScale(CGPoint(x:pose.x,y:pose.y));zRotation = -pose.rotation
    }
    func beginSourcePickup()->Bool {
        sourceAppSpawnInterruption?.pickup()
        guard !disposed else{return false}
        return sourceOuterBridge?.pickup() ?? false
    }
    func beginSourceReturn(to destination:CGPoint,onCompleted:@escaping()->Void)->Bool {sourceOuterBridge?.snapBack(to:destination,onCompleted:onCompleted) ?? false}
    func beginSourceIdle(_ motion:NativeRegularIdleMotion,release:@escaping()->Void,onSmoke:@escaping()->Void,onFinished:@escaping()->Void)->Bool {
        guard let bridge=sourceOuterBridge else{release();return false}
        return bridge.idle(motion,releaseSourceFrames:release,onSmoke:onSmoke,onFinished:onFinished)
    }
    func interruptSourceOuter(){sourceOuterBridge?.interrupt()}
    func interruptSourceOuter(receipt:NativeTileOuterReceipt){sourceOuterBridge?.interrupt(receipt:receipt)}
    // Literal Source topology: shadow container lift scale/alpha wraps the
    // existing immutable PNG; inner appearance scale does not scale its offset.
    var dragShadowTileID:String {tileID}
    var dragShadowGeneration:UInt64 {sourceGeneration}
    var dragShadowIsWild:Bool {isSpecial}
    var dragShadowAlpha:CGFloat {
        get {sourceShadowContainer.alpha}
        set {sourceShadowContainer.alpha=newValue}
    }
    var dragShadowLiftScale:CGFloat {
        get {sourceShadowContainer.xScale}
        set {sourceShadowContainer.setScale(newValue)}
    }
    var dragShadowVisible:Bool {
        get {!sourceShadowContainer.isHidden}
        set {sourceShadowContainer.isHidden = !newValue}
    }
    var sourceInnerPosition:CGPoint {
        get {let center=NativeDragShadowPose.center(tilt:dragInnerTilt);return CGPoint(x:visual.position.x-center.x,y:visual.position.y+center.y)}
        set {let center=NativeDragShadowPose.center(tilt:dragInnerTilt);visual.position=CGPoint(x:newValue.x+center.x,y:newValue.y-center.y)}
    }
    var dragInnerTilt:CGFloat {
        get {-visual.zRotation}
        set {
            let baseline=sourceInnerPosition
            visual.zRotation = -newValue
            // Native center conversion composes the independently captured
            // rotG position channel with Source top-center pivot(-64).
            let center=NativeDragShadowPose.center(tilt:newValue)
            visual.position=CGPoint(x:baseline.x+center.x,y:baseline.y-center.y)
        }
    }
    func paintDragShadow(_ pose:NativeDragShadowPose) {
        guard !disposed else{return}
        shadow.position=CGPoint(x:pose.position.x,y:-pose.position.y)
        shadow.setScale(pose.appearanceScale);shadow.zRotation=0
    }
    func installSourceDragTweenDriver(_ driver:NativeDragTweenDriver) {
        guard !disposed,sourceShadowOwner==nil else{return}
        sourceBindingRevision &+= 1
        shadow.removeFromParent();sourceShadowContainer.addChild(shadow)
        sourceShadowContainer.zPosition = -20;sourceShadowContainer.alpha=0;sourceShadowContainer.isHidden=true
        shadow.alpha=1;shadow.zPosition=0;if sourceShadowContainer.parent==nil {addChild(sourceShadowContainer)}
        sourceShadowOwner=NativeDragShadowPresentationOwner(host:self,driver:driver)
    }
    private var sourceKeepsInnerIdle:Bool {variant == "spaceship"}
    func sourcePointerDown() {
        if !sourceKeepsInnerIdle {sourceShadowOwner?.cancelInnerTiltReturn()}
        sourceShadowOwner?.pickup()
    }
    func sourcePointerMoved(filteredVelocity:CGPoint) {
        guard sourceShadowOwner != nil,dragging else{return}
        if !sourceKeepsInnerIdle {
            let target=max(-0.16,min(0.16,-filteredVelocity.x*18))
            dragInnerTilt += (target-dragInnerTilt)*0.18
        }
        sourceShadowOwner?.update(filteredVelocity:filteredVelocity)
    }
    func sourcePointerUp(){sourceShadowOwner?.release(keepsInnerIdle:sourceKeepsInnerIdle)}
    func sourceSnapBackCompleted(){sourceShadowOwner?.snapBackCompleted()}
    var onResourceReady: (() -> Void)?

    init(id: String, value: Int, kind: String, variant: String?, depth: Int, locked: Bool,
         textures: NativeBoardTextures, deferSourceIdle:Bool=false,sourceSpecialIdle:NativeSourceSpecialIdleScope?=nil) {
        sourceIdleDeferred=deferSourceIdle
        self.sourceSpecialIdle=sourceSpecialIdle
        sourceRegistryPending=sourceSpecialIdle != nil && (kind != "regular" && kind != "normal" && kind != "" || variant.flatMap{NativeSpecialDiceRegistry.variants[$0]} != nil)
        tileID = id; self.value = value; self.kind = kind; self.variant = variant
        self.depth = depth; self.locked = locked; self.textures = textures
        let hash = id.utf8.reduce(UInt64(5381)) { ($0 &* 33) &+ UInt64($1) }
        definition = NativeDiceArtwork.definition(kind: kind, variant: variant, regularSkin: Int(hash % 4))
        super.init()
        name = "native-die-\(id)"
        visual.name = "die-visual"
        shadow.texture = textures.texture("assets/shadow.png")
        shadow.size = CGSize(width: 128 * 1.42 * 0.7 * 1.1, height: 128 * 1.42 * 0.7 * 1.1)
        shadow.alpha = 0; shadow.zPosition = -20
        addChild(shadow); addChild(visual)
        visual.addChild(stack); visual.addChild(face); visual.addChild(pips); visual.addChild(artwork)
        visual.addChild(spaceshipRoot)
        visual.addChild(flowerCanvas); flowerCanvas.zPosition = 2; flowerCanvas.isHidden = true
        flowerCanvas.addChild(flowerRoot); flowerRoot.addChild(flowerScale)
        flowerScale.addChild(flowerRotation); flowerRotation.addChild(flowerArt)
        stack.zPosition = -5; pips.zPosition = 1; artwork.zPosition = 2
        rebuild()
        if let sourceSpecialIdle {_ = configureSourceSpecialIdle(sourceSpecialIdle)}
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    var hasAnimatedArtwork: Bool {
        !disposed && !sourceWildStateCleared && !sourceRegistryPaused && !sourceIdleDeferred && !sourceRegistryPending && ((!frames.isEmpty && definition.idleSheet != nil) || variant == "bee" || variant == "flower" || variant == "cubero" || variant == "bottle" || variant == "spaceship" || variant == "fish" && artworkPhaseID != nil && !artworkRunning || honeyIdle?.hasActiveMotion==true || idleFizz?.isRunning==true || mushroomSmoke != nil || kantaIdle?.assetReady == true)
    }
    var hasPresentationActions: Bool { hasActions() || visual.hasActions() || shadow.hasActions() }
    var resourcePaths: Set<String> {
        var paths: Set<String> = [definition.path, "assets/shadow.png"]
        if let sheet = definition.idleSheet { paths.insert(sheet.path) }
        if variant == "kanta" { paths.formUnion(["assets/shop/kanta/02.png","assets/shop/kanta/04.png"]) }
        if variant == "flower" { paths.insert("assets/shop/bush/flower-pixi-source.png") }
        if variant == "spaceship" {paths.formUnion((1...4).map {"assets/shop/spaceship/spaceship-idle\($0).png"})}
        if variant == "honey" {paths.formUnion((1...7).map {"assets/shop/honey/bee\($0).png"})}
        return paths
    }

    func update(value: Int, kind: String, variant: String?, depth: Int, locked: Bool) {
        guard !disposed else { return }
        if sourceWildDestinationFrames != nil {return} // Exact captured face owns these fields through main.
        if sourceRegularFramePending,kind==self.kind,variant==self.variant,locked==self.locked,!isSpecial {self.value=value;return}
        if sourceRegularFrameBinding != nil && (kind != self.kind || variant != self.variant || locked != self.locked) {retireSourceStackFrames()}
        guard !disposed else{return}
        guard self.value != value || self.kind != kind || self.variant != variant || self.depth != depth || self.locked != locked else { return }
        if self.kind != kind || self.variant != variant {
            sourceSpecialIdle?.retire(self);sourceRegistryPaused=false
            sourceRegistryPending=sourceSpecialIdle != nil && (kind != "regular" && kind != "normal" && kind != "" || variant.flatMap{NativeSpecialDiceRegistry.variants[$0]} != nil)
        }
        self.value = value; self.depth = depth; self.locked = locked
        let identityChanged = self.kind != kind || self.variant != variant
        self.kind = kind; self.variant = variant
        if identityChanged {
            if let id=artworkPhaseID {textures.releaseIdlePhase(id)}
            fishMediaReady=false
            artworkPhaseID=nil;artworkRunning=false;artworkElapsed=0
            kantaIdle?.dispose(); kantaIdle = nil;mushroomSmoke?.dispose();mushroomSmoke=nil;spaceshipEngine?.dispose();spaceshipEngine=nil;honeyIdle?.dispose();honeyIdle=nil;idleFizz?.dispose();idleFizz=nil
            let hash = tileID.utf8.reduce(UInt64(5381)) { ($0 &* 33) &+ UInt64($1) }
            definition = NativeDiceArtwork.definition(kind: kind, variant: variant, regularSkin: Int(hash % 4))
            elapsed = 0; cuberoElapsed = 0; bottleElapsed=0;spaceshipElapsed=0;spaceshipRoot.position = .zero;spaceshipRoot.zRotation=0;face.position = .zero; face.zRotation = 0; frames = []; paintedFrame = -1
        }
        rebuild()
        if let scope=sourceSpecialIdle {_ = configureSourceSpecialIdle(scope)}
    }

    private func rebuild() {
        if !sourceIdleDeferred && !sourceRegistryPending,idleFizz==nil,let family=NativeIdleBubbleMotion.family(kind:kind,variant:variant) {
            let field=NativeIdleBubbleField(family:family);idleFizz=field;visual.addChild(field)
        }
        face.texture = textures.texture(value == 0 && !isSpecial ? "assets/tile.png" : definition.path)
        face.size = definition.size; face.anchorPoint = definition.anchor
        let faceHost=variant == "spaceship" ? spaceshipRoot:visual
        if face.parent !== faceHost {face.removeFromParent();faceHost.addChild(face)}
        face.isHidden = false; artwork.isHidden = true
        paintFishVisibility()
        flowerCanvas.isHidden = true
        if !sourceIdleDeferred && !sourceRegistryPending,variant == "spaceship",spaceshipEngine==nil {
            let engine=NativeSpaceshipDiceIdle();spaceshipEngine=engine;spaceshipRoot.addChild(engine);engine.zPosition = -2
        }
        if !sourceIdleDeferred && !sourceRegistryPending,variant == "honey",honeyIdle==nil {
            let idle=NativeHoneyDiceIdle(textures:textures);honeyIdle=idle;visual.addChild(idle)
        }
        if !sourceIdleDeferred && !sourceRegistryPending,variant == "mushroom",mushroomSmoke==nil {
            let smoke=NativeMushroomDiceSmoke();mushroomSmoke=smoke;visual.addChild(smoke);smoke.zPosition = -1
        }
        if !sourceIdleDeferred && !sourceRegistryPending,variant == "kanta" {
            if kantaIdle == nil {
                let idle = NativeKantaDiceIdle(textures:textures,size:definition.size)
                kantaIdle = idle;visual.addChild(idle);idle.zPosition = 2
            }
            face.isHidden = kantaIdle?.assetReady == true
            kantaIdle?.alpha = locked ? 0.18 : 1
        }
        if variant == "flower" {
            let scale: CGFloat = 128 / 108.36
            flowerCanvas.position = CGPoint(x: -79.33*scale, y: 74.78*scale)
            flowerCanvas.setScale(scale)
            flowerScale.position = CGPoint(x: 80, y: -117)
            flowerRotation.position = CGPoint(x: 0, y: 42)
            flowerArt.texture = textures.texture("assets/shop/bush/flower-pixi-source.png")
            flowerArt.anchorPoint = CGPoint(x: 0, y: 1)
            flowerArt.position = CGPoint(x: -80+25.15, y: 75-20.6)
            flowerArt.size = CGSize(width: 108.36, height: 108.36)
            if flowerArt.texture != nil {admitArtworkPhase(group:"flower-bouncy-pixi",cycle:NativeFlowerMotion.duration)}
            paintFlower()
        }
        face.alpha = locked ? 0.18 : 1
        paintBottle()
        sourceStackRevision &+= 1
        pips.removeAllChildren(); stack.removeAllChildren()
        if !isSpecial && !locked && value > 0 {
            let maps = [1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]]
            for index in maps[min(6,max(1,value))] ?? [] {
                let x = CGFloat(index % 3 - 1) * 25.6
                let y = -CGFloat(index / 3 - 1) * 25.6
                let pip=SKSpriteNode(texture:textures.pipTexture(),size:CGSize(width:15,height:15))
                pip.position=CGPoint(x:x,y:y)
                pips.addChild(pip)
            }
            for index in 1..<max(1,min(4,depth)) {
                let layer = SKSpriteNode(texture: face.texture)
                let shrink = 1 - CGFloat(index) * 0.05
                layer.size = CGSize(width: 128 * shrink, height: 128 * shrink)
                layer.alpha = 0.9
                // Persisted ID gives independent, stable layer poses on re-render.
                let seed = CGFloat(tileID.utf8.reduce(index * 7) { ($0 * 31 + Int($1)) % 991 })
                layer.position = CGPoint(x: sin(seed) * (6 + CGFloat(index)*1.6), y: cos(seed) * (5 + CGFloat(index)*1.3))
                layer.zRotation = (index % 2 == 0 ? -1 : 1) * (10 + seed.truncatingRemainder(dividingBy: 10)) * .pi / 180
                layer.zPosition = CGFloat(-10 + index)
                layer.color = UIColor(red: 139.0/255, green: 90.0/255, blue: 43.0/255, alpha: 1)
                layer.colorBlendFactor = 0.25
                stack.addChild(layer)
            }
        }
        artworkGeneration += 1
        let token = artworkGeneration
        if !sourceIdleDeferred && !sourceRegistryPending,let sheet = definition.idleSheet {
            if !frames.isEmpty { paintArtwork(); return }
            textures.prepare(sheet) { [weak self] loaded in
                guard let self, !self.disposed, token == self.artworkGeneration, !self.sourceIdleDeferred else { return }
                self.frames = loaded
                if !loaded.isEmpty {self.admitArtworkPhase(group:sheet.path,cycle:sheet.cycle)}
                self.paintArtwork()
                self.onResourceReady?()
            }
        }
    }

    /// Literal _ccDeferWildIdleFx boundary. Static original artwork may paint
    /// while hidden; phase/media allocation starts only at real Source landed.
    var sourceIdleOwnerCount:Int {
        [artworkPhaseID != nil,kantaIdle != nil,mushroomSmoke != nil,
         spaceshipEngine != nil,honeyIdle != nil,idleFizz != nil].filter{$0}.count
    }
    func setSourceIdleDeferred(_ active:Bool) {
        guard !disposed,sourceIdleDeferred != active else{return}
        sourceIdleDeferred=active;artworkGeneration+=1
        if active {
            if let id=artworkPhaseID {textures.releaseIdlePhase(id)}
            artworkPhaseID=nil;artworkRunning=false;artworkElapsed=0;fishMediaReady=false
            kantaIdle?.dispose();kantaIdle=nil;mushroomSmoke?.dispose();mushroomSmoke=nil
            spaceshipEngine?.dispose();spaceshipEngine=nil;honeyIdle?.dispose();honeyIdle=nil
            idleFizz?.dispose();idleFizz=nil
            elapsed=0;cuberoElapsed=0;bottleElapsed=0;spaceshipElapsed=0
            spaceshipRoot.position = .zero;spaceshipRoot.zRotation=0
            face.position = .zero;face.zRotation=0;face.xScale=1;face.yScale=1
        }
        rebuild()
        if !active,let scope=sourceSpecialIdle {_ = configureSourceSpecialIdle(scope)}
        onResourceReady?()
    }

    private var sourceIdleEligible:Bool {!sourceWildStateCleared && (isSpecial || variant.flatMap{NativeSpecialDiceRegistry.variants[$0]} != nil)}
    @discardableResult func configureSourceSpecialIdle(_ scope:NativeSourceSpecialIdleScope)->Bool {
        guard !disposed,scope.admissionOpen,sourceSpecialIdle == nil || sourceSpecialIdle === scope else{return false}
        sourceSpecialIdle=scope
        guard sourceIdleEligible else{scope.retire(self);return true}
        if sourceIdleDeferred {sourceRegistryPending=true;return true}
        return scope.register(self,owner:.init(start:{[weak self] in
            guard let self,!self.disposed else{return}
            let pending=self.sourceRegistryPending;self.sourceRegistryPending=false;self.sourceRegistryPaused=false
            if pending {self.rebuild()};self.onResourceReady?()
        },stop:{[weak self] in self?.stopSourceRegisteredIdle()},pause:{[weak self] in
            self?.setSourceRegistryPaused(true)
        },resume:{[weak self] in self?.setSourceRegistryPaused(false)}))
    }
    func retireSourceSpecialIdleBinding(_ scope:NativeSourceSpecialIdleScope){
        guard sourceSpecialIdle === scope else{return};sourceSpecialIdle=nil;sourceRegistryPending=sourceIdleEligible;scope.retire(self)
    }
    private func setSourceRegistryPaused(_ active:Bool) {
        guard !disposed,sourceRegistryPaused != active else{return}
        sourceRegistryPaused=active
        let effective=active || dragging
        kantaIdle?.setDragging(effective);mushroomSmoke?.setDragging(effective);honeyIdle?.setDragging(effective)
        // Direct artwork state stays pointer-only; retain painted phase/skin.
        onResourceReady?()
    }
    private func stopSourceRegisteredIdle() {
        guard !disposed else{return};sourceRegistryPaused=true;artworkGeneration+=1
        if let id=artworkPhaseID {textures.releaseIdlePhase(id)};artworkPhaseID=nil
        kantaIdle?.dispose();kantaIdle=nil;mushroomSmoke?.dispose();mushroomSmoke=nil
        spaceshipEngine?.dispose();spaceshipEngine=nil;honeyIdle?.dispose();honeyIdle=nil;idleFizz?.dispose();idleFizz=nil
        // Retain final artwork pose until the captured Node's normal exit.
    }

    var isSpecial: Bool { kind != "regular" && kind != "normal" && kind != "" }

    /// Literal level-flow ensureActiveFullVisual(tile,true): kill only known
    /// carrier scale owners. Position, rotation, shadow and family cues survive.
    func repairSourceLevelFlowVisual() {
        guard !disposed else{return}
        visual.removeAction(forKey:"stack")
        visual.removeAction(forKey:"source-ordinary-six-hero")
        visual.setScale(1)
        alpha=1;visual.alpha=1;face.alpha=1;pips.alpha=1;pips.isHidden=false
    }

    func setDragging(_ active: Bool,sourceOuterTransform:Bool=false) {
        guard !disposed else { return }
        dragging = active
        if active {idleFizz?.stopForPointer()}
        if variant == "cubero" {cuberoElapsed = 0;face.position = .zero;face.zRotation = 0}
        kantaIdle?.setDragging(active || sourceRegistryPaused);mushroomSmoke?.setDragging(active || sourceRegistryPaused);honeyIdle?.setDragging(active || sourceRegistryPaused)
        if !sourceOuterTransform {
            visual.removeAction(forKey: "stack"); visual.removeAction(forKey: "lift")
            visual.setScale(active ? 1.08 : 1)
        }
        if sourceShadowOwner==nil {
            shadow.removeAllActions()
            shadow.run(.fadeAlpha(to: active ? 0.35 : 0, duration: 0.08))
        }
        paintArtwork()
        paintFlower()
        if variant == "bottle" {bottleElapsed=0;paintBottle()}
        paintFishVisibility()
    }

    func updateShadow(direction: CGPoint) {
        guard dragging, !disposed,sourceShadowOwner==nil else { return }
        let distance = max(1, hypot(direction.x, direction.y))
        shadow.position = CGPoint(x: direction.x / distance * 12, y: direction.y / distance * 12 - 10)
    }

    func resumeIdleAfterLanding() {
        guard !disposed,!sourceIdleDeferred && !sourceRegistryPending,!dragging else {return}
        idleFizz?.restartAfterLanding();onResourceReady?()
    }

    func updateIdleDrag(offset:CGPoint,velocity:CGPoint) {honeyIdle?.updateDrag(offset:offset,velocity:velocity)}

    func tick(_ delta: TimeInterval, suspended: Bool, viewportCenter: CGFloat, fizzDelta:TimeInterval?=nil) {
        guard !disposed, !sourceWildStateCleared, !sourceIdleDeferred && !sourceRegistryPending, !isHidden, alpha > 0, !suspended,!sourceRegistryPaused else { return }
        elapsed += delta
        idleFizz?.tick(fizzDelta ?? delta)
        if let id=artworkPhaseID {
            if !artworkRunning {if textures.advanceIdlePhase(id) {artworkRunning=true;artworkElapsed=0}}
            else {artworkElapsed+=delta}
        }
        if variant == "bee" {
            let time = elapsed
            let index = Int(floor(time / (dragging ? 0.032 : 0.04))) % 4 + 1
            if paintedFrame != index {
                face.texture = textures.texture("assets/shop/bee/bee\(index).png"); paintedFrame = index
            }
            face.xScale = position.x > viewportCenter ? -1 : 1
            if !dragging {
                face.position = CGPoint(x: sin(time * .pi * 1.7) * 2.8, y: -sin(time * .pi * 2.3 + .pi * 0.35) * 5)
                face.zRotation = -sin(time * .pi * 1.9 + .pi * 0.2) * 0.025
                let scale = 1 + sin(time * .pi * 2.6 + .pi * 0.6) * 0.018
                face.yScale = scale; face.xScale *= scale
            } else { face.position = .zero; face.zRotation = 0; face.yScale = 1 }
        } else if variant == "cubero" {
            if !dragging {cuberoElapsed += delta}
            let pose=NativeCuberoIdleMotion.sample(seconds:cuberoElapsed)
            face.position=CGPoint(x:pose.x,y:-pose.y);face.zRotation = -pose.rotation
        } else if variant == "bottle" {
            if !dragging {bottleElapsed+=delta};paintBottle()
        } else if variant == "spaceship" {
            spaceshipElapsed+=delta
            let pose=NativeSpaceshipIdleMotion.sample(seconds:spaceshipElapsed)
            spaceshipRoot.position=CGPoint(x:pose.x,y:-pose.y);spaceshipRoot.zRotation = -pose.rotation
            let frame=NativeSpaceshipIdleMotion.frame(seconds:spaceshipElapsed)
            if paintedFrame != frame,let texture=textures.texture("assets/shop/spaceship/spaceship-idle\(frame+1).png") {face.texture=texture;paintedFrame=frame}
            spaceshipEngine?.paint(seconds:spaceshipElapsed)
        } else if variant == "kanta" { kantaIdle?.tick(delta,globalX:position.x,viewportCenter:viewportCenter) }
        else if variant == "honey" {honeyIdle?.tick(delta)}
        else if variant == "mushroom" {mushroomSmoke?.tick(delta);paintArtwork()}
        else if variant == "flower" { paintFlower() }
        else { paintArtwork() }
    }

    func prepareFishMediaPhase() {
        guard !disposed,!sourceIdleDeferred && !sourceRegistryPending,variant == "fish" else {return}
        admitArtworkPhase(group:"fish-swim-composition",cycle:1.125);onResourceReady?()
    }
    func setFishMediaReady(_ ready:Bool) {
        guard !disposed,variant == "fish",!ready || !sourceIdleDeferred && !sourceRegistryPending else {return}
        fishMediaReady=ready
        if !ready {if let id=artworkPhaseID {textures.releaseIdlePhase(id)};artworkPhaseID=nil;artworkRunning=false;artworkElapsed=0}
        paintFishVisibility();onResourceReady?()
    }
    private func paintFishVisibility() {
        guard variant == "fish" else {return}
        face.isHidden=fishMediaReady && !dragging
        idleFizz?.isHidden=fishMediaReady && !dragging
        if !dragging {face.xScale=1}
    }
    func fishFrame(in scene:SKScene,visible:Bool)->NativeFishIdleFrame? {
        guard !disposed,!sourceIdleDeferred && !sourceRegistryPending,variant == "fish" else {return nil}
        let center=visual.convert(CGPoint.zero,to:scene)
        if dragging {face.xScale=center.x>scene.size.width/2 ? -1:1}
        let horizontal=visual.convert(CGPoint(x:1,y:0),to:scene),vertical=visual.convert(CGPoint(x:0,y:-1),to:scene)
        var branchAlpha:CGFloat=face.alpha
        var ancestor:SKNode?=visual
        var branchVisible=visible
        while let node=ancestor {branchAlpha*=node.alpha;branchVisible=branchVisible && !node.isHidden && node.alpha>0.001;ancestor=node.parent}
        return NativeFishIdleFrame.project(center:center,horizontalUnit:horizontal,verticalUnit:vertical,sceneHeight:scene.size.height,alpha:branchAlpha,dragging:dragging,phaseStarted:artworkRunning,visible:branchVisible,bubbles:idleFizz?.fishBubbleSnapshots ?? [],depth:zPosition,paintOrder:parent?.children.firstIndex(where:{$0 === self}) ?? 0)
    }

    private func admitArtworkPhase(group:String,cycle:TimeInterval) {
        guard !disposed,!sourceIdleDeferred && !sourceRegistryPending,artworkPhaseID==nil else {return}
        let phase=textures.reserveIdlePhase(group:group,cycle:cycle)
        artworkPhaseID=phase.id;artworkRunning=phase.running;artworkElapsed=0
    }

    private func paintBottle() {
        guard variant == "bottle" else {return}
        if dragging || sourceIdleDeferred || sourceRegistryPending {face.anchorPoint=definition.anchor;face.position = .zero;face.zRotation=0;return}
        let pose=NativeBottleIdleMotion.sample(seconds:bottleElapsed)
        face.anchorPoint=CGPoint(x:0.5,y:0)
        face.position=CGPoint(x:0,y:-definition.size.height*0.5-pose.y);face.zRotation = -pose.rotation
    }

    private func paintFlower() {
        guard variant == "flower", !disposed else { return }
        flowerCanvas.isHidden = sourceIdleDeferred || sourceRegistryPending || dragging || flowerArt.texture == nil || !artworkRunning
        face.isHidden = !flowerCanvas.isHidden
        guard !flowerCanvas.isHidden else { return }
        let pose = NativeFlowerMotion.sample(seconds: artworkElapsed)
        flowerRoot.position.y = -pose.translateY
        flowerScale.xScale = pose.scaleX; flowerScale.yScale = pose.scaleY
        flowerRotation.zRotation = -pose.rotationDegrees * .pi / 180
    }

    private func paintArtwork() {
        guard !disposed, !sourceIdleDeferred && !sourceRegistryPending, let sheet = definition.idleSheet, !frames.isEmpty else { return }
        let useFrames = artworkRunning && (!dragging || sheet.animateDuringDrag)
        artwork.isHidden = !useFrames; face.isHidden = useFrames
        guard useFrames else { return }
        let frame = sheet.frame(at: artworkElapsed)
        if frame != paintedFrame { artwork.texture = frames[frame]; paintedFrame = frame }
        artwork.anchorPoint = sheet.anchor
        artwork.size = CGSize(width: sheet.cell.width * sheet.displayScale, height: sheet.cell.height * sheet.displayScale)
        artwork.position.y = sheet.offsetY
    }

    /// Capture only the current authored artwork into plain nodes. SpriteKit's
    /// polymorphic copy would instantiate a second custom idle owner.
    func detachedArtworkCarrier() -> SKNode {
        func capture(_ original:SKNode)->SKNode {
            let node:SKNode
            if let sprite=original as? SKSpriteNode {
                let image=SKSpriteNode(texture:sprite.texture,color:sprite.color,size:sprite.size)
                image.anchorPoint=sprite.anchorPoint;image.colorBlendFactor=sprite.colorBlendFactor;image.blendMode=sprite.blendMode;image.shader=sprite.shader
                node=image
            } else if let shape=original as? SKShapeNode {
                let image=SKShapeNode(path:shape.path ?? CGPath(rect:.zero,transform:nil))
                image.fillColor=shape.fillColor;image.strokeColor=shape.strokeColor;image.lineWidth=shape.lineWidth;image.glowWidth=shape.glowWidth
                image.lineCap=shape.lineCap;image.lineJoin=shape.lineJoin;image.isAntialiased=shape.isAntialiased
                node=image
            } else if let label=original as? SKLabelNode {
                let image=SKLabelNode(fontNamed:label.fontName)
                image.text=label.text;image.attributedText=label.attributedText;image.fontSize=label.fontSize;image.fontColor=label.fontColor
                image.horizontalAlignmentMode=label.horizontalAlignmentMode;image.verticalAlignmentMode=label.verticalAlignmentMode
                node=image
            } else {node=SKNode()}
            node.name=original.name;node.position=original.position;node.zPosition=original.zPosition
            node.xScale=original.xScale;node.yScale=original.yScale;node.zRotation=original.zRotation;node.alpha=original.alpha;node.isHidden=original.isHidden
            for child in original.children {node.addChild(capture(child))}
            return node
        }
        return capture(visual)
    }

    func stackFeedback() {
        guard !disposed else { return }
        visual.removeAllActions(); visual.setScale(1)
        visual.run(NativeBoardMotion.stack(squash: depth % 2 == 0), withKey: "stack")
    }

    func dispose() {
        guard !disposed else { return }
        let idleScope=sourceSpecialIdle;sourceSpecialIdle=nil;idleScope?.retire(self)
        if sourceAppSpawnInterruption != nil {disposed=true;interruptSourceAppSpawn()}
        if sourceOuterDriven || sourceShadowOwner != nil || sourceRegularFrameBinding != nil || sourceWildDestinationFrames != nil || sourceRestoreEmptyFaceFrame != nil {
            disposed=true // seal before captured Source release/cancellation reentry
            retireSourceStackFrames()
            let outer=sourceOuterBridge,shadowOwner=sourceShadowOwner
            sourceOuterBridge=nil;sourceShadowOwner=nil;sourceOuterBindingID=nil;sourceBindingRevision &+= 1
            outer?.dispose();shadowOwner?.dispose()
        }
        sourceLockedSpawnMarkers.removeAll();sourceMarkerCoverageGeneration=nil
        disposed=true;artworkGeneration += 1
        if let id=artworkPhaseID {textures.releaseIdlePhase(id)}
        artworkPhaseID=nil
        kantaIdle?.dispose(); kantaIdle = nil;mushroomSmoke?.dispose();mushroomSmoke=nil;spaceshipEngine?.dispose();spaceshipEngine=nil;honeyIdle?.dispose();honeyIdle=nil;idleFizz?.dispose();idleFizz=nil
        removeAllActions(); visual.removeAllActions(); shadow.removeAllActions()
        frames.removeAll(); onResourceReady = nil
        removeAllChildren(); removeFromParent()
    }
}
