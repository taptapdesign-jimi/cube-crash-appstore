const fs=require('fs'),vm=require('vm'),ts=require('/Users/user/cube-crash/node_modules/typescript');
Date.now=()=>10000;const {gsap}=require('/Users/user/cube-crash/node_modules/gsap/dist/gsap.js');gsap.ticker.sleep();
const source=fs.readFileSync('/tmp/native-magnet-source-pull-draft/OriginalAppCore.ts','utf8');
const first=source.indexOf('        nearestTiles.forEach((tile: any, index: number) => {'),end=source.indexOf('        // Store callback to trigger merge',first);
const code=ts.transpile(source.slice(first,end),{target:ts.ScriptTarget.ES2020});
const records=[];
for(const count of [1,2,3,4]){
 gsap.globalTimeline.clear();gsap.globalTimeline.time(0,false);gsap.ticker.sleep();
 const tiles=Array.from({length:count},(_,i)=>({x:64+i*148,y:64,rotG:{rotation:0},scale:{x:1,y:1}}));
 let now=0,started=false;const trace=[];
 const ctx={nearestTiles:tiles,Math,mergeX:148,mergeY:64,TILE:128,totalTiles:count,animationManager:{trackExternalTimeline:x=>x},gsap,activeTimelines:[],mergeStarted:false,arrivedCount:0,allTilesArrived:false,multiplierShown:false,magnetVariantAtMergeEntry:null,devLog(){},devWarn(){},devError(){},cleanupPulledTile(){trace.push(['cleanup',now])},playMagnetPullForceSounds:()=>true,playHoneyPullMergeSounds(){},playBottlePullMergeSounds(){},tryMergePulledTiles:async()=>{ctx.mergeStarted=true;started=true;trace.push(['import-await',now])}};
 vm.createContext(ctx);vm.runInContext(code,ctx);gsap.ticker.sleep();
 for(let ms=0;ms<1000;ms+=5){now=ms/1000;gsap.globalTimeline.time(now,false);if(started){started=false;const before=ctx.activeTimelines.map(x=>({dur:x.duration(),time:x.time(),parent:!!x.parent,children:x.getChildren().length}));
   for(const tile of tiles){gsap.killTweensOf(tile);gsap.killTweensOf(tile.scale);gsap.killTweensOf(tile.rotG);gsap.killTweensOf(tile.rotG.scale)}
   const after=ctx.activeTimelines.map(x=>({dur:x.duration(),time:x.time(),parent:!!x.parent,children:x.getChildren().length}));trace.push(['kill',now,before,after]);
  }}
 records.push({count,trace,final:ctx.activeTimelines.map(x=>({dur:x.duration(),time:x.time(),parent:!!x.parent,children:x.getChildren().length,killed:x._killed}))});
}
fs.writeFileSync('/tmp/native-magnet-source-pull-draft/PullBodyKillAudit.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records));gsap.ticker.sleep();
