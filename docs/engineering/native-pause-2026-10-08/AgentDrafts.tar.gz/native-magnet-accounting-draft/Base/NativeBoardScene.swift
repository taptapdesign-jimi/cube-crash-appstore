import SpriteKit
import UIKit
import StackToSixGameplay

/// One native renderer/input owner. The engine is the only decision owner;
/// animation completion never computes a merge, spawn, reward or terminal.
@MainActor
final class NativeBoardScene: SKScene {
    let engine: NativeGameplayEngine
    var onStateChange: ((NativeBoardState) -> Void)?
    var onTerminal: ((NativeResolution) -> Void)?
    var onGameplayEvent: ((NativeGameplayEvent) -> Void)?
    var onGameplayReceipt: ((NativeGameplayEvent,NativeTile?,NativeTile?,UInt64) -> Void)?
    var onSpecialMoment: ((String?,String,Int) -> Void)?
    var onTntGlyphClock: ((String,TimeInterval,Bool) -> Void)?
    var onSplashGlyphClock: ((String,String,TimeInterval,Bool) -> Void)?
    var onHaptic: ((String) -> Void)?
    var onSpecialPresentationCancelled: ((String?) -> Void)?
    var authoredFinalePresentationReady: ((String) -> Bool)?
    var authoredTntPresentationReady: ((String) -> Bool)?
    var onAuthoredLaserImpact: (([NativeLaserVisualTarget],UInt64,@escaping (Int,String) -> Bool,@escaping () -> Void,@escaping () -> Void) -> Bool)?
    var onAuthoredTntPresentation: ((String,CGPoint,UInt64,@escaping () -> Void,@escaping () -> Void) -> Bool)?
    var onAuthoredFinale: ((String,CGPoint,UInt64,@escaping () -> Void) -> Bool)?
    var onExitRequest: (() -> Void)?
    var onHelpRequest: (() -> Void)?
    var onScoreRequest: (() -> Void)?
    var onComboRequest: (() -> Void)?
    var onPointerState: ((Bool) -> Void)?
    var onRenderingDemand: ((Bool) -> Void)?
    var onFrameTarget:((Int)->Void)?
    var onSpecialIdleSuspended:((Bool)->Void)?
    private let sourceFrames=NativeSourceFrameRuntime()
    private var sourceFramesAttached=false
    private var sourcePopIn:NativeSourceFrameRuntime.Capture?
    private var sourcePreparedEntry:NativeSourceFrameRuntime.Capture?
    private var sourceExit:NativeSourceFrameRuntime.Capture?
    private var sourceHUDExit:NativeSourceFrameRuntime.Capture?
    private var sourceStars:NativeSourceFrameRuntime.Capture?
    private var sourceGameplay:[NativeSourceFrameRuntime.Key:NativeSourceFrameRuntime.Capture]=[:]
    private var sourcePopulation:Set<String>=[]
    private struct SourceSpawnScope {
        let tileID:String,actionKey:String,id:String,release:()->Void
    }
    private var sourceSpawns:[String:SourceSpawnScope]=[:]
    var sourceWrappedSpawnCount:Int {sourceSpawns.count}
    var sourceFrameSnapshot:NativeBoardFrameCadence.Snapshot {sourceFrames.snapshot}
    var sourceFrameBudget:NativeBoardFrameBudget.Snapshot {sourceFrames.budget.snapshot}
    private var sourceIdleScope:NativeGameplaySourceContext.Scope?
    private var sourceIdleGeneration:UInt64?
    private var sourceIdleWasScoped=false
    var sourceSpecialIdleAdmissionOpen:Bool {
        guard sourceAnimationBindingAdmissionOpen,let scope=sourceIdleScope,scope.current,
            sourceIdleGeneration==engine.state.generation,scope.specialIdle.admissionOpen else{return false}
        return sourceAnimationBindingAdmissionOpen && sourceIdleScope === scope && scope.current && sourceIdleGeneration==engine.state.generation
    }
    @discardableResult func configureSourceSpecialIdle(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,scope.specialIdle.admissionOpen,sourceIdleScope==nil,
            sourceOuterTimelineDriver === scope.timeline,sourceDragTweenDriver === scope.tween else{return false}
        sourceIdleScope=scope;sourceIdleGeneration=engine.state.generation;sourceIdleWasScoped=true
        scope.specialIdle.onStateChange={[weak self,weak scope] snapshot in
            guard let self,let scope,self.sourceSpecialIdleAdmissionOpen,self.sourceIdleScope === scope else{return}
            self.sourceCallbackTime();self.sourceFrames.setRegistrySuspended(snapshot.suspended)
            self.refreshSourceIdlePopulation()
            self.onSpecialIdleSuspended?(snapshot.suspended || self.sourceFrames.isSpecialIdleSuspended)
        }
        for node in Array(nodesByID.values) {
            guard sourceSpecialIdleAdmissionOpen,node.configureSourceSpecialIdle(scope.specialIdle) else{retireSourceSpecialIdleBindings();return false}
        }
        guard sourceSpecialIdleAdmissionOpen else{retireSourceSpecialIdleBindings();return false}
        refreshSourceIdlePopulation();return true
    }
    func acquireSourceSpecialIdle(reason:String)->(()->Void)? {
        guard sourceSpecialIdleAdmissionOpen,let scope=sourceIdleScope else{return nil}
        let captured=scope.specialIdle.acquire(reason:reason)
        guard sourceSpecialIdleAdmissionOpen,sourceIdleScope === scope else{captured?();return nil}
        return captured
    }
    private func refreshSourceIdlePopulation(){
        if let scope=sourceIdleScope,sourceSpecialIdleAdmissionOpen {
            sourceFrames.registerPopulation(Set(scope.specialIdle.registeredKeys.compactMap{($0 as? NativeDiceNode)?.tileID}))
        } else {sourceFrames.registerPopulation(sourceIdleWasScoped ? []:sourcePopulation)}
    }
    private func retireSourceSpecialIdleBindings(){
        guard let captured=sourceIdleScope else{return}
        sourceIdleScope=nil;sourceIdleGeneration=nil;captured.specialIdle.onStateChange=nil
        for node in Array(nodesByID.values){node.retireSourceSpecialIdleBinding(captured.specialIdle)}
        sourceCallbackTime();sourceFrames.setRegistrySuspended(false);refreshSourceIdlePopulation()
    }
    private func sourceCallbackTime() {sourceFrames.receiveCallbackTime(CACurrentMediaTime()*1000)}
    /// Caller is an actual authored owner, never a generic visual counter.
    func beginSourceMotion(_ kind:NativeSourceFrameRuntime.Kind,id:String,generation:UInt64)->(() -> Void)? {
        guard !sourceDisposalInProgress else {return nil}
        guard !disposed,engine.state.generation==generation else{return nil}
        sourceCallbackTime()
        let capture=sourceFrames.begin(.init(kind:kind,generation:generation,id:id))
        return { [weak self] in guard let self else{return};self.sourceCallbackTime();self.sourceFrames.end(capture) }
    }
    /// Initial/retry committed surface wrapper; Continue owns only pop-in.
    func prepareSourceBoardEntry() {
        guard !sourceDisposalInProgress else {return}
        guard !disposed,sourcePreparedEntry==nil else{return}
        sourceCallbackTime();sourcePreparedEntry=sourceFrames.begin(.init(kind:.boardEntry,generation:engine.state.generation,id:UUID().uuidString))
        if !entryInProgress {finishSourceEntry()}
    }
    private func finishSourceEntry() {
        sourceCallbackTime()
        if let capture=sourcePopIn {sourcePopIn=nil;sourceFrames.end(capture)}
        if let capture=sourcePreparedEntry {sourcePreparedEntry=nil;sourceFrames.end(capture)}
    }
    /// Exact accepted handoff begin/release observer for the separate endgame
    /// Date ledger. No Date value or meter-ledger write is manufactured here.
    var onSourceRegularHandoffMutation:((NativeSourceRegularHandoffMutationReceipt,NativeSourceRegularHandoffMutationReceipt.Phase)->Void)?
    var sourceEndgameMutationLedgerEnabled=false
    private var sourceEndgameMutationBinding:NativeSourceEndgameMutationLedger.Binding?
    private weak var sourceEndgameMutationScope:NativeGameplaySourceContext.Scope?
    var sourceEndgameMutationLedgerAdmissionOpen:Bool {sourceAnimationBindingAdmissionOpen && sourceEndgameMutationScope?.current==true && sourceEndgameMutationBinding?.retired==false}
    private var sourceEndgameMutationEpoch:UInt64=0
    @discardableResult func configureSourceEndgameMutationLedger(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceEndgameMutationLedgerEnabled,scope.current,
            sourceSameNodeStackAbsorbsEnabled,sourceOuterTimelineDriver === scope.timeline,sourceDragTweenDriver === scope.tween,
            sourceEndgameMutationBinding==nil,onSourceRegularHandoffMutation==nil,
            !sourceGameplay.keys.contains(where:{$0.kind == .regularMergeHandoff}) else{return false}
        let generation=engine.state.generation,epoch=sourceEndgameMutationEpoch
        let seal:()->Bool = {[weak self,weak scope] in
            guard let self,let scope else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.sourceEndgameMutationLedgerEnabled && scope.current &&
                self.engine.state.generation==generation && self.sourceEndgameMutationEpoch==epoch &&
                self.sourceOuterTimelineDriver === scope.timeline && self.sourceDragTweenDriver === scope.tween
        }
        guard let binding=scope.bindEndgameMutations(current:seal) else{return false}
        guard seal(),sourceEndgameMutationBinding==nil,onSourceRegularHandoffMutation==nil else{scope.retireEndgameMutations(binding);return false}
        sourceEndgameMutationScope=scope;sourceEndgameMutationBinding=binding
        onSourceRegularHandoffMutation={[weak self,weak binding] receipt,phase in
            guard let self,let binding,seal(),self.sourceEndgameMutationBinding === binding,receipt.generation==generation else{return}
            _=binding.handoff(receipt,phase:phase)
        }
        return true
    }
    /// Default-off selected token begin. This does not advertise actual Source
    /// coroutine-finally, signature, repair or full input/save capability.
    struct SourceOrdinarySpawnCompanions {
        let releaseSpecialTransaction:()->Void
        let queueWildAfterGuardRelease:()->Void
    }
    var sourceOrdinarySixSpawnOwnerEnabled=false
    private var sourceOrdinarySixSpawnScope:NativeGameplaySourceContext.Scope?
    private var sourceOrdinarySixSpawnResets:((String,UInt64)->SourceOrdinarySpawnCompanions?)?
    private var sourceOrdinarySixSpawnClaims:[String:NativeSourceMergeSixSpawnOwner.Claim]=[:]
    @discardableResult func configureSourceOrdinarySixSpawnOwner(scope:NativeGameplaySourceContext.Scope,
        resets:@escaping(String,UInt64)->SourceOrdinarySpawnCompanions?)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceOrdinarySixSpawnOwnerEnabled,
            sourceOrdinarySixSameNodeEnabled,scope.current,sourceSixScope === scope,
            sourceEndgameMutationScope === scope,sourceEndgameMutationLedgerAdmissionOpen,
            sourceOrdinarySixSpawnScope==nil,sourceOrdinarySixSpawnResets==nil,
            sourceDragTweenDriver === scope.tween,sourceOuterTimelineDriver === scope.timeline,
            engine.stagedOrdinaryMoves,engine.stagedOrdinaryAssignments,
            !engine.sourceOrdinarySixSpawnBeginReceiptsEnabled,
            engine.pendingOrdinarySix==nil else{return false}
        sourceOrdinarySixSpawnScope=scope;sourceOrdinarySixSpawnResets=resets
        engine.sourceOrdinarySixSpawnBeginReceiptsEnabled=true;return true
    }
    private func acceptSourceOrdinarySixSpawnBegin(event:NativeGameplayEvent,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceOrdinarySixSpawnOwnerEnabled,
            let scope=sourceOrdinarySixSpawnScope,scope.current,sourceSixScope === scope,
            sourceEndgameMutationScope === scope,let binding=sourceEndgameMutationBinding,
            let factory=sourceOrdinarySixSpawnResets,engine.state.generation==generation,
            let receipt=engine.pendingSourceOrdinarySixSpawnBeginReceipts.first(where:{$0.id.uuidString==event.reason}),
            receipt.generation==generation,sourceOrdinarySixSpawnClaims[receipt.ownerID]==nil else{return false}
        let epoch=sourceEndgameMutationEpoch
        let current:()->Bool = {[weak self,weak scope,weak binding] in
            guard let self,let scope,let binding else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.sourceOrdinarySixSpawnOwnerEnabled && scope.current &&
                self.sourceOrdinarySixSpawnScope === scope && self.sourceSixScope === scope &&
                self.sourceEndgameMutationScope === scope && self.sourceEndgameMutationBinding === binding &&
                self.sourceEndgameMutationEpoch==epoch && self.engine.state.generation==generation &&
                self.engine.sourceOrdinarySixSpawnBeginReceiptsEnabled && self.engine.sourceOrdinarySixSpawnBeginIsCurrent(receipt)
        }
        let external=factory(receipt.ownerID,generation)
        guard let external,current() else{return false}
        // The actual captured frame/idle lease was installed at contact. The
        // callback argument cannot replace that Scene-owned real companion.
        let companions=NativeSourceMergeSixSpawnOwner.ResetBindings(endResolutionFrames:{[weak self] in
            self?.finishSourceGameplay(.mergeSixResolution,id:receipt.ownerID,generation:generation)
        },releaseSpecialTransaction:external.releaseSpecialTransaction,
            queueWildAfterGuardRelease:external.queueWildAfterGuardRelease)
        guard let claim=binding.beginSpawn(receipt,service:scope.service,resets:companions,current:current),current(),
            sourceOrdinarySixSpawnClaims[receipt.ownerID]==nil else{return false}
        guard engine.acknowledgeSourceOrdinarySixSpawnBegin(receipt) else{return false}
        sourceOrdinarySixSpawnClaims[receipt.ownerID]=claim
        return true
    }
    /// Explicit captured Source coroutine finally endpoint. It is intentionally
    /// NOT called by Native releaseOrdinarySixIfReady/primary/visual completion.
    /// The literal regular/endgame Promise finally producer is still OPEN.
    @discardableResult func sourceOrdinarySixSpawnCoroutineFinally(ownerID:String,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceOrdinarySixSpawnOwnerEnabled,
            engine.state.generation==generation,let scope=sourceOrdinarySixSpawnScope,scope.current,
            sourceEndgameMutationScope === scope,let binding=sourceEndgameMutationBinding,
            let claim=sourceOrdinarySixSpawnClaims[ownerID],claim.generation==generation else{return false}
        sourceOrdinarySixSpawnClaims.removeValue(forKey:ownerID)
        return binding.resetSpawn(claim)
    }
    private func retireSourceOrdinarySixSpawnOwner() {
        let generation=engine.state.generation
        sourceOrdinarySixSpawnScope=nil;sourceOrdinarySixSpawnResets=nil;sourceOrdinarySixSpawnClaims=[:]
        engine.sourceOrdinarySixSpawnBeginReceiptsEnabled=false
        engine.retireSourceOrdinarySixSpawnBeginReceipts(generation:generation)
        // Actual captured binding retirement below owns token teardown. No
        // synthetic Date, arrival or native handoff completion is produced.
    }
    private func retireSourceEndgameMutationLedger() {
        retireSourceOrdinarySixSpawnOwner()
        let captured=sourceEndgameMutationBinding,scope=sourceEndgameMutationScope
        sourceEndgameMutationBinding=nil;sourceEndgameMutationScope=nil;sourceEndgameMutationEpoch &+= 1
        if captured != nil {onSourceRegularHandoffMutation=nil}
        if let captured {if let scope {scope.retireEndgameMutations(captured)}else{captured.retire()}}
    }
    private var sourceRegularHandoffMutationReceipts:[NativeSourceFrameRuntime.Key:NativeSourceRegularHandoffMutationReceipt]=[:]
    private func beginSourceGameplay(_ kind:NativeSourceFrameRuntime.Kind,id:String,generation:UInt64) {
        let key=NativeSourceFrameRuntime.Key(kind:kind,generation:generation,id:id)
        guard sourceGameplay[key]==nil else{return}
        sourceCallbackTime();sourceGameplay[key]=sourceFrames.begin(key)
        if kind == .regularMergeHandoff,onSourceRegularHandoffMutation != nil {
            let receipt=NativeSourceRegularHandoffMutationReceipt(ownerID:id,generation:generation)
            sourceRegularHandoffMutationReceipts[key]=receipt
            onSourceRegularHandoffMutation?(receipt,.began)
        }
    }
    private func finishSourceGameplay(_ kind:NativeSourceFrameRuntime.Kind,id:String,generation:UInt64) {
        let key=NativeSourceFrameRuntime.Key(kind:kind,generation:generation,id:id)
        if let capture=sourceGameplay.removeValue(forKey:key) {
            let receipt=sourceRegularHandoffMutationReceipts.removeValue(forKey:key)
            sourceCallbackTime();sourceFrames.end(capture)
            if let receipt {onSourceRegularHandoffMutation?(receipt,.released)}
        }
        if kind == .mergeSixResolution,let release=sourceSixIdleReleases.removeValue(forKey:id) {release()}
    }
    private func finishSourceStars() {
        guard hudStarIDs.isEmpty,let capture=sourceStars else{return}
        sourceStars=nil;sourceCallbackTime();sourceFrames.end(capture)
    }
    private func retireSourceSpawns(tileID:String?=nil) {
        for (key,owner) in Array(sourceSpawns) where tileID==nil || owner.tileID==tileID {
            sourceSpawns.removeValue(forKey:key);owner.release()
        }
    }
    /// Only source-identified wrapped/app-spawn paths call this helper. The
    /// unported Wild meter drop must not acquire a substitute bounce scope.
    private func runSourceSpawn(_ node:NativeDiceNode,key:String,postDelay:Double=0,completion:(()->Void)?=nil) {
        let ownerKey=node.tileID+":"+key,id=UUID().uuidString
        if let previous=sourceSpawns.removeValue(forKey:ownerKey) {previous.release()}
        let release=beginSourceMotion(.spawnBounce,id:id,generation:engine.state.generation) ?? {}
        sourceSpawns[ownerKey]=SourceSpawnScope(tileID:node.tileID,actionKey:key,id:id,release:release)
        var actions:[SKAction]=[NativeBoardMotion.spawnBounce(),.run { [weak self] in
            release()
            if self?.sourceSpawns[ownerKey]?.id==id {self?.sourceSpawns.removeValue(forKey:ownerKey)}
        }]
        if postDelay>0 {actions.append(.wait(forDuration:postDelay))}
        if let completion {actions.append(.run(completion))}
        node.visual.run(.sequence(actions),withKey:key)
    }
    var onBoardEntry: ((TimeInterval, [TimeInterval]) -> Void)?
    var onHUDDrop: ((UInt64) -> Void)?
    private let textures: NativeBoardTextures
    private let closeStageFont:UIFont
    private var closeButton:NativeHUDCloseNode?
    private let fontName: String
    private let finaleFontName: String
    private var nodesByID: [String: NativeDiceNode] = [:]
    private let canvasRoot:SKNode
    private var sourceInitialConstruction:NativeSourceInitialBoardConstruction?
    private var sourceInitialEntryPending=false
    private var sourceInitialStartupRejected=false
    var sourceInitialStartupReady:Bool {!sourceInitialStartupRejected && (sourceInitialConstruction == nil || sourceInitialConstruction?.isCurrent==true)}
    private let ghosts = SKNode()
    private let hud = SKNode()
    private let effects = SKNode()
    private let hudStarFlights = SKNode()
    private var hudStarNodes:[String:SKNode]=[:]
    private var hudStarIDs = Set<String>()
    private var meterTimeoutIDs=Set<String>()
    private var hudStarVisualReceipts: [String:UInt64] = [:]
    private let score = SKLabelNode()
    private let scoreArt = SKSpriteNode()
    private let comboArt = SKSpriteNode()
    private let comboX = SKLabelNode()
    private let comboNumber = SKLabelNode()
    private var scoreHitRect = CGRect.zero
    private var comboHitRect = CGRect.zero
    private let roundIndicator: NativeRoundIndicator
    private let noMoves = SKLabelNode()
    private let meter = SKShapeNode()
    private let meterBackground = SKShapeNode()
    private let hover = SKShapeNode()
    private var hoverTargetID: String?
    private var geometry: NativeBoardGeometry?
    var boardGeometry: NativeBoardGeometry? { geometry }
    private var safeInsets = UIEdgeInsets.zero
    private var activeTouch: UITouch?
    private var draggedID: String?
    private var dragMoved = false
    private var fingerOffset = CGPoint.zero
    private var touchStart = CGPoint.zero
    private var lastTouchPoint = CGPoint.zero
    private var lastPointerTime:TimeInterval=0
    private var pointerVelocity=CGPoint.zero
    private var lastFrame: TimeInterval?
    private var lastGeneration: UInt64?
    private var terminalPresentedGeneration: UInt64?
    private var pendingTerminal: NativeResolution?
    private var pendingTerminalGeneration: UInt64?
    private var visualLifetime: UInt64 = 0
    private var visualOwners = 0
    private var ordinaryAbsorbs:[String:(SKNode,UInt64)] = [:]
    private var ordinaryPostchecks=Set<String>()
    // PRIVATE canonical save endpoint. No generic state-change debounce.
    private var sourceCanonicalSaveBinding:NativeSourceCanonicalSaveOwner<NativeBoardState>.Binding?
    private var sourceCanonicalSaveEpoch:UInt64=0
    @discardableResult func configureSourceCanonicalSave(scope:NativeGameplaySourceContext.Scope,binding:NativeSourceCanonicalSaveOwner<NativeBoardState>.Binding)->Bool {
        guard sourceAnimationBindingAdmissionOpen else{return false}
        sourceCanonicalSaveEpoch &+= 1;let e=sourceCanonicalSaveEpoch
        let initialScope=scope.current
        guard initialScope,sourceAnimationBindingAdmissionOpen,sourceCanonicalSaveEpoch==e else{return false}
        let initialBinding=binding.current
        guard initialBinding,sourceAnimationBindingAdmissionOpen,sourceCanonicalSaveEpoch==e else{return false}
        let previous=sourceCanonicalSaveBinding;sourceCanonicalSaveBinding=nil;previous?.retire()
        let scopeReady=scope.current
        guard scopeReady,sourceAnimationBindingAdmissionOpen,sourceCanonicalSaveEpoch==e,sourceCanonicalSaveBinding==nil else{return false}
        let saveReady=binding.current
        guard saveReady,sourceAnimationBindingAdmissionOpen,sourceCanonicalSaveEpoch==e,sourceCanonicalSaveBinding==nil else{return false}
        sourceCanonicalSaveBinding=binding;sourceDisposalSealingEnabled=true;return true
    }
    func scheduleSourceCanonicalSaveWall(milliseconds:Int,generation:UInt64,elapsed:@escaping()->Void)->(()->Void)? {
        guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation else{return nil}
        let receipt=sourceAppTimeouts.schedule(sourceID:"source-canonical-game-save",generation:generation,delayMilliseconds:milliseconds,elapsed:elapsed)
        return{[weak self] in _=self?.sourceAppTimeouts.cancel(receipt)}
    }
    private func retireSourceCanonicalSave() {
        sourceCanonicalSaveEpoch &+= 1;let captured=sourceCanonicalSaveBinding;sourceCanonicalSaveBinding=nil;captured?.retire()
    }
    // PRIVATE Source NO MOVES splice. Defaults OFF; owners are mandatory.
    var sourceNoMovesPresentationEnabled=false
    var sourceNoMovesRuntimeAuthorityEnabled=false
    private var sourceNoMovesCallerInvocationBound=false
    private var sourceNoMovesOwnedRuntimeAuthority:NativeSourceNoMovesRuntimeAuthority?
    var sourceNoMovesDepletedCallersEnabled=false
    private var sourceNoMovesCallerAdmission:NativeSourceNoMovesCallerAdmission?
    private var sourceNoMovesCallerFlow:NativeSourceNoMovesDepletedCallerFlow?
    private var sourceNoMovesCallerCompletion:NativeSourceNoMovesCallerCompletionBinding?
    private var sourceNoMovesCallerReplies:[String:(UUID,()->Void)]=[:]
    private var sourceNoMovesCallerEpoch:UInt64=0
    var sourceOrdinaryPreDebitPresentationEnabled=false
    private var sourceOrdinaryPreDebitEpoch:UInt64=0
    private var sourceOrdinaryPreDebitFlow:NativeSourceOrdinaryPreDebitFlow?
    private var sourceOrdinaryPreDebitAdmission:NativeSourceOrdinaryPreDebitAdmission?
    private var sourceOrdinaryPreDebitBindings:NativeSourceOrdinaryPreDebitBindings?
    private var sourcePreDebitDeferredMain:Set<String>=[]
    private struct SourcePreDebitContact {
        let source:NativeDiceNode,destination:NativeDiceNode
        let sourceSpecial:String?,destinationSpecial:String?,effectiveSum:Int
        let visibleBefore:Int,physicalBefore:Int,bothCapturedActive:Bool
        let generation:UInt64,epoch:UInt64
    }
    private var sourcePreDebitContacts:[String:SourcePreDebitContact]=[:]
    private var sourcePreDebitMain:[String:NativeSourcePostcheckMainCapture]=[:]
    private var sourcePreDebitRequests:[String:NativeSourceOrdinaryPreDebitReceipt]=[:]

    private var sourceNoMovesBridge:NativeSourceNoMovesSceneBridge?
    private var sourceNoMovesTerminalRegistry:NativeSourceNoMovesTerminalRegistryEndpoint?
    private var sourceNoMovesBindings:NativeSourceNoMovesSceneBindings?
    private var sourceNoMovesGeneration:UInt64?
    private var sourceNoMovesConfigurationEpoch:UInt64=0
    private var sourceNoMovesRetirement:(()->Void)?
    private var sourceNoMovesDestroyed=false
    var sourceNoMovesCandidateActive:Bool {sourceNoMovesBridge?.hasActiveCandidate == true}
    @discardableResult
    func configureSourceNoMoves(bindings:NativeSourceNoMovesSceneBindings,
        showText:@escaping(NativeNoMovesCandidateOwner.Plan,UInt64)->Void,
        beginTextExit:@escaping(UInt64,@escaping(Bool)->Void)->Void,
        clearText:@escaping()->Void,
        confirmedBoardExit:@escaping(UInt64,@escaping(Bool)->Void)->Void,
        terminalRegistry:NativeSourceNoMovesTerminalRegistryEndpoint?=nil,
        callerInvocationReceiptBound:Bool=false)->Bool {
        guard sourceAnimationBindingAdmissionOpen,!sourceNoMovesDestroyed,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves,
            !sourceNoMovesCandidateActive else{return false}
        sourceDisposalSealingEnabled=true
        let expectedEpoch=sourceNoMovesConfigurationEpoch &+ 1
        retireSourceNoMoves()
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesConfigurationEpoch==expectedEpoch,
            sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves else{return false}
        let generation=engine.state.generation
        let priorRuntimeAuthority=engine.sourceNoMovesRuntimeAuthority
        let admitted=bindings.admitted(generation)
        guard admitted,sourceAnimationBindingAdmissionOpen,sourceNoMovesConfigurationEpoch==expectedEpoch,
            engine.state.generation==generation,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves else{return false}
        let authority=sourceNoMovesRuntimeAuthorityEnabled ? bindings.runtimeAuthority:nil
        if sourceNoMovesRuntimeAuthorityEnabled {
            guard engine.sourceNoMovesRuntimeAuthority === priorRuntimeAuthority,let authority else{return false}
            let current=authority.isCurrent()
            guard current,engine.sourceNoMovesRuntimeAuthority === priorRuntimeAuthority,sourceNoMovesRuntimeAuthorityEnabled,sourceAnimationBindingAdmissionOpen,sourceNoMovesConfigurationEpoch==expectedEpoch,
                engine.state.generation==generation,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves else{return false}
        }
        sourceNoMovesBindings=bindings;sourceNoMovesGeneration=generation
        let bridge=NativeSourceNoMovesSceneBridge(engine:engine,hooks:.init(
            current:{[weak self] gen in
                guard let self,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==gen,
                    self.sourceNoMovesGeneration==gen,self.sourceNoMovesConfigurationEpoch==expectedEpoch,
                    terminalRegistry?.current ?? true else{return false}
                let accepted=bindings.admitted(gen)
                return self.sourceAnimationBindingAdmissionOpen && self.sourceNoMovesGeneration==gen && self.sourceNoMovesConfigurationEpoch==expectedEpoch && self.engine.state.generation==gen && accepted && (terminalRegistry?.current ?? true)
            },refreshSourceRuntime:bindings.refreshRuntime,
            appWait:{[weak self] key,gen,ms,elapsed,cancelled in
                guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceNoMovesGeneration==gen else{return}
                self.sourceAppTimeouts.schedule(sourceID:key,generation:gen,delayMilliseconds:ms,elapsed:elapsed,cancelled:cancelled)
            },navigation:{[weak self] value in self?.navigationLocked=value},
            stopIdleAndIdleSmoke:bindings.stopIdleAndIdleSmoke,persistStuckState:bindings.persistStuckState,
            resetHint:bindings.resetHint,showText:showText,beginTextExit:beginTextExit,clearText:clearText,
            terminalFields:{active,ttl in
                if let terminalRegistry {_ = terminalRegistry.terminalFields(active:active,ttlMilliseconds:ttl,observer:bindings.terminalFields)}
                else {bindings.terminalFields(active,ttl)}
            },restartIdle:bindings.restartIdle,
            queueGuardRelease:bindings.queueGuardRelease,scheduleGSAPRecheck:bindings.scheduleGSAPRecheck,
            confirmedBoardExit:confirmedBoardExit,confirmedResult:{[weak self] result in
                guard let self,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==generation else{return}
                self.consume(result,previous:self.engine.state)
            },exitFailure:bindings.exitFailure))
        sourceNoMovesRetirement=clearText
        sourceNoMovesTerminalRegistry=terminalRegistry
        sourceNoMovesBridge=bridge
        if let authority {
            guard sourceAnimationBindingAdmissionOpen,sourceNoMovesBridge === bridge,
                sourceNoMovesConfigurationEpoch==expectedEpoch,engine.state.generation==generation else{return false}
            let bound:()->Bool = {[weak self,weak bridge] in
                guard let self,let bridge else{return false}
                return self.sourceAnimationBindingAdmissionOpen && self.sourceNoMovesRuntimeAuthorityEnabled &&
                    self.sourceNoMovesBridge === bridge && self.sourceNoMovesConfigurationEpoch==expectedEpoch &&
                    self.sourceNoMovesOwnedRuntimeAuthority != nil &&
                    self.engine.sourceNoMovesRuntimeAuthority === self.sourceNoMovesOwnedRuntimeAuthority &&
                    self.sourceNoMovesGeneration==generation && self.engine.state.generation==generation
            }
            let captured=NativeSourceNoMovesRuntimeAuthority(isCurrent:{
                guard bound() else{return false};let accepted=authority.isCurrent();return accepted && bound()
            },capture:{
                guard bound() else{return nil};let result=authority.capture();return bound() ? result:nil
            })
            sourceNoMovesOwnedRuntimeAuthority=captured;engine.sourceNoMovesRuntimeAuthority=captured
        }
        sourceNoMovesCallerInvocationBound=callerInvocationReceiptBound
        bridge.enabled=true;return true
    }
    /// The VC has received true from configure. Confirm only that exact captured
    /// publication; an unconfirmed endpoint deliberately refuses candidate use.
    @discardableResult func confirmSourceNoMovesTerminalRegistry(_ endpoint:NativeSourceNoMovesTerminalRegistryEndpoint)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesTerminalRegistry === endpoint,
            let bridge=sourceNoMovesBridge,let generation=sourceNoMovesGeneration else{return false}
        let epoch=sourceNoMovesConfigurationEpoch
        let accepted=endpoint.confirmPublication(current:{[weak self,weak bridge,weak endpoint] in
            guard let self,let bridge,let endpoint else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.sourceNoMovesBridge === bridge &&
                self.sourceNoMovesTerminalRegistry === endpoint && self.sourceNoMovesGeneration==generation &&
                self.sourceNoMovesConfigurationEpoch==epoch && self.engine.state.generation==generation
        })
        return accepted && sourceAnimationBindingAdmissionOpen && sourceNoMovesBridge === bridge &&
            sourceNoMovesTerminalRegistry === endpoint && sourceNoMovesConfigurationEpoch==epoch && engine.state.generation==generation
    }
    /// Captured owner removal never retires a replacement bridge C.
    @discardableResult func retireSourceNoMovesTerminalRegistry(_ endpoint:NativeSourceNoMovesTerminalRegistryEndpoint)->Bool {
        guard sourceNoMovesTerminalRegistry === endpoint else{return false}
        retireSourceNoMoves();return true
    }
    /// Genuine checkLevelEnd caller preflight, never a resolver .fail inference.
    @discardableResult func beginSourceNoMovesFromLevelEndCaller()->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves,
            let bridge=sourceNoMovesBridge,let bindings=sourceNoMovesBindings,
            let proof=bindings.levelEndPreflight(),!disposed,
            sourceNoMovesBridge === bridge,proof.admits(engine),!disposed,
            sourceNoMovesBridge === bridge,sourceNoMovesGeneration==engine.state.generation else{return false}
        let effect=bridge.begin(origin:.levelEnd)
        if case .candidate=effect{return true};return false
    }
    @discardableResult func refuseUnsupportedSourceNoMovesCaller(_ caller:NativeSourceNoMovesUnsupportedCaller)->Bool {
        // These callers never consume a postcheck or allocate ownership.
        false
    }
    func scheduleSourceNoMovesExitFallback(generation:UInt64,elapsed:@escaping()->Void)->(()->Void) {
        guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation else{return {}}
        let receipt=sourceAppTimeouts.schedule(sourceID:"no-moves-text1190:"+UUID().uuidString,
            generation:generation,delayMilliseconds:1190,elapsed:elapsed)
        return {[weak self] in _=self?.sourceAppTimeouts.cancel(receipt)}
    }
    @discardableResult func configureSourceNoMovesDepletedCallers(_ bindings:NativeSourceNoMovesDepletedCallerBindings)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesDepletedCallersEnabled,sourceNoMovesPresentationEnabled,
            sourceNoMovesRuntimeAuthorityEnabled,sourceNoMovesCallerInvocationBound,engine.stagedSourceNoMoves,sourceNoMovesCallerFlow==nil,
            let bridge=sourceNoMovesBridge,let authority=sourceNoMovesOwnedRuntimeAuthority,
            engine.sourceNoMovesRuntimeAuthority === authority,engine.sourceNoMovesCallerAdmission==nil,
            engine.sourceNoMovesCallerCompletionBinding==nil,let tasks=sourceAppTimeouts.sourceMicrotaskTasks,
            let installation=sourceMicrotaskInstallation,installation.isCurrent,installation.tasks === tasks,
            !bindings.kinds.isEmpty,bindings.kinds.isSubset(of:[.ordinaryMovesDepleted,.mergeMovesDepleted]) else{return false}
        if bindings.kinds.contains(.ordinaryMovesDepleted) {
            guard sourceSameNodeStackAbsorbsEnabled,sourceDragTweenDriver != nil,engine.stagedOrdinaryMoves else{return false}
        }
        if bindings.kinds.contains(.mergeMovesDepleted) {
            guard sourceOrdinarySixSameNodeEnabled,sourceSixScope?.current==true,engine.stagedOrdinaryAssignments,
                engine.sourceMergeSixAutoCenterHook === sourceSixAutoHook else{return false}
        }
        let generation=engine.state.generation,epoch=sourceNoMovesCallerEpoch
        let stackDriver=sourceDragTweenDriver,sixScope=sourceSixScope,sixHook=sourceSixAutoHook
        // Pure captured endpoint seal. Presence callbacks cannot change the
        // selected Scene/Core producer and still publish A's capability.
        let prerequisitesMatch:()->Bool = {[weak self] in
            guard let self else{return false}
            if bindings.kinds.contains(.ordinaryMovesDepleted) {
                guard self.sourceSameNodeStackAbsorbsEnabled,self.engine.stagedOrdinaryMoves,
                    stackDriver != nil,self.sourceDragTweenDriver === stackDriver else{return false}
            }
            if bindings.kinds.contains(.mergeMovesDepleted) {
                guard self.sourceOrdinarySixSameNodeEnabled,self.engine.stagedOrdinaryAssignments,
                    sixScope != nil,sixHook != nil,self.sourceSixScope === sixScope,self.sourceSixAutoHook === sixHook,
                    self.engine.sourceMergeSixAutoCenterHook === sixHook else{return false}
            }
            return true
        }
        guard prerequisitesMatch() else{return false}
        let accepted=bindings.admitted(generation,bindings.kinds)
        guard accepted,prerequisitesMatch(),sourceAnimationBindingAdmissionOpen,sourceNoMovesDepletedCallersEnabled,
            sourceNoMovesPresentationEnabled,sourceNoMovesRuntimeAuthorityEnabled,engine.stagedSourceNoMoves,
            sourceNoMovesCallerEpoch==epoch,sourceNoMovesBridge === bridge,sourceNoMovesCallerFlow==nil,
            sourceNoMovesOwnedRuntimeAuthority === authority,sourceAppTimeouts.sourceMicrotaskTasks === tasks,
            sourceMicrotaskInstallation === installation,sourceNoMovesCallerInvocationBound,
            engine.state.generation==generation,engine.sourceNoMovesRuntimeAuthority === authority,
            engine.sourceNoMovesCallerAdmission==nil,engine.sourceNoMovesCallerCompletionBinding==nil else{return false}
        let admission=NativeSourceNoMovesCallerAdmission(generation:generation,kinds:bindings.kinds)
        let current:(NativeSourceNoMovesCallerReceipt)->Bool = {[weak self,weak bridge] receipt in
            guard let self,let bridge,prerequisitesMatch(),self.sourceAnimationBindingAdmissionOpen,self.sourceNoMovesDepletedCallersEnabled,
                self.sourceNoMovesPresentationEnabled,self.sourceNoMovesRuntimeAuthorityEnabled,self.engine.stagedSourceNoMoves,
                self.sourceNoMovesCallerAdmission === admission,self.sourceNoMovesBridge === bridge,
                self.sourceNoMovesOwnedRuntimeAuthority === authority,self.engine.sourceNoMovesRuntimeAuthority === authority,
                self.sourceAppTimeouts.sourceMicrotaskTasks === tasks,
                self.sourceNoMovesCallerEpoch==epoch,self.engine.state.generation==generation,
                self.engine.sourceNoMovesCallerIsCurrent(receipt) else{return false}
            let result=bindings.admitted(generation,bindings.kinds)
            return result && prerequisitesMatch() && self.sourceAnimationBindingAdmissionOpen && self.sourceNoMovesCallerAdmission === admission &&
                self.sourceNoMovesPresentationEnabled && self.sourceNoMovesRuntimeAuthorityEnabled && self.engine.stagedSourceNoMoves &&
                self.sourceNoMovesBridge === bridge && self.sourceNoMovesOwnedRuntimeAuthority === authority &&
                self.engine.sourceNoMovesRuntimeAuthority === authority && self.sourceAppTimeouts.sourceMicrotaskTasks === tasks &&
                self.sourceNoMovesCallerEpoch==epoch && self.engine.state.generation==generation && self.engine.sourceNoMovesCallerIsCurrent(receipt)
        }
        let flow=NativeSourceNoMovesDepletedCallerFlow(hooks:.init(current:current,busyEnding:bindings.busyEnding,wait:{[weak self] key,gen,ms,elapsed,cancelled in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceNoMovesCallerAdmission === admission,
                self.engine.state.generation==gen else{return {}}
            let timer=self.sourceAppTimeouts.schedule(sourceID:key,generation:gen,delayMilliseconds:ms,elapsed:elapsed,cancelled:cancelled)
            return {[weak self] in _=self?.sourceAppTimeouts.cancel(timer)}
        },ensureTutorialSingleTile:bindings.ensureTutorialSingleTile,fresh:bindings.forceFresh,resetHint:bindings.resetHint,
            deferWild:bindings.deferWild,tutorialFinalChance:bindings.tutorialFinalChance,cleanVisibility:bindings.cleanVisibility,
            clean:bindings.clean,beginNoMoves:{[weak self,weak bridge] receipt,reply in
                guard let self,let bridge,current(receipt),self.sourceNoMovesBridge === bridge else{return}
                self.sourceNoMovesCallerReplies[receipt.id]=(admission.id,reply)
                let effect=bridge.capturedCaller(receipt)
                guard self.sourceNoMovesCallerAdmission === admission,self.sourceNoMovesBridge === bridge,
                    self.sourceNoMovesCallerEpoch==epoch,self.engine.state.generation==generation else{return}
                if case .candidate=effect {return} // actual final/rollback receipt owns reply
                if let completion=self.sourceNoMovesCallerCompletion,completion.admissionID==admission.id {
                    // Async Source returns/deferrals still resolve via one actual
                    // Promise reaction. Never inline a caller continuation.
                    completion.deliver(receipt)
                }
            },continueMergeSix:{[weak self] receipt in
                guard let self,current(receipt) else{return};let previous=self.engine.state
                let result=self.engine.continueSourceMergeSixAfterNoMovesCaller(receipt)
                guard self.sourceAnimationBindingAdmissionOpen,self.sourceNoMovesCallerAdmission === admission,
                    self.engine.state.generation==generation,result.accepted else{return}
                self.consume(result,previous:previous);self.releaseOrdinarySixIfReady()
            },returned:{[weak self] receipt,reason in
                guard let self else{return}
                if reason == .unsupported {_=self.engine.refuseSourceNoMovesCaller(receipt)}
                else {_=self.engine.retireSourceNoMovesCaller(receipt)}
            }))
        let completion=NativeSourceNoMovesCallerCompletionBinding(admissionID:admission.id,deliver:{[weak self] receipt in
            guard let self,self.sourceNoMovesCallerAdmission === admission,self.sourceNoMovesCallerEpoch==epoch,
                self.engine.state.generation==generation,let pending=self.sourceNoMovesCallerReplies[receipt.id],
                pending.0==admission.id else{return}
            let enqueued=installation.enqueue{[weak self] in
                guard let self,self.sourceNoMovesCallerAdmission === admission,self.sourceNoMovesCallerEpoch==epoch,
                    self.engine.state.generation==generation,
                    let captured=self.sourceNoMovesCallerReplies[receipt.id],captured.0==pending.0 else{return}
                self.sourceNoMovesCallerReplies.removeValue(forKey:receipt.id);captured.1()
            }
            if !enqueued {_=self.engine.refuseSourceNoMovesCaller(receipt)}
        })
        sourceNoMovesCallerAdmission=admission;sourceNoMovesCallerFlow=flow;sourceNoMovesCallerCompletion=completion
        engine.sourceNoMovesCallerAdmission=admission;engine.sourceNoMovesCallerCompletionBinding=completion
        engine.sourceNoMovesCallerReceiptsEnabled=true;return true
    }
    @discardableResult func configureSourceOrdinaryPreDebit(_ bindings:NativeSourceOrdinaryPreDebitBindings)->Bool {
        guard bindings.markerCapabilities == Set(NativeSourceNoMovesRuntimeSnapshot.Capability.allCases),
            sourceAnimationBindingAdmissionOpen,sourceOrdinaryPreDebitPresentationEnabled,
            sourceSameNodeStackAbsorbsEnabled,engine.stagedOrdinaryMoves,engine.stagedSourceNoMoves,
            sourceNoMovesPresentationEnabled,sourceNoMovesRuntimeAuthorityEnabled,sourceNoMovesCallerInvocationBound,
            let callerAdmission=sourceNoMovesCallerAdmission,callerAdmission.kinds.contains(.ordinaryMovesDepleted),
            let completion=sourceNoMovesCallerCompletion,engine.sourceNoMovesCallerAdmission === callerAdmission,
            engine.sourceNoMovesCallerCompletionBinding === completion,let bridge=sourceNoMovesBridge,
            let authority=sourceNoMovesOwnedRuntimeAuthority,engine.sourceNoMovesRuntimeAuthority === authority,
            let driver=sourceDragTweenDriver,let installation=sourceMicrotaskInstallation,installation.isCurrent,
            let tasks=sourceAppTimeouts.sourceMicrotaskTasks,installation.tasks === tasks,
            sourceOrdinaryPreDebitFlow==nil,engine.sourceOrdinaryPreDebitAdmission==nil else{return false}
        let gen=engine.state.generation,epoch=sourceOrdinaryPreDebitEpoch,callerEpoch=sourceNoMovesCallerEpoch
        let seal:()->Bool = {[weak self,weak bridge] in
            guard let self,let bridge else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.sourceOrdinaryPreDebitPresentationEnabled &&
                self.sourceSameNodeStackAbsorbsEnabled && self.engine.stagedOrdinaryMoves && self.engine.stagedSourceNoMoves &&
                self.sourceNoMovesPresentationEnabled && self.sourceNoMovesRuntimeAuthorityEnabled && self.sourceNoMovesCallerInvocationBound &&
                self.engine.state.generation==gen && self.sourceOrdinaryPreDebitEpoch==epoch && self.sourceNoMovesCallerEpoch==callerEpoch &&
                self.sourceNoMovesCallerAdmission === callerAdmission && self.engine.sourceNoMovesCallerAdmission === callerAdmission && !callerAdmission.retired &&
                self.sourceNoMovesCallerCompletion === completion && self.engine.sourceNoMovesCallerCompletionBinding === completion &&
                self.sourceNoMovesBridge === bridge && self.sourceNoMovesOwnedRuntimeAuthority === authority && self.engine.sourceNoMovesRuntimeAuthority === authority &&
                self.sourceDragTweenDriver === driver && self.sourceMicrotaskInstallation === installation && installation.isCurrent &&
                self.sourceAppTimeouts.sourceMicrotaskTasks === tasks
        }
        guard seal() else{return false}
        let admitted=bindings.admitted(gen);guard admitted,seal(),sourceOrdinaryPreDebitFlow==nil,engine.sourceOrdinaryPreDebitAdmission==nil else{return false}
        let endpoint=NativeSourceOrdinaryPreDebitAdmission(callerAdmissionID:callerAdmission.id,generation:gen,isCurrent:{
            guard seal() else{return false};let accepted=bindings.admitted(gen);return accepted && seal()
        })
        let current:(NativeSourceOrdinaryPreDebitReceipt)->Bool = {[weak self,weak endpoint] receipt in
            guard let self,let endpoint,seal(),self.sourceOrdinaryPreDebitAdmission === endpoint,
                self.engine.sourceOrdinaryPreDebitAdmission === endpoint,!endpoint.retired else{return false}
            return self.engine.sourceOrdinaryPreDebitIsCurrent(receipt) && seal() && self.sourceOrdinaryPreDebitAdmission === endpoint
        }
        let enqueue:(@escaping()->Void)->Void = {body in _=installation.enqueue{guard seal() else{return};body()}}
        let flow=NativeSourceOrdinaryPreDebitFlow(hooks:.init(current:current,mainCapture:{[weak self] receipt in
            guard let self,current(receipt) else{return nil};return self.sourcePreDebitMain[receipt.ownerID]
        },busyEnding:bindings.busyEnding,wait:{[weak self] key,generation,ms,elapsed,cancelled in
            guard let self,seal() else{return {}}
            let token=self.sourceAppTimeouts.schedule(sourceID:key,generation:generation,delayMilliseconds:ms,elapsed:elapsed,cancelled:cancelled)
            return {[weak self] in _=self?.sourceAppTimeouts.cancel(token)}
        },stateRoster:{[weak self] in
            guard let self,seal() else{return nil};let roster=bindings.stateRoster()
            guard seal(),let roster,self.sourcePreDebitRosterMatches(roster) else{return nil};return roster
        },reread:{[weak self] held in
            guard let self,seal() else{return nil};let tile=bindings.reread(held)
            guard seal(),let tile,tile.object === held.object,self.sourcePreDebitTileMatches(tile) else{return nil};return tile
        },fresh:bindings.forceFresh,clearEndGameCache:bindings.clearEndGameCache,resetHint:bindings.resetHint,
            deferStackWild:bindings.deferStackWild,ensureTutorialSingleTile:{reason,reply in
                bindings.ensureTutorialSingleTile(reason,{value in enqueue{reply(value)}})
            },tutorialFinalChance:{reason,reply in
                bindings.tutorialFinalChance(reason,{value in enqueue{reply(value)}})
            },beginNoMoves:{[weak self,weak bridge] receipt,trigger,reply in
                guard let self,let bridge,current(receipt),let caller=self.engine.prepareSourceOrdinaryPreDebitNoMoves(receipt,trigger:trigger),current(receipt) else{return}
                self.sourceNoMovesCallerReplies[caller.id]=(callerAdmission.id,reply)
                let effect=bridge.capturedCaller(caller)
                guard seal(),current(receipt) else{return}
                if case .candidate=effect {return} // actual invocation/rollback reply owns continuation
                completion.deliver(caller) // same genuine Source FIFO completion endpoint
            },finished:{[weak self] receipt,reason in
                guard let self,current(receipt),self.sourcePreDebitRequests[receipt.ownerID]==receipt else{return}
                if reason == .unsupported {_=self.engine.refuseSourceOrdinaryPreDebit(receipt);return}
                let outcome:NativeSourceOrdinaryPreDebitOutcome = reason == .continueToDebit ? .continueToDebit:(reason == .cancelled ? .cancelled:.returned)
                let previous=self.engine.state
                let result=self.engine.finishSourceOrdinaryPreDebit(receipt,outcome:outcome)
                guard seal(),result.accepted else{return}
                self.sourcePreDebitRequests.removeValue(forKey:receipt.ownerID);self.sourcePreDebitContacts.removeValue(forKey:receipt.ownerID);self.sourcePreDebitMain.removeValue(forKey:receipt.ownerID)
                let callers=self.engine.pendingSourceNoMovesCallerReceipts.filter{$0.ownerID==receipt.ownerID && $0.isPreDebit}
                for caller in callers {_=self.engine.retireSourceNoMovesCaller(caller)}
                if outcome == .continueToDebit {self.startSourceNoMovesDepletedCaller(ownerID:receipt.ownerID,kind:.ordinaryMovesDepleted,generation:receipt.generation)}
                self.consume(result,previous:previous)
            }))
        guard seal(),sourceOrdinaryPreDebitFlow==nil,engine.sourceOrdinaryPreDebitAdmission==nil else{endpoint.retire();flow.dispose();return false}
        sourceOrdinaryPreDebitBindings=bindings;sourceOrdinaryPreDebitAdmission=endpoint;sourceOrdinaryPreDebitFlow=flow
        engine.sourceOrdinaryPreDebitAdmission=endpoint;engine.sourceOrdinaryPreDebitEnabled=true;return true
    }
    private func sourcePreDebitTileMatches(_ tile:NativeSourcePostcheckTile)->Bool {
        guard let node=tile.object as? NativeDiceNode,nodesByID[tile.id] === node,node.parent === canvasRoot,
            node.sourceGeneration==engine.state.generation,node.sourceContactNodeAlive,
            node.sourceValue==tile.value,node.sourceStackDepth==tile.depth,node.sourceLocked==tile.locked else{return false}
        // actual wild-like marker predicate is supplied by its covered observer;
        // special nil/default Star texture alone is not a regular-kind proof.
        return true
    }
    private func sourcePreDebitRosterMatches(_ roster:NativeSourcePostcheckRoster)->Bool {
        roster.complete && roster.tiles.map(\.id)==engine.state.tiles.map(\.id) && roster.tiles.allSatisfy(sourcePreDebitTileMatches)
    }
    private func captureSourcePreDebitContact(sourceID:String,destinationID:String,generation:UInt64)->SourcePreDebitContact? {
        guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation,
            let bindings=sourceOrdinaryPreDebitBindings,let endpoint=sourceOrdinaryPreDebitAdmission,
            engine.sourceOrdinaryPreDebitAdmission === endpoint,let source=nodesByID[sourceID],let destination=nodesByID[destinationID],
            source.parent === canvasRoot,destination.parent === canvasRoot,source.sourceGeneration==generation,destination.sourceGeneration==generation,
            source.sourceContactNodeAlive,destination.sourceContactNodeAlive else{return nil}
        let epoch=sourceOrdinaryPreDebitEpoch,roster=bindings.captureBefore()
        guard sourceAnimationBindingAdmissionOpen,sourceOrdinaryPreDebitEpoch==epoch,sourceOrdinaryPreDebitAdmission === endpoint,
            engine.state.generation==generation,let roster,sourcePreDebitRosterMatches(roster),nodesByID[sourceID] === source,nodesByID[destinationID] === destination else{return nil}
        let active=roster.tiles.filter(\.active)
        guard let s=roster.tiles.first(where:{$0.object === source}),let d=roster.tiles.first(where:{$0.object === destination}),
            !s.isWildLike,!d.isWildLike,!source.isSpecial,!destination.isSpecial,
            !source.sourceResidualWildPresence,!destination.sourceResidualWildPresence,source.variant==nil,destination.variant==nil else{return nil}
        return SourcePreDebitContact(source:source,destination:destination,sourceSpecial:nil,destinationSpecial:nil,
            effectiveSum:s.value+d.value,visibleBefore:active.count,physicalBefore:active.reduce(0){$0+max(1,$1.depth)},
            bothCapturedActive:active.contains{$0.object === source} && active.contains{$0.object === destination},generation:generation,epoch:epoch)
    }
    private func captureSourcePreDebitMain(id:String,generation:UInt64) {
        guard sourceAnimationBindingAdmissionOpen,sourceOrdinaryPreDebitPresentationEnabled,let contact=sourcePreDebitContacts[id],
            contact.generation==generation,contact.epoch==sourceOrdinaryPreDebitEpoch,engine.state.generation==generation,
            nodesByID[contact.source.tileID] === contact.source,nodesByID[contact.destination.tileID] === contact.destination,
            contact.source.parent === canvasRoot,contact.destination.parent === canvasRoot,
            contact.source.sourceContactNodeAlive,contact.destination.sourceContactNodeAlive else{return}
        sourcePreDebitMain[id]=NativeSourcePostcheckMainCapture(source:contact.source,destination:contact.destination,
            sourceID:contact.source.tileID,destinationID:contact.destination.tileID,effectiveSum:contact.effectiveSum,
            sourceValue:contact.source.sourceValue,destinationValue:contact.destination.sourceValue,
            sourceSpecial:contact.sourceSpecial,destinationSpecial:contact.destinationSpecial,
            sourceDepth:max(1,contact.source.sourceStackDepth),destinationDepth:max(1,contact.destination.sourceStackDepth),
            visibleBefore:contact.visibleBefore,physicalBefore:contact.physicalBefore,bothCapturedActive:contact.bothCapturedActive)
    }
    private func retireSourceOrdinaryPreDebit() {
        let flow=sourceOrdinaryPreDebitFlow,endpoint=sourceOrdinaryPreDebitAdmission,requests=Array(sourcePreDebitRequests.values)
        sourceOrdinaryPreDebitFlow=nil;sourceOrdinaryPreDebitAdmission=nil;sourceOrdinaryPreDebitBindings=nil
        sourcePreDebitRequests=[:];sourcePreDebitContacts=[:];sourcePreDebitMain=[:];sourcePreDebitDeferredMain=[];sourceOrdinaryPreDebitEpoch &+= 1
        if let endpoint,engine.sourceOrdinaryPreDebitAdmission === endpoint {engine.sourceOrdinaryPreDebitAdmission=nil;engine.sourceOrdinaryPreDebitEnabled=false}
        endpoint?.retire();flow?.dispose()
        for receipt in requests {_=engine.retireSourceOrdinaryPreDebit(receipt)}
    }
    @discardableResult func sourceNoMovesConfirmedCallerInvocation(planToken:UInt64,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesCallerInvocationBound,
            sourceNoMovesCallerAdmission != nil,engine.state.generation==generation,let bridge=sourceNoMovesBridge else{return false}
        return bridge.confirmedCallerInvocation(planToken:planToken,generation:generation)
    }
    private func startSourceNoMovesDepletedCaller(ownerID:String,kind:NativeSourceNoMovesCallerReceipt.Kind,generation:UInt64) {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesDepletedCallersEnabled,let flow=sourceNoMovesCallerFlow,
            let receipt=engine.sourceNoMovesCaller(ownerID:ownerID,generation:generation,kind:kind) else{return}
        if !flow.start(receipt) {_=engine.refuseSourceNoMovesCaller(receipt)}
    }
    private func retireSourceNoMovesDepletedCallers() {
        retireSourceOrdinaryPreDebit()
        let flow=sourceNoMovesCallerFlow,admission=sourceNoMovesCallerAdmission,completion=sourceNoMovesCallerCompletion
        sourceNoMovesCallerFlow=nil;sourceNoMovesCallerAdmission=nil;sourceNoMovesCallerCompletion=nil
        sourceNoMovesCallerReplies=[:];sourceNoMovesCallerEpoch &+= 1
        if let completion,engine.sourceNoMovesCallerCompletionBinding === completion {engine.sourceNoMovesCallerCompletionBinding=nil}
        if let admission,engine.sourceNoMovesCallerAdmission === admission {
            engine.sourceNoMovesCallerAdmission=nil;engine.sourceNoMovesCallerReceiptsEnabled=false
        }
        let captured=engine.pendingSourceNoMovesCallerReceipts.filter{$0.admissionID==admission?.id}
        admission?.retire();flow?.dispose()
        for receipt in captured {_=engine.retireSourceNoMovesCaller(receipt)}
    }
    func retireSourceNoMoves() {
        let authority=sourceNoMovesOwnedRuntimeAuthority;sourceNoMovesOwnedRuntimeAuthority=nil
        if let authority,engine.sourceNoMovesRuntimeAuthority === authority {engine.sourceNoMovesRuntimeAuthority=nil}
        let captured=sourceNoMovesBridge,clear=sourceNoMovesRetirement,terminal=sourceNoMovesTerminalRegistry
        sourceNoMovesRetirement=nil
        sourceNoMovesConfigurationEpoch &+= 1
        sourceNoMovesBridge=nil;sourceNoMovesBindings=nil;sourceNoMovesGeneration=nil;sourceNoMovesTerminalRegistry=nil;sourceNoMovesCallerInvocationBound=false
        retireSourceNoMovesDepletedCallers()
        terminal?.retire();captured?.retireObsolete();clear?()
    }
    private var ordinarySpawnVisuals:[String:UInt64] = [:]
    private var ordinaryDeferred=Set<String>()
    private var sourceLockedBounceActionIDs=Set<String>()
    private var sourceLockedSlotMarkerNodes:[String:NativeDiceNode]=[:]
    var onLevelFlowBounceCompletion:((String,UInt64)->Void)?
    private var ordinaryPrimaryVisuals:[String:(String,String,UInt64)] = [:]
    private struct OrdinarySixVisual {
        let id:String,generation:UInt64,receipt:UInt64
        var committed=false,consuming=false
    }
    var onFishIdleFrames:(([String:NativeFishIdleFrame],UInt64,Bool)->Void)?
    var onJourneyBottomDecorShake:((CGPoint,UInt64)->Void)?
    var reducedBoardEffects=false
    var onPresentationFailure:((String)->Void)?
    private var regularSixPresentations:[String:NativeRegularSixSpritePresentation]=[:]
    private var regularSixShakeID:String?
    private var boardShake=NativeRegularSixSpritePresentation.ShakeReceipt(canvas:.zero,indicator:.zero,bottomDecor:.zero)
    private var ordinarySixVisual:OrdinarySixVisual?
    private var specialPresentationIDs = Set<String>()
    private var laserSpawnCallbacks:[String:() -> Void] = [:]
    private let sourceAppTimeouts=NativeSourceAppTimeoutOwner()
    private var sourceMicrotaskInstallation:NativeSourceSceneMicrotaskInstallation?
    private var sourceMicrotaskConfigurationEpoch:UInt64=0
    var sourceMicrotaskBoundariesInstalled:Bool{sourceMicrotaskInstallation?.isCurrent==true}
    /// All four real producer paths are installed by this Scene, but FIFO/tasks
    /// are borrowed from the app scope. No creation or service mutation here.
    @discardableResult func configureSourceMicrotaskBoundaries(scope:NativeGameplaySourceContext.Scope,
        fifo:NativeSourceMicrotaskFIFO)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceMicrotaskInstallation==nil,
              sourceMeterCaller==nil,sourceMeterQueue==nil,sourceMeterLanding==nil,
              scope.current,let tasks=scope.sourceMicrotaskTasks,tasks.isBound(to:fifo),
              scope.service.sourceMicrotaskTasks === tasks,scope.service.sourceMicrotaskRAFBoundaryInstalled,
              sourceAppTimeouts.sourceMicrotaskTasks==nil else{return false}
        sourceMicrotaskConfigurationEpoch &+= 1
        let epoch=sourceMicrotaskConfigurationEpoch,generation=engine.state.generation
        let current:()->Bool = {[weak self,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceMicrotaskConfigurationEpoch==epoch,
                  self.engine.state.generation==generation,self.sourceAppTimeouts.sourceMicrotaskTasks === tasks,
                  scope.sourceMicrotaskTasks === tasks,scope.service.sourceMicrotaskTasks === tasks else{return false}
            let valid=scope.current
            return valid && self.sourceAnimationBindingAdmissionOpen && self.sourceMicrotaskConfigurationEpoch==epoch &&
                self.engine.state.generation==generation && self.sourceAppTimeouts.sourceMicrotaskTasks === tasks &&
                scope.sourceMicrotaskTasks === tasks && scope.service.sourceMicrotaskTasks === tasks
        }
        sourceAppTimeouts.sourceMicrotaskTasks=tasks
        guard current(),let binding=NativeSourceSceneMicrotaskInstallation(fifo:fifo,tasks:tasks,
            service:scope.service,timeouts:sourceAppTimeouts,current:current),current(),sourceMicrotaskInstallation==nil else {
            // No external dispose occurs before unhook; an old A cannot clear C.
            if sourceMicrotaskConfigurationEpoch==epoch,sourceMicrotaskInstallation==nil,
               sourceAppTimeouts.sourceMicrotaskTasks === tasks {sourceAppTimeouts.sourceMicrotaskTasks=nil}
            return false
        }
        sourceMicrotaskInstallation=binding;sourceDisposalSealingEnabled=true
        return true
    }
    func retireSourceMicrotaskBoundaries() {
        sourceMicrotaskConfigurationEpoch &+= 1
        let binding=sourceMicrotaskInstallation;sourceMicrotaskInstallation=nil
        if let binding,sourceAppTimeouts.sourceMicrotaskTasks === binding.tasks {sourceAppTimeouts.sourceMicrotaskTasks=nil}
        binding?.dispose() // unhook ALL owned slots before dropping captures
    }
    private func sourceMeterEnqueue(_ binding:NativeSourceSceneMicrotaskInstallation?,_ action:@escaping @MainActor ()->Void) {
        guard let binding else{DispatchQueue.main.async{action()};return} // unchanged default fixture/Raw path
        guard sourceMicrotaskInstallation === binding,binding.isCurrent,binding.enqueue(action) else {
            if sourceAnimationBindingAdmissionOpen {onPresentationFailure?("source_meter_microtask_producer_not_bound")}
            return // never synthesize an async fallback for Source-owned work
        }
    }
    // PRIVATE/default OFF: genuine pre-Core autoCenter and same-object main80.
    // App-created Scope owns all clocks/RNG/pools. This bridge creates none.
    var sourceOrdinarySixSameNodeEnabled=false
    var sourceDirectWildSameNodeEnabled=false
    private weak var sourceDirectScope:NativeGameplaySourceContext.Scope?
    var sourceDirectWildDestinationFaceEnabled=false
    private var sourceDirectWildDestinationTexture:SKTexture?
    private var sourceDirectWildDestinationPreparationEpoch:UInt64=0
    /// Existing texture owner performs selected decode/upload before admission.
    /// No new Source wait is inserted in a valid contact; unready drops refuse.
    func prepareSourceDirectWildDestinationFace(scope:NativeGameplaySourceContext.Scope,completion:@escaping(Bool)->Void) {
        guard sourceAnimationBindingAdmissionOpen,sourceDirectWildDestinationFaceEnabled,
              sourceDirectScope === scope,scope.current else{completion(false);return}
        sourceDirectWildDestinationPreparationEpoch &+= 1
        let epoch=sourceDirectWildDestinationPreparationEpoch,generation=engine.state.generation
        sourceDirectWildDestinationTexture=nil
        textures.prepareSelectedFinaleAsset(.init(["assets/wild.png"])) {[weak self,weak scope] texture in
            guard let self,let scope,self.sourceAnimationBindingAdmissionOpen,scope.current,
                  self.sourceDirectScope === scope,self.engine.state.generation==generation,
                  self.sourceDirectWildDestinationPreparationEpoch==epoch else{completion(false);return}
            self.sourceDirectWildDestinationTexture=texture
            completion(texture != nil)
        }
    }

    private var sourceSixScope:NativeGameplaySourceContext.Scope?
    private var sourceSixAutoHook:NativeSourceMergeSixAutoCenterHook?
    private var sourceSixShared:NativeRegularSixSharedContext?
    private var sourceSixSurfaces:NativeSixSourceSurfaceOwner?
    private var sourceSixIdleAcquire:((String)->(()->Void)?)?
    private var sourceSixIdleReleases:[String:()->Void]=[:]
    private var sourceSixHeroes:[String:NativeSourceMergeSixHeroOwner]=[:]
    @MainActor private final class SourceSixContact {
        let source,destination:NativeDiceNode,generation:UInt64,owner:NativeSourceMergeSixAbsorbOwner
        var plan:NativeOrdinaryMovePlan?,directPlan:NativeDirectWildMovePlan?,capture:NativeSourceMergeSixMainCapture<NativeDiceNode>?,root:UUID?
        var transactionID:String? {plan?.id ?? directPlan?.id}
        var visualReceipt:UInt64?
        var retired=false
        init(source:NativeDiceNode,destination:NativeDiceNode,generation:UInt64,owner:NativeSourceMergeSixAbsorbOwner){self.source=source;self.destination=destination;self.generation=generation;self.owner=owner}
        isolated deinit {capture?.capturedObjectRetired();owner.dispose()}
    }
    private var sourceSixPrepared:SourceSixContact?
    private var sourceSixContacts:[String:SourceSixContact]=[:]
    var sourceSameObjectSixCount:Int {sourceSixContacts.count}
    @discardableResult func configureSourceOrdinarySixMain(scope:NativeGameplaySourceContext.Scope,
        acquireIdle:@escaping(String)->(()->Void)?) -> Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceSameNodeStackAbsorbsEnabled,sourceOrdinarySixSameNodeEnabled,scope.current,
              sourceSixScope==nil,engine.sourceMergeSixAutoCenterHook==nil,
              sourceDragTweenDriver === scope.tween,sourceStackFrameService === scope.service,
              scope.service.sourceFrameTransportAdmissionOpen,engine.stagedOrdinaryMoves,
              engine.stagedOrdinaryAssignments,UIFont(name:"Arial-BoldMT",size:33) != nil else{return false}
        let generation=engine.state.generation
        let current:(UInt64)->Bool = {[weak self,scope] gen in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==gen,
                  self.sourceSixScope === scope,scope.current else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.engine.state.generation==gen && self.sourceSixScope === scope && scope.current
        }
        let shared=NativeRegularSixSharedContext(resources:scope.sixResources,
            scheduler:NativeSharedSmokeClockRootScheduler(service:scope.service),
            wall:NativeRegularSixAppWallScheduler(timers:sourceAppTimeouts),smokeRenderer:scope.smoke,
            monotonicNow:{CACurrentMediaTime()*1000},current:current,acquire:{[weak self] receipt in
                guard let self,current(receipt.generation) else{return nil}
                let kind:NativeSourceFrameRuntime.Kind=receipt.kind == .shards ? .regularSixShards:.regularSixSmoke
                return self.beginSourceMotion(kind,id:receipt.invocationID,generation:receipt.generation)
            })
        let surfaces=NativeSixSourceSurfaceOwner(service:scope.service,current:{current(generation)},paintShake:{[weak self] pose in
            guard let self,current(generation) else{return}
            self.applyBoardShake(.init(canvas:CGPoint(x:pose.canvas[0],y:pose.canvas[1]),indicator:CGPoint(x:pose.indicator[0],y:pose.indicator[1]),bottomDecor:CGPoint(x:pose.decor[0],y:pose.decor[1])))
        })
        let hook=NativeSourceMergeSixAutoCenterHook(usesSourceDestinationParentState:true,prepare:{[weak self] source,destination,gen in
            self?.prepareSourceSixAuto(source:source,destination:destination,generation:gen)
        })
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceSixScope==nil,engine.sourceMergeSixAutoCenterHook==nil,
              engine.state.generation==generation else{shared.dispose();surfaces.dispose();return false}
        sourceSixScope=scope;sourceSixShared=shared;sourceSixSurfaces=surfaces;sourceSixIdleAcquire=acquireIdle
        sourceSixAutoHook=hook;engine.sourceMergeSixAutoCenterHook=hook
        sourceDisposalSealingEnabled=true;return true
    }
    private func sourceSixNodeCurrent(_ node:NativeDiceNode,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceSameNodeStackAbsorbsEnabled,(sourceOrdinarySixSameNodeEnabled || sourceDirectWildSameNodeEnabled),let scope=sourceSixScope,
              scope.current,engine.state.generation==generation,nodesByID[node.tileID] === node,
              node.parent === canvasRoot,node.sourceGeneration==generation,node.sourceContactNodeAlive else{return false}
        return sourceAnimationBindingAdmissionOpen && sourceSixScope === scope && scope.current &&
            engine.state.generation==generation && nodesByID[node.tileID] === node && node.parent === canvasRoot && node.sourceGeneration==generation && node.sourceContactNodeAlive
    }
    @discardableResult func configureSourceDirectWildMain(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceDirectWildSameNodeEnabled,
              sourceSixScope === scope,sourceDirectScope==nil,scope.current,sourceSpecialTransactions != nil,
              sourceSpecialIdleAdmissionOpen,engine.stagedDirectWildMoves,engine.stagedDirectWildAssignments,
              sourceStackFrameService === scope.service,sourceDragTweenDriver === scope.tween,
              scope.service.sourceFrameTransportAdmissionOpen else{return false}
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceSixScope === scope,sourceSpecialIdleAdmissionOpen else{return false}
        sourceDirectScope=scope
        sourceSixIdleAcquire={[weak self] reason in self?.acquireSourceSpecialIdle(reason:reason)}
        return true
    }
    private func sourceDirectReady(source:NativeTile,destination:NativeTile,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceDirectWildSameNodeEnabled,
              (source.isWild || destination.isWild),destination.variant==nil,
              sourceSpecialTransactions != nil,engine.stagedDirectWildMoves,engine.stagedDirectWildAssignments,
              let scope=sourceSixScope,sourceDirectScope === scope,scope.current,sourceSpecialIdleAdmissionOpen,
              let src=nodesByID[source.id],let dst=nodesByID[destination.id],
              sourceSixNodeCurrent(src,generation:generation),sourceSixNodeCurrent(dst,generation:generation),
              src.sourceOuterDriven,dst.sourceOuterDriven,src.value==source.value,dst.value==destination.value,
              src.depth==source.stackDepth,dst.depth==destination.stackDepth,
              !src.sourceRegularFramePending,!dst.sourceRegularFramePending,
              sourceSixPrepared==nil,sourceSixContacts.isEmpty,sourceSixIdleAcquire != nil,
              engine.state.generation==generation else{return false}
        if destination.isWild {
            guard sourceDirectWildDestinationFaceEnabled,sourceDirectWildDestinationTexture != nil,
                  (destination.gameplayArchetype == .star || destination.gameplayArchetype == .juice),
                  dst.sourceWildDestinationFaceReady(service:scope.service) else{return false}
        } else {guard dst.sourceMergeSixFaceReady(service:scope.service) else{return false}}
        let archetype=source.gameplayArchetype ?? destination.gameplayArchetype
        let pull=archetype == .magnet && !NativeGameplayResolver.magnetCandidates(engine.state.tiles,source:source,destination:destination).isEmpty
        let final=NativeGameplayResolver.finalMerge(engine.state.tiles,source:source,destination:destination,effectiveSum:6,hasTilesToPull:pull)
        guard final.isFinalMerge || archetype == .star || archetype == .juice else{return false}
        if archetype == .star || archetype == .juice {guard sourceHUDStarJobsAdmissionOpen else{return false}}
        if final.isFinalMerge {guard engine.finalePresentationAdmitted != nil else{return false}}
        return sourceSixNodeCurrent(src,generation:generation) && sourceSixNodeCurrent(dst,generation:generation)
    }
    private func sourceSixReady(source:NativeTile,destination:NativeTile,generation:UInt64)->Bool {
        guard !source.isWild,!destination.isWild,source.value+destination.value==6,
              let scope=sourceSixScope,let src=nodesByID[source.id],let dst=nodesByID[destination.id],
              sourceSixNodeCurrent(src,generation:generation),sourceSixNodeCurrent(dst,generation:generation),
              src.sourceOuterDriven,dst.sourceOuterDriven,sourceDragTweenDriver === scope.tween,
              sourceStackFrameService === scope.service,scope.service.sourceFrameTransportAdmissionOpen,
              sourceSixShared?.canAdmit==true,sourceSixSurfaces != nil,sourceSixIdleAcquire != nil,
              sourceSixPrepared==nil,sourceSixContacts.isEmpty,dst.sourceMergeSixFaceReady(service:scope.service),
              src.value==source.value,dst.value==destination.value,src.depth==source.stackDepth,dst.depth==destination.stackDepth,
              !src.sourceRegularFramePending,!dst.sourceRegularFramePending else{return false}
        return sourceSixNodeCurrent(src,generation:generation) && sourceSixNodeCurrent(dst,generation:generation)
    }
    private func prepareSourceSixAuto(source:NativeTile,destination:NativeTile,generation:UInt64)->NativeSourceMergeSixAutoCenterLease? {
        guard (sourceSixReady(source:source,destination:destination,generation:generation) || sourceDirectReady(source:source,destination:destination,generation:generation)),let scope=sourceSixScope,
              let src=nodesByID[source.id],let dst=nodesByID[destination.id] else{return nil}
        let owner=NativeSourceMergeSixAbsorbOwner(host:src,driver:scope.tween)
        let entry=SourceSixContact(source:src,destination:dst,generation:generation,owner:owner)
        sourceSixPrepared=entry
        let current:()->Bool = {[weak self,weak entry] in
            guard let self,let entry,!entry.retired else{return false}
            let bound=self.sourceSixPrepared === entry || entry.transactionID.flatMap{self.sourceSixContacts[$0]} === entry
            return bound && self.sourceSixNodeCurrent(entry.source,generation:entry.generation) && self.sourceSixNodeCurrent(entry.destination,generation:entry.generation) && !entry.retired
        }
        guard owner.startAuto(destination:dst.position,current:current,onScaleInitialize:{[weak src] in src?.killSourceActiveScaleChildren()}),current() else{
            if sourceSixPrepared === entry {sourceSixPrepared=nil};entry.retired=true;owner.dispose();return nil
        }
        return NativeSourceMergeSixAutoCenterLease(isCurrent:current,rejected:{[weak self,weak entry] in
            guard let entry,!entry.retired else{return};entry.retired=true
            if self?.sourceSixPrepared === entry {self?.sourceSixPrepared=nil};entry.owner.dispose()
        })
    }
    private func sourceSixOwns(_ node:NativeDiceNode,generation:UInt64)->Bool {
        sourceSixContacts.values.contains {entry in
            guard !entry.retired,entry.generation==generation,let capture=entry.capture else{return false}
            return capture.retains(node,id:node.tileID,generation:generation)
        }
    }
    private func startSourceSixContact(_ plan:NativeOrdinaryMovePlan,result:NativeMoveResult,previous:NativeBoardState)->Bool {
        guard let entry=sourceSixPrepared,entry.generation==plan.generation,entry.source.tileID==plan.source.id,
              entry.destination.tileID==plan.destination.id,!entry.retired,let scope=sourceSixScope,
              sourceSixNodeCurrent(entry.source,generation:plan.generation),sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        sourceSixPrepared=nil;entry.plan=plan;sourceSixContacts[plan.id]=entry
        entry.destination.sourceEventMode="none" // literal accepted app-prefix, before frame/idle/audio.
        let capture=NativeSourceMergeSixMainCapture(plan:.ordinary(plan),engine:engine,source:entry.source,destination:entry.destination,hooks:.init(
            contextCurrent:{[weak self] in self?.sourceAnimationBindingAdmissionOpen==true && self?.sourceSixScope === scope && scope.current},
            nodeCurrent:{[weak self] node,_,gen in self?.sourceSixNodeCurrent(node,generation:gen)==true},
            captureGeometry:{[weak self] node in
                guard let self,let view=self.view,self.sourceSixNodeCurrent(node,generation:plan.generation) else{return nil}
                return .init(destinationScreen:view.convert(node.convert(CGPoint.zero,to:self),from:self))
            },removeCapturedPair:{[weak self] src,dst in
                guard let self else{return};for node in [src,dst] where self.nodesByID[node.tileID] === node {
                    self.nodesByID.removeValue(forKey:node.tileID);node.dispose();node.removeFromParent()
                }
            },releaseFramesAndIdle:{[weak self] in self?.retireOrdinarySixVisual();self?.finishSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)},
            releaseSpecialAndQueue:{[weak self] in self?.sourceSpecialTransactions?.absorbInterrupted(id:plan.id,generation:plan.generation)},
            publish:{[weak self,weak entry] committed,geometry in
                guard let self,let entry,!entry.retired,self.sourceSixContacts[plan.id] === entry,self.engine.state.generation==plan.generation else{return}
                if geometry != nil {
                    self.ordinarySixVisual?.committed=true;self.ordinarySixVisual?.consuming=true
                    self.consume(committed,previous:previous)
                    self.startSourceNoMovesDepletedCaller(ownerID:plan.id,kind:.mergeMovesDepleted,generation:plan.generation)
                    self.ordinarySixVisual?.consuming=false;self.releaseOrdinarySixIfReady()
                } else if self.sourceAnimationBindingAdmissionOpen {self.consume(committed,previous:previous)}
            },retireNativeRoots:{[weak entry] in entry?.owner.dispose()}))
        entry.capture=capture
        // Literal app prefix acquires100 and all-live idle suspension before cue.
        beginSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)
        guard let release=sourceSixIdleAcquire?("merge6-resolution") else{
            capture.capturedObjectRetired();retireSourceSixContact(entry);return false
        }
        guard sourceSixNodeCurrent(entry.source,generation:plan.generation),!entry.retired,sourceSixContacts[plan.id] === entry else{
            release();capture.capturedObjectRetired();retireSourceSixContact(entry);return false
        }
        sourceSixIdleReleases[plan.id]=release
        consume(result,previous:previous) // existing authored cue, then Source hero/face
        guard sourceSixNodeCurrent(entry.source,generation:plan.generation),sourceSixContacts[plan.id] === entry,
              !entry.retired,capture.phase == .captured else{capture.capturedObjectRetired();retireSourceSixContact(entry);return false}
        let started=entry.owner.startMain(destination:entry.destination.position,current:{[weak self,weak entry] in
            guard let self,let entry,!entry.retired else{return false}
            return self.sourceSixContacts[plan.id] === entry && self.sourceSixNodeCurrent(entry.source,generation:plan.generation) && self.sourceSixNodeCurrent(entry.destination,generation:plan.generation)
        },onInstalled:{[weak entry] receipt in
            guard let entry,!entry.retired else{return};entry.root=receipt.id
            if entry.capture?.mainInstalled(receipt.id) != true {entry.capture?.capturedObjectRetired()}
        },onCompleted:{[weak self,weak entry] in
            guard let self,let entry,let root=entry.root else{return}
            _=entry.capture?.mainCompleted(root);self.retireSourceSixContact(entry);self.synchronize()
        },onInterrupted:{[weak self,weak entry] in
            guard let self,let entry,let root=entry.root else{return}
            _=entry.capture?.mainInterrupted(root);self.retireSourceSixContact(entry)
        })
        if !started {capture.capturedObjectRetired();retireSourceSixContact(entry)}
        return started
    }
    private func startSourceDirectContact(_ plan:NativeDirectWildMovePlan,result:NativeMoveResult,previous:NativeBoardState)->Bool {
        guard let entry=sourceSixPrepared,entry.generation==plan.generation,entry.source.tileID==plan.source.id,
              entry.destination.tileID==plan.destination.id,!entry.retired,let scope=sourceSixScope,
              sourceSixNodeCurrent(entry.source,generation:plan.generation),sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        sourceSixPrepared=nil;entry.directPlan=plan;sourceSixContacts[plan.id]=entry
        entry.visualReceipt=beginVisual();directPresentationID=plan.id;directPresentationVariant=plan.variant
        specialPresentationIDs.formUnion([plan.source.id,plan.destination.id])
        entry.destination.sourceEventMode="none" // literal accepted app-prefix, before frame/idle/audio.
        let capture=NativeSourceMergeSixMainCapture(plan:.direct(plan),engine:engine,source:entry.source,destination:entry.destination,hooks:.init(
            contextCurrent:{[weak self] in self?.sourceAnimationBindingAdmissionOpen==true && self?.sourceSixScope === scope && scope.current},
            nodeCurrent:{[weak self] node,_,gen in self?.sourceSixNodeCurrent(node,generation:gen)==true},
            captureGeometry:{[weak self] node in
                guard let self,let view=self.view,self.sourceSixNodeCurrent(node,generation:plan.generation) else{return nil}
                return .init(destinationScreen:view.convert(node.convert(CGPoint.zero,to:self),from:self))
            },removeCapturedPair:{[weak self] src,dst in
                guard let self else{return};for node in [src,dst] where self.nodesByID[node.tileID] === node {
                    self.nodesByID.removeValue(forKey:node.tileID);node.dispose();node.removeFromParent()
                }
            },releaseFramesAndIdle:{[weak self,weak entry] in
                guard let self else{return}
                self.specialPresentationIDs.subtract([plan.source.id,plan.destination.id])
                self.directPresentationID=nil;self.directPresentationVariant=nil
                if let receipt=entry?.visualReceipt {entry?.visualReceipt=nil;self.finishVisual(receipt)}
                self.finishSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)
            },
            releaseSpecialAndQueue:{[weak self] in self?.sourceSpecialTransactions?.absorbInterrupted(id:plan.id,generation:plan.generation)},
            publish:{[weak self,weak entry] committed,geometry in
                guard let self,let entry,!entry.retired,self.sourceSixContacts[plan.id] === entry,self.engine.state.generation==plan.generation else{return}
                if let geometry {
                    let stars=committed.events.filter{$0.kind == .hudStarsPrepared}.flatMap(\.tileIDs)
                    for id in stars {self.sourceDirectHUDOrigins[id]=(plan.generation,geometry.destinationScreen)}
                    self.specialPresentationIDs.subtract([plan.source.id,plan.destination.id])
                    self.consume(committed,previous:previous)
                    for id in stars {self.sourceDirectHUDOrigins.removeValue(forKey:id)}
                    self.finishWildSourceResolutionIfReady()
                    guard self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==plan.generation,
                          self.engine.pendingDirectWild?.id==plan.id,let receipt=entry.visualReceipt else{return}
                    entry.visualReceipt=nil
                    self.finishWildSourceResolutionIfReady()
                    if plan.isFinal {
                        self.directFinalReceipt=(plan.id,plan.generation,receipt);self.releaseFinalDirectIfReady()
                    } else {
                        // Original wild-only input gate uses setTimeout; global
                        // timeline pause does not freeze its release callback.
                        self.sourceAppTimeouts.schedule(sourceID:plan.id+":source-fx-input-release",generation:plan.generation,
                            delayMilliseconds:plan.archetype == .juice ? 1860:900,elapsed:{[weak self] in
                                guard let self,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==plan.generation,
                                      self.engine.pendingDirectWild?.id==plan.id else{return}
                                let before=self.engine.state,result=self.engine.releaseDirectWildPresentation(transactionID:plan.id,generation:plan.generation)
                                self.directPresentationID=nil;self.directPresentationVariant=nil
                                if result.accepted {self.consume(result,previous:before)}
                                self.finishVisual(receipt)
                            })
                    }
                } else if self.sourceAnimationBindingAdmissionOpen {self.consume(committed,previous:previous)}
            },retireNativeRoots:{[weak entry] in entry?.owner.dispose()}))
        entry.capture=capture
        // Literal app prefix acquires100 and all-live idle suspension before cue.
        beginSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)
        guard let release=sourceSixIdleAcquire?("merge6-resolution") else{
            capture.capturedObjectRetired();retireSourceSixContact(entry);return false
        }
        guard sourceSixNodeCurrent(entry.source,generation:plan.generation),!entry.retired,sourceSixContacts[plan.id] === entry else{
            release();capture.capturedObjectRetired();retireSourceSixContact(entry);return false
        }
        sourceSixIdleReleases[plan.id]=release
        consume(result,previous:previous) // existing authored cue, then Source hero/face
        guard sourceSixNodeCurrent(entry.source,generation:plan.generation),sourceSixContacts[plan.id] === entry,
              !entry.retired,capture.phase == .captured else{capture.capturedObjectRetired();retireSourceSixContact(entry);return false}
        let started=entry.owner.startMain(destination:entry.destination.position,current:{[weak self,weak entry] in
            guard let self,let entry,!entry.retired else{return false}
            return self.sourceSixContacts[plan.id] === entry && self.sourceSixNodeCurrent(entry.source,generation:plan.generation) && self.sourceSixNodeCurrent(entry.destination,generation:plan.generation)
        },onInstalled:{[weak entry] receipt in
            guard let entry,!entry.retired else{return};entry.root=receipt.id
            if entry.capture?.mainInstalled(receipt.id) != true {entry.capture?.capturedObjectRetired()}
        },onCompleted:{[weak self,weak entry] in
            guard let self,let entry,let root=entry.root else{return}
            _=entry.capture?.mainCompleted(root);self.retireSourceSixContact(entry);self.synchronize()
        },onInterrupted:{[weak self,weak entry] in
            guard let self,let entry,let root=entry.root else{return}
            _=entry.capture?.mainInterrupted(root);self.retireSourceSixContact(entry)
        })
        if !started {capture.capturedObjectRetired();retireSourceSixContact(entry)}
        return started
    }
    private func prepareSourceDirectPrefix(_ plan:NativeDirectWildMovePlan)->Bool {
        guard let entry=sourceSixContacts[plan.id],entry.directPlan==plan,!entry.retired,let scope=sourceSixScope,
              sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        if plan.destination.isWild {
            guard sourceDirectWildDestinationFaceEnabled,sourceDirectWildDestinationTexture != nil,
                  entry.destination.sourceWildDestinationFaceReady(service:scope.service) else{return false}
        } else {guard entry.destination.sourceMergeSixFaceReady(service:scope.service) else{return false}}
        let result=engine.prepareSourceDirectWildPrefix(receiptID:plan.id,generation:plan.generation)
        guard result.accepted,let prefix=engine.sourceDirectWildPrefix,prefix.id==plan.id,
              sourceSixContacts[plan.id] === entry,!entry.retired,sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        if plan.destination.isWild {
            guard let texture=sourceDirectWildDestinationTexture,
                  let face=engine.prepareSourceWildDestinationFace(transactionID:plan.id,generation:plan.generation) else{return false}
            var physicalResult:NativeMoveResult?,physicalPrevious:NativeBoardState?
            let prepared=entry.destination.prepareSourceDirectWildDestination(prefix:prefix,faceReceipt:face,
                preparedStarTexture:texture,service:scope.service,random:{scope.smokeSession.nextVisualRandom()},
                current:{[weak self,weak entry] in
                    guard let self,let entry,!entry.retired,self.sourceSixContacts[plan.id] === entry else{return false}
                    return self.sourceSixNodeCurrent(entry.destination,generation:plan.generation)
                },commitPhysical:{[weak self] in
                    guard let self,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==plan.generation else{return false}
                    physicalPrevious=self.engine.state
                    let result=self.engine.commitSourceWildDestinationFace(receiptID:face.id,generation:face.generation)
                    physicalResult=result;return result.accepted
                },onFacePainted:{[weak self] in
                    guard let self,let result=physicalResult,let previous=physicalPrevious,result.accepted,self.sourceAnimationBindingAdmissionOpen,
                          self.engine.state.generation==plan.generation else{return}
                    self.consume(result,previous:previous)
                },onFaceCancelled:{[weak entry] in entry?.capture?.capturedObjectRetired()})
            if prepared && plan.isFinal {
                // Literal hideFinal child-only repeat uses Source app timeout,
                // independent of the global GSAP modal pause.
                sourceAppTimeouts.schedule(sourceID:face.id+":final-hide",generation:plan.generation,delayMilliseconds:80,
                    elapsed:{[weak self,weak entry] in
                        guard let self,let entry,!entry.retired,self.sourceSixContacts[plan.id] === entry,
                              self.sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return}
                        entry.destination.hideSourceWildDestinationFinalChildren()
                    })
            }
            return prepared
        }
        return entry.destination.prepareSourceDirectWildRegularDestination(prefix,service:scope.service,
            random:{scope.smokeSession.nextVisualRandom()},onFaceCancelled:{[weak entry] in entry?.capture?.capturedObjectRetired()})
    }
    private func retireSourceSixContact(_ entry:SourceSixContact) {
        guard !entry.retired else{return};entry.retired=true
        if sourceSixPrepared === entry {sourceSixPrepared=nil}
        if let id=entry.transactionID,sourceSixContacts[id] === entry {sourceSixContacts.removeValue(forKey:id)}
        entry.destination.retireSourceWildDestinationFrames()
        entry.capture?.retireObsolete();entry.owner.dispose()
        if let receipt=entry.visualReceipt {entry.visualReceipt=nil;finishVisual(receipt)}
    }
    private func playSourceSixHeroAndFace(_ plan:NativeOrdinaryMovePlan)->Bool {
        guard let entry=sourceSixContacts[plan.id],let scope=sourceSixScope,!entry.retired,
              sourceSixNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        let target=entry.destination
        let hero=NativeSourceMergeSixHeroOwner(node:target,service:scope.service,generation:plan.generation,current:{[weak self,weak target] in
            guard let self,let target else{return false};return self.sourceSixNodeCurrent(target,generation:plan.generation)
        })
        sourceSixHeroes[plan.id]=hero
        hero.onFinished={[weak self,weak hero] _ in if self?.sourceSixHeroes[plan.id] === hero {self?.sourceSixHeroes.removeValue(forKey:plan.id)}}
        guard hero.begin(random:{scope.smokeSession.nextVisualRandom()}),sourceSixNodeCurrent(target,generation:plan.generation) else{return false}
        return target.prepareSourceMergeSixFace(depth:plan.source.stackDepth+plan.destination.stackDepth,final:plan.isFinal,usesSourceDestinationParentState:true,
            service:scope.service,random:{scope.smokeSession.nextVisualRandom()},onFaceCancelled:{[weak entry] in entry?.capture?.capturedObjectRetired()})
    }
    private func playSourceSixMain(_ plan:NativeOrdinaryMovePlan)->Bool {
        guard let entry=sourceSixContacts[plan.id],!entry.retired,let shared=sourceSixShared,let surfaces=sourceSixSurfaces,
              let geometry,shared.canAdmit,sourceSixNodeCurrent(entry.destination,generation:plan.generation),regularSixPresentations[plan.id]==nil else{return false}
        let origin=entry.destination.position,depth=entry.destination.zPosition
        let slot=NativeRegularSixSharedSlot(context:shared,canvas:canvasRoot,tile:entry.destination)
        let owner:NativeRegularSixSpritePresentation
        do {
            owner=try NativeRegularSixSpritePresentation(origin:origin,tileSize:geometry.tileSize,destinationDepth:depth,
                combinedDepth:plan.source.stackDepth+plan.destination.stackDepth,generation:plan.generation,reduced:reducedBoardEffects,
                hotFactor:0,patternIndex:0,initialShake:boardShake,isCurrent:{[weak self] gen in
                    self?.sourceAnimationBindingAdmissionOpen==true && self?.engine.state.generation==gen && self?.sourceSixShared === shared
                },random:{shared.resources.smoke.nextVisualRandom()},sourceSlot:slot,sourceSurfaces:surfaces)
        } catch {onPresentationFailure?("source_six_shared_layers_not_admitted");return false}
        guard sourceAnimationBindingAdmissionOpen,sourceSixShared === shared,engine.state.generation==plan.generation else{owner.dispose();return false}
        regularSixPresentations[plan.id]=owner
        let visual=beginVisual()
        owner.onFinished={[weak self,weak owner] _ in
            guard let self else{return}
            if self.regularSixPresentations[plan.id] === owner {self.regularSixPresentations.removeValue(forKey:plan.id)}
            self.finishVisual(visual)
        }
        owner.mount(in:canvasRoot);return true
    }
    private func retireSourceSixBindings() {
        let prepared=sourceSixPrepared,captured=Array(sourceSixContacts.values),hook=sourceSixAutoHook
        sourceSixPrepared=nil;sourceSixAutoHook=nil
        if let hook,engine.sourceMergeSixAutoCenterHook === hook {engine.sourceMergeSixAutoCenterHook=nil}
        prepared?.capture?.capturedObjectRetired();if let prepared{retireSourceSixContact(prepared)}
        for entry in captured {entry.capture?.capturedObjectRetired();retireSourceSixContact(entry)}
        let heroes=Array(sourceSixHeroes.values);sourceSixHeroes.removeAll();for hero in heroes{hero.dispose()}
        let shared=sourceSixShared,surfaces=sourceSixSurfaces;sourceSixShared=nil;sourceSixSurfaces=nil
        shared?.dispose();surfaces?.dispose()
        let releases=Array(sourceSixIdleReleases.values);sourceSixIdleReleases.removeAll();for release in releases{release()}
        sourceDirectWildDestinationPreparationEpoch &+= 1;sourceDirectWildDestinationTexture=nil
        sourceSixIdleAcquire=nil;sourceSixScope=nil;sourceDirectScope=nil
    }

    // PRIVATE/default OFF: resources and union service belong to the app scope.
    private var sourceMagnetFallbackScope:NativeGameplaySourceContext.Scope?
    private var sourceMagnetFallbackCallers:[String:NativeSourceMagnetFallbackCaller]=[:]
    private var sourceMagnetConstructorBatch:NativeSourceAnimationClockService.SourceFrameLease?
    private var sourceMagnetConstructorNodes:[String:NativeDiceNode]=[:]
    private var sourceMagnetConstructorEpoch:UInt64=0
    @discardableResult func configureSourceMagnetFallback(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetFallbackScope==nil,
              sourceOuterTimelineDriver != nil,sourceInitialStartupReady,
              let installation=sourceMicrotaskInstallation,installation.isCurrent,
              let tasks=scope.sourceMicrotaskTasks,installation.tasks === tasks,
              scope.service.sourceMicrotaskTasks === tasks,scope.service.sourceFrameTransportAdmissionOpen,
              sourceAppTimeouts.sourceMicrotaskTasks === tasks,textures.sourceRetainedRegularOpenTexturesReady else{return false}
        sourceMagnetFallbackScope=scope;engine.sourceMagnetFallbacksEnabled=true;sourceDisposalSealingEnabled=true
        return true
    }
    /// Actual app-merge zero-active branch calls this callback. It consumes the
    /// authentic post-commit Core receipt and opens exact captured cells only.
    func sourceMagnetFallback(_ plan:NativeSpecialMovePlan,count:Int,done:@escaping(Bool)->Void)->Bool {
        guard sourceAnimationBindingAdmissionOpen,let scope=sourceMagnetFallbackScope,scope.current,
              let helper=sourceMagnetHelpers[plan.id],helper.active,sourceMagnetFallbackCallers[plan.id]==nil,
              sourceInitialConstruction?.constructorBatchPending != true,
              let installation=sourceMicrotaskInstallation,installation.isCurrent else{return false}
        let current:()->Bool = {[weak self,weak helper,scope] in
            guard let self,let helper,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetFallbackScope === scope,
                scope.current,self.sourceMagnetHelpers[plan.id] === helper,self.engine.state.generation==plan.generation,
                self.sourceMicrotaskInstallation === installation,installation.isCurrent else{return false}
            let accepted=helper.mayContinueSourceFallback()
            return accepted && self.sourceAnimationBindingAdmissionOpen && self.sourceMagnetFallbackScope === scope && scope.current && self.sourceMagnetHelpers[plan.id] === helper && self.engine.state.generation==plan.generation
        }
        let caller=NativeSourceMagnetFallbackCaller(engine:engine,service:scope.service,hooks:.init(
            current:current,resourcesReady:{[weak self] in self?.textures.sourceRetainedRegularOpenTexturesReady==true},random:{scope.smokeSession.nextVisualRandom()},
            enqueue:{callback in guard current() else{return false};return installation.enqueue(callback)},
            removeHolder:{[weak self] id in
                guard let self,current(),let node=self.nodesByID.removeValue(forKey:id) else{return}
                self.sourceMagnetConstructorNodes.removeValue(forKey:id);node.dispose()
            },construct:{[weak self] opening,rotation in
                guard let self,current(),let holder=opening.holder,let geometry=self.geometry else{return nil}
                if !opening.createdHolder {return self.nodesByID[holder.id]}
                guard self.nodesByID[holder.id]==nil,let rotation,let driver=self.sourceOuterTimelineDriver else{return nil}
                let node=NativeDiceNode(id:holder.id,value:0,kind:"regular",variant:nil,depth:1,locked:true,textures:self.textures,sourceSpecialIdle:scope.specialIdle)
                node.position=geometry.center(row:holder.cell.row,column:holder.cell.column)
                node.zPosition=CGFloat(holder.cell.row*self.engine.state.columns+holder.cell.column)
                self.canvasRoot.addChild(node);self.nodesByID[holder.id]=node
                guard node.prepareSourceInitialHolder(rotation:rotation,generation:plan.generation),current(),self.nodesByID[holder.id] === node else{node.dispose();return nil}
                node.installSourceOuterDriver(driver,generation:plan.generation,geometryScale:geometry.scale)
                if let tween=self.sourceDragTweenDriver {node.installSourceDragTweenDriver(tween)}
                self.sourceMagnetConstructorNodes[holder.id]=node
                if self.sourceMagnetConstructorBatch==nil {
                    self.sourceMagnetConstructorEpoch &+= 1;let batchEpoch=self.sourceMagnetConstructorEpoch
                    let frame=scope.service.requestSourceAnimationFrame(ownerID:"magnet-open-constructors:\(plan.generation)",generation:plan.generation,
                        callback:{[weak self,scope] in
                            guard let self,self.sourceMagnetConstructorEpoch==batchEpoch,self.sourceMagnetFallbackScope === scope else{return};self.sourceMagnetConstructorBatch=nil
                            let captured=self.sourceMagnetConstructorNodes;self.sourceMagnetConstructorNodes=[:]
                            for (id,node) in captured {
                                guard self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetFallbackScope === scope,scope.current,self.engine.state.generation==plan.generation else{return}
                                if self.nodesByID[id] === node,node.parent === self.canvasRoot,node.sourceGeneration==plan.generation {node.flushSourceInitialHolderVisuals()}
                            }
                        },onCancelled:{[weak self] in guard let self,self.sourceMagnetConstructorEpoch==batchEpoch else{return};self.sourceMagnetConstructorBatch=nil})
                    guard current(),self.sourceMagnetConstructorEpoch==batchEpoch,self.nodesByID[holder.id] === node,let frame else{frame?.cancel();return nil}
                    self.sourceMagnetConstructorBatch=frame
                }
                return current() ? node:nil
            },owns:{[weak self] node,opening in
                guard let self,current() else{return false}
                return self.nodesByID[node.tileID] === node && node.parent === self.canvasRoot && node.sourceContactNodeAlive && node.sourceGeneration==opening.generation && self.engine.state.tile(at:opening.cell)?.id==node.tileID
            },publish:{[weak self] result,previous in guard let self,current() else{return};self.consume(result,previous:previous)},
            acquireFrames:{[weak self] id,generation in guard let self,current() else{return nil};return self.beginSourceMotion(.spawnBounce,id:"magnet-fallback:"+id,generation:generation)},
            frameCurrent:{[weak self,scope] node,open in
                guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetFallbackScope === scope,
                    self.engine.state.generation==open.generation,self.nodesByID[node.tileID] === node,
                    node.parent === self.canvasRoot,node.sourceGeneration==open.generation,node.sourceContactNodeAlive else{return false}
                let accepted=scope.current
                return accepted && self.sourceAnimationBindingAdmissionOpen && self.sourceMagnetFallbackScope === scope && self.engine.state.generation==open.generation && self.nodesByID[node.tileID] === node && node.parent === self.canvasRoot && node.sourceGeneration==open.generation && node.sourceContactNodeAlive
            }))
        sourceMagnetFallbackCallers[plan.id]=caller
        let accepted=caller.start(transactionID:plan.id,generation:plan.generation,count:count,finished:{[weak self,weak caller,weak helper] outcome in
            guard let self,let caller,self.sourceMagnetFallbackCallers[plan.id] === caller else{return}
            self.sourceMagnetFallbackCallers.removeValue(forKey:plan.id)
            if outcome == .cancelled {helper?.sourceFallbackCancelled()}
            done(outcome == .completed)
        })
        if !accepted,sourceMagnetFallbackCallers[plan.id] === caller {sourceMagnetFallbackCallers.removeValue(forKey:plan.id);caller.retire()}
        return accepted
    }
    private func sourceMagnetFallbackOwns(_ node:NativeDiceNode)->Bool {sourceMagnetFallbackCallers.values.contains{$0.owns(node)}}
    private func retireSourceMagnetFallback(){
        let scope=sourceMagnetFallbackScope;sourceMagnetFallbackScope=nil
        if scope != nil {engine.sourceMagnetFallbacksEnabled=false}
        let callers=Array(sourceMagnetFallbackCallers.values);sourceMagnetFallbackCallers=[:]
        let batch=sourceMagnetConstructorBatch;sourceMagnetConstructorBatch=nil;sourceMagnetConstructorNodes=[:];sourceMagnetConstructorEpoch &+= 1
        batch?.cancel();callers.forEach{$0.retire()}
    }
    private var sourceMagnetNormalCallers:[String:NativeSourceMagnetNormalCaller]=[:]
    private var sourceMagnetNormalTokens:[String:UInt64]=[:],sourceMagnetNormalEpoch:UInt64=0
    private func sourceMagnetNormalOwns(_ node:NativeDiceNode)->Bool {sourceMagnetNormalCallers.values.contains{$0.owns(node)}}
    private func startSourceMagnetRespawn(_ plan:NativeSpecialMovePlan,receipt:UInt64,carrier:SKNode?)->Bool {
        guard sourceAnimationBindingAdmissionOpen,specialIsCurrent(plan),sourceMagnetBindings != nil,
              let scope=sourceContactScopeForMagnet,scope.current,sourceMagnetNormalCallers[plan.id]==nil,
              let adapter=sourceMagnetGuardAdapter,let installation=sourceMicrotaskInstallation,installation.isCurrent,
              textures.sourceRetainedRegularOpenTexturesReady,sourceInitialConstruction?.constructorBatchPending != true else{return false}
        sourceMagnetNormalEpoch &+= 1;let epoch=sourceMagnetNormalEpoch
        sourceMagnetNormalTokens[plan.id]=epoch
        let current:()->Bool = {[weak self,scope] in
            guard let self else{return false}
            return self.sourceAnimationBindingAdmissionOpen && self.sourceMagnetNormalTokens[plan.id]==epoch && scope.current && self.sourceContactScopeForMagnet === scope &&
                self.sourceMicrotaskInstallation === installation && installation.isCurrent && self.specialIsCurrent(plan)
        }
        let caller=NativeSourceMagnetNormalCaller(engine:engine,service:scope.service,hooks:.init(
            current:current,resourcesReady:{[weak self] in self?.textures.sourceRetainedRegularOpenTexturesReady==true},
            random:{scope.smokeSession.nextVisualRandom()},schedule:{ms,elapsed,cancelled in
                guard current() else{return nil};return adapter.schedule(id:plan.id+":normal",generation:plan.generation,ms:ms,elapsed:elapsed,cancelled:cancelled)
            },enqueue:{callback in guard current() else{return false};return installation.enqueue(callback)},
            construct:{[weak self] tile,rotation in
                guard let self,current(),let geometry=self.geometry,let driver=self.sourceOuterTimelineDriver else{return nil}
                // forceFreshPlaceholder replaces only this cell's empty locked
                // object; active, Wild or rebound C was rejected by Core caller.
                if let old=self.engine.state.tile(at:tile.cell),let oldNode=self.nodesByID[old.id] {
                    guard old.locked,old.value==0,!old.isWild else{return nil}
                    self.nodesByID.removeValue(forKey:old.id);self.sourceMagnetConstructorNodes.removeValue(forKey:old.id);oldNode.dispose()
                    guard current() else{return nil}
                }
                guard self.nodesByID[tile.id]==nil else{return nil}
                let node=NativeDiceNode(id:tile.id,value:0,kind:"regular",variant:nil,depth:1,locked:true,textures:self.textures,sourceSpecialIdle:scope.specialIdle)
                node.position=geometry.center(row:tile.cell.row,column:tile.cell.column)
                node.zPosition=CGFloat(tile.cell.row*self.engine.state.columns+tile.cell.column)
                self.canvasRoot.addChild(node);self.nodesByID[tile.id]=node
                guard node.prepareSourceInitialHolder(rotation:rotation,generation:plan.generation),current(),self.nodesByID[tile.id] === node else{node.dispose();return nil}
                node.installSourceOuterDriver(driver,generation:plan.generation,geometryScale:geometry.scale)
                if let tween=self.sourceDragTweenDriver {node.installSourceDragTweenDriver(tween)}
                self.sourceMagnetConstructorNodes[tile.id]=node
                if self.sourceMagnetConstructorBatch==nil {
                    self.sourceMagnetConstructorEpoch &+= 1;let epoch=self.sourceMagnetConstructorEpoch
                    let frame=scope.service.requestSourceAnimationFrame(ownerID:"magnet-open-constructors:\(plan.generation)",generation:plan.generation,
                        callback:{[weak self,scope] in
                            guard let self,self.sourceMagnetConstructorEpoch==epoch,self.sourceContactScopeForMagnet === scope else{return}
                            self.sourceMagnetConstructorBatch=nil;let captured=self.sourceMagnetConstructorNodes;self.sourceMagnetConstructorNodes=[:]
                            for(id,node) in captured {
                                guard self.sourceAnimationBindingAdmissionOpen,scope.current,self.engine.state.generation==plan.generation else{return}
                                if self.nodesByID[id] === node,node.parent === self.canvasRoot,node.sourceGeneration==plan.generation {node.flushSourceInitialHolderVisuals()}
                            }
                        },onCancelled:{[weak self] in guard let self,self.sourceMagnetConstructorEpoch==epoch else{return};self.sourceMagnetConstructorBatch=nil})
                    guard current(),self.sourceMagnetConstructorEpoch==epoch,self.nodesByID[tile.id] === node,let frame else{frame?.cancel();return nil}
                    self.sourceMagnetConstructorBatch=frame
                }
                return current() ? node:nil
            },owns:{[weak self] node,tile in
                guard let self,current() else{return false}
                return self.nodesByID[tile.id] === node && node.parent === self.canvasRoot && node.sourceContactNodeAlive && node.sourceGeneration==plan.generation
            },publish:{[weak self] result,previous in guard let self,current() else{return};self.consume(result,previous:previous)},
            verify:{[weak self] cell in
                guard let self,current(),let tile=self.engine.state.tile(at:cell),let node=self.nodesByID[tile.id],
                      node.parent === self.canvasRoot,node.sourceContactNodeAlive,node.sourceGeneration==plan.generation else{return false}
                let success = !node.sourceLocked && node.sourceValue>0
                if success {self.sourceMagnetSuccessfulSpawns[plan.id]?.insert(node.tileID);node.sourceEventMode="static"}
                return success && current()
            },acquireFrames:{[weak self] id,generation in guard let self,current() else{return nil};return self.beginSourceMotion(.spawnBounce,id:id,generation:generation)},
            finished:{[weak self,weak carrier] outcome in
                guard let self,self.sourceMagnetNormalTokens[plan.id]==epoch else{return}
                let owns=current()
                self.sourceMagnetNormalTokens.removeValue(forKey:plan.id)
                guard self.sourceMagnetNormalCallers.removeValue(forKey:plan.id) != nil,owns else{return}
                guard case .completed(let successes)=outcome,
                      successes==(self.engine.pendingSourceMagnetLazyRespawn?.slots.count ?? self.engine.pendingMagnetRespawn?.replacements.count) else{self.onPresentationFailure?("source_magnet_replacement_retry_not_bound");return}
                let previous:NativeBoardState,result:NativeMoveResult
                if self.sourceMagnetLazyScope != nil {
                    guard let committed=self.finishSourceMagnetLazyBoard(plan) else{self.onPresentationFailure?("source_magnet_lazy_survivor_not_bound");return}
                    result=committed.0;previous=committed.1
                } else {previous=self.engine.state;result=self.engine.commitSpecialBoard(transactionID:plan.id)}
                if result.accepted {self.sourceMagnetHelpers[plan.id]?.boardCommitted(spawnCount:successes,shouldRunPostCheck:true,
                    publish:{[weak self] in self?.sourceSpecialTransactions?.boardCommitted(id:plan.id,generation:plan.generation)})}
                self.specialPresentationID=nil;self.consume(result,previous:previous)
                guard self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==plan.generation else{return}
                self.navigationLocked=self.engine.state.terminal != nil || self.pendingTerminal != nil
                self.finishVisual(receipt);carrier?.removeFromParent()
            },frameCurrent:{[weak self,scope] node,_ in
                guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceContactScopeForMagnet === scope,
                    self.engine.state.generation==plan.generation,self.nodesByID[node.tileID] === node,
                    node.parent === self.canvasRoot,node.sourceGeneration==plan.generation,node.sourceContactNodeAlive else{return false}
                let accepted=scope.current
                return accepted && self.sourceAnimationBindingAdmissionOpen && self.sourceContactScopeForMagnet === scope && self.engine.state.generation==plan.generation && self.nodesByID[node.tileID] === node && node.parent === self.canvasRoot && node.sourceGeneration==plan.generation && node.sourceContactNodeAlive
            },removeEmptyHolder:{[weak self] opening in
                guard let self,current() else{return false}
                guard let oldID=opening.removedHolderID else{return true}
                // Exact old object ID from Core's force-fresh action; the new
                // zero holder is already canonical and must never be removed.
                if let old=self.nodesByID[oldID] {
                    guard old.sourceGeneration==plan.generation,old.sourceValue==0,old.sourceLocked,old.sourceContactNodeAlive else{return false}
                    self.nodesByID.removeValue(forKey:oldID);self.sourceMagnetConstructorNodes.removeValue(forKey:oldID);old.dispose();old.removeFromParent()
                }
                return current()
            }))
        sourceMagnetNormalCallers[plan.id]=caller
        let accepted=caller.start(transactionID:plan.id,generation:plan.generation)
        if !accepted,sourceMagnetNormalCallers[plan.id] === caller {sourceMagnetNormalCallers.removeValue(forKey:plan.id);sourceMagnetNormalTokens.removeValue(forKey:plan.id);caller.retire()}
        return accepted
    }
    private var sourceMagnetSuccessfulSpawns:[String:Set<String>]=[:]
    private var sourceMagnetPullCarriers:[String:SKNode]=[:]
    private var sourceMagnetPullFlagOwner:(id:String,generation:UInt64)?
    /// Concrete normal helper binding; no loose count callbacks at startup.
    /// The real Source observer uses STATE order plus same retained grid objects.
    @discardableResult func configureSourceMagnetPhysicalVerification(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetBindings==nil,
              sourceSpecialTransactions != nil,sourceMagnetFallbackScope === scope,
              sourceInitialStartupReady else{return false}
        let generation=engine.state.generation
        let current:()->Bool = {[weak self,scope] in
            guard let self else{return false}
            return self.sourceAnimationBindingAdmissionOpen && scope.current && self.engine.state.generation==generation
        }
        let bindings=NativeSourceMagnetSceneBindings(admitted:{[weak self] in
            guard let self,current() else{return false}
            return self.sourceMagnetPhysicalSnapshot(generation:generation) != nil
        },ownsLifecycle:{plan in current() && plan.generation==generation},simulate:{[weak self] in
            guard let self,current(),let tiles=self.sourceMagnetPhysicalSnapshot(generation:generation) else{return false}
            return NativeSourceMagnetPhysicalState.simulate(tiles)
        },observation:{[weak self] plan in
            guard let self,current(),plan.generation==generation,
                  let tiles=self.sourceMagnetPhysicalSnapshot(generation:generation) else{return nil}
            let count=self.engine.sourceMagnetPostCommit.flatMap{$0.transactionID==plan.id ? $0.spawnCount:nil}
            guard let count else{return nil}
            // successfulSpawns is counted at the actual captured open
            // completion callback, never from expected/planned replacement count.
            let read=NativeSourceMagnetPhysicalState.read(tiles,spawnCount:count,successfulSpawnCount:self.sourceMagnetSuccessfulSpawns[plan.id]?.count ?? 0,
                lastMerge:self.engine.sourceMeterLastMergeTileIDs.contains(plan.destination.id))
            let resolution:NativeSourceMagnetCoroutineOwner.Resolution
            switch read.reason {
            case "merge-or-stack-potential":resolution = .mergePotential(clearLastMerge:read.clearLastMerge)
            case "clean-merge6-only":resolution = .cleanSix
            case "stuck-unlocked-tiles":resolution = .stuckUnlocked
            case "stuck-active-tiles":resolution = .stuckActive
            default:resolution = .continueWithoutCheck(clearLastMerge:read.clearLastMerge)
            }
            // The native app-spawn wrapper has no literal _spawnTween field.
            // Selected locked-slot flags are cleared by their own assignment
            // callback. Defensive read may observe but cannot retire another
            // outstanding captured slot; native safe ownership differs from
            // Source's unscoped stale boolean repair.
            return .init(lockedActiveCount:read.lockedActiveCount,stillSpawningCount:read.stillSpawningCount,
                activeCount:read.activeCount,playableLockedCount:read.playableLockedCount,resolution:resolution)
        },fallback:{[weak self] plan,count,done in guard let self,current() else{return false};return self.sourceMagnetFallback(plan,count:count,done:done)},
        fxStatus:{[weak self] in
            guard let self,current() else{return nil}
            // Compiled Swift namespace is already loaded; this is the genuine
            // native core-Juice owner, not a count or an invented activity lease.
            return self.effects.children.compactMap{$0 as? NativeJuiceFinale}.contains{$0.hasActiveClock}
        },clearLastMerge:{[weak self] plan in
            guard let self,current(),plan.generation==generation else{return}
            self.engine.sourceMeterLastMergeTileIDs.remove(plan.destination.id) // exact old ID only; never survivor/new C.
        },updateGhostVisibility:{[weak self] in guard let self,current(),let geometry=self.geometry else{return};self.renderGhosts(state:self.engine.state,geometry:geometry)},
        centralCheck:{[weak self] _ in
            guard let self,current() else{return}
            guard self.sourceMagnetPhysicalMatchesCore(generation:generation) else{self.onPresentationFailure?("source_magnet_physical_core_divergence");return}
            self.evaluate()
        },
        cleanupPullAnimations:{[weak self] plan in
            guard let self,current() else{return}
            if let entry=self.sourceMagnetSourcePulls[plan.id] {entry.owner?.cleanup(preserveCommittedSound:true)}
            // Captured pull targets only; remove this owner's authored action
            // keys, never removeAllActions on intervening ordinary play/new C.
            if let carrier=self.sourceMagnetPullCarriers.removeValue(forKey:plan.id) {carrier.removeAllActions();carrier.removeFromParent()}
        },releasePullFlag:{[weak self] plan in
            guard let self,current(),plan.generation==generation else{return}
            guard self.sourceMagnetPullFlagOwner?.id==plan.id,self.sourceMagnetPullFlagOwner?.generation==generation else{return}
            self.sourceMagnetPullFlagOwner=nil
            var flags=self.engine.flags;flags.wildMagnetPullInProgress=false
            self.engine.setRuntimeFlags(flags)
        })
        return configureSourceMagnetVerification(scope:scope,bindings:bindings)
    }
    func captureSourceMagnetPhysicalTiles()->[NativeSourceMagnetPhysicalTile]? {
        sourceMagnetPhysicalSnapshot(generation:engine.state.generation)
    }
    func captureSourceSaveTileMarkers(id:String)->NativeSourceSaveTileMarkers? {
        guard sourceAnimationBindingAdmissionOpen,let model=engine.state.tiles.first(where:{$0.id==id}),
              let node=nodesByID[id],node.parent === canvasRoot,node.sourceContactNodeAlive,
              node.sourceGeneration==engine.state.generation else{return nil}
        return node.captureSourceSaveTileMarkers(model:model,runtime:engine.noMovesTileRuntime[id])
    }
    private func sourceMagnetPhysicalSnapshot(generation:UInt64)->[NativeSourceMagnetPhysicalTile]? {
        guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation else{return nil}
        let state=engine.state
        var result:[NativeSourceMagnetPhysicalTile]=[]
        for model in state.tiles {
            guard let node=nodesByID[model.id],node.parent === canvasRoot,node.sourceGeneration==generation,
                  node.sourceContactNodeAlive,
                  let observed=node.captureSourceMagnetPhysical(model:model,runtime:engine.noMovesTileRuntime[model.id],
                    lastMerge:engine.sourceMeterLastMergeTileIDs.contains(model.id)) else{return nil}
            result.append(observed)
        }
        guard sourceAnimationBindingAdmissionOpen,engine.state==state else{return nil}
        return result
    }
    private func sourceMagnetPhysicalMatchesCore(generation:UInt64)->Bool {
        guard let observed=sourceMagnetPhysicalSnapshot(generation:generation) else{return false}
        let models=engine.state.tiles
        return observed.count==models.count && zip(observed,models).allSatisfy{p,m in
            // Alpha storage is SpriteKit Float32, so compare the source semantic
            // boundaries used by classification; never replace physical alpha.
            p.id==m.id && p.value==m.value && p.depth==m.stackDepth && p.locked==m.locked && p.visible==m.visible &&
            (p.alpha>0.01)==(m.alpha>0.01) && (p.alpha>0.35)==(m.alpha>0.35)
        }
    }

    private var sourceMagnetBindings:NativeSourceMagnetSceneBindings?
    private var sourceMagnetGuardAdapter:NativeSourceMagnetGuardAdapter?
    private var sourceMagnetHelpers:[String:NativeSourceMagnetCoroutineOwner]=[:]
    @discardableResult func configureSourceMagnetVerification(scope:NativeGameplaySourceContext.Scope,bindings:NativeSourceMagnetSceneBindings)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceSpecialTransactions != nil,
              sourceMagnetBindings==nil,let installation=sourceMicrotaskInstallation,installation.isCurrent,
              let tasks=scope.sourceMicrotaskTasks,sourceAppTimeouts.sourceMicrotaskTasks === tasks,
              installation.tasks === tasks else{return false}
        let ready=bindings.admitted()
        guard ready,sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetBindings==nil,
              sourceMicrotaskInstallation === installation,installation.isCurrent else{return false}
        let adapter=NativeSourceMagnetGuardAdapter(scope:scope.registries,timeouts:sourceAppTimeouts,tasks:tasks,
            enqueue:{[weak self,installation] callback in guard let self,self.sourceMicrotaskInstallation === installation,installation.isCurrent else{return false};return installation.enqueue(callback)})
        guard adapter.mount(),sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetBindings==nil,
              sourceMicrotaskInstallation === installation,installation.isCurrent else{adapter.retire();return false}
        sourceMagnetBindings=bindings;sourceContactScopeForMagnet=scope;sourceMagnetGuardAdapter=adapter;sourceDisposalSealingEnabled=true
        return true
    }
    private func beginSourceMagnetHelper(_ plan:NativeSpecialMovePlan)->Bool {
        guard let bindings=sourceMagnetBindings else{return true} // Raw unchanged.
        guard sourceAnimationBindingAdmissionOpen,let adapter=sourceMagnetGuardAdapter,
              let scope=sourceContactScopeForMagnet,sourceMagnetHelpers[plan.id]==nil else{return false}
        let owns:()->Bool = {[weak self,bindings,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetBindings === bindings,
                  scope.current,self.engine.state.generation==plan.generation else{return false}
            let owned=bindings.ownsLifecycle(plan)
            return owned && self.sourceAnimationBindingAdmissionOpen && self.sourceMagnetBindings === bindings && scope.current && self.engine.state.generation==plan.generation
        }
        let helper=NativeSourceMagnetCoroutineOwner(hooks:.init(ownsLifecycle:owns,revision:{scope.contactMutations.revision},
            beginGuard:{adapter.beginGuard()},schedule:{ms,elapsed,cancel in adapter.schedule(id:plan.id,generation:plan.generation,ms:ms,elapsed:elapsed,cancelled:cancel)},enqueue:{adapter.reaction($0)},
            simulate:bindings.simulate,observe:{bindings.observation(plan)},fallback:{count,done in bindings.fallback(plan,count,done)},readFXStatus:bindings.fxStatus,
            clearCapturedLastMerge:{bindings.clearLastMerge(plan)},updateGhostVisibility:bindings.updateGhostVisibility,centralCheck:bindings.centralCheck,
            helperFinally:{[weak self,bindings] _,_ in guard let self,self.sourceMagnetBindings === bindings else{return};self.sourceMagnetHelpers.removeValue(forKey:plan.id);self.sourceMagnetSuccessfulSpawns.removeValue(forKey:plan.id);_ = self.engine.retireSourceMagnetPostCommit(transactionID:plan.id,generation:plan.generation)},
            handlerComplete:{[weak self,bindings] owned,_ in
                guard let self,owned,owns(),self.sourceMagnetBindings === bindings else{return}
                if let pull=self.sourceMagnetSourcePulls[plan.id] {pull.owner?.cleanup(preserveCommittedSound:true)}
                guard owns() else{return}
                bindings.cleanupPullAnimations(plan);guard owns() else{return}
                bindings.releasePullFlag(plan);guard owns() else{return}
                self.sourceMagnetHelperFinally(id:plan.id,generation:plan.generation,ownsLifecycle:true)
            }))
        sourceMagnetSuccessfulSpawns[plan.id]=[]
        sourceMagnetHelpers[plan.id]=helper
        guard helper.begin(),owns(),sourceMagnetHelpers[plan.id] === helper else{
            if sourceMagnetHelpers[plan.id] === helper {sourceMagnetHelpers.removeValue(forKey:plan.id)}
            helper.retire();return false
        }
        return true
    }
    private var sourceContactScopeForMagnet:NativeGameplaySourceContext.Scope?
    private func retireSourceMagnetVerification(){
        retireSourceMagnetPullBindings()
        retireSourceMagnetLazyRespawn()
        let capturedPostCommit=engine.sourceMagnetPostCommit
        retireSourceMagnetFallback()
        if let capturedPostCommit {_ = engine.retireSourceMagnetPostCommit(transactionID:capturedPostCommit.transactionID,generation:capturedPostCommit.generation)}
        sourceMagnetBindings=nil;sourceContactScopeForMagnet=nil
        let normal=Array(sourceMagnetNormalCallers.values);sourceMagnetNormalCallers=[:];sourceMagnetNormalTokens=[:]
        normal.forEach{$0.retire()}
        sourceMagnetSuccessfulSpawns=[:];sourceMagnetPullFlagOwner=nil
        let carriers=Array(sourceMagnetPullCarriers.values);sourceMagnetPullCarriers=[:]
        carriers.forEach{$0.removeAllActions();$0.removeFromParent()}
        let adapter=sourceMagnetGuardAdapter;sourceMagnetGuardAdapter=nil
        let captured=Array(sourceMagnetHelpers.values);sourceMagnetHelpers=[:]
        captured.forEach{$0.retire()};adapter?.retire()
    }
    @MainActor private final class SourceMagnetSurvivorEntry {
        let node:NativeDiceNode,plan:NativeSpecialMovePlan
        var retired=false,owner:NativeSourceMagnetSurvivorOwner?
        var reserved:[String:NativeDiceNode]=[:]
        init(node:NativeDiceNode,plan:NativeSpecialMovePlan){self.node=node;self.plan=plan}
    }
    private var sourceMagnetLazyScope:NativeGameplaySourceContext.Scope?
    private var sourceMagnetSurvivorEntries:[String:SourceMagnetSurvivorEntry]=[:]
    /// Bounded normal all-target continuation; other special families remain
    /// rejected. Core/constructor/raw-face/tail borrow ONE actual APP Math.
    @discardableResult func configureSourceMagnetLazyRespawn(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceMagnetLazyScope==nil,sourceMagnetMainScope === scope,
              sourceContactScopeForMagnet === scope,scope.current,engine.sourceMathRandom === scope.mathRandom,
              sourceMagnetBindings != nil,sourceSpecialTransactions != nil,sourceOuterTimelineDriver === scope.timeline,
              sourceStackFrameService === scope.service,textures.sourceRetainedRegularOpenTexturesReady,
              sourceInitialConstruction?.constructorBatchPending != true else{return false}
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetLazyScope==nil,sourceMagnetMainScope === scope else{return false}
        sourceMagnetLazyScope=scope;engine.sourceMagnetLazyRespawnEnabled=true;return true
    }
    var sourceMagnetSurvivorPendingInputIDs:Set<String> {
        Set(sourceMagnetSurvivorEntries.values.filter{sourceMagnetSurvivorCurrent($0) && $0.owner?.inputBound != true}.map{$0.node.tileID})
    }
    private func sourceMagnetSurvivorCurrent(_ entry:SourceMagnetSurvivorEntry)->Bool {
        guard sourceAnimationBindingAdmissionOpen,!entry.retired,let scope=sourceMagnetLazyScope else{return false}
        func matches()->Bool {
            !entry.retired && sourceAnimationBindingAdmissionOpen && sourceMagnetSurvivorEntries[entry.plan.id] === entry &&
            sourceMagnetLazyScope === scope && engine.state.generation==entry.plan.generation && nodesByID[entry.node.tileID] === entry.node &&
            entry.node.parent === canvasRoot && entry.node.sourceContactNodeAlive && entry.node.sourceGeneration==entry.plan.generation
        }
        guard matches() else{return false};let accepted=scope.current;return accepted && matches()
    }
    private func retireSourceMagnetSurvivor(_ entry:SourceMagnetSurvivorEntry){
        guard !entry.retired else{return};entry.retired=true
        if sourceMagnetSurvivorEntries[entry.plan.id] === entry {sourceMagnetSurvivorEntries.removeValue(forKey:entry.plan.id)}
        let owner=entry.owner;entry.owner=nil;owner?.retire()
    }
    private func retireSourceMagnetLazyRespawn(){
        let entries=Array(sourceMagnetSurvivorEntries.values);sourceMagnetSurvivorEntries=[:]
        sourceMagnetLazyScope=nil;engine.sourceMagnetLazyRespawnEnabled=false
        entries.forEach{retireSourceMagnetSurvivor($0)}
    }
    private func sourceMagnetSurvivorOwns(_ node:NativeDiceNode)->Bool {
        sourceMagnetSurvivorEntries.values.contains{entry in sourceMagnetSurvivorCurrent(entry) && (entry.node === node || entry.reserved[node.tileID] === node)}
    }
    private func sourceMagnetSurvivorOwnsSpawn(_ event:NativeGameplayEvent)->Bool {
        event.kind == .spawned && sourceMagnetSurvivorEntries.values.contains{entry in
            sourceMagnetSurvivorCurrent(entry) && event.tileIDs.contains{$0==entry.node.tileID || entry.reserved[$0] != nil}
        }
    }
    private func constructSourceMagnetReserveFill(_ fill:NativeSourceMagnetReserveFill,entry:SourceMagnetSurvivorEntry,scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceMagnetSurvivorCurrent(entry),let geometry,let driver=sourceOuterTimelineDriver else{return false}
        for(index,tile) in fill.holders.enumerated() {
            guard sourceMagnetSurvivorCurrent(entry),engine.state.tile(at:tile.cell)==nil,nodesByID[tile.id]==nil else{return false}
            let roll=scope.mathRandom.next()
            guard sourceMagnetSurvivorCurrent(entry),roll.isFinite,roll>=0,roll<1 else{return false}
            let node=NativeDiceNode(id:tile.id,value:0,kind:"regular",variant:nil,depth:1,locked:true,textures:textures,sourceSpecialIdle:scope.specialIdle)
            node.position=geometry.center(row:tile.cell.row,column:tile.cell.column);node.zPosition=CGFloat(tile.cell.row*engine.state.columns+tile.cell.column)
            canvasRoot.addChild(node);nodesByID[tile.id]=node;entry.reserved[tile.id]=node
            guard node.prepareSourceMagnetReservedHolder(rotation:roll*0.12-0.06,generation:entry.plan.generation),sourceMagnetSurvivorCurrent(entry),nodesByID[tile.id] === node else{
                if nodesByID[tile.id] === node{nodesByID.removeValue(forKey:tile.id);node.dispose();node.removeFromParent()};return false
            }
            node.installSourceOuterDriver(driver,generation:entry.plan.generation,geometryScale:geometry.scale)
            if let tween=sourceDragTweenDriver {node.installSourceDragTweenDriver(tween)}
            sourceMagnetConstructorNodes[tile.id]=node
            if sourceMagnetConstructorBatch==nil {
                sourceMagnetConstructorEpoch &+= 1;let epoch=sourceMagnetConstructorEpoch
                let frame=scope.service.requestSourceAnimationFrame(ownerID:"magnet-reserves:\(entry.plan.generation)",generation:entry.plan.generation,
                    callback:{[weak self,scope] in
                        guard let self,self.sourceMagnetConstructorEpoch==epoch,self.sourceMagnetLazyScope === scope else{return}
                        self.sourceMagnetConstructorBatch=nil;let captured=self.sourceMagnetConstructorNodes;self.sourceMagnetConstructorNodes=[:]
                        for(id,node) in captured {
                            guard self.sourceAnimationBindingAdmissionOpen,scope.current,self.engine.state.generation==entry.plan.generation else{return}
                            if self.nodesByID[id] === node,node.parent === self.canvasRoot,node.sourceGeneration==entry.plan.generation{node.flushSourceInitialHolderVisuals()}
                        }
                    },onCancelled:{[weak self] in guard let self,self.sourceMagnetConstructorEpoch==epoch else{return};self.sourceMagnetConstructorBatch=nil})
                guard sourceMagnetSurvivorCurrent(entry),sourceMagnetConstructorEpoch==epoch,let frame else{frame?.cancel();return false}
                sourceMagnetConstructorBatch=frame
            }
            let before=engine.state,result=engine.commitSourceMagnetLazyReserve(transactionID:entry.plan.id,generation:entry.plan.generation,index:index,sourceCurrent:{[weak self,weak entry] in
                guard let self,let entry else{return false};return self.sourceMagnetSurvivorCurrent(entry)
            })
            guard result.accepted,sourceMagnetSurvivorCurrent(entry) else{return false}
            consume(result,previous:before);guard sourceMagnetSurvivorCurrent(entry) else{return false}
        }
        return sourceMagnetSurvivorCurrent(entry)
    }
    /// Called by real replacement Promise-all after actual bounce + wall50
    /// verification. Reserve constructors precede conversion/value/tail.
    private func finishSourceMagnetLazyBoard(_ plan:NativeSpecialMovePlan)->(NativeMoveResult,NativeBoardState)? {
        guard let scope=sourceMagnetLazyScope,sourceMagnetMainScope === scope,scope.current,
              engine.sourceSpecialAbsorbMainEntered,let main=sourceMagnetMainEntries[plan.id],main.capture?.phase == .entered,
              sourceMagnetMainNodeCurrent(main.destination,generation:plan.generation),sourceMagnetSurvivorEntries[plan.id]==nil,
              let geometry,let driver=sourceOuterTimelineDriver else{return nil}
        let entry=SourceMagnetSurvivorEntry(node:main.destination,plan:plan);sourceMagnetSurvivorEntries[plan.id]=entry
        let current:()->Bool = {[weak self,weak entry] in guard let self,let entry else{return false};return self.sourceMagnetSurvivorCurrent(entry)}
        guard current(),let fill=engine.prepareSourceMagnetLazyReserveFill(transactionID:plan.id,generation:plan.generation,sourceCurrent:current),
              constructSourceMagnetReserveFill(fill,entry:entry,scope:scope),current() else{
            retireSourceMagnetSurvivor(entry);return nil
        }
        let owner=NativeSourceMagnetSurvivorOwner(node:entry.node,transactionID:plan.id,generation:plan.generation,service:scope.service,driver:driver,hooks:.init(
            current:current,frameCurrent:{[weak self,weak node=entry.node,scope] in
                guard let self,let node,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetLazyScope === scope else{return false}
                let accepted=scope.current
                return accepted && self.sourceAnimationBindingAdmissionOpen && self.sourceMagnetLazyScope === scope && self.sourceMagnetMainNodeCurrent(node,generation:plan.generation)
            },random:scope.mathRandom.next,acquireFrames:{[weak self] in guard let self,current() else{return nil};return self.beginSourceMotion(.spawnBounce,id:plan.id+":survivor",generation:plan.generation)},
            beforeSetValue:{[weak self] in
                guard let self,current() else{return false};let before=self.engine.state
                let result=self.engine.commitSourceMagnetLazySurvivorValue(transactionID:plan.id,generation:plan.generation,sourceCurrent:current)
                guard result.accepted,current() else{return false};self.consume(result,previous:before);return current()
            },resolutionReleased:{[weak self,weak entry] in
                guard let self,let entry,current() else{return}
                if !self.engine.releaseSourceMagnetLazySurvivorResolution(transactionID:plan.id,generation:plan.generation,sourceCurrent:current){self.retireSourceMagnetSurvivor(entry)}
            },inputBound:{[weak entry] in if current(){entry?.node.sourceEventMode="static"}},finished:{[weak self,weak entry] outcome in
                guard let self,let entry else{return};let valid=current();self.retireSourceMagnetSurvivor(entry)
                if valid,outcome != .completed{self.onPresentationFailure?("source_magnet_survivor_tail_interrupted")}
            }))
        entry.owner=owner
        guard owner.start(position:geometry.center(row:plan.destination.cell.row,column:plan.destination.cell.column),depthZ:CGFloat(plan.destination.cell.row*engine.state.columns+plan.destination.cell.column),selectSurvivor:{[weak self] in
            guard let self,current() else{return nil}
            return self.engine.prepareSourceMagnetLazySurvivor(transactionID:plan.id,generation:plan.generation,sourceCurrent:current)?.survivor
        }),current(),entry.owner === owner else{
            retireSourceMagnetSurvivor(entry);return nil
        }
        if let tween=sourceDragTweenDriver {entry.node.installSourceDragTweenDriver(tween)}
        // Source's final fill rechecks the SAME reserved cells; already-created
        // holders are not recreated. Empty-list full-grid is handled above.
        let before=engine.state,result=engine.commitSpecialBoard(transactionID:plan.id)
        guard result.accepted,current() else{retireSourceMagnetSurvivor(entry);return nil}
        return(result,before)
    }

    @MainActor private final class SourceMagnetPullEntry {
        let plan:NativeSpecialMovePlan,token=UUID(),scope:NativeGameplaySourceContext.Scope,geometry:NativeBoardGeometry
        let nodes:[String:NativeDiceNode],original:[String:NativeSourceMagnetPullMotion.Pose]
        var owner:NativeSourceMagnetPullOwner?,retired=false
        var capturedForceStop:(()->Void)?
        init(plan:NativeSpecialMovePlan,scope:NativeGameplaySourceContext.Scope,geometry:NativeBoardGeometry,nodes:[String:NativeDiceNode],original:[String:NativeSourceMagnetPullMotion.Pose]){
            self.plan=plan;self.scope=scope;self.geometry=geometry;self.nodes=nodes;self.original=original
        }
    }
    private var sourceMagnetPullScope:NativeGameplaySourceContext.Scope?
    private var sourceMagnetPullForceStopFactory:((String,UInt64)->(()->Void))?
    private var sourceMagnetPullSelectionOwner:NativeSourceMagnetPullSelectionOwner?
    private var sourceMagnetSourcePulls:[String:SourceMagnetPullEntry]=[:]
    private var sourceMagnetBodyReleases:[String:(UInt64,()->Void)]=[:]
    var sourceMagnetActualPullOwnerCount:Int {sourceMagnetSourcePulls.count}
    /// Core Magnet→regular-dst only. Raw and other variants retain existing
    /// route. This borrows the actual APP Math, timeout and per-RAF FIFO owners.
    @discardableResult func configureSourceMagnetPull(scope:NativeGameplaySourceContext.Scope,captureForceStop:@escaping(String,UInt64)->(()->Void))->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetPullScope==nil,
              sourceMagnetMainScope === scope,sourceMagnetLazyScope === scope,
              engine.sourceMathRandom === scope.mathRandom,engine.pendingSpecial==nil,
              engine.sourceMagnetPullSelection==nil,sourceMagnetSourcePulls.isEmpty,
              scope.service.sourceFrameTransportAdmissionOpen,
              let installation=sourceMicrotaskInstallation,installation.isCurrent,
              let tasks=scope.sourceMicrotaskTasks,installation.tasks === tasks,
              scope.service.sourceMicrotaskTasks === tasks,sourceAppTimeouts.sourceMicrotaskTasks === tasks else{return false}
        let selector=NativeSourceMagnetPullSelectionOwner{[weak self,scope] state,src,dst,candidates in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetPullScope === scope,
                  scope.current,self.engine.state==state,src.gameplayArchetype == .magnet,src.variant==nil,!dst.isWild,dst.variant==nil,
                  let destination=self.nodesByID[dst.id],self.sourceMagnetMainNodeCurrent(destination,generation:state.generation) else{return nil}
            // CollectBoardGameplayTiles visits STATE order first and deduplicates
            // grid references. Covered physical/Core roster guarantees no extra
            // dangling grid die here; no sorted model-cell distance replacement.
            var seen=Set<String>(),records:[(String,Double,Int)]=[]
            for (index,tile) in candidates.enumerated() {
                guard seen.insert(tile.id).inserted,let node=self.nodesByID[tile.id],
                      self.sourceMagnetMainNodeCurrent(node,generation:state.generation),node.sourcePhysicalMarkersCovered,
                      node.position.x.isFinite,node.position.y.isFinite,node.sourceValue==tile.value,
                      node.sourceLocked==tile.locked,!node.isHidden,Double(node.alpha)>0.01 else{return nil}
                records.append((tile.id,hypot(Double(node.position.x-destination.position.x),Double(node.position.y-destination.position.y)),index))
            }
            let order=records.sorted{a,b in a.1==b.1 ? a.2<b.2:a.1<b.1}.map{$0.0}
            guard self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetPullScope === scope,scope.current,self.engine.state==state else{return nil}
            return order
        }
        sourceMagnetPullScope=scope;sourceMagnetPullForceStopFactory=captureForceStop;sourceMagnetPullSelectionOwner=selector;engine.sourceMagnetPullSelection=selector
        return true
    }
    private func sourceMagnetPullCurrent(_ entry:SourceMagnetPullEntry)->Bool {
        guard sourceAnimationBindingAdmissionOpen,!entry.retired,sourceMagnetSourcePulls[entry.plan.id] === entry,
              sourceMagnetPullScope === entry.scope,engine.state.generation==entry.plan.generation else{return false}
        let accepted=entry.scope.current
        return accepted && sourceAnimationBindingAdmissionOpen && !entry.retired && sourceMagnetSourcePulls[entry.plan.id] === entry && sourceMagnetPullScope === entry.scope && engine.state.generation==entry.plan.generation
    }
    private func sourceMagnetPullNodeCurrent(_ node:NativeDiceNode,entry:SourceMagnetPullEntry)->Bool {
        sourceMagnetPullCurrent(entry) && entry.nodes[node.tileID] === node && nodesByID[node.tileID] === node && node.parent === canvasRoot && node.sourceContactNodeAlive && node.sourceGeneration==entry.plan.generation
    }
    private func sourceMagnetPullPoint(_ point:CGPoint,geometry:NativeBoardGeometry)->NativeSourceMagnetPullMotion.Point {
        let top=geometry.origin.y+(CGFloat(geometry.rows)*NativeBoardGeometry.tile+CGFloat(geometry.rows-1)*NativeBoardGeometry.gap)*geometry.scale
        return .init(x:Double((point.x-geometry.origin.x)/geometry.scale),y:Double((top-point.y)/geometry.scale))
    }
    private func sourceMagnetPullPose(_ node:NativeDiceNode,geometry:NativeBoardGeometry)->NativeSourceMagnetPullMotion.Pose {
        .init(point:sourceMagnetPullPoint(node.position,geometry:geometry),rotation:Double(node.dragInnerTilt),scaleX:Double(node.xScale/geometry.scale),scaleY:Double(node.yScale/geometry.scale),converged:false)
    }
    private func sourceMagnetPaintPull(_ node:NativeDiceNode,pose:NativeSourceMagnetPullMotion.Pose,geometry:NativeBoardGeometry){
        let top=geometry.origin.y+(CGFloat(geometry.rows)*NativeBoardGeometry.tile+CGFloat(geometry.rows-1)*NativeBoardGeometry.gap)*geometry.scale
        node.position = .init(x:geometry.origin.x+CGFloat(pose.point.x)*geometry.scale,y:top-CGFloat(pose.point.y)*geometry.scale)
        node.xScale=CGFloat(pose.scaleX)*geometry.scale;node.yScale=CGFloat(pose.scaleY)*geometry.scale;node.dragInnerTilt=CGFloat(pose.rotation)
    }
    private func startSourceMagnetPull(_ plan:NativeSpecialMovePlan,receipt:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,let scope=sourceMagnetPullScope,scope.current,sourceMagnetMainScope === scope,
              plan.archetype == .magnet,plan.variant==nil,plan.source.gameplayArchetype == .magnet,!plan.destination.isWild,
              let geometry,let destination=nodesByID[plan.destination.id],!plan.targets.isEmpty,
              sourceMagnetSourcePulls[plan.id]==nil,let installation=sourceMicrotaskInstallation,installation.isCurrent,
              let adapter=sourceMagnetGuardAdapter,let captureForceStop=sourceMagnetPullForceStopFactory else{return false}
        let targets=plan.targets.compactMap{nodesByID[$0.id]}
        guard targets.count==plan.targets.count,targets.allSatisfy({sourceMagnetMainNodeCurrent($0,generation:plan.generation) && $0.sourcePhysicalMarkersCovered}) else{return false}
        let nodes=Dictionary(uniqueKeysWithValues:targets.map{($0.tileID,$0)})
        let poses=Dictionary(uniqueKeysWithValues:targets.map{($0.tileID,sourceMagnetPullPose($0,geometry:geometry))})
        let entry=SourceMagnetPullEntry(plan:plan,scope:scope,geometry:geometry,nodes:nodes,original:poses)
        sourceMagnetSourcePulls[plan.id]=entry;sourceMagnetPullFlagOwner=(plan.id,plan.generation)
        let current:()->Bool = {[weak self,weak entry] in guard let self,let entry else{return false};return self.sourceMagnetPullCurrent(entry)}
        let owner=NativeSourceMagnetPullOwner(service:scope.service,hooks:.init(current:current,random:scope.mathRandom.next,
            protect:{[weak self,weak entry] target in
                guard let self,let entry,current(),let node=entry.nodes[target.id],self.sourceMagnetPullNodeCurrent(node,entry:entry) else{return false}
                return node.protectSourceMagnetPull(token:entry.token,generation:plan.generation,current:current) && current()
            },prepareRoot:{[weak entry] target in
                guard let entry,current(),let node=entry.nodes[target.id] else{return false}
                return node.prepareSourceMagnetPullScale(token:entry.token,generation:plan.generation) && current()
            },read:{[weak self,weak entry] id in
                guard let self,let entry,current(),let node=entry.nodes[id],self.sourceMagnetPullNodeCurrent(node,entry:entry) else{return nil}
                return self.sourceMagnetPullPose(node,geometry:geometry)
            },paint:{[weak self,weak entry] id,pose in
                guard let self,let entry,current(),let node=entry.nodes[id] else{return false}
                if !self.sourceMagnetPullNodeCurrent(node,entry:entry) {
                    // Literal Source roots retain destroyed JS targets after
                    // app-merge removes them. Native captured tombstone roots
                    // keep their original linked duration without repainting an
                    // old/new die. They create no extra clock/activity/RNG.
                    return entry.owner?.mergeStarted==true
                }
                self.sourceMagnetPaintPull(node,pose:pose,geometry:geometry);return current()
            },arrived:{[weak self,weak entry] id in
                guard let self,let entry,current(),let node=entry.nodes[id] else{return false}
                return self.sourceMagnetPullNodeCurrent(node,entry:entry)
            },convergence:{[weak self,weak entry] in
                guard let self,let entry,current(),self.engine.sourceSpecialAbsorbMainEntered else{return false}
                self.onSpecialMoment?(plan.variant ?? "magnet","pull",plan.targets.count)
                guard current() else{return false}
                // Capture the just-played actual Force voice, never a later
                // global voice lookup. A reentrant factory cannot republish A.
                let stop=captureForceStop(plan.id,plan.generation)
                guard current() else{stop();return false}
                entry.capturedForceStop=stop
                // Actual original import/await reaction follows this global
                // root dispatch, not one guessed Pixi-render-frame callback.
                return installation.enqueue{[weak self,weak entry] in
                    guard let self,let entry,current(),self.specialIsCurrent(plan),self.engine.sourceSpecialAbsorbMainEntered else{return}
                    self.specialPresentationIDs.removeAll()
                    guard self.beginSourceMagnetHelper(plan) else{self.onPresentationFailure?("source_magnet_helper_producer_missing");self.retireSourceMagnetPull(entry);return}
                    let before=self.engine.state
                    let result=self.engine.prepareSourceMagnetLazyRespawn(transactionID:plan.id,generation:plan.generation,sourceCurrent:current)
                    self.consume(result,previous:before)
                    guard result.accepted,current() else{self.sourceMagnetHelpers[plan.id]?.retire();self.retireSourceMagnetPull(entry);return}
                    self.startMagnetRespawn(plan,receipt:receipt,owner:nil)
                }
            },restore:{[weak self,weak entry] target in
                guard let self,let entry,let node=entry.nodes[target.id],self.engine.state.generation==plan.generation,
                      self.nodesByID[target.id] === node,node.parent === self.canvasRoot,node.sourceContactNodeAlive,node.sourceGeneration==plan.generation else{return}
                guard node.releaseSourceMagnetPull(token:entry.token,generation:plan.generation,restore:true) else{return}
                self.sourceMagnetPaintPull(node,pose:target.pose,geometry:geometry)
            },acquireFrames:{[weak self] in guard let self,current() else{return nil};return self.beginSourceMotion(.magnetPull,id:plan.id,generation:plan.generation)},
            stopForceSound:{[weak entry] in
                guard let entry else{return};let stop=entry.capturedForceStop;entry.capturedForceStop=nil;stop?()
            },
            releasePullGuard:{[weak self] in
                guard let self,self.engine.state.generation==plan.generation,self.sourceMagnetPullFlagOwner?.id==plan.id,self.sourceMagnetPullFlagOwner?.generation==plan.generation else{return}
                self.sourceMagnetPullFlagOwner=nil
            },pullGuardActive:{[weak self] in current() && self?.sourceMagnetPullFlagOwner?.id==plan.id && self?.engine.flags.wildMagnetPullInProgress==true},
            scheduleTimeout:{ms,elapsed,cancelled in guard current() else{return nil};return adapter.schedule(id:plan.id+":pull",generation:plan.generation,ms:ms,elapsed:elapsed,cancelled:cancelled)},
            recoveryCheck:{[weak self] _ in
                // A timeout is NOT a synthesized model commit. The actual
                // post-main rollback/recovery Core receipt is a separate gap.
                self?.onPresentationFailure?("source_magnet_pull_timeout_model_recovery_not_bound")
            },finished:{[weak self,weak entry] outcome in
                guard let self,let entry else{return}
                if self.sourceMagnetSourcePulls[plan.id] === entry {self.sourceMagnetSourcePulls.removeValue(forKey:plan.id)}
                entry.retired=true;entry.owner=nil;entry.capturedForceStop=nil
                for node in entry.nodes.values{node.releaseSourceMagnetPull(token:entry.token,generation:plan.generation,restore:false)}
                if outcome != .cleaned,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==plan.generation {self.onPresentationFailure?("source_magnet_pull_"+String(describing:outcome))}
            }))
        entry.owner=owner
        let exactTargets=plan.targets.compactMap{tile in poses[tile.id].map{NativeSourceMagnetPullOwner.Target(id:tile.id,pose:$0)}}
        guard owner.start(targets:exactTargets,destination:sourceMagnetPullPoint(destination.position,geometry:geometry)),current(),entry.owner === owner else{retireSourceMagnetPull(entry);return false}
        return true
    }
    private func retireSourceMagnetPull(_ entry:SourceMagnetPullEntry){
        guard !entry.retired else{return};entry.retired=true
        if sourceMagnetSourcePulls[entry.plan.id] === entry {sourceMagnetSourcePulls.removeValue(forKey:entry.plan.id)}
        let owner=entry.owner;entry.owner=nil;owner?.dispose()
    }
    private func retireSourceMagnetPullBindings(){
        sourceMagnetPullScope=nil;sourceMagnetPullForceStopFactory=nil
        let selector=sourceMagnetPullSelectionOwner;sourceMagnetPullSelectionOwner=nil
        if let selector,engine.sourceMagnetPullSelection === selector {engine.sourceMagnetPullSelection=nil}
        let captures=Array(sourceMagnetSourcePulls.values);sourceMagnetSourcePulls=[:]
        captures.forEach{retireSourceMagnetPull($0)}
        let body=sourceMagnetBodyReleases;sourceMagnetBodyReleases=[:];body.values.forEach{$0.1()}
    }
    private func sourceMagnetBodyEnd(id:String,generation:UInt64){
        guard let capture=sourceMagnetBodyReleases[id],capture.0==generation else{return}
        sourceMagnetBodyReleases.removeValue(forKey:id);capture.1()
    }

    @MainActor private final class SourceMagnetMainEntry {
        let source:NativeDiceNode,destination:NativeDiceNode,generation:UInt64,owner:NativeSourceMergeSixAbsorbOwner
        var plan:NativeSpecialMovePlan?,capture:NativeSourceSpecialMainCapture<NativeDiceNode>?,retired=false
        var targetPoses:[String:(NativeDiceNode,CGPoint,CGFloat,CGFloat,CGFloat)]=[:]
        init(source:NativeDiceNode,destination:NativeDiceNode,generation:UInt64,owner:NativeSourceMergeSixAbsorbOwner){self.source=source;self.destination=destination;self.generation=generation;self.owner=owner}
    }
    private var sourceMagnetMainScope:NativeGameplaySourceContext.Scope?
    private var sourceMagnetMainPrepared:SourceMagnetMainEntry?
    private var sourceMagnetMainEntries:[String:SourceMagnetMainEntry]=[:]
    /// Only core Magnet source→already-bound regular destination, default OFF.
    /// Pull timelines/RNG/lazy survivor order have separate source admission.
    @discardableResult func configureSourceMagnetMain80(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetMainScope==nil,
              sourceContactScopeForMagnet === scope,sourceSpecialTransactions != nil,sourceMagnetBindings != nil,
              sourceDragTweenDriver === scope.tween,sourceStackFrameService === scope.service,
              scope.service.sourceFrameTransportAdmissionOpen,sourceContactVisualRandom != nil,
              textures.sourceRetainedRegularOpenTexturesReady else{return false}
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceMagnetMainScope==nil,
              sourceContactScopeForMagnet === scope,sourceAnimationBindingAdmissionOpen else{return false}
        sourceMagnetMainScope=scope;engine.sourceMagnetMain80Enabled=true;return true
    }
    private func sourceMagnetMainNodeCurrent(_ node:NativeDiceNode,generation:UInt64)->Bool {
        sourceAnimationBindingAdmissionOpen && engine.state.generation==generation && nodesByID[node.tileID] === node &&
        node.parent === canvasRoot && node.sourceGeneration==generation && node.sourceContactNodeAlive
    }
    private func sourceMagnetMainReady(_ src:NativeTile,_ dst:NativeTile,generation:UInt64)->Bool {
        guard src.gameplayArchetype == .magnet,src.variant==nil,!dst.isWild,dst.variant==nil,
              let scope=sourceMagnetMainScope,scope.current,sourceContactScopeForMagnet === scope,
              sourceMagnetMainPrepared==nil,sourceMagnetMainEntries.isEmpty,
              let a=nodesByID[src.id],let b=nodesByID[dst.id],sourceMagnetMainNodeCurrent(a,generation:generation),
              sourceMagnetMainNodeCurrent(b,generation:generation),a.sourceOuterDriven,b.sourceOuterDriven,
              a.sourceValue==src.value,b.sourceValue==dst.value,a.sourceStackDepth==src.stackDepth,b.sourceStackDepth==dst.stackDepth,
              !a.sourceRegularFramePending,!b.sourceRegularFramePending,b.sourceMergeSixFaceReady(service:scope.service),
              sourceMagnetLazyScope == nil || b.sourcePhysicalMarkersCovered else{return false}
        return sourceAnimationBindingAdmissionOpen && sourceMagnetMainScope === scope && scope.current && sourceMagnetMainNodeCurrent(a,generation:generation) && sourceMagnetMainNodeCurrent(b,generation:generation)
    }
    private func claimSourceMagnetMain(source:NativeTile,destination:NativeTile,kind:NativeWildArchetype,
        claim:()->NativeSourceSpecialContactLease?)->NativeSourceSpecialContactLease? {
        guard sourceMagnetMainScope != nil,kind == .magnet else{return claim()}
        let generation=engine.state.generation
        guard sourceMagnetMainReady(source,destination,generation:generation),let scope=sourceMagnetMainScope,
              let src=nodesByID[source.id],let dst=nodesByID[destination.id] else{return nil}
        let entry=SourceMagnetMainEntry(source:src,destination:dst,generation:generation,
            owner:NativeSourceMergeSixAbsorbOwner(host:src,driver:scope.tween))
        sourceMagnetMainPrepared=entry // captured before lazy auto roots/acquisition can reenter.
        let current:()->Bool = {[weak self,weak entry] in
            guard let self,let entry,!entry.retired else{return false}
            let bound=self.sourceMagnetMainPrepared === entry || entry.plan.map{self.sourceMagnetMainEntries[$0.id] === entry}==true
            return bound && self.sourceMagnetMainScope === scope && scope.current && !entry.retired && self.sourceMagnetMainNodeCurrent(entry.source,generation:generation) && self.sourceMagnetMainNodeCurrent(entry.destination,generation:generation)
        }
        guard entry.owner.startAuto(destination:dst.position,current:current,onScaleInitialize:{[weak src] in src?.killSourceActiveScaleChildren()}),current() else{retireSourceMagnetMainEntry(entry);return nil}
        guard let lease=claim() else{retireSourceMagnetMainEntry(entry);return nil}
        guard current() else{retireSourceMagnetMainEntry(entry);lease.rejected();return nil}
        return .init(isCurrent:{[weak entry] in guard let entry,!entry.retired,current() else{return false};let accepted=lease.isCurrent();return accepted && current()},
            rejected:{[weak self,entry] in self?.retireSourceMagnetMainEntry(entry);lease.rejected()})
    }
    private func sourceMagnetMainOwns(_ node:NativeDiceNode)->Bool {
        Array(sourceMagnetMainEntries.values).contains{entry in
            guard !entry.retired,let capture=entry.capture else{return false}
            if capture.phase == .entered {return entry.destination === node && sourceMagnetMainNodeCurrent(node,generation:entry.generation)}
            return capture.retains(node,id:node.tileID,generation:entry.generation)
        }
    }
    private func startSourceMagnetMain(_ plan:NativeSpecialMovePlan,result:NativeMoveResult,previous:NativeBoardState)->Bool {
        guard let entry=sourceMagnetMainPrepared,let scope=sourceMagnetMainScope,!entry.retired,
              entry.generation==plan.generation,entry.source.tileID==plan.source.id,entry.destination.tileID==plan.destination.id,
              sourceMagnetMainNodeCurrent(entry.source,generation:plan.generation),sourceMagnetMainNodeCurrent(entry.destination,generation:plan.generation) else{return false}
        sourceMagnetMainPrepared=nil;entry.plan=plan;sourceMagnetMainEntries[plan.id]=entry
        for tile in plan.targets {if let node=nodesByID[tile.id] {entry.targetPoses[tile.id]=(node,node.position,node.xScale,node.yScale,node.visual.zRotation)}}
        var canceled:NativeMoveResult?
        let capture=NativeSourceSpecialMainCapture(plan:plan,source:entry.source,destination:entry.destination,hooks:.init(
            generationCurrent:{[weak self] in self?.engine.state.generation==plan.generation},
            nodeCurrent:{[weak self] node,_,generation in self?.sourceMagnetMainNodeCurrent(node,generation:generation)==true},
            register:{[weak self,weak entry] in
                guard let self,let entry,!entry.retired,self.sourceMagnetMainEntries[plan.id] === entry,
                      self.sourceMagnetMainScope === scope,scope.current else{return nil}
                return self.engine.registerSourceSpecialAbsorbOwner(transactionID:plan.id,generation:plan.generation)
            },commit:{[weak self,weak entry] receipt in
                guard let self,let entry,!entry.retired,self.sourceMagnetMainEntries[plan.id] === entry else{return false}
                return self.engine.commitSourceSpecialAbsorbMain(receiptID:receipt.id,generation:receipt.generation).accepted
            },cancel:{[weak self] receipt in
                guard let self else{return false}
                let result=self.engine.cancelSourceSpecialAbsorb(receiptID:receipt.id,generation:receipt.generation)
                if result.accepted {canceled=result};return result.accepted
            },removeCapturedPair:{[weak self] src,dst in
                guard let self else{return}
                for node in [src,dst] where self.nodesByID[node.tileID] === node {self.nodesByID.removeValue(forKey:node.tileID);node.dispose();node.removeFromParent()}
            },cleanupCapturedPull:{[weak self,weak entry] in
                guard let self,let entry,self.engine.state.generation==plan.generation else{return}
                let sourcePull=self.sourceMagnetSourcePulls[plan.id]
                if let sourcePull {self.retireSourceMagnetPull(sourcePull)}
                // Existing Raw carrier remains separately clocked.
                // Exact actual object/paint capture is restored on its owned
                // destructive cancellation; neither center reset nor new idle.
                let carrier=self.sourceMagnetPullCarriers.removeValue(forKey:plan.id);carrier?.removeAllActions();carrier?.removeFromParent()
                if sourcePull==nil {
                    for(_,pose) in entry.targetPoses where self.nodesByID[pose.0.tileID] === pose.0 && pose.0.parent === self.canvasRoot && pose.0.sourceGeneration==plan.generation && pose.0.sourceContactNodeAlive {
                        pose.0.position=pose.1;pose.0.xScale=pose.2;pose.0.yScale=pose.3;pose.0.visual.zRotation=pose.4
                    }
                }
            },releaseMainFramesAndIdle:{[weak self] in self?.sourceMagnetBodyEnd(id:plan.id,generation:plan.generation)},
            releaseSpecialAndQueue:{[weak self] in self?.sourceSpecialTransactions?.absorbInterrupted(id:plan.id,generation:plan.generation)},
            publishCanceledState:{[weak self,weak entry] in
                guard let self,let entry,let canceled,self.engine.state.generation==plan.generation else{return}
                self.specialPresentationID=nil;self.retireSourceMagnetMainEntry(entry)
                self.consume(canceled,previous:self.engine.state)
            },continueAfterMain:{[weak self,weak entry] in
                guard let self,let entry,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetMainEntries[plan.id] === entry,!entry.retired else{return}
                // Literal main80 removes only the actual src while dst remains
                // the same protected six for its genuine pull continuation.
                if self.nodesByID[entry.source.tileID] === entry.source {self.nodesByID.removeValue(forKey:entry.source.tileID);entry.source.dispose();entry.source.removeFromParent()}
            },retireNativeRoots:{[weak entry] in entry?.owner.dispose()}))
        entry.capture=capture
        guard entry.destination.prepareSourceMagnetRegularDestination(plan,service:scope.service,random:{scope.smokeSession.nextVisualRandom()},
            onFaceCancelled:{[weak self,weak entry] in if let entry {self?.retireSourceMagnetMainEntry(entry)}}),sourceMagnetMainNodeCurrent(entry.destination,generation:plan.generation),!entry.retired else{retireSourceMagnetMainEntry(entry);return false}
        if sourceMagnetPullScope === scope {
            let prior=sourceMagnetBodyReleases;sourceMagnetBodyReleases=[:];prior.values.forEach{$0.1()}
            guard sourceAnimationBindingAdmissionOpen,!entry.retired,sourceMagnetMainEntries[plan.id] === entry,scope.current else{retireSourceMagnetMainEntry(entry);return false}
            guard let frames=beginSourceMotion(.mergeSixResolution,id:plan.id,generation:plan.generation) else{retireSourceMagnetMainEntry(entry);return false}
            guard sourceAnimationBindingAdmissionOpen,!entry.retired,sourceMagnetMainEntries[plan.id] === entry,scope.current else{frames();retireSourceMagnetMainEntry(entry);return false}
            let idle=scope.specialIdle.acquire(reason:"merge6-resolution")
            guard sourceAnimationBindingAdmissionOpen,!entry.retired,sourceMagnetMainEntries[plan.id] === entry,scope.current,let idle else{frames();idle?();retireSourceMagnetMainEntry(entry);return false}
            sourceMagnetBodyReleases[plan.id]=(plan.generation,{frames();idle()})
        }
        consume(result,previous:previous) // actual prefix cue/pull roots precede main registration.
        guard sourceAnimationBindingAdmissionOpen,!entry.retired,sourceMagnetMainEntries[plan.id] === entry else{retireSourceMagnetMainEntry(entry);return false}
        var installed:UUID?
        let admitted=entry.owner.startMain(destination:entry.destination.position,current:{[weak self,weak entry] in
            guard let self,let entry,!entry.retired else{return false};return self.sourceMagnetMainEntries[plan.id] === entry && self.sourceMagnetMainScope === scope && scope.current && self.sourceMagnetMainNodeCurrent(entry.source,generation:plan.generation) && self.sourceMagnetMainNodeCurrent(entry.destination,generation:plan.generation)
        },onInstalled:{[weak capture] receipt in installed=receipt.id;if capture?.mainInstalled(receipt.id) != true {capture?.capturedObjectRetired()}},
            onCompleted:{[weak capture] in if let installed {_=capture?.mainCompleted(installed)}},
            onInterrupted:{[weak capture] in if let installed {_=capture?.mainInterrupted(installed)}})
        guard admitted,capture.phase == .installed,!entry.retired else{retireSourceMagnetMainEntry(entry);return false}
        return true
    }
    private func retireSourceMagnetMainEntry(_ entry:SourceMagnetMainEntry){
        guard !entry.retired else{return}
        let capture=entry.capture,plan=entry.plan
        let setup=(capture?.phase == .captured || capture?.phase == .retired && capture?.coreReceipt==nil)
        entry.retired=true
        if sourceMagnetMainPrepared === entry {sourceMagnetMainPrepared=nil}
        if let id=plan?.id,sourceMagnetMainEntries[id] === entry {sourceMagnetMainEntries.removeValue(forKey:id)}
        entry.capture=nil // seal/unhook BEFORE Core/registry/native cancellation callbacks.
        if setup,let plan,engine.state.generation==plan.generation {
            let result=engine.cancelSourceMagnetMainSetup(transactionID:plan.id,generation:plan.generation)
            if result.accepted {
                for node in [entry.source,entry.destination] where nodesByID[node.tileID] === node {nodesByID.removeValue(forKey:node.tileID);node.dispose();node.removeFromParent()}
                sourceSpecialTransactions?.absorbInterrupted(id:plan.id,generation:plan.generation)
            }
        }
        capture?.capturedObjectRetired();capture?.retireObsolete();entry.owner.dispose()
        if setup,let plan {sourceMagnetBodyEnd(id:plan.id,generation:plan.generation)}
    }
    private func retireSourceMagnetMain(){
        let entries=Array(sourceMagnetMainEntries.values)+(sourceMagnetMainPrepared.map{[$0]} ?? [])
        sourceMagnetMainEntries=[:];sourceMagnetMainPrepared=nil
        entries.forEach{entry in entry.capture?.capturedObjectRetired();retireSourceMagnetMainEntry(entry)}
        sourceMagnetMainScope=nil;engine.sourceMagnetMain80Enabled=false
    }

    private var sourceSpecialTransactions:NativeSourceSpecialSceneTransactionOwner?
    private var sourceSpecialContactHook:NativeSourceSpecialContactHook?
    @discardableResult func configureSourceSpecialTransactions(scope:NativeGameplaySourceContext.Scope)->Bool {
        guard sourceAnimationBindingAdmissionOpen,scope.current,sourceSpecialTransactions==nil,
              engine.sourceSpecialContactHook==nil else{return false}
        let generation=engine.state.generation
        let owner=NativeSourceSpecialSceneTransactionOwner(scope:scope.registries,mutations:scope.contactMutations,
            current:{[weak self,scope] in guard let self else{return false};return self.sourceAnimationBindingAdmissionOpen && scope.current && self.engine.state.generation==generation},
            guardReleased:{[weak self] in self?.sourceMeterQueue?.guardReleased()})
        guard owner.mount(),sourceAnimationBindingAdmissionOpen,scope.current,engine.state.generation==generation,
              sourceSpecialTransactions==nil,engine.sourceSpecialContactHook==nil else{owner.retire();return false}
        let hook=NativeSourceSpecialContactHook(claim:{[weak self,weak owner] source,destination,kind in
            guard let self,let owner else{return nil}
            return self.claimSourceMagnetMain(source:source,destination:destination,kind:kind,
                claim:{owner.claim(source:source,destination:destination,kind:kind,generation:generation)})
        })
        sourceSpecialTransactions=owner;sourceSpecialContactHook=hook;engine.sourceSpecialContactHook=hook
        sourceDisposalSealingEnabled=true
        return true
    }
    private func retireSourceSpecialTransactions(){
        retireSourceMagnetMain()
        retireSourceMagnetVerification()
        let owner=sourceSpecialTransactions,hook=sourceSpecialContactHook
        sourceSpecialTransactions=nil;sourceSpecialContactHook=nil
        if let hook,engine.sourceSpecialContactHook === hook {engine.sourceSpecialContactHook=nil}
        owner?.retire()
    }
    /// The genuine app-merge tail must supply this ONLY from its ownsLifecycle
    /// finally. Current Native Magnet atomic conversion has no such caller yet.
    func sourceMagnetHelperFinally(id:String,generation:UInt64,ownsLifecycle:Bool){
        if ownsLifecycle {sourceMagnetBodyEnd(id:id,generation:generation)}
        sourceSpecialTransactions?.magnetHelperFinally(id:id,generation:generation,ownsLifecycle:ownsLifecycle)
    }
    private var sourceMeterCaller:NativeMeterSceneCaller?
    private var sourceMeterQueue:NativeMeterSourceQueueCoreBridge?
    private var sourceMeterLanding:NativeMeterLandingSourceOwner?
    private var sourceMeterQueueEpoch:UInt64=0,sourceMeterLandingEpoch:UInt64=0
    private var sourceMeterTearingDown=false
    private var sourceMeterRenderEpoch:UInt64=0
    private var sourceMeterConfigurationEpoch:UInt64=0
    func configureSourceMeterOpen(scope:NativeGameplaySourceContext.Scope,
        resources:NativeWildMeterDropResources,
        texturesCurrent:@escaping()->Bool,
        selectedAudio:@escaping(NativeTile,NativeMeterSelectedFinaleWarmup<SKTexture>.Capture)->Void,
        carrierAudio:@escaping(Bool,String,UInt64)->(()->Void),
        dividerMask:@escaping()->(()->Void),
        landing:@escaping(NativeDiceNode,NativeWildMeterDropRuntime.Capture)->Void) -> Bool {
        guard sourceAnimationBindingAdmissionOpen,!sourceMeterTearingDown,sourceMeterCaller==nil,scope.current,!engine.sourceMeterSpawnInProgress else{return false}
        let microtasks=sourceMicrotaskInstallation
        let sourceMicrotasksRequired=microtasks != nil
        let resourcePreparation=microtasks.flatMap{_ in resources.sourceSynchronousPreparationReceipt()}
        // Cold I/O/Assets await is NOT a proven Source producer. Only actual
        // retained original textures can make prepare inline in this task.
        if let microtasks {
            guard microtasks.isCurrent,let ready=resourcePreparation,
                  resources.sourceSynchronousPreparationIsCurrent(ready) else{return false}
        }
        sourceDisposalSealingEnabled=true
        sourceMeterConfigurationEpoch &+= 1
        let configuration=sourceMeterConfigurationEpoch,generation=engine.state.generation
        let admitted:()->Bool = {[weak self,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,!self.sourceMeterTearingDown,self.sourceMeterConfigurationEpoch==configuration else{return false}
            if let microtasks {
                guard self.sourceMicrotaskInstallation === microtasks,microtasks.isCurrent,
                      let ready=resourcePreparation,resources.sourceSynchronousPreparationIsCurrent(ready) else{return false}
            }
            let current=scope.current
            return current && self.sourceAnimationBindingAdmissionOpen && !self.sourceMeterTearingDown && self.sourceMeterConfigurationEpoch==configuration
        }
        let owner=NativeMeterSceneCaller(engine:engine,textures:textures,resources:resources,
            timeouts:sourceAppTimeouts,service:scope.service,stage:canvasRoot,
            hooks:.init(current:admitted,
                viewport:{[weak self] in self?.size ?? .zero},renderEpoch:{[weak self] in self?.sourceMeterRenderEpoch ?? 0},
                node:{[weak self] in self?.nodesByID[$0]},install:{[weak self] node,_ in
                    guard let self,admitted() else{return};self.nodesByID[node.tileID]=node
                    if let driver=self.sourceOuterTimelineDriver,let geometry=self.geometry {
                        node.installSourceOuterDriver(driver,generation:self.engine.state.generation,geometryScale:geometry.scale)
                        guard admitted() else{return}
                        if let tween=self.sourceDragTweenDriver {node.installSourceDragTweenDriver(tween)}
                        guard admitted() else{return}
                    }
                    if let idle=sourceIdleScope?.specialIdle {guard node.configureSourceSpecialIdle(idle) else{return}}
                    node.onResourceReady={ [weak self] in guard let self,admitted() else{return};self.onRenderingDemand?(!self.suspended)}
                },retire:{[weak self] id,node in
                    guard let self,self.nodesByID[id] === node else{return}
                    self.nodesByID.removeValue(forKey:id);self.sourcePopulation.remove(id)
                    self.refreshSourceIdlePopulation();node.dispose()
                },cellPose:{[weak self] cell in guard let self,let geometry=self.geometry else{return nil}
                    return (geometry.center(row:cell.row,column:cell.column),geometry.scale)
                },enqueue:{[weak self,microtasks] action in
                    guard let self,admitted() else{return}
                    // Captured optional binding: configuration may not switch
                    // from old Raw delivery into a newly installed Source owner.
                    if let captured=microtasks {self.sourceMeterEnqueue(captured,action)}
                    else if !sourceMicrotasksRequired,self.sourceMicrotaskInstallation==nil {self.sourceMeterEnqueue(nil,action)}
                },
                sourceActivity:{[weak self] id,generation in guard admitted() else{return nil};return self?.beginSourceMotion(.wildSpawnDrop,id:id,generation:generation)},
                carrierAudio:carrierAudio,dividerMask:dividerMask,selectedAudio:selectedAudio,
                texturesCurrent:texturesCurrent,
                onImpact:{[weak self] node,capture in guard admitted() else{return};self?.sourceMeterImpact(node,capture,fallback:landing)},onHaptic:{[weak self] in guard admitted() else{return};self?.onHaptic?("medium")},
                idleAdmitted:{[weak self] node in guard let self,admitted(),self.nodesByID[node.tileID] === node else{return}
                    self.sourcePopulation.insert(node.tileID);self.refreshSourceIdlePopulation()
                },ownershipReleased:{[weak self] in guard admitted() else{return};self?.synchronize()},
                fault:{[weak self] in guard admitted() else{return};self?.onPresentationFailure?($0)},consume:{[weak self] result,previous in guard admitted() else{return};self?.consume(result,previous:previous)}),
            random:{[scope] in scope.smokeSession.nextVisualRandom()},wallNow:{CACurrentMediaTime()*1000},
            sourcePromiseBookkeeping:microtasks != nil)
        guard admitted(),engine.state.generation==generation else{owner.dispose();return false}
        for tile in engine.state.tiles {
            if let node=nodesByID[tile.id] {owner.bind(node,cell:tile.cell,generation:generation)}
            guard admitted(),engine.state.generation==generation else{owner.dispose();return false}
        }
        guard admitted(),engine.state.generation==generation,sourceMeterCaller==nil else{owner.dispose();return false}
        sourceMeterCaller=owner
        // Admission remains explicit until canonical queue/save/retry and
        // landing shake/common smoke callers are independently connected.
        engine.stagedMeterDrops=true;engine.stagedMeterOpen=true
        return true
    }
    // PRIVATE capability only: exact Source environment, app microtask and
    // shared save debounce are mandatory owners, never fabricated defaults.
    @discardableResult func configureSourceMeterQueue(scope:NativeGameplaySourceContext.Scope,
        signals:NativeMeterQueueSignals,
        permission:@escaping(Bool)->NativeMeterSourceQueue.Permission,
        continuation:@escaping()->Bool,meterReady:@escaping()->Bool,
        enqueue:@escaping(@escaping @MainActor ()->Void)->Void,
        queueInProgress:@escaping(Bool)->Void,shimmer:@escaping()->Void,
        canonicalSave:@escaping(Int)->Void)->Bool {
        guard sourceAnimationBindingAdmissionOpen,!sourceMeterTearingDown,sourceMeterCaller != nil,
              sourceMeterQueue==nil,scope.current else{return false}
        sourceMeterQueueEpoch &+= 1
        let epoch=sourceMeterQueueEpoch,generation=engine.state.generation
        let current:()->Bool = {[weak self,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,!self.sourceMeterTearingDown,
                  self.sourceMeterQueueEpoch==epoch,self.engine.state.generation==generation else{return false}
            let admitted=scope.current
            return admitted && self.sourceAnimationBindingAdmissionOpen && !self.sourceMeterTearingDown && self.sourceMeterQueueEpoch==epoch && self.engine.state.generation==generation
        }
        let microtasks=sourceMicrotaskInstallation
        let sourceMicrotasksRequired=microtasks != nil
        if let microtasks {guard microtasks.isCurrent else{return false}}
        let owner=NativeMeterSourceQueueCoreBridge(engine:engine,timeouts:sourceAppTimeouts,signalRegistry:signals,
            hooks:.init(current:current,permission:permission,continuation:continuation,meterReady:meterReady,
                enqueue:{[weak self,microtasks] action in
                    guard let self,current() else{return}
                    if let captured=microtasks {self.sourceMeterEnqueue(captured,action)}
                    else if !sourceMicrotasksRequired,self.sourceMicrotaskInstallation==nil {enqueue(action)}
                },sourceQueueInProgress:queueInProgress,shimmer:shimmer,canonicalSave:canonicalSave,
                consume:{[weak self] result,previous in guard current() else{return};self?.consume(result,previous:previous)},
                fault:{[weak self] in guard current() else{return};self?.onPresentationFailure?($0)}))
        guard current(),sourceMeterQueue==nil else{owner.dispose();return false}
        sourceMeterQueue=owner;return true
    }
    @discardableResult func configureSourceMeterLanding(scope:NativeGameplaySourceContext.Scope,
        sound:@escaping()->Void)->Bool {
        guard sourceAnimationBindingAdmissionOpen,!sourceMeterTearingDown,sourceMeterCaller != nil,
              sourceMeterLanding==nil,scope.current else{return false}
        sourceMeterLandingEpoch &+= 1
        let epoch=sourceMeterLandingEpoch,generation=engine.state.generation
        let current:()->Bool = {[weak self,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,!self.sourceMeterTearingDown,
                  self.sourceMeterLandingEpoch==epoch,self.engine.state.generation==generation else{return false}
            let admitted=scope.current
            return admitted && self.sourceAnimationBindingAdmissionOpen && !self.sourceMeterTearingDown && self.sourceMeterLandingEpoch==epoch && self.engine.state.generation==generation
        }
        let owner=NativeMeterLandingSourceOwner(service:scope.service,renderer:scope.smoke,session:scope.smokeSession,
            hooks:.init(current:current,impactCurrent:{[weak self] capture in
                guard current() else{return false};return self?.sourceMeterCaller?.landingOrigin(capture) != nil
            },readShake:{[weak self] in
                guard let self else{return .init(canvas:[0,0],indicator:[0,0],decor:[0,0])}
                let pose=self.boardShake
                return .init(canvas:[Double(pose.canvas.x),Double(pose.canvas.y)],indicator:[Double(pose.indicator.x),Double(pose.indicator.y)],decor:[Double(pose.bottomDecor.x),Double(pose.bottomDecor.y)])
            },paintShake:{[weak self] pose in
                guard let self,current() else{return}
                self.applySourceMeterShake(pose)
            },sound:sound,reduced:{[weak self] in self?.sourceFrames.reducedFx ?? false},
                monotonicMilliseconds:{CACurrentMediaTime()*1000},fault:{[weak self] in guard current() else{return};self?.onPresentationFailure?($0)}))
        guard current(),sourceMeterLanding==nil else{owner.dispose();return false}
        sourceMeterLanding=owner;return true
    }
    private func applySourceMeterShake(_ pose:NativeMeterLandingShakeGraph.Pose) {
        let canvas=CGPoint(x:pose.canvas[0],y:pose.canvas[1]),indicator=CGPoint(x:pose.indicator[0],y:pose.indicator[1]),decor=CGPoint(x:pose.decor[0],y:pose.decor[1])
        boardShake = .init(canvas:canvas,indicator:indicator,bottomDecor:decor)
        canvasRoot.position=CGPoint(x:canvas.x,y:-canvas.y)
        let base=NativeGameplayChromePlan.make(viewport:size,safeTop:safeInsets.top).roundCenter
        roundIndicator.position=CGPoint(x:base.x+indicator.x,y:base.y-indicator.y)
        // Internal publication precedes external footer callback. Reentrant C
        // must observe painted pose; retired A has no post-callback writes.
        onJourneyBottomDecorShake?(decor,engine.state.generation)
    }
    private func sourceMeterImpact(_ node:NativeDiceNode,_ capture:NativeWildMeterDropRuntime.Capture,
        fallback:(NativeDiceNode,NativeWildMeterDropRuntime.Capture)->Void) {
        guard let owner=sourceMeterLanding else{fallback(node,capture);return}
        guard sourceAnimationBindingAdmissionOpen,!sourceMeterTearingDown,
              let origin=sourceMeterCaller?.landingOrigin(capture),origin.sourceTile === node else{return}
        _=owner.impact(capture,origin:origin)
    }
    private func retireSourceMeterAuxiliaries() {
        sourceMeterQueueEpoch &+= 1;sourceMeterLandingEpoch &+= 1
        let queue=sourceMeterQueue,landing=sourceMeterLanding
        sourceMeterQueue=nil;sourceMeterLanding=nil // unhook before external cancellation
        retireSourceMicrotaskBoundaries()
        queue?.dispose();landing?.dispose()
    }
    private func retireSourceMeterOpenBinding() {
        sourceMeterConfigurationEpoch &+= 1
        let old=sourceMeterCaller;sourceMeterCaller=nil
        retireSourceMeterAuxiliaries()
        old?.dispose()
    }

    private var retiringSourceTransports=false
    private var wildScheduledActionIDs=Set<String>()
    private var wildCommandOwners:[String:(SKNode,UInt64)] = [:]
    private var wildSpawnVisuals:[String:(UInt64,UInt64,NativeWildSpawnArrival?,(() -> Void)?)] = [:]
    private var wildBonusVisuals:[String:(UInt64,UInt64)] = [:]
    private var directAbsorb:(NativeDirectWildMovePlan,SKNode,UInt64)?
    private var wildSourceResolution:(id:String,generation:UInt64)?
    private var directFinalReceipt:(String,UInt64,UInt64)?
    private var directPresentationID:String?
    private var directPresentationVariant:String?
    private var specialPresentationID: String?
    private var specialPresentationVariant: String?
    private var candidateSignature: String?
    private(set) var navigationLocked = false
    var isBoardEntryComplete:Bool {!disposed && !sourceDisposalInProgress && !entryInProgress && inputAdmitted}
    private var preparedEntryGeneration:UInt64?
    private var inputAdmitted = false
    private var entryInProgress = false
    private var entryOwners = 0
    private var hudEntryReveal=NativeHUDEntryReveal()
    private var hudEntryReceipt:NativeHUDEntryReveal.Receipt?
    private(set) var isHUDRevealPending=false
    private var suspended = false
    private var disposed = false
    // Default Raw lifetime remains unchanged. Source bindings opt into an
    // entry seal before ANY captured external cleanup callback can reenter.
    var sourceDisposalSealingEnabled = false
    private var sourceDisposalInProgress = false
    private var sourceDisposalGeneration:UInt64?
    var sourceAnimationBindingAdmissionOpen:Bool {
        !disposed && !sourceDisposalInProgress && !sourceOuterTearingDown
    }
    private var exitInProgress = false
    private var exitCompletion: ((Bool) -> Void)?
    private var exitOwners = 0

    init(engine: NativeGameplayEngine, resourceRoot: URL, size: CGSize, sourceInitialConstruction:NativeSourceInitialBoardConstruction?=nil) {
        self.sourceInitialConstruction=sourceInitialConstruction
        canvasRoot=sourceInitialConstruction?.canvas ?? SKNode()
        self.engine = engine
        engine.stagedTntActivation = true
        engine.stagedDirectWildMoves = true
        engine.stagedDirectWildAssignments = true
        engine.stagedOrdinaryMoves = true
        engine.stagedOrdinaryAssignments = true
        engine.ordinarySixPresentationAdmitted = {UIFont(name:"Arial-BoldMT",size:33) != nil}
        // Reject an unavailable choreography before RNG/reservation/mutation.
        textures = sourceInitialConstruction?.textures ?? NativeBoardTextures(root: resourceRoot)
        let fonts = JimiV9Artwork(resourceRoot: resourceRoot)
        closeStageFont=fonts.font(size:16)
        fontName = fonts.font(size: 24).fontName
        finaleFontName = fonts.font(size: 24,weight: "ExtraBold").fontName
        roundIndicator = NativeRoundIndicator(font: fonts.font(size: 18,weight: "SemiBold"))
        super.init(size: size)
        scaleMode = .resizeFill; backgroundColor = .clear
        canvasRoot.name="native-gameplay-canvas";addChild(canvasRoot)
        if let sourceInitialConstruction {
            if sourceInitialConstruction.adopt(engine:engine,scene:self) {nodesByID=sourceInitialConstruction.nodes;lastGeneration=engine.state.generation;sourceInitialEntryPending=true}
            else {sourceInitialStartupRejected=true;sourceInitialConstruction.dispose()}
        }
        canvasRoot.addChild(ghosts);canvasRoot.addChild(effects);canvasRoot.addChild(hud);canvasRoot.addChild(hudStarFlights)
        hudStarFlights.zPosition = 999999
        hover.fillColor = .clear
        hover.strokeColor = UIColor(red: 138.0/255,green: 110.0/255,blue: 87.0/255,alpha: 0.15)
        hover.zPosition = 14000; hover.isHidden = true; canvasRoot.addChild(hover)
        hud.name="native-game-hud"
        ghosts.zPosition = -10000; effects.zPosition = 15000; hud.zPosition = 10000
        setupHUD()
        sourceFrames.onTarget={ [weak self] fps in self?.onFrameTarget?(fps) }
        sourceFrames.onBudget={ [weak self] receipt in self?.reducedBoardEffects=receipt.reducedFx }
        sourceFrames.onIdleSuspension={ [weak self] suspended in self?.onSpecialIdleSuspended?(suspended) }
        engine.laserTargetX = { [weak self] tile in self?.geometry.map {Double($0.center(row:tile.cell.row,column:tile.cell.column).x)} ?? .nan }
        engine.specialPresentationAdmitted = { [weak self] archetype,variant in
            guard let self else {return false}
            if archetype == .magnet {return true}
            if archetype == .star || archetype == .juice {return self.directArtworkReady(archetype,variant:variant)}
            guard archetype == .tnt else {return false}
            guard let variant else {return true}
            return self.authoredTntPresentationReady?(variant) == true
        }
        engine.finalePresentationAdmitted = { [weak self] archetype,variant in
            guard let self else {return false}
            if let variant {return self.authoredFinalePresentationReady?(variant) == true}
            if archetype == .star || archetype == .juice {return self.directArtworkReady(archetype,variant:nil)}
            return true
        }
    }

    private func directArtworkReady(_ archetype:NativeWildArchetype,variant:String?)->Bool {
        if let variant {return authoredFinalePresentationReady?(variant) == true}
        if archetype == .star {return textures.texture("assets/small-star.png") != nil}
        if archetype == .juice {
            let paths=NativeJuiceBubbleMotion.sources+["casa","poklopac","slamka"].map {"assets/shop/juice/\($0).png"}+(1...8).map {"assets/animations/bubble\($0).png"}
            return paths.allSatisfy {textures.texture($0) != nil}
        }
        return false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func didMove(to view: SKView) {
        view.isMultipleTouchEnabled = true
        let sourceInitialEntry=sourceInitialEntryPending;sourceInitialEntryPending=false
        synchronize(animateEntry: lastGeneration == nil || sourceInitialEntry)
    }

    func layout(size: CGSize, insets: UIEdgeInsets, animateEntry: Bool = false) {
        guard !sourceDisposalInProgress else {return }
        if let gen=sourceNoMovesGeneration,gen != engine.state.generation {retireSourceNoMoves()}
        guard !sourceDisposalInProgress else{return}
        guard !disposed else { return }
        guard self.size != size || safeInsets != insets || geometry == nil else { return }
        if exitInProgress { finishExit(completed: false) }
        cancelEntry()
        self.size = size; safeInsets = insets
        cancelDrag()
        geometry = nil
        synchronize(animateEntry: animateEntry)
    }

    func prepareNextBoardEntry() {
        guard !sourceDisposalInProgress else {return }
        guard !disposed else {return}
        cancelEntry();cancelDrag();cancelCandidate();synchronize()
        preparedEntryGeneration=engine.state.generation
        engine.setInputLock("native-board-entry-handoff",active:true)
        inputAdmitted=false;navigationLocked=true
    }

    func releasePreparedBoardEntry(generation:UInt64) {
        guard !sourceDisposalInProgress else {return }
        guard !disposed,preparedEntryGeneration == generation,engine.state.generation == generation else {return}
        preparedEntryGeneration=nil;engine.setInputLock("native-board-entry-handoff",active:false)
        synchronize(animateEntry:true)
        navigationLocked=engine.state.terminal != nil || pendingTerminal != nil
        if !entryInProgress {evaluate()}
    }

    private func setupHUD() {
        let brown = UIColor(red: 0.42, green: 0.35, blue: 0.29, alpha: 1)
        for label in [score, noMoves] {
            label.fontName = fontName; label.fontColor = brown
            label.verticalAlignmentMode = .center; hud.addChild(label)
        }
        score.fontSize = 18
        score.horizontalAlignmentMode = .left
        score.fontColor = UIColor(red: 181.0/255,green: 133.0/255,blue: 115.0/255,alpha: 1)
        for label in [comboX,comboNumber] {
            label.fontName = fontName; label.horizontalAlignmentMode = .left; label.verticalAlignmentMode = .center
            label.fontColor = UIColor(red: 231.0/255,green: 116.0/255,blue: 73.0/255,alpha: 1); hud.addChild(label)
        }
        comboX.text = "x"; comboX.fontSize = 14; comboNumber.fontSize = 18
        noMoves.fontSize = 42; noMoves.zPosition = 20000; noMoves.isHidden = true
        let close=NativeHUDCloseNode(texture:textures.texture("assets/close-icon.png"),stageFont:closeStageFont)
        closeButton=close;hud.addChild(close)
        let help = SKSpriteNode(texture: textures.texture("assets/hud/help.png"))
        help.name = "native-game-help"; help.size = CGSize(width: 44, height: 44); hud.addChild(help)
        scoreArt.texture = textures.texture("assets/hud/score-hud.png")
        scoreArt.name = "native-game-score-art"; hud.addChild(scoreArt)
        comboArt.name = "native-game-combo-art"; hud.addChild(comboArt)
        meterBackground.name = "native-game-wild-meter-track"
        meterBackground.fillColor = UIColor(red:234.0/255,green:223.0/255,blue:214.0/255,alpha:1)
        meterBackground.strokeColor = .clear;hud.addChild(meterBackground)
        meter.name = "native-game-wild-meter-fill"
        meter.fillColor = UIColor(red:231.0/255,green:116.0/255,blue:74.0/255,alpha:1)
        meter.strokeColor = .clear; hud.addChild(meter)
        addChild(roundIndicator)
    }

    private func layoutHUD() {
        let chrome = NativeGameplayChromePlan.make(viewport:size,safeTop:safeInsets.top)
        let top = chrome.valueRowY
        closeButton?.layout(valueRowY:top)
        let shift = (size.width*0.05).rounded()
        let spacing: CGFloat = size.width >= 768 ? 110 : 92
        let scoreX = size.width-24-62-spacing-shift
        hud.childNode(withName: "native-game-help")?.position = CGPoint(x: size.width >= 768 ? scoreX-spacing : 118, y: top)
        for icon in [scoreArt,comboArt] {
            let dimensions = icon.texture?.size() ?? CGSize(width: 28,height: 28)
            let scale = 28/max(1,max(dimensions.width,dimensions.height))
            icon.size = CGSize(width: dimensions.width*scale,height: dimensions.height*scale)
        }
        scoreArt.position = CGPoint(x: scoreX,y: top)
        score.position = CGPoint(x: scoreX+scoreArt.size.width/2+6,y: top)
        let comboWidth = comboArt.size.width+4+comboX.frame.width+comboNumber.frame.width
        let comboCenter = size.width-36-comboWidth/2-shift
        comboArt.position = CGPoint(x: comboCenter,y: top)
        comboX.position = CGPoint(x: comboCenter+comboArt.size.width/2+4,y: top)
        comboNumber.position = CGPoint(x: comboX.position.x+comboX.frame.width,y: top)
        scoreHitRect = CGRect(x: scoreX-33,y: top-30,width: 70,height: 60)
        comboHitRect = CGRect(x: comboCenter-53,y: top-30,width: 106,height: 60)
        noMoves.position = CGPoint(x: size.width / 2, y: size.height / 2)
        let rect=chrome.meterRect
        meterBackground.path=CGPath(roundedRect:CGRect(origin:.zero,size:rect.size),cornerWidth:5,cornerHeight:5,transform:nil)
        meterBackground.position=rect.origin;meter.position=rect.origin
        let ratio=NativeGameplayChromePlan.visibleMeterRatio(engine.state.wildMeter)
        meter.isHidden=ratio<=0
        meter.path=CGPath(roundedRect:CGRect(x:0,y:0,width:rect.width*ratio,height:rect.height),cornerWidth:5,cornerHeight:5,transform:nil)
        roundIndicator.position=chrome.roundCenter

    }

    private struct SourceHeldOrigin {let tileID:String;let generation:UInt64;let cell:NativeCell;let position:CGPoint;let zPosition:CGFloat}
    private var sourceHeldOrigin:SourceHeldOrigin?
    var sourceOuterTimelineDriver:NativeTileOuterTimelineDriver?
    var sourceDragTweenDriver:NativeDragTweenDriver?
    // PRIVATE opt-in limited to ordinary sub-six. Parent owns the one source
    // service, visual RNG and authoritative feature readiness before model drop.
    var sourceSameNodeStackAbsorbsEnabled=false
    // Independent opt-in full small-stack handoff; no Raw/component defaults change.
    var sourceRegularStackHandoffEnabled=false
    // Independent Core physical-face pairing. Parent installs frozen Core222;
    // defaultfalse preserves the proven component-only Source handoff behavior.
    var sourceStackCoreFaceReceiptsEnabled=false
    private struct SourceFaceDeferredPostcheck {let id:String,generation:UInt64,order:UInt64}
    private var sourceFaceDeferredPostchecks:[String:SourceFaceDeferredPostcheck]=[:]
    private var sourceFaceDeferredPostcheckSequence:UInt64=0
    private var sourceStackFrameService:NativeSourceAnimationClockService?
    private var sourceStackFrameAdmission:(()->Bool)?
    private var sourceStackFeedback:[String:NativeRegularStackFeedbackNodeBridge]=[:]
    var sourceRegularStackFeedbackRootCount:Int {sourceStackFeedback.values.reduce(0){$0+$1.activeRootCount}}
    func configureSourceRegularStackHandoff(service:NativeSourceAnimationClockService,admitted:@escaping()->Bool) {
        guard sourceAnimationBindingAdmissionOpen,service.sourceFrameTransportAdmissionOpen else{return}
        sourceStackFrameService=service;sourceStackFrameAdmission=admitted
    }
    private func sourceStackFrameReady(_ target:NativeDiceNode,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,let service=sourceStackFrameService,service.sourceFrameTransportAdmissionOpen,engine.state.generation==generation,target.parent === canvasRoot,nodesByID[target.tileID] === target,target.sourceGeneration==generation,sourceStackFrameAdmission?()==true else{return false}
        return sourceAnimationBindingAdmissionOpen && sourceStackFrameService === service && service.sourceFrameTransportAdmissionOpen && engine.state.generation==generation && target.parent === canvasRoot && nodesByID[target.tileID] === target && target.sourceGeneration==generation && target.sourceContactNodeAlive && target.sourceNumbersSkinsAvailable().contains(.base)
    }
    private func sourceStackDecisionMatches(_ captured:NativeBoardState,source:NativeTile,destination:NativeTile)->Bool {
        guard sourceAnimationBindingAdmissionOpen,engine.stagedOrdinaryMoves,(engine.sourceOrdinaryStackFacesEnabled == sourceStackCoreFaceReceiptsEnabled),engine.state==captured,let sourceNode=nodesByID[source.id],let destinationNode=nodesByID[destination.id],sourceNode.sourceContactNodeAlive,destinationNode.sourceContactNodeAlive,sourceNode.parent === canvasRoot,destinationNode.parent === canvasRoot,sourceNode.sourceGeneration==captured.generation,destinationNode.sourceGeneration==captured.generation,(sourceStackCoreFaceReceiptsEnabled || (!sourceNode.sourceRegularFramePending && !destinationNode.sourceRegularFramePending)) else{return false}
        // Source value is immediate, physical depth is RAF-owned. Do not accept
        // another merge using a precommitted Core depth while its face is pending.
        return sourceNode.value==source.value && destinationNode.value==destination.value && sourceNode.depth==source.stackDepth && destinationNode.depth==destination.stackDepth
    }
    private func retireSourceStackHandoff() {
        sourceStackFrameService=nil;sourceStackFrameAdmission=nil
        let expired=Array(sourceFaceDeferredPostchecks.values);sourceFaceDeferredPostchecks.removeAll()
        for post in expired where engine.state.generation==post.generation {_=engine.cancelOrdinaryPostcheck(receiptID:post.id,generation:post.generation)}
        let captured=Array(sourceStackFeedback.values);sourceStackFeedback.removeAll()
        for feedback in captured {feedback.dispose()}
        for node in Array(nodesByID.values) {node.retireSourceStackFrames()}
    }
    var sourceContactVisualRandom:(()->Double)?
    private var sourceRegularContactCompanions:NativeRegularContactSceneCompanions?
    func configureSourceRegularContact(_ companions:NativeRegularContactSceneCompanions,admitted:@escaping()->Bool) {
        guard sourceAnimationBindingAdmissionOpen else{return}
        sourceRegularContactCompanions=companions
        sourceContactVisualRandom={ [companions] in companions.nextVisualRandom() }
        sourceStackAbsorbAdmission={ [weak self,weak companions] source,destination in
            guard let self,let companions,admitted(),!self.disposed,!self.sourceOuterTearingDown,self.sourceRegularContactCompanions === companions,let target=self.nodesByID[destination.id],companions.ready(canvas:self.canvasRoot,target:target,generation:self.engine.state.generation) else{return false}
            return self.engine.state.tiles.allSatisfy{tile in tile.id==source.id || tile.id==destination.id || tile.locked || tile.isWild || tile.variant != nil || tile.value<=0 || self.engine.noMovesTileRuntime[tile.id]?.destroyed==true || self.nodesByID[tile.id] != nil}
        }
    }
    var sourceStackAbsorbAdmission:((NativeTile,NativeTile)->Bool)?
    // Full contact callsite companions remain separately admitted: layer-click
    // BEFORE impact, neighbour recoil + source shared smoke AFTER impact. These
    // seams consume the same injected visual draw stream in original order.
    var onSourceStackContactPrefix:((NativeDiceNode,NativeDiceNode,()->Double)->Void)?
    var onSourceStackContactSuffix:((NativeDiceNode,NativeDiceNode,()->Double)->Void)?
    private struct SourceAcceptedStack {
        let plan:NativeOrdinaryMovePlan,node:NativeDiceNode,owner:NativeSourceAcceptedAbsorbOwner,visual:UInt64
    }
    private var sourceAcceptedStacks:[String:SourceAcceptedStack]=[:]
    private var sourceOuterTearingDown=false
    func sourceNativeTileNode(_ tileID:String)->NativeDiceNode? {nodesByID[tileID]}
    private func sourceAcceptedStackOwns(_ tileID:String,generation:UInt64)->Bool {
        sourceAcceptedStacks.values.contains{$0.plan.source.id==tileID && $0.plan.generation==generation && nodesByID[tileID] === $0.node && $0.node.parent === canvasRoot && $0.node.sourceGeneration==generation && $0.node.sourceContactNodeAlive}
    }
    // Genuine source markers supplied by their captured native feature owners.
    // Decorative inner actions never populate this dictionary.
    var sourceOuterTileMarkers:[String:NativeTileOuterEligibility.Owners]=[:]
    func sourceOuterEligibility(tile:NativeTile,node:NativeDiceNode)->NativeTileOuterEligibility {
        var result=NativeTileOuterEligibility();result.visible=tile.visible;result.locked=tile.locked;result.value=tile.value;result.variant=tile.variant;result.eventMode=node.sourceEventMode
        let currentOwner=engine.state.tile(at:tile.cell)?.id==tile.id && nodesByID[tile.id] === node
        result.destroyed=engine.noMovesTileRuntime[tile.id]?.destroyed ?? false
        result.gridMembership=currentOwner && draggedID != tile.id ? .sameIdentity:.missingOrDifferentIdentity
        result.idleTimelinePresent=node.sourceIdleTimelinePresent;result.activeIdle=node.sourceActiveIdle
        var markers=sourceOuterTileMarkers[tile.id] ?? .init()
        markers.mergeImpact=markers.mergeImpact || node.sourceOuterOwners.mergeImpact
        markers.pickupScale=markers.pickupScale || node.sourceOuterOwners.pickupScale
        markers.snapBack=markers.snapBack || node.sourceOuterOwners.snapBack
        markers.isBeingSpawned=markers.isBeingSpawned || tile.transientSpawn
        markers.pendingRemoval=markers.pendingRemoval || tile.pendingRemoval
        let runtime=engine.noMovesTileRuntime[tile.id]
        markers.beingRemoved=markers.beingRemoved || runtime?.beingRemoved == true
        markers.cleanupQueued=markers.cleanupQueued || runtime?.cleanupQueued == true
        markers.wildSpawnDropping=markers.wildSpawnDropping || runtime?.wildDropping == true || engine.meterDropReservations.values.contains{$0.tileID==tile.id && $0.assetsPrepared && !$0.landed}
        markers.skipIdleScaleReset=markers.skipIdleScaleReset || node.sourceSkipIdleScaleReset
        result.owners=markers;return result
    }

    func synchronize(animateEntry: Bool = false) {
        guard !sourceDisposalInProgress else {return }
        guard !disposed else { return }
        onRenderingDemand?(true)
        guard !sourceDisposalInProgress else {return}
        let state = engine.state
        if sourceInitialStartupRejected {onPresentationFailure?("source_initial_startup_not_adopted");return}
        if let initial=sourceInitialConstruction,!initial.isCurrent {sourceInitialConstruction=nil;initial.dispose()}
        if lastGeneration != state.generation {
            if lastGeneration != nil {retireSourceEndgameMutationLedger()}
            retireSourceSpecialIdleBindings()
            retireSourceSixBindings()
            if lastGeneration != nil {retireSourceHUDStarJobs()}
            sourceFaceDeferredPostchecks.removeAll()
            let oldFeedback=Array(sourceStackFeedback.values);sourceStackFeedback.removeAll()
            for feedback in oldFeedback {feedback.dispose()}
            if let previous=lastGeneration {retireSourceSpecialTransactions();retireSourceMeterAuxiliaries();sourceMeterCaller?.retireGeneration(previous)}
            if sourceMeterCaller != nil || sourceMeterTearingDown {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==state.generation else{return}}
            let enclosingSourceRetirement=sourceOuterTearingDown
            if !sourceAcceptedStacks.isEmpty {retireSourceAcceptedStacks()};sourceOuterTearingDown=enclosingSourceRetirement
            sourceOuterTileMarkers.removeAll()
            invalidateWildTransports()
            sourceCallbackTime()
            retireSourceSpawns()
            if let previous=lastGeneration {sourceRegularContactCompanions?.retire(generation:previous);sourceFrames.retireGeneration(previous)}
            sourceGameplay.removeAll();sourceRegularHandoffMutationReceipts.removeAll();sourcePopulation.removeAll();sourceFrames.registerPopulation([]);sourceStars=nil
            if sourceFramesAttached {sourceFrames.newBoard(nowMs:sourceFrames.nowMs,configuredFPS:Double(view?.preferredFramesPerSecond ?? 60))}
            retireRegularSixPresentations()
            finishExit(completed: false)
            cancelEntry()
            removeAllActions(); retireEffects(); meterTimeoutIDs.removeAll();laserSpawnCallbacks.removeAll();cancelCandidate()
            textures.invalidatePendingPreparation()
            nodesByID.values.forEach { $0.dispose() }
            guard !sourceDisposalInProgress else {return}
            nodesByID.removeAll()
            hudStarFlights.removeAllChildren(); hudStarIDs.removeAll();hudStarNodes.removeAll(); hudStarVisualReceipts.removeAll()
            specialPresentationIDs.removeAll(); specialPresentationID = nil;directPresentationID=nil;directPresentationVariant=nil;directFinalReceipt=nil
            ordinaryAbsorbs.removeAll();ordinaryPostchecks.removeAll();ordinarySpawnVisuals.removeAll();ordinaryDeferred.removeAll();ordinaryPrimaryVisuals.removeAll();ordinarySixVisual=nil
            terminalPresentedGeneration = nil; inputAdmitted = !animateEntry
            pendingTerminal = nil; pendingTerminalGeneration = nil; visualLifetime += 1; visualOwners = 0
            navigationLocked = state.terminal != nil
            lastGeneration = state.generation; lastFrame = nil
        }
        if geometry == nil || geometry?.columns != state.columns || geometry?.rows != state.rows {
            geometry = NativeBoardGeometry(columns:state.columns,rows:state.rows,viewport:size,safeInsets:safeInsets)
        }
        guard let geometry else { return }
        engine.laserViewportWidth=Double(size.width)
        // Destroyed/detached captured source is a real interruption. Retire
        // that exact accepted-small receipt, not a replacement object, before
        // resynchronizing the atomic committed state. Pure pause keeps parent.
        if let invalid=sourceAcceptedStacks.values.first(where:{$0.plan.generation==state.generation && (nodesByID[$0.plan.source.id] !== $0.node || $0.node.parent !== canvasRoot || !$0.node.sourceContactNodeAlive || $0.node.sourceGeneration != state.generation)}) {
            invalid.owner.cancelAll()
            finishSourceAcceptedStack(invalid.plan.id,generation:invalid.plan.generation,interrupted:true)
            return // finalizer consumed/synchronized the fresh state already
        }
        if let invalid=sourceSixContacts.values.first(where:{entry in
            entry.generation==state.generation && (nodesByID[entry.source.tileID] !== entry.source ||
                nodesByID[entry.destination.tileID] !== entry.destination || entry.source.parent !== canvasRoot ||
                entry.destination.parent !== canvasRoot || !entry.source.sourceContactNodeAlive || !entry.destination.sourceContactNodeAlive)
        }) {
            invalid.capture?.capturedObjectRetired();retireSourceSixContact(invalid)
            return // captured cancellation published its fresh coherent state.
        }
        for entry in Array(sourceMagnetMainEntries.values) where !entry.retired && entry.capture?.phase != .entered {
            if !sourceMagnetMainNodeCurrent(entry.source,generation:entry.generation) || !sourceMagnetMainNodeCurrent(entry.destination,generation:entry.generation) {entry.capture?.capturedObjectRetired();retireSourceMagnetMainEntry(entry)}
        }
        let live = state.tiles.filter { (nodesByID[$0.id].map{sourceSixOwns($0,generation:state.generation) || sourceMagnetMainOwns($0)}==true) || sourceAcceptedStackOwns($0.id,generation:state.generation) || (!$0.pendingRemoval && $0.visible && $0.alpha > 0.01) }
        let sixRetainedIDs=Set(nodesByID.values.filter{sourceSixOwns($0,generation:state.generation) || sourceMagnetMainOwns($0)}.map(\.tileID))
        let liveIDs = Set(live.map(\.id)).union(sourceMeterCaller?.retainedNodeIDs ?? []).union(sixRetainedIDs)
        for id in Array(nodesByID.keys) where !liveIDs.contains(id) {
            if let node=nodesByID[id] {sourceMeterCaller?.remove(node)}
            if sourceMeterCaller != nil || sourceMeterTearingDown {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==state.generation else{return}}
            retireSourceSpawns(tileID:id)
            finishOrdinarySpawnVisual(id)
            finishWildSpawnVisual(id,interrupted:true)
            sourceStackFeedback.removeValue(forKey:id)?.dispose()
            sourcePopulation.remove(id);refreshSourceIdlePopulation()
            nodesByID.removeValue(forKey: id)?.dispose()
        }
        for tile in live {
            let node: NativeDiceNode
            if let existing = nodesByID[tile.id] {
                node = existing
                if sourceMagnetSourcePulls.values.contains(where:{$0.nodes[node.tileID] === node && sourceMagnetPullCurrent($0)}) {continue}
                if sourceMagnetSurvivorOwns(node) {continue}
                if sourceMagnetFallbackOwns(node) || sourceMagnetNormalOwns(node) {continue}
                if sourceSixOwns(node,generation:state.generation) || sourceMagnetMainOwns(node) {continue}
                if sourceMeterCaller?.owns(node)==true {sourceMeterCaller?.bind(node,cell:tile.cell,generation:state.generation);if sourceMeterCaller != nil || sourceMeterTearingDown {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==state.generation else{return}};continue}
                node.update(value: tile.value, kind: tile.gameplayArchetype?.rawValue ?? "regular", variant: tile.variant,
                            depth: tile.stackDepth, locked: tile.locked)
            } else {
                node = NativeDiceNode(id: tile.id, value: tile.value, kind: tile.gameplayArchetype?.rawValue ?? "regular",
                    variant: tile.variant, depth: tile.stackDepth, locked: tile.locked, textures: textures,sourceSpecialIdle:sourceIdleScope?.specialIdle)
                node.onResourceReady = { [weak self] in
                    guard let self, !self.disposed else { return }
                    self.onRenderingDemand?(!self.suspended)
                }
                nodesByID[tile.id] = node; canvasRoot.addChild(node)
            }
            if let sourceOuterTimelineDriver {
                node.installSourceOuterDriver(sourceOuterTimelineDriver,generation:state.generation,geometryScale:geometry.scale)
                if let sourceDragTweenDriver {node.installSourceDragTweenDriver(sourceDragTweenDriver)}
                if sourceInitialConstruction?.ownsHiddenInitialObject(node) != true {node.isHidden = !tile.visible} // initial hidden capture is exact-object-only.
            }
            if !entryInProgress || node.action(forKey: "entry") == nil {
                node.synchronizeSourceGeometry(geometry.scale)
                node.alpha = presentationAlpha(tile,state: state)
                if tile.id != draggedID && !node.sourceOuterOwners.snapBack && !sourceAcceptedStackOwns(tile.id,generation:state.generation) && !specialPresentationIDs.contains(tile.id) { node.position = geometry.center(row: tile.cell.row, column: tile.cell.column) }
            }
            if sourceOuterTimelineDriver == nil || (tile.id != draggedID && !sourceAcceptedStackOwns(tile.id,generation:state.generation)) {node.zPosition = tile.isWild ? 12001 : CGFloat(tile.cell.row * state.columns + tile.cell.column)}
            sourceMeterCaller?.bind(node,cell:tile.cell,generation:state.generation)
            if sourceMeterCaller != nil || sourceMeterTearingDown {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==state.generation else{return}}
            // Source admission is canonical Special identity, including assets
            // and phase waiting. Rendering readiness does not define population.
            if tile.gameplayArchetype != nil || tile.variant.flatMap({NativeSpecialDiceRegistry.variants[$0]}) != nil {sourcePopulation.insert(tile.id)}
            else {sourcePopulation.remove(tile.id)}
        }
        refreshSourceIdlePopulation()
        renderGhosts(state: state, geometry: geometry)
        score.text = String(state.score)
        comboNumber.text = String(state.combo)
        comboArt.texture = textures.texture(state.combo >= 10 ? "assets/hud/mega-combo-hud.png" : state.combo >= 5 ? "assets/hud/extra-combo-hud.png" : "assets/hud/combo-hud.png")
        roundIndicator.synchronize(round:state.stage,arcade:state.mode == .arcade,viewport:size,alpha:state.tutorial?.shouldLockHUD == true ? 0.2:1)
        layoutHUD()
        applyBoardShake(boardShake)
        for child in hud.children where child !== noMoves { child.alpha = state.tutorial?.shouldLockHUD == true ? 0.2 : 1 }
        if animateEntry && !UIAccessibility.isReduceMotionEnabled {
            animateBoardEntry(tiles: live,geometry: geometry)
        } else if !entryInProgress { inputAdmitted = state.terminal == nil && pendingTerminal == nil;roundIndicator.enter(animated:false) }
        if preparedEntryGeneration == state.generation {inputAdmitted=false;navigationLocked=true}
        publishFishIdleFrames(force:true)
    }

    private func presentationAlpha(_ tile: NativeTile,state: NativeBoardState) -> CGFloat {
        guard let tutorial = state.tutorial,tutorial.active,
              tutorial.step == .stack || tutorial.step == .mergeSix,
              !tutorial.guidedPair.contains(tile.id),!tile.isWild else { return CGFloat(tile.alpha) }
        return CGFloat(tile.alpha)*0.2
    }

    private func animateBoardEntry(tiles: [NativeTile],geometry: NativeBoardGeometry) {
        let targets = tiles.compactMap { nodesByID[$0.id] }
        if let initial=sourceInitialConstruction {initial.releaseToExistingNativeEntry();for node in targets {node.isHidden=false}}
        let positions = targets.map { CGPoint(x: $0.position.x,y: size.height-$0.position.y) }
        let plans = NativeBoardEntryPlan.make(positions: positions,maxOffset: geometry.tileSize*0.42)
        // The original empty owner resolves before installing midpoint work.
        guard !plans.isEmpty else {
            sourceCallbackTime()
            let empty=sourceFrames.begin(.init(kind:.boardPopIn,generation:engine.state.generation,id:UUID().uuidString))
            sourceFrames.end(empty)
            inputAdmitted=true;evaluate();return
        }
        entryInProgress = true; entryOwners = plans.count; inputAdmitted = false
        let generation = engine.state.generation
        sourceCallbackTime();sourcePopIn=sourceFrames.begin(.init(kind:.boardPopIn,generation:generation,id:UUID().uuidString))
        let receipt=hudEntryReveal.begin(generation:generation,tileCount:plans.count)
        hudEntryReceipt=receipt;isHUDRevealPending=true
        hud.removeAction(forKey:"hud-enter");hud.position.y=140;hud.alpha=0
        roundIndicator.primeEntry()
        let waveDuration=plans.map(\.end).max() ?? 0
        run(.sequence([.wait(forDuration:max(0.01,waveDuration*0.5)),.run { [weak self] in
            guard let self,!self.disposed,self.hudEntryReceipt==receipt,self.engine.state.generation==generation else{return}
            self.hudEntryReveal.midpoint(receipt)
        }]),withKey:"hud-midpoint")
        onBoardEntry?(waveDuration+0.03,NativeBoardEntryPlan.hapticBeats(plans))
        for plan in plans {
            let node = targets[plan.tileIndex]
            let rest = node.position, rotation = node.zRotation, alpha = node.alpha
            let start = CGPoint(x: rest.x+plan.offset.x,y: rest.y-plan.offset.y)
            node.position = start; node.zRotation = rotation-plan.rotation; node.setScale(0); node.alpha = 0
            node.run(.sequence([.wait(forDuration: plan.delay),.group([
                NativeBoardMotion.move(from: start,to: rest,duration: 0.42,ease: .backOut(1.7)),
                NativeBoardMotion.rotate(from: rotation-plan.rotation,to: rotation,duration: 0.42,ease: .backOut(1.7)),
                NativeBoardMotion.fade(from: 0,to: alpha,duration: 0.08,ease: .power2Out),
                NativeBoardMotion.enter(base: geometry.scale)
            ]),.run { [weak self,weak node] in
                guard let self,!self.disposed,self.entryInProgress,self.hudEntryReceipt==receipt,self.engine.state.generation == generation else { return }
                node?.position = rest; node?.zRotation = rotation; node?.setScale(geometry.scale)
                self.hudEntryReveal.tileCompleted(receipt)
                self.entryOwners = max(0,self.entryOwners-1)
                if self.entryOwners == 0 {self.scheduleEntryAdmission(receipt)}
            }]),withKey: "entry")
        }
    }

    private func scheduleEntryAdmission(_ receipt:NativeHUDEntryReveal.Receipt) {
        run(.sequence([.wait(forDuration:0.03),.run { [weak self] in
            guard let self,!self.disposed,self.entryInProgress,self.hudEntryReceipt==receipt,self.engine.state.generation==receipt.generation else{return}
            self.finishSourceEntry()
            self.entryInProgress=false;self.inputAdmitted=true;self.evaluate()
        }]),withKey:"entry-admission")
    }

    private func startHUDDrop(_ receipt:NativeHUDEntryReveal.Receipt) {
        guard !disposed,!exitInProgress,hudEntryReceipt==receipt,engine.state.generation==receipt.generation else{return}
        isHUDRevealPending=false
        hud.run(.sequence([.customAction(withDuration:NativeHUDTransitionMotion.dropDuration) { node,time in
            let pose=NativeHUDTransitionMotion.drop(at:Double(time))
            node.position.y=CGFloat(pose.offset);node.alpha=CGFloat(pose.alpha)
        },.run { [weak self] in
            guard let self,self.hudEntryReceipt==receipt,self.engine.state.generation==receipt.generation else{return}
            self.hud.position = .zero;self.hud.alpha=1
        }]),withKey:"hud-enter")
        roundIndicator.enter(animated:true);onHUDDrop?(receipt.generation)
    }

    private func cancelEntry(restoreHUD:Bool=true) {
        finishSourceEntry()
        if let receipt=hudEntryReceipt {hudEntryReveal.cancel(receipt)}
        hudEntryReceipt=nil;isHUDRevealPending=false
        removeAction(forKey:"hud-midpoint");hud.removeAction(forKey:"hud-enter")
        if restoreHUD {hud.position = .zero;hud.alpha=1;roundIndicator.cancelExit()}
        guard entryInProgress else { return }
        entryInProgress = false; entryOwners = 0; removeAction(forKey: "entry-admission")
        for node in nodesByID.values {
            node.removeAction(forKey: "entry"); node.zRotation = 0
            if let geometry { node.setScale(geometry.scale) }
        }
    }

    private func renderGhosts(state: NativeBoardState, geometry: NativeBoardGeometry) {
        ghosts.removeAllChildren()
        let occupied = Set(state.tiles.filter { !$0.pendingRemoval && $0.visible && $0.alpha > 0.01 }.map(\.cell))
        let texture = textures.texture("assets/tile.png")
        for row in 0..<state.rows {
            for column in 0..<state.columns where !occupied.contains(NativeCell(column: column, row: row)) {
                let ghost = SKSpriteNode(texture: texture)
                ghost.size = CGSize(width: geometry.tileSize, height: geometry.tileSize)
                ghost.alpha = 0.08; ghost.position = geometry.center(row: row, column: column)
                ghosts.addChild(ghost)
            }
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let binding=sourceMicrotaskInstallation {
            _=binding.inputTask{[self] in sourceTouchesBegan(touches,with:event)}
        } else {sourceTouchesBegan(touches,with:event)}
    }
    private func sourceTouchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !sourceDisposalInProgress else {return }
        guard !disposed,!touches.isEmpty else{return}
        sourceCallbackTime();sourceFrames.pointerBegan()
        guard !disposed, !suspended, activeTouch == nil, draggedID == nil, let touch = touches.first else { return }
        onRenderingDemand?(true)
        let point = touch.location(in: self)
        let canvasPoint=canvasRoot.convert(point,from:self)
        if closeButton?.hitRect.contains(canvasPoint)==true {
            guard inputAdmitted,!navigationLocked,engine.state.tutorial?.shouldLockHUD != true else{return}
            closeButton?.playTapBounce()
            onExitRequest?();return
        }
        if nodes(at:point).contains(where:{$0.name == "native-game-help"}) {
            guard inputAdmitted,!navigationLocked,engine.state.tutorial?.shouldLockHUD != true else {return}
            onHelpRequest?()
            return
        }
        if scoreHitRect.contains(canvasPoint) || comboHitRect.contains(canvasPoint) {
            guard inputAdmitted,!navigationLocked,engine.state.tutorial?.shouldLockHUD != true else { return }
            if comboHitRect.contains(canvasPoint) { onComboRequest?() } else { onScoreRequest?() }
            return
        }
        if beginDrag(at: point) { activeTouch = touch }
    }

    @discardableResult
    func beginDrag(at point: CGPoint) -> Bool {
        // Programmatic QA shares the existing callback domain; no new ticker.
        guard sourceAnimationBindingAdmissionOpen else{return false};sourceCallbackTime();sourceFrames.pointerBegan()
        let point=canvasRoot.convert(point,from:self)
        guard !disposed,!sourceOuterTearingDown, !suspended, !exitInProgress, draggedID == nil, inputAdmitted, let hit = geometry?.cell(at: point),
              let tile = engine.state.tile(at: NativeCell(column: hit.column, row: hit.row)),
              let node = nodesByID[tile.id],(!node.sourceOuterDriven || node.sourceEventMode == "static"), !sourceMagnetSurvivorEntries.values.contains(where:{$0.node === node && sourceMagnetSurvivorCurrent($0) && $0.owner?.inputBound != true}), engine.beginDrag(tileID: tile.id, pointerID: 1) else { return false }
        onRenderingDemand?(true)
        cancelCandidate()
        draggedID = tile.id; dragMoved = false; touchStart = point; lastTouchPoint = point
        lastPointerTime=CACurrentMediaTime();pointerVelocity = .zero
        fingerOffset = CGPoint(x: node.position.x - point.x, y: node.position.y - point.y)
        retireSourceSpawns(tileID:tile.id)
        finishOrdinarySpawnVisual(tile.id)
        finishWildSpawnVisual(tile.id,interrupted:true)
        sourceHeldOrigin=node.sourceOuterDriven ? SourceHeldOrigin(tileID:tile.id,generation:engine.state.generation,cell:tile.cell,position:node.position,zPosition:node.zPosition):nil
        if node.sourceOuterDriven {
            // Captured Source outer owner replaces only its own transform.
            // Exact spawn receipts were retired above; inner family cues survive.
            _ = node.beginSourcePickup()
        } else {node.removeAllActions();node.visual.removeAllActions()}
        node.zPosition = 18000
        node.setDragging(true,sourceOuterTransform:node.sourceOuterDriven)
        if node.sourceOuterDriven {sourceRegularContactCompanions?.pointerDown(node);node.sourcePointerDown()}
        publishFishIdleFrames(force:true)
        onPointerState?(true)
        onGameplayEvent?(NativeGameplayEvent(.dragBegan, tileIDs: [tile.id], archetype: tile.gameplayArchetype))
        return true
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let binding=sourceMicrotaskInstallation {
            _=binding.inputTask{[self] in sourceTouchesMoved(touches,with:event)}
        } else {sourceTouchesMoved(touches,with:event)}
    }
    private func sourceTouchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = activeTouch, touches.contains(touch) else { return }
        moveDrag(to: touch.location(in: self))
    }

    func moveDrag(to point: CGPoint,now:TimeInterval=CACurrentMediaTime()) {
        guard !sourceDisposalInProgress else {return }
        let point=canvasRoot.convert(point,from:self)
        guard let id = draggedID, let node = nodesByID[id] else { return }
        node.position = CGPoint(x: point.x + fingerOffset.x, y: point.y + fingerOffset.y)
        let milliseconds=max(1,(now-lastPointerTime)*1000)
        pointerVelocity.x+=((point.x-lastTouchPoint.x)/milliseconds-pointerVelocity.x)*0.10
        pointerVelocity.y+=((lastTouchPoint.y-point.y)/milliseconds-pointerVelocity.y)*0.10
        let scale=max(0.0001,geometry?.scale ?? 1)
        if hypot(point.x-touchStart.x,point.y-touchStart.y)/scale > 4 {dragMoved=true}
        node.updateIdleDrag(offset:CGPoint(x:(point.x-touchStart.x)/scale,y:(touchStart.y-point.y)/scale),velocity:pointerVelocity)
        lastPointerTime=now
        if node.sourceOuterDriven {node.sourcePointerMoved(filteredVelocity:pointerVelocity)}
        else {node.updateShadow(direction: CGPoint(x: point.x-lastTouchPoint.x, y: point.y-lastTouchPoint.y))}
        lastTouchPoint = point
        guard let geometry,let source=engine.state.tiles.first(where:{$0.id==id}),
              let target=dragTarget(source:source,pointer:nil) else {clearHover();return}
        if hoverTargetID != target.id {
            hoverTargetID = target.id; hover.isHidden = false
            let side = geometry.tileSize
            hover.path = CGPath(roundedRect: CGRect(x: -side/2,y: -side/2,width: side,height: side),
                                cornerWidth: 22*geometry.scale,cornerHeight: 22*geometry.scale,transform: nil)
            hover.lineWidth = 4*geometry.scale
            hover.position = geometry.center(row: target.cell.row,column: target.cell.column)
        }
    }

    private func dragTarget(source: NativeTile, pointer: CGPoint?) -> NativeTile? {
        guard let geometry else { return nil }
        // Special targeting remains with the existing owner until its full
        // authored footprint policy is independently admitted.
        guard !source.isWild, let node = nodesByID[source.id] else {
            let point = pointer ?? lastTouchPoint
            guard let hit = geometry.cell(at: point),
                  let tile = engine.state.tile(at: NativeCell(column:hit.column,row:hit.row)),
                  NativeGameplayResolver.canDrop(source,onto:tile),
                  NativeTutorialRules.allowsDrop(source:source,destination:tile,tutorial:engine.state.tutorial,rows:engine.state.rows) else { return nil }
            return tile
        }
        let candidates = engine.state.tiles.compactMap { tile -> NativeRegularDropTarget.Candidate? in
            guard tile.id != source.id, NativeGameplayResolver.canDrop(source,onto:tile),
                  NativeTutorialRules.allowsDrop(source:source,destination:tile,tutorial:engine.state.tutorial,rows:engine.state.rows),
                  let target = nodesByID[tile.id], !tile.transientSpawn else { return nil }
            let side=geometry.tileSize
            return .init(id:tile.id,bounds:target.calculateAccumulatedFrame(),
                         pointerBounds:CGRect(x:target.position.x-side/2,y:target.position.y-side/2,width:side,height:side))
        }
        let selected=NativeRegularDropTarget.pick(source:node.calculateAccumulatedFrame(),candidates:candidates,pointer:pointer,tileSize:geometry.tileSize)
        return selected.flatMap {id in engine.state.tiles.first {$0.id==id}}
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let binding=sourceMicrotaskInstallation {
            _=binding.inputTask{[self] in sourceTouchesEnded(touches,with:event)}
        } else {sourceTouchesEnded(touches,with:event)}
    }
    private func sourceTouchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        sourceCallbackTime();sourceFrames.pointerEnded()
        guard let touch = activeTouch, touches.contains(touch) else { return }
        finishDrag(at: touch.location(in: self), now: CACurrentMediaTime())
    }

    @discardableResult
    func finishDrag(at point: CGPoint, now: TimeInterval) -> NativeMoveResult? {
        guard !sourceDisposalInProgress else {return nil }
        sourceCallbackTime();sourceFrames.pointerEnded()
        guard !disposed,let id=draggedID else{return nil}
        // Accepted v9 interaction: consume the real release sample before lookup.
        let releasePoint=canvasRoot.convert(point,from:self)
        if releasePoint != lastTouchPoint {moveDrag(to:point,now:now)}
        let point=releasePoint,moved=dragMoved
        let tile=engine.state.tiles.first(where:{$0.id==id})
        let target=moved ? tile.flatMap{dragTarget(source:$0,pointer:point)?.cell}:nil
        let oldState = engine.state
        let heldOrigin=sourceHeldOrigin;sourceHeldOrigin=nil
        let source = nodesByID[id]
        let sourcePosition = source?.position
        let sourceVisual = sourceSameNodeStackAbsorbsEnabled ? nil:source?.detachedArtworkCarrier()
        activeTouch = nil; draggedID = nil; source?.setDragging(false,sourceOuterTransform:source?.sourceOuterDriven == true)
        if source?.sourceOuterDriven==true {
            source?.sourcePointerUp()
            if let heldOrigin,heldOrigin.tileID==id,heldOrigin.generation==engine.state.generation {source?.zPosition=heldOrigin.zPosition}
        }
        publishFishIdleFrames(force:true)
        onPointerState?(false)
        clearHover()
        // Reject unadmitted presentation BEFORE gameplay capture, value/score,
        // RNG or revision mutation. Full Six/direct80 waits its exact destructive
        // callback owner; never disguise a killed tween as arrival.
        if sourceSameNodeStackAbsorbsEnabled,(!sourceRegularStackHandoffEnabled || engine.pendingOrdinaryStack==nil),let sourceTile=oldState.tiles.first(where:{$0.id==id}),let target,let destinationTile=oldState.tile(at:target) {
            let bounded = (!sourceTile.isWild && !destinationTile.isWild && sourceTile.value+destinationTile.value<6) || sourceSixReady(source:sourceTile,destination:destinationTile,generation:oldState.generation) || sourceDirectReady(source:sourceTile,destination:destinationTile,generation:oldState.generation) || sourceMagnetMainReady(sourceTile,destinationTile,generation:oldState.generation)
            let handoffReady = !sourceRegularStackHandoffEnabled || (sourceStackDecisionMatches(oldState,source:sourceTile,destination:destinationTile) && nodesByID[destinationTile.id].map{sourceStackFrameReady($0,generation:oldState.generation)}==true)
            let ready = handoffReady && bounded && source?.sourceOuterDriven==true && sourceDragTweenDriver != nil && sourceContactVisualRandom != nil && !sourceOuterTearingDown && (sourceSixReady(source:sourceTile,destination:destinationTile,generation:oldState.generation) || sourceDirectReady(source:sourceTile,destination:destinationTile,generation:oldState.generation) || sourceMagnetMainReady(sourceTile,destinationTile,generation:oldState.generation) || sourceStackAbsorbAdmission?(sourceTile,destinationTile)==true) && !disposed && !sourceOuterTearingDown && sourceDragTweenDriver != nil && sourceContactVisualRandom != nil && source?.parent === canvasRoot && nodesByID[id] === source && source?.sourceContactNodeAlive==true && source?.sourceGeneration==oldState.generation && engine.state.generation==oldState.generation && (!sourceRegularStackHandoffEnabled || sourceStackDecisionMatches(oldState,source:sourceTile,destination:destinationTile))
            if !ready {
                if !sourceRegularStackHandoffEnabled || (engine.state.generation==oldState.generation && engine.state.revision==oldState.revision) {engine.cancelDrag()}
                let rejection=NativeMoveResult(accepted:false,state:engine.state,events:[NativeGameplayEvent(.blocked,tileIDs:[id],reason:"source_same_node_absorb_not_admitted")],resolution:engine.resolve())
                if let source,let heldOrigin,(!sourceRegularStackHandoffEnabled || (engine.state.generation==oldState.generation && source.sourceGeneration==oldState.generation && nodesByID[id] === source && source.parent === canvasRoot)) {
                    let generation=engine.state.generation
                    _ = source.beginSourceReturn(to:heldOrigin.position,onCompleted:{[weak self,weak source] in guard let self,!self.disposed,self.engine.state.generation==generation else{return};source?.sourceSnapBackCompleted()})
                }
                consume(rejection,previous:oldState,preserveRejectedPosition:id);return rejection
            }
        }
        let preDebitEpoch=sourceOrdinaryPreDebitEpoch
        var preDebitContact:SourcePreDebitContact?
        if sourceOrdinaryPreDebitPresentationEnabled,let target,
            let srcModel=oldState.tiles.first(where:{$0.id==id}),let dstModel=oldState.tiles.first(where:{$0.cell==target}),
            !srcModel.isWild,!dstModel.isWild,srcModel.value+dstModel.value<6 {
            guard let contact=captureSourcePreDebitContact(sourceID:id,destinationID:dstModel.id,generation:oldState.generation),
                sourceAnimationBindingAdmissionOpen,sourceOrdinaryPreDebitEpoch==preDebitEpoch,
                engine.state==oldState,sourceOrdinaryPreDebitPresentationEnabled else {
                let rejected=NativeMoveResult(accepted:false,state:engine.state,events:[.init(.blocked,tileIDs:[id],reason:"source_predebit_contact_not_admitted")],resolution:engine.resolve())
                if engine.state.generation==oldState.generation {engine.cancelDrag()}
                return rejected
            }
            preDebitContact=contact
        }
        let result = engine.drop(target: target, pointerID: 1, now: now)
        if result.accepted,let contact=preDebitContact,sourceOrdinaryPreDebitEpoch==preDebitEpoch,
            sourceAnimationBindingAdmissionOpen,let plan=engine.pendingOrdinaryStack,
            plan.source.id==id,plan.destination.id==contact.destination.tileID,plan.generation==contact.generation {
            sourcePreDebitContacts[plan.id]=contact
        }
        if let transactions=sourceSpecialTransactions {
            if result.accepted {_ = transactions.acceptedContact(result,direct:engine.pendingDirectWild,special:engine.pendingSpecial)}
            else {transactions.rejectedContact()}
        }
        if !result.accepted {
            if let tile = oldState.tiles.first(where: { $0.id == id }), let geometry, let source {
                let captured=heldOrigin
                let destination = source.sourceOuterDriven && captured?.tileID==id && captured?.generation==engine.state.generation ? captured!.position:geometry.center(row: tile.cell.row, column: tile.cell.column)
                if source.sourceOuterDriven {
                    let generation=engine.state.generation
                    _ = source.beginSourceReturn(to:destination,onCompleted:{[weak self,weak source] in
                        guard let self,!self.disposed,self.engine.state.generation==generation else{return}
                        source?.sourceSnapBackCompleted();source?.resumeIdleAfterLanding()
                    })
                } else {
                let action = NativeBoardMotion.move(from: source.position, to: destination, duration: 0.18, ease: .backOut(1.65))
                source.run(action, withKey: "snapback")
                let generation=engine.state.generation
                source.visual.run(.sequence([NativeBoardMotion.rejectedLanding(),.run { [weak self,weak source] in
                    guard let self,self.engine.state.generation==generation,!self.disposed else {return}
                    source?.resumeIdleAfterLanding()
                }]),withKey:"rejected-landing")
                }
            }
            consume(result, previous: oldState, preserveRejectedPosition: id)
        } else {
            if sourceMagnetMainScope != nil,let plan=engine.pendingSpecial,plan.archetype == .magnet,plan.source.id==id {
                if !startSourceMagnetMain(plan,result:result,previous:oldState) {onPresentationFailure?("source_magnet_main80_setup_failed")}
                return result
            }
            if sourceDirectWildSameNodeEnabled,let plan=engine.pendingDirectWild,plan.source.id==id {
                if !startSourceDirectContact(plan,result:result,previous:oldState) {onPresentationFailure?("source_direct_main_setup_failed")}
                return result
            }
            if sourceOrdinarySixSameNodeEnabled,let plan=engine.pendingOrdinarySix,plan.source.id==id {
                if !startSourceSixContact(plan,result:result,previous:oldState) {onPresentationFailure?("source_six_main_setup_failed")}
                return result
            }
            // Literal v9 ordinary sub-six disables only the consumed source.
            // Main-six eventMode is not inferred from this branch.
            if source?.sourceOuterDriven==true,engine.pendingOrdinaryStack?.source.id==id {source?.sourceEventMode="none"}
            if sourceSameNodeStackAbsorbsEnabled,let source,let driver=sourceDragTweenDriver,let plan=engine.pendingOrdinaryStack,plan.source.id==id,
               let destination=nodesByID[plan.destination.id] {
                let owner=NativeSourceAcceptedAbsorbOwner(host:source,driver:driver),receipt=beginVisual()
                sourceAcceptedStacks[plan.id]=SourceAcceptedStack(plan:plan,node:source,owner:owner,visual:receipt)
                ordinaryAbsorbs[plan.id]=(source,receipt)
                let ready=owner.begin(destination:destination.position,onAutoScaleInitialize:{[weak source] in source?.killSourceActiveScaleChildren()},onBeforeMainRegistration:{[weak self,weak source] in
                    self?.consume(result,previous:oldState)
                    guard let self,let source,self.sourceAnimationBindingAdmissionOpen,
                        self.engine.state.generation==plan.generation,self.nodesByID[id] === source,
                        source.parent === self.canvasRoot,source.sourceContactNodeAlive,
                        source.sourceGeneration==plan.generation,self.sourceSameNodeStackAbsorbsEnabled else{return}
                    // Actual literal <6 contact, not a generic merged observer.
                    _=self.sourceCanonicalSaveBinding?.notify(.ordinarySubSixContact)
                },isCurrent:{[weak self,weak source] in
                    guard let self,let source else{return false};return !self.disposed && self.engine.state.generation==plan.generation && self.nodesByID[id] === source && source.parent === self.canvasRoot && source.sourceContactNodeAlive && source.sourceGeneration==plan.generation
                },onMainCompleted:{[weak self] in self?.finishSourceAcceptedStack(plan.id,generation:plan.generation,interrupted:false)},onMainInterrupted:{[weak self] in self?.finishSourceAcceptedStack(plan.id,generation:plan.generation,interrupted:true)})
                if !ready {finishSourceAcceptedStack(plan.id,generation:plan.generation,interrupted:true);onPresentationFailure?("source_same_node_absorb_setup_failed")}
                return result
            }
            if let sourceVisual, let sourcePosition, let target, let geometry {
                sourceVisual.removeAllActions()
                sourceVisual.position = sourcePosition; sourceVisual.setScale(geometry.scale)
                sourceVisual.zPosition = 18000; effects.addChild(sourceVisual)
                let receipt = beginVisual()
                let destination = geometry.center(row: target.row,column: target.column)
                let ordinaryPlan=[engine.pendingOrdinaryStack,engine.pendingOrdinarySix].compactMap {$0}.first {$0.source.id==id}
                if let ordinaryPlan {ordinaryAbsorbs[ordinaryPlan.id]=(sourceVisual,receipt)}
                let directPlan=engine.pendingDirectWild.flatMap {$0.source.id==id ? $0:nil}
                sourceVisual.run(.sequence([NativeBoardMotion.move(from: sourcePosition,to: destination,duration: 0.08,ease: .power2Out),
                    .run { [weak self] in
                        if let ordinaryPlan {self?.finishOrdinaryAbsorb(ordinaryPlan)}
                        if let directPlan {self?.finishDirectWildAbsorb(directPlan)}
                        self?.finishVisual(receipt)
                    }, .removeFromParent()]))
            }
            consume(result, previous: oldState)
        }
        return result
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let binding=sourceMicrotaskInstallation {
            _=binding.inputTask{[self] in sourceTouchesCancelled(touches,with:event)}
        } else {sourceTouchesCancelled(touches,with:event)}
    }
    private func sourceTouchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        sourceCallbackTime();sourceFrames.pointerEnded()
        if let touch = activeTouch,touches.contains(touch) {cancelDrag(pointerCancelled:true);evaluate()}
    }

    func cancelDrag(pointerCancelled:Bool=false) {
        sourceCallbackTime();sourceFrames.pointerEnded()
        let id=draggedID,held=sourceHeldOrigin;sourceHeldOrigin=nil
        activeTouch=nil;draggedID=nil
        let matchingSourceGeneration = sourceDisposalGeneration == nil || sourceDisposalGeneration == engine.state.generation
        if matchingSourceGeneration {engine.cancelDrag()}
        if id != nil {onPointerState?(false)}
        clearHover()
        // onPointerState is external and can restart the shared engine. The
        // captured pre-callback permit cannot authorize painting a new run.
        if matchingSourceGeneration,(sourceDisposalGeneration == nil || sourceDisposalGeneration == engine.state.generation),let id,let node=nodesByID[id],let tile=engine.state.tiles.first(where:{$0.id==id}),let geometry {
            node.setDragging(false,sourceOuterTransform:node.sourceOuterDriven)
            node.zPosition=node.sourceOuterDriven && held?.tileID==id && held?.generation==engine.state.generation ? held!.zPosition:(tile.isWild ? 12001:CGFloat(tile.cell.row*engine.state.columns+tile.cell.column))
            if node.sourceOuterDriven {
                // Literal cancelActive/cleanup clears pointer/family ownership
                // without a new position/scale/shadow return. Pure pause never
                // calls this destructive path. UIKit pointercancel is onCancel.
                if pointerCancelled,let held,held.tileID==id,held.generation==engine.state.generation {
                    let generation=held.generation
                    _ = node.beginSourceReturn(to:held.position,onCompleted:{[weak self,weak node] in
                        guard let self,!self.disposed,self.engine.state.generation==generation else{return}
                        node?.sourceSnapBackCompleted();node?.resumeIdleAfterLanding()
                    })
                }
            } else {
                node.removeAllActions();node.position=geometry.center(row:tile.cell.row,column:tile.cell.column)
            }
        }
        publishFishIdleFrames(force:true)
    }

    func prepareFishMedia(tileID:String,generation:UInt64) {
        guard !disposed,engine.state.generation==generation else {return}
        nodesByID[tileID]?.prepareFishMediaPhase();publishFishIdleFrames(force:true)
    }
    func setFishMediaReady(tileID:String,generation:UInt64,ready:Bool) {
        guard !disposed,engine.state.generation==generation else {return}
        nodesByID[tileID]?.setFishMediaReady(ready);publishFishIdleFrames(force:true)
    }
    private func publishFishIdleFrames(force:Bool=false) {
        guard !sourceDisposalInProgress else {return}
        guard !disposed else {return}
        var frames:[String:NativeFishIdleFrame]=[:]
        for (id,node) in nodesByID {
            if let frame=node.fishFrame(in:self,visible:view != nil && !suspended && !exitInProgress && engine.state.terminal==nil && !specialPresentationIDs.contains(id)) {frames[id]=frame}
        }
        onFishIdleFrames?(frames,engine.state.generation,force)
    }

    private func clearHover() {
        guard hoverTargetID != nil || !hover.isHidden else { return }
        hoverTargetID = nil; hover.isHidden = true
    }

    private func consume(_ result: NativeMoveResult, previous: NativeBoardState, preserveRejectedPosition: String? = nil) {
        guard !sourceDisposalInProgress else {return}
        cancelCandidate()
        let rejectedPosition = preserveRejectedPosition.flatMap { nodesByID[$0]?.position }
        sourceMeterQueue?.receive(result)
        if sourceMeterQueue != nil {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==result.state.generation else{return}}
        sourceMeterCaller?.receive(result)
        if sourceMeterCaller != nil || sourceMeterTearingDown {guard sourceAnimationBindingAdmissionOpen,engine.state.generation==result.state.generation else{return}}
        // Literal setValue schedules ONE actual RAF before contact. Its immediate
        // value is visible now; old stack objects/depth remain until that callback.
        if sourceRegularStackHandoffEnabled,sourceSameNodeStackAbsorbsEnabled {
            for event in result.events where event.kind == .merged && event.archetype==nil && (event.value ?? 6)<6 {
                guard let sourceID=event.tileIDs.first,sourceAcceptedStackOwns(sourceID,generation:previous.generation),let destinationID=event.tileIDs.dropFirst().first,let target=nodesByID[destinationID],let source=previous.tiles.first(where:{$0.id==sourceID}),let value=event.value,let service=sourceStackFrameService,let random=sourceContactVisualRandom,sourceStackFrameReady(target,generation:previous.generation) else{continue}
                let generation=previous.generation
                let face = sourceStackCoreFaceReceiptsEnabled ? engine.pendingSourceOrdinaryStackFaces.first(where:{$0.ordinaryMoveID==engine.pendingOrdinaryStack?.id && $0.destinationID==destinationID && $0.generation==generation}):nil
                if sourceStackCoreFaceReceiptsEnabled && face==nil {onPresentationFailure?("source_core_face_receipt_missing");return}
                var observation:(NativeMoveResult,NativeBoardState)?
                let physical:(()->Bool)? = face.map {face in { [weak self,weak target] in
                    guard let self,let target,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==generation,self.nodesByID[destinationID] === target,target.parent === self.canvasRoot,target.sourceGeneration==generation else{return false}
                    let before=self.engine.state,result=self.engine.commitSourceOrdinaryStackFace(receiptID:face.id,generation:generation)
                    if result.accepted {observation=(result,before)}
                    return result.accepted
                }}
                let finished:(()->Void)? = face.map { _ in { [weak self,weak target] in
                    guard let self,let target,self.sourceAnimationBindingAdmissionOpen,self.engine.state.generation==generation,self.nodesByID[destinationID] === target,target.parent === self.canvasRoot,let captured=observation else{return}
                    observation=nil
                    self.consume(captured.0,previous:captured.1)
                    self.resumeSourceFacePostchecks(generation:generation)
                }}
                let cancelled:(()->Void)? = face.map {face in { [weak self] in
                    guard let self,self.engine.state.generation==generation else{return}
                    _=self.engine.cancelSourceOrdinaryStackFace(receiptID:face.id,generation:generation)
                }}
                let admitted=target.queueSourceStackValue(value,addStack:source.stackDepth,service:service,random:random,current:{[weak self,weak target,weak service] in
                    guard let self,let target,let service else{return false}
                    return self.sourceAnimationBindingAdmissionOpen && self.sourceStackFrameService === service && service.sourceFrameTransportAdmissionOpen && self.engine.state.generation==generation && self.nodesByID[destinationID] === target && target.parent === self.canvasRoot && target.sourceGeneration==generation
                },onPhysicalCommit:physical,onFinished:finished,onCancelled:cancelled)
                if !admitted {onPresentationFailure?("source_stack_face_frame_not_admitted")}
                guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation else{return}
            }
        }
        synchronize()
        if let id = preserveRejectedPosition, let rejectedPosition { nodesByID[id]?.position = rejectedPosition }
        for event in result.events {
            guard !sourceDisposalInProgress else {return}
            // Internal Source request dispatches before generic event observers;
            // actual active token +Date must precede prepare scheduling. This
            // request itself is never a Date/ownership capability.
            if event.kind == .sourceOrdinarySixSpawnOwnerBeginRequested {
                let selected=sourceOrdinarySixSpawnScope,epoch=sourceEndgameMutationEpoch
                guard acceptSourceOrdinarySixSpawnBegin(event:event,generation:result.state.generation) else {
                    if sourceAnimationBindingAdmissionOpen,sourceOrdinarySixSpawnScope === selected,selected?.current==true,
                        sourceEndgameMutationEpoch==epoch,engine.state.generation==result.state.generation {
                        onPresentationFailure?("source_ordinary_spawn_owner_begin_refused")
                    }
                    return
                }
                continue
            }
            if event.kind == .specialBoardCommitted,let id=event.reason,let entry=sourceMagnetMainEntries[id] {retireSourceMagnetMainEntry(entry)}
            let deferSourceContactAudio=sourceRegularContactCompanions != nil && sourceSameNodeStackAbsorbsEnabled && event.kind == .merged && event.archetype==nil && (event.value ?? 6)<6 && event.tileIDs.first.map{sourceAcceptedStackOwns($0,generation:previous.generation)}==true
            if !deferSourceContactAudio {onGameplayEvent?(event)}
            guard !sourceDisposalInProgress else {return}
            let source = event.tileIDs.first.flatMap { id in previous.tiles.first { $0.id == id } }
            let destination = event.tileIDs.dropFirst().first.flatMap { id in previous.tiles.first { $0.id == id } }
            if !deferSourceContactAudio {onGameplayReceipt?(event,source,destination,previous.generation)}
            guard !sourceDisposalInProgress else {return}
            switch event.kind {
            case .sourceOrdinarySixSpawnOwnerBeginRequested:break
            case .ordinarySpawnsPrepareRequested:
                if let plan=engine.pendingOrdinarySix,event.reason==plan.id {
                    scheduleOrdinaryCommand(key:"prepare:"+plan.id,generation:plan.generation,delay:Double(event.value ?? 50)/1000) { [weak self] in
                        guard let self else {return}
                        let previous=self.engine.state
                        self.consume(self.engine.prepareOrdinarySpawns(receiptID:plan.id,generation:plan.generation),previous:previous)
                        self.releaseOrdinarySixIfReady()
                    }
                }
            case .ordinaryAssignmentsPrepared:
                startOrdinaryAssignments(ids:event.tileIDs)
            case .ordinaryDestinationCleanupPrepared:
                if let plan=engine.pendingOrdinarySix,event.reason==plan.id {
                    scheduleOrdinaryCommand(key:"cleanup:"+plan.id,generation:plan.generation,delay:Double(event.value ?? 100)/1000) { [weak self] in
                        guard let self,self.engine.pendingOrdinaryDestinationCleanup?.id == plan.id else {return}
                        let previous=self.engine.state
                        self.consume(self.engine.commitOrdinaryDestinationCleanup(receiptID:plan.id,generation:plan.generation),previous:previous)
                        self.releaseOrdinarySixIfReady()
                    }
                }
            case .ordinaryStackReserved:
                if let plan=engine.pendingOrdinaryStack {beginSourceGameplay(.regularMergeHandoff,id:plan.id,generation:plan.generation)}
            case .ordinarySixReserved:
                if let plan=engine.pendingOrdinarySix,ordinarySixVisual==nil {
                    beginSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)
                    ordinarySixVisual=OrdinarySixVisual(id:plan.id,generation:plan.generation,receipt:beginVisual())
                    if sourceSixContacts[plan.id] != nil {
                        if !playSourceSixHeroAndFace(plan) {sourceSixContacts[plan.id]?.capture?.capturedObjectRetired();onPresentationFailure?("source_six_prefix_setup_failed")}
                    } else {playRegularSixHero(plan)}
                }
            case .ordinaryPostcheckPrepared:
                if let id=event.reason {startOrdinaryPostcheck(id:id)}
            case .merged:
                let regularSix=event.value==6 && event.reason==engine.pendingOrdinarySix?.id
                let sourceStackContact=sourceSameNodeStackAbsorbsEnabled && event.archetype==nil && (event.value ?? 6)<6 && event.tileIDs.first.map{sourceAcceptedStackOwns($0,generation:previous.generation)}==true
                let sourceDirectContact=engine.pendingDirectWild.map{sourceSixContacts[$0.id]?.directPlan != nil}==true
                for id in event.tileIDs {retireSourceSpawns(tileID:id);finishOrdinarySpawnVisual(id);finishWildSpawnVisual(id,interrupted:true);if !regularSix && !sourceStackContact && !sourceDirectContact && nodesByID[id].map{!sourceMagnetMainOwns($0)} != false {nodesByID[id]?.stackFeedback()}}
                if sourceStackContact,let destinationID=event.tileIDs.dropFirst().first,let target=nodesByID[destinationID],let random=sourceContactVisualRandom {
                    // Exact Source contact consumes variant THEN variation, before
                    // neighbour recoil/smoke. Their shared RNG/callsite remain
                    // separately admitted; no fallback Double.random here.
                    let capturedGeneration=previous.generation
                    if let companions=sourceRegularContactCompanions,let sourceID=event.tileIDs.first,let sourceNode=nodesByID[sourceID] {
                        guard companions.prefix(destination:target,generation:capturedGeneration),!disposed,engine.state.generation==capturedGeneration else{onPresentationFailure?("source_stack_click_setup_failed");continue}
                        let motion=NativeMergeImpactMotion(variantDraw:random(),variationDraw:random())
                        guard target.beginSourceMergeImpact(motion),!disposed,engine.state.generation==capturedGeneration,let geometry else{onPresentationFailure?("source_stack_impact_setup_failed");continue}
                        guard companions.suffix(source:sourceNode,destination:target,tiles:engine.state.tiles,nodes:nodesByID,destroyedTileIDs:Set(engine.noMovesTileRuntime.compactMap{ $0.value.destroyed ? $0.key:nil }),canvas:canvasRoot,generation:capturedGeneration,tileSize:geometry.tileSize,renderScale:geometry.scale,reduced:sourceFrames.reducedFx,current:{[weak self,weak target] generation in
                            guard let self,let target else{return false};return !self.disposed && self.engine.state.generation==generation && self.nodesByID[target.tileID] === target && target.parent === self.canvasRoot
                        }) else{onPresentationFailure?("source_stack_suffix_setup_failed");continue}
                        // Literal v9 playOrdinaryStackSound8325 follows the full
                        // contact owner; deliver the existing semantic event once.
                        if deferSourceContactAudio {onGameplayEvent?(event);onGameplayReceipt?(event,source,destination,capturedGeneration)}
                        if sourceRegularStackHandoffEnabled {
                            // Original8325 authored audio precedes OLD-child overlays,
                            // alternating rotation and delayed fade. Capture exact target.
                            guard sourceAnimationBindingAdmissionOpen,engine.state.generation==capturedGeneration,nodesByID[destinationID] === target,target.parent === canvasRoot,let source,let service=sourceStackFrameService,service.sourceFrameTransportAdmissionOpen else{return}
                            let feedback:NativeRegularStackFeedbackNodeBridge
                            if let existing=sourceStackFeedback[destinationID] {feedback=existing}
                            else {
                                feedback=NativeRegularStackFeedbackNodeBridge(tile:target,service:service,current:{[weak self,weak target,weak service] in
                                    guard let self,let target,let service else{return false}
                                    return self.sourceAnimationBindingAdmissionOpen && self.sourceStackFrameService === service && self.engine.state.generation==capturedGeneration && self.nodesByID[destinationID] === target && target.parent === self.canvasRoot
                                });sourceStackFeedback[destinationID]=feedback
                            }
                            if !feedback.play(sourceDepth:source.stackDepth,random:random) {onPresentationFailure?("source_stack_old_feedback_not_admitted")}
                            guard sourceAnimationBindingAdmissionOpen,engine.state.generation==capturedGeneration else{return}
                        }
                    } else {
                        // Retained bounded component-test seam, not full product
                        // admission; parent must configure real companions.
                        if let sourceID=event.tileIDs.first,let source=nodesByID[sourceID] {onSourceStackContactPrefix?(source,target,random)}
                        let motion=NativeMergeImpactMotion(variantDraw:random(),variationDraw:random())
                        if !target.beginSourceMergeImpact(motion) {onPresentationFailure?("source_stack_impact_setup_failed")}
                        if let sourceID=event.tileIDs.first,let source=nodesByID[sourceID] {onSourceStackContactSuffix?(source,target,random)}
                    }
                }
                if regularSix,let plan=engine.pendingOrdinarySix {
                    if sourceSixContacts[plan.id] != nil {if !playSourceSixMain(plan) {onPresentationFailure?("source_six_main_visual_not_admitted")}}
                    else {playRegularSixMain(plan)}
                }
                else if event.value == 6 && engine.pendingSpecial == nil {
                    let tile = event.tileIDs.reversed().compactMap { id in previous.tiles.first { $0.id == id } }.first
                    let carrier = event.tileIDs.compactMap { id in previous.tiles.first { $0.id == id } }.first { $0.isWild }
                    if let variant = event.variant,["fish","bottle","honey","spaceship","laser-gun","flower","barell","beach-ball","kanta","bee","cubero","mushroom","robo-cube"].contains(variant),let tile,let geometry,
                       authoredFinale(variant,at: geometry.center(row: tile.cell.row,column: tile.cell.column)) {
                        // Native media/glyph owner holds its own visible receipt.
                    } else if event.archetype == .tnt && carrier?.variant == nil {
                        coreTntFinale()
                    } else if event.archetype == .star && carrier?.variant == nil {
                        coreStarFinale()
                    } else if event.archetype == .juice && carrier?.variant == nil {
                        coreJuiceFinale()
                    } else if let tile, let geometry {
                        smoke(at: geometry.center(row: tile.cell.row, column: tile.cell.column), special: event.archetype != nil)
                    }
                }
            case .mergeSixAbsorbInterrupted:
                if let id=event.reason {sourceSpecialTransactions?.absorbInterrupted(id:id,generation:previous.generation)}
            case .directWildReserved:
                if let plan=engine.pendingDirectWild {
                    wildSourceResolution=(plan.id,plan.generation)
                    beginSourceGameplay(.mergeSixResolution,id:plan.id,generation:plan.generation)
                    if sourceSixContacts[plan.id]?.directPlan != nil {
                        if !prepareSourceDirectPrefix(plan) {sourceSixContacts[plan.id]?.capture?.capturedObjectRetired();onPresentationFailure?("source_direct_prefix_setup_failed")}
                    } else {playDirectWild(plan)}
                }
            case .wildSpawnActionsPrepared:
                startWildSpawnActions(ids:event.tileIDs)
            case .wildLockedBonusPrepared:
                startWildLockedBonus(ids:event.tileIDs)
            case .wildRecoveryCheckPrepared:
                if let id=event.reason {startWildRecoveryCheck(id:id)}
            case .meterRewardPrepared:
                startMeterRewards(ids: event.tileIDs)
            case .hudStarsPrepared:
                startHUDStarFlights(ids: event.tileIDs,lead: event.archetype == .magnet && engine.pendingSpecial != nil ? 0.2 : 0)
            case .specialReserved:
                if let plan = engine.pendingSpecial { playReservedSpecial(plan) }
            case .specialImpact:
                var paintedIDs=Set<String>()
                for id in event.tileIDs where paintedIDs.insert(id).inserted { if let node = nodesByID[id] {
                    node.visual.setScale(0.30)
                    if let completed=laserSpawnCallbacks.removeValue(forKey:id) {
                        runSourceSpawn(node,key:"special-impact-spawn",postDelay:0.05,completion:completed)
                    } else {runSourceSpawn(node,key:"special-impact-spawn")}
                } }
            case .spawned:
                if sourceMagnetSurvivorOwnsSpawn(event) || sourceMagnetFallbackCallers.values.contains(where:{$0.ownsSpawnEvent(event)}) || sourceMagnetNormalCallers.values.contains(where:{$0.ownsSpawnEvent(event)}) {continue}
                for id in event.tileIDs {
                    guard let node=nodesByID[id] else {continue}
                    if engine.pendingWildLockedBonusPresentations.contains(where:{$0.tileID==id && $0.generation==engine.state.generation}) && event.value==0 {continue}
                    if let presentation=engine.pendingWildSpawnPresentations.first(where:{$0.tileID==id && $0.generation==engine.state.generation}) {
                        startWildSpawnVisual(presentation,node:node,actionID:event.reason ?? presentation.tileID)
                        continue
                    }
                    if let actionID=event.reason,wildScheduledActionIDs.contains(actionID) {
                        // A source fallback value assignment without a bounce
                        // receipt is plain logical normalization, never generic FX.
                        finishWildSpawnVisual(id,interrupted:true)
                        node.visual.setScale(1);node.visual.zRotation=0
                        continue
                    }
                    node.visual.setScale(0.30)
                    if let ordinary=ordinarySixVisual,ordinary.committed,
                       event.reason != nil || ordinary.consuming {
                        if engine.pendingOrdinarySpawns.contains(id) {
                            _ = engine.commitOrdinarySpawnArrival(receiptID:ordinary.id,generation:ordinary.generation,tileID:id)
                        }
                        finishOrdinarySpawnVisual(id)
                        ordinarySpawnVisuals[id]=beginVisual()
                        if let primary=engine.pendingOrdinaryPrimaryArrival,primary.id==event.reason {
                            ordinaryPrimaryVisuals[id]=(ordinary.id,primary.id,primary.generation)
                        }
                        let isLevelFlow=event.reason.map{sourceLockedBounceActionIDs.contains($0)} ?? false
                        runSourceSpawn(node,key:"spawn",completion:{ [weak self,weak node] in
                            guard let self,self.engine.state.generation==ordinary.generation else {return}
                            if isLevelFlow,let node {self.completeSourceLevelFlowBounce(node,generation:ordinary.generation)}
                            self.finishOrdinarySpawnVisual(id,interrupted:false)
                        })
                    } else {node.visual.run(NativeBoardMotion.spawnBounce(),withKey:"spawn")}
                }
            default: break
            }
        }
        guard !sourceDisposalInProgress else {return}
        onStateChange?(engine.state)
        guard !sourceDisposalInProgress else {return}
        handleResolution(result.resolution)
    }

    func evaluate() {
        guard !sourceDisposalInProgress,!disposed else{return}
        let result=engine.resolve()
        if result.kind == .fail,engine.state.terminal==nil,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves {
            _=beginSourceNoMovesFromLevelEndCaller()
        }
        guard !sourceDisposalInProgress,!disposed else{return}
        handleResolution(result)
    }

    private func finishSourceAcceptedStack(_ id:String,generation:UInt64,interrupted:Bool) {
        guard let captured=sourceAcceptedStacks[id],captured.plan.generation==generation else{return}
        sourceAcceptedStacks.removeValue(forKey:id) // retire before logical reentry
        if !disposed,engine.state.generation==generation,engine.pendingOrdinaryStack?.id==id {
            if interrupted {
                sourcePreDebitContacts.removeValue(forKey:id);sourcePreDebitMain.removeValue(forKey:id)
                ordinaryAbsorbs.removeValue(forKey:id)
                let previous=engine.state
                consume(engine.finishOrdinaryStackAbsorb(receiptID:id,generation:generation,interrupted:true),previous:previous)
                finishSourceGameplay(.regularMergeHandoff,id:id,generation:generation)
            } else {
                // Canonical source delivery is authoritative even if an earlier
                // captured lazy callback just paused the global timeline.
                ordinaryAbsorbs.removeValue(forKey:id)
                captureSourcePreDebitMain(id:id,generation:generation)
                let preDebitEpoch=sourceOrdinaryPreDebitEpoch,preDebitEndpoint=sourceOrdinaryPreDebitAdmission
                let deferred=sourceOrdinaryPreDebitPresentationEnabled && sourcePreDebitMain[id] != nil
                if deferred {sourcePreDebitDeferredMain.insert(id)}
                let previous=engine.state
                // consume performs the actual captured source removal / destination
                // normalization. The postcheck event is held until Source release.
                consume(engine.finishOrdinaryStackAbsorb(receiptID:id,generation:generation),previous:previous)
                finishSourceGameplay(.regularMergeHandoff,id:id,generation:generation)
                // Literal finalizeRegularMergeBoardCommit releases frames/idle
                // before pre-debit busy query and the one genuine app-wall100.
                if deferred,sourcePreDebitDeferredMain.remove(id) != nil,
                    sourceAnimationBindingAdmissionOpen,engine.state.generation==generation,
                    sourceOrdinaryPreDebitEpoch==preDebitEpoch,sourceOrdinaryPreDebitAdmission === preDebitEndpoint,
                    sourcePreDebitMain[id] != nil {startOrdinaryPostcheck(id:id)}
            }
        }
        finishVisual(captured.visual)
    }
    private func retireSourceAcceptedStacks() {
        sourceOuterTearingDown=true
        let captured=Array(sourceAcceptedStacks.values)
        for stack in captured {
            stack.owner.cancelAll()
            // Contact acquisition can destroy Scene before main registration;
            // accepted ordinary atomic finalizer still owns its captured state.
            finishSourceAcceptedStack(stack.plan.id,generation:stack.plan.generation,interrupted:true)
        }
        sourceAcceptedStacks.removeAll()
    }

    private func finishOrdinaryAbsorb(_ plan:NativeOrdinaryMovePlan) {
        guard !disposed,!suspended,engine.state.generation==plan.generation,
              ordinaryAbsorbs.removeValue(forKey:plan.id) != nil else {return}
        let previous=engine.state
        if engine.pendingOrdinaryStack?.id==plan.id {
            consume(engine.finishOrdinaryStackAbsorb(receiptID:plan.id,generation:plan.generation),previous:previous)
            finishSourceGameplay(.regularMergeHandoff,id:plan.id,generation:plan.generation)
        } else if engine.pendingOrdinarySix?.id==plan.id {
            ordinarySixVisual?.committed=true;ordinarySixVisual?.consuming=true
            let result=engine.commitOrdinarySix(receiptID:plan.id,generation:plan.generation)
            consume(result,previous:previous)
            ordinarySixVisual?.consuming=false
            if !result.accepted {retireOrdinarySixVisual()}
            else {releaseOrdinarySixIfReady()}
        }
    }

    private func resumeSourceFacePostchecks(generation:UInt64) {
        guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation,!engine.hasPendingSourceOrdinaryStackFace else{return}
        let captured=sourceFaceDeferredPostchecks.values.filter{$0.generation==generation}.sorted{$0.order<$1.order}
        for post in captured {
            guard sourceAnimationBindingAdmissionOpen,engine.state.generation==generation,!engine.hasPendingSourceOrdinaryStackFace,sourceFaceDeferredPostchecks.removeValue(forKey:post.id) != nil else{return}
            commitExpiredOrdinaryPostcheck(id:post.id,generation:generation)
        }
    }
    private func commitExpiredOrdinaryPostcheck(id:String,generation:UInt64) {
        guard !disposed,!sourceDisposalInProgress,engine.state.generation==generation,engine.pendingOrdinaryPostchecks.contains(where:{$0.id==id && $0.generation==generation}) else{return}
            let previous=engine.state
            let result=engine.commitOrdinaryPostcheck(receiptID:id,generation:generation)
            if result.accepted,sourceNoMovesPresentationEnabled,engine.stagedSourceNoMoves,
                let bridge=sourceNoMovesBridge,let bindings=sourceNoMovesBindings,
                engine.state.tutorial==nil,bindings.ordinaryCallerReady(id,generation),
                !disposed,sourceNoMovesBridge === bridge,engine.state.generation==generation {
                _=bridge.ordinaryPostcheck(receiptID:id,generation:generation)
            }
            if result.accepted {startSourceNoMovesDepletedCaller(ownerID:id,kind:.ordinaryMovesDepleted,generation:generation)}
            consume(result,previous:previous)
    }
    private func startOrdinaryPostcheck(id:String) {
        if sourcePreDebitDeferredMain.contains(id) {return}
        guard !disposed,!ordinaryPostchecks.contains(id),
              let pending=engine.pendingOrdinaryPostchecks.first(where:{$0.id==id && $0.generation==engine.state.generation}) else {return}
        if sourceOrdinaryPreDebitPresentationEnabled {
            guard sourcePreDebitMain[id] != nil,let flow=sourceOrdinaryPreDebitFlow,
                let receipt=engine.claimSourceOrdinaryPreDebit(ownerID:id,generation:pending.generation) else {
                onPresentationFailure?("source_predebit_main_not_admitted");return
            }
            sourcePreDebitRequests[id]=receipt
            if !flow.start(receipt) {_=engine.refuseSourceOrdinaryPreDebit(receipt)}
            return
        }
        ordinaryPostchecks.insert(id)
        let elapsed:()->Void = { [weak self] in
            guard let self,!self.disposed,self.engine.state.generation==pending.generation,
                  self.ordinaryPostchecks.remove(id) != nil,
                  self.engine.pendingOrdinaryPostchecks.contains(where:{$0.id==id && $0.generation==pending.generation}) else{return}
            if self.sourceStackCoreFaceReceiptsEnabled,self.engine.hasPendingSourceOrdinaryStackFace {
                self.sourceFaceDeferredPostcheckSequence &+= 1
                self.sourceFaceDeferredPostchecks[id]=SourceFaceDeferredPostcheck(id:id,generation:pending.generation,order:self.sourceFaceDeferredPostcheckSequence)
                return // actual original wall wait elapsed; do NOT add another100ms
            }
            self.commitExpiredOrdinaryPostcheck(id:id,generation:pending.generation)
        }
        if pending.delayMilliseconds==0 {elapsed()}
        else {sourceAppTimeouts.schedule(sourceID:"ordinary-postcheck:"+id,generation:pending.generation,
            delayMilliseconds:pending.delayMilliseconds,elapsed:elapsed,cancelled:{ [weak self] in
                guard let self else{return};self.ordinaryPostchecks.remove(id)
                // Literal waitTrackedResult cancellation returns before moves--.
                if self.engine.state.generation==pending.generation {
                    _=self.engine.cancelOrdinaryPostcheck(receiptID:id,generation:pending.generation)
                }
            })}
    }

    private func playRegularSixHero(_ plan:NativeOrdinaryMovePlan) {
        let node=nodesByID[plan.destination.id],start=CGPoint(x:node?.visual.xScale ?? 1,y:node?.visual.yScale ?? 1)
        // The source hidden final carrier still consumes the authored peak draw.
        let motion=NativeRegularSixHeroMotion(random:{Double.random(in:0..<1)})
        guard let node else {return}
        node.visual.removeAllActions()
        node.visual.run(.customAction(withDuration:0.275) { [weak node] _,time in
            node?.visual.xScale=motion.sample(seconds:Double(time),startingScale:Double(start.x))
            node?.visual.yScale=motion.sample(seconds:Double(time),startingScale:Double(start.y))
        },withKey:"source-ordinary-six-hero")
    }

    private func playRegularSixMain(_ plan:NativeOrdinaryMovePlan) {
        guard let geometry,regularSixPresentations[plan.id]==nil else {return}
        let cadence=NativeRegularSixFxCadence.shared
        let reduced=reducedBoardEffects
        let captured=boardShake
        let owner:NativeRegularSixSpritePresentation
        do {
            owner=try NativeRegularSixSpritePresentation(origin:geometry.center(row:plan.destination.cell.row,column:plan.destination.cell.column),tileSize:geometry.tileSize,
                destinationDepth:CGFloat(plan.destination.cell.row*engine.state.columns+plan.destination.cell.column),combinedDepth:plan.source.stackDepth+plan.destination.stackDepth,
                generation:plan.generation,reduced:reduced,hotFactor:cadence.hotFactor(nowMilliseconds:CACurrentMediaTime()*1000,reducedBoardFx:reduced),patternIndex:cadence.nextPattern(),initialShake:captured,
                isCurrent:{ [weak self] generation in self?.disposed == false && self?.engine.state.generation == generation },random:{Double.random(in:0..<1)})
        } catch {
            // The same process-stable source font was checked before capture.
            // Report an unexpected native renderer failure without substituting
            // an unrelated effect for the authored source receipt.
            onPresentationFailure?("ordinary_six_source_font_missing")
            return
        }
        if let previous=regularSixShakeID {regularSixPresentations[previous]?.detachShake()}
        regularSixShakeID=plan.id;regularSixPresentations[plan.id]=owner
        let receipt=beginVisual()
        owner.onShake={ [weak self] pose,generation in
            guard let self,self.regularSixShakeID==plan.id,self.engine.state.generation==generation else {return}
            self.applyBoardShake(pose)
        }
        owner.onFinished={ [weak self] _ in
            guard let self else {return}
            self.regularSixPresentations.removeValue(forKey:plan.id)
            if self.regularSixShakeID==plan.id {self.regularSixShakeID=nil;self.applyBoardShake(.init(canvas:.zero,indicator:.zero,bottomDecor:.zero))}
            self.finishVisual(receipt)
        }
        owner.mount(in:canvasRoot)
    }

    private func applyBoardShake(_ pose:NativeRegularSixSpritePresentation.ShakeReceipt) {
        onJourneyBottomDecorShake?(pose.bottomDecor,engine.state.generation)
        boardShake=pose;canvasRoot.position=CGPoint(x:pose.canvas.x,y:-pose.canvas.y)
        let base=NativeGameplayChromePlan.make(viewport:size,safeTop:safeInsets.top).roundCenter
        roundIndicator.position=CGPoint(x:base.x+pose.indicator.x,y:base.y-pose.indicator.y)
    }

    private func retireRegularSixPresentations() {
        for owner in Array(regularSixPresentations.values) {owner.dispose()}
        regularSixPresentations.removeAll();regularSixShakeID=nil;applyBoardShake(.init(canvas:.zero,indicator:.zero,bottomDecor:.zero))
    }

    private func scheduleOrdinaryCommand(key:String,generation:UInt64,delay:Double,command:@escaping ()->Void) {
        guard !disposed,ordinaryDeferred.insert(key).inserted else{return}
        let elapsed:()->Void = { [weak self] in
            guard let self,!self.disposed,self.engine.state.generation==generation,
                  self.ordinaryDeferred.remove(key) != nil else{return}
            command()
        }
        let milliseconds=Int((max(0,delay)*1000).rounded())
        if milliseconds==0 {elapsed()}
        else {sourceAppTimeouts.schedule(sourceID:"ordinary-command:"+key,generation:generation,
            delayMilliseconds:milliseconds,elapsed:elapsed,cancelled:{ [weak self] in self?.ordinaryDeferred.remove(key) })}
    }

    private func startOrdinaryAssignments(ids:[String]) {
        guard let plan=engine.pendingOrdinarySix else{return}
        let slots=engine.pendingOrdinaryAssignments.filter{ids.contains($0.id)}
        guard !slots.isEmpty else{releaseOrdinarySixIfReady();return}
        let deadline=DispatchTime.now()
        for slot in slots {
            let key="assignment:"+slot.id
            guard ordinaryDeferred.insert(key).inserted else{continue}
            if slot.kind == .locked {sourceLockedBounceActionIDs.insert(slot.id)}
            if slot.kind == .locked,let id=slot.tileID,let node=nodesByID[id],
               node.sourcePhysicalMarkersCovered,node.sourceGeneration==slot.generation,
               node.parent === canvasRoot,node.beginSourceLockedSpawnMarker(id:slot.id) {
                sourceLockedSlotMarkerNodes[slot.id]=node
            }
            let elapsed:()->Void = { [weak self] in
                guard let self else{return}
                defer {self.sourceLockedSlotMarkerNodes.removeValue(forKey:slot.id)?.clearSourceLockedSpawnMarker(id:slot.id)}
                guard !self.disposed,self.engine.state.generation==plan.generation,
                      self.ordinaryDeferred.remove(key) != nil,
                      self.engine.pendingOrdinarySix?.id==plan.id,
                      self.engine.pendingOrdinaryAssignments.contains(where:{$0.id==slot.id}) else{return}
                let previous=self.engine.state
                self.consume(self.engine.commitOrdinaryAssignment(receiptID:plan.id,generation:plan.generation,assignmentID:slot.id),previous:previous)
                // Literal safeResolve clears AFTER actual assignment/unlock,
                // before the Promise continuation, never at bounce completion.
                self.sourceLockedSlotMarkerNodes.removeValue(forKey:slot.id)?.clearSourceLockedSpawnMarker(id:slot.id)
                self.releaseOrdinarySixIfReady()
            }
            if slot.delayMilliseconds==0 {elapsed()}
            else {sourceAppTimeouts.schedule(sourceID:key,generation:plan.generation,
                delayMilliseconds:slot.delayMilliseconds,from:deadline,elapsed:elapsed,cancelled:{ [weak self] in
                    guard let self else{return};self.ordinaryDeferred.remove(key)
                    self.sourceLockedSlotMarkerNodes.removeValue(forKey:slot.id)?.clearSourceLockedSpawnMarker(id:slot.id)
                    if slot.kind == .forcedLocked,self.engine.state.generation==plan.generation,
                       self.engine.pendingOrdinaryAssignments.first?.id==slot.id {
                        let previous=self.engine.state
                        let result=self.engine.cancelOrdinarySpawnWait(receiptID:plan.id,generation:plan.generation,assignmentID:slot.id)
                        // Actual destruction suppresses newly queued presentation;
                        // the source cancellation cannot fabricate a bounce arrival.
                        if !self.retiringSourceTransports,!self.disposed,result.accepted {self.consume(result,previous:previous);self.releaseOrdinarySixIfReady()}
                    }
                })}
        }
    }

    private func releaseOrdinarySixIfReady() {
        guard !disposed,let owner=ordinarySixVisual,owner.committed,!owner.consuming,
              engine.state.generation==owner.generation,engine.pendingOrdinarySpawns.isEmpty,
              engine.pendingOrdinarySix?.id==owner.id else {return}
        let previous=engine.state,result=engine.releaseOrdinarySixHandoff(receiptID:owner.id,generation:owner.generation)
        guard result.accepted else {return}
        // Native pending-six handoff is not the original Promise finally.
        // A genuine Source token keeps its captured frame+idle companions until
        // the actual explicit coroutine/reset endpoint or captured teardown.
        if sourceOrdinarySixSpawnClaims[owner.id]==nil {
            finishSourceGameplay(.mergeSixResolution,id:owner.id,generation:owner.generation)
        }
        ordinarySixVisual=nil
        consume(result,previous:previous);finishVisual(owner.receipt)
    }
    private func retireOrdinarySixVisual() {
        if let owner=ordinarySixVisual {ordinarySixVisual=nil;finishSourceGameplay(.mergeSixResolution,id:owner.id,generation:owner.generation);finishVisual(owner.receipt)}
    }
    private func finishOrdinarySpawnVisual(_ id:String,interrupted:Bool=true) {
        if let receipt=ordinarySpawnVisuals.removeValue(forKey:id) {finishVisual(receipt)}
        if let primary=ordinaryPrimaryVisuals.removeValue(forKey:id),engine.state.generation==primary.2,
           engine.pendingOrdinaryPrimaryArrival?.id==primary.1 {
            let previous=engine.state
            consume(engine.finishOrdinaryPrimarySpawn(receiptID:primary.0,generation:primary.2,assignmentID:primary.1,interrupted:interrupted),previous:previous)
            releaseOrdinarySixIfReady()
        }
    }

    private func handleResolution(_ resolution: NativeResolution) {
        guard !sourceDisposalInProgress else {return }
        guard !disposed else { return }
        if resolution.kind == .wait,resolution.reason == "wild_continuation_pending" {
            cancelCandidate()
            if let queue=sourceMeterQueue {queue.queueIfNeeded();return}
            let previous = engine.state,result = engine.claimMeterReward()
            if result.accepted { consume(result,previous:previous) }
            return
        }
        if resolution.kind == .wait,resolution.reason == "tutorial_final_chance_pending" {
            cancelCandidate()
            let previous = engine.state,result = engine.claimTutorialFinalChance()
            if result.accepted { consume(result,previous: previous) }
            return
        }
        switch resolution.kind {
        case .fail:
            if engine.state.terminal?.kind == .fail { presentTerminal(resolution) }
            else if !engine.stagedSourceNoMoves { scheduleCandidate() }
        case .complete: presentTerminal(resolution)
        default: if candidateSignature != nil { cancelCandidate() }
        }
    }

    private func scheduleCandidate() {
        let state = engine.state
        if candidateSignature == state.signature { return }
        cancelCandidate()
        guard engine.beginNoMovesConfirmation() == state.signature else { cancelCandidate(); return }
        candidateSignature = state.signature; navigationLocked = true
        noMoves.isHidden = false; noMoves.text = "NO MOVES"
        onRenderingDemand?(true)
        let signature = state.signature, generation = state.generation
        onGameplayEvent?(NativeGameplayEvent(.noMovesCandidate))
        run(.sequence([.wait(forDuration: 1.5), .run { [weak self] in
            guard let self, !self.disposed, self.candidateSignature == signature else { return }
            let result = self.engine.confirmNoMoves(signature: signature, generation: generation)
            self.cancelCandidate(); self.consume(result, previous: state)
        }]), withKey: "no-moves-confirm")
    }

    private func cancelCandidate() {
        guard !sourceNoMovesCandidateActive else{return}
        removeAction(forKey: "no-moves-confirm"); candidateSignature = nil
        if sourceDisposalGeneration == nil || sourceDisposalGeneration == engine.state.generation {engine.cancelNoMovesConfirmation()}
        noMoves.isHidden = true; navigationLocked = engine.state.terminal != nil || pendingTerminal != nil || exitInProgress
    }

    private func presentTerminal(_ resolution: NativeResolution) {
        let generation = engine.state.generation
        guard terminalPresentedGeneration != generation, pendingTerminalGeneration != generation else { return }
        inputAdmitted = false; navigationLocked = true
        cancelDrag(); removeAction(forKey: "no-moves-confirm"); candidateSignature = nil
        onStateChange?(engine.state)
        pendingTerminal = resolution
        pendingTerminalGeneration = generation
        publishPendingTerminal()
    }

    private func beginVisual() -> UInt64 { visualOwners += 1; return visualLifetime }
    private func finishVisual(_ receipt: UInt64) {
        guard !disposed, receipt == visualLifetime else { return }
        visualOwners = max(0,visualOwners-1)
        releaseFinalDirectIfReady()
        publishPendingTerminal()
    }
    private func releaseFinalDirectIfReady() {
        guard !sourceDisposalInProgress else {return}
        guard !disposed,!suspended,visualOwners == 1,engine.pendingHUDStars.isEmpty,engine.pendingMeterRewards.isEmpty,
              let (id,generation,receipt)=directFinalReceipt,engine.pendingDirectWild?.id == id,engine.pendingDirectWild?.isFinal == true,engine.directWildGameplayCommitted else {return}
        directFinalReceipt=nil;directPresentationID=nil;directPresentationVariant=nil;directFinalReceipt=nil
        let previous=engine.state,result=engine.releaseDirectWildPresentation(transactionID:id,generation:generation)
        if result.accepted,let captured=wildSourceResolution,captured.id==id,captured.generation==generation {
            wildSourceResolution=nil
            sourceSpecialTransactions?.directGameplaySettled(id:id,generation:generation)
            finishSourceGameplay(.mergeSixResolution,id:id,generation:generation)
        }
        consume(result,previous:previous);finishVisual(receipt)
    }
    private func publishPendingTerminal() {
        guard !sourceDisposalInProgress else {return}
        guard !disposed, !suspended, visualOwners == 0, engine.pendingHUDStars.isEmpty, engine.pendingMeterRewards.isEmpty, let pendingTerminal, pendingTerminalGeneration == engine.state.generation,
              terminalPresentedGeneration != engine.state.generation else { return }
        self.pendingTerminal = nil; pendingTerminalGeneration = nil; terminalPresentedGeneration = engine.state.generation
        onTerminal?(pendingTerminal)
    }

    private func smoke(at point: CGPoint, special: Bool,completion:(() -> Void)?=nil) {
        guard let geometry else { return }
        onRenderingDemand?(true)
        let receipt = beginVisual()
        for index in 0..<6 {
            let puff = SKSpriteNode(texture: textures.texture("assets/smoke/smoke\(index % 5 + 1).png"))
            puff.position = point
            let size = geometry.tileSize * (special ? 1.7 : 1.35)
            puff.size = CGSize(width: size, height: size); puff.alpha = 0.8
            puff.zRotation = CGFloat(index) * .pi / 3
            effects.addChild(puff)
            let angle = CGFloat(index) * .pi / 3
            let move = SKAction.moveBy(x: cos(angle)*geometry.tileSize*0.6, y: sin(angle)*geometry.tileSize*0.6, duration: 0.65)
            move.timingMode = .easeOut
            var actions: [SKAction] = [.group([move, .scale(to: 1.45, duration: 0.65), .fadeOut(withDuration: 0.65)])]
            if index == 5 { actions.append(.run { [weak self] in self?.finishVisual(receipt);completion?() }) }
            actions.append(.removeFromParent())
            puff.run(.sequence(actions))
        }
    }

    private func authoredFinale(_ variant: String,at point: CGPoint) -> Bool {
        guard let onAuthoredFinale else { return false }
        let receipt = beginVisual()
        let accepted = onAuthoredFinale(variant,CGPoint(x: point.x,y: size.height-point.y),engine.state.generation) { [weak self] in
            self?.finishVisual(receipt)
        }
        if !accepted { finishVisual(receipt) }
        return accepted
    }

    private func playDirectWild(_ plan:NativeDirectWildMovePlan) {
        guard !disposed,directPresentationID != plan.id else {return}
        directPresentationID=plan.id;directPresentationVariant=plan.variant
        specialPresentationIDs.formUnion([plan.source.id,plan.destination.id])
        nodesByID[plan.source.id]?.alpha=0
        let owner=SKNode(),receipt=beginVisual()
        effects.addChild(owner);navigationLocked=true;onRenderingDemand?(true)
        directAbsorb=(plan,owner,receipt)
        // Actual source ghost's80ms move completion invokes finishDirectWildAbsorb.
    }
    private func finishDirectWildAbsorb(_ plan:NativeDirectWildMovePlan) {
        guard !disposed,!suspended,engine.state.generation==plan.generation,
              engine.pendingDirectWild?.id==plan.id,let captured=directAbsorb,captured.0.id==plan.id else{return}
        directAbsorb=nil
        let owner=captured.1,receipt=captured.2,previous=engine.state
        let result=engine.commitDirectWildGameplay(transactionID:plan.id)
        specialPresentationIDs.remove(plan.source.id);specialPresentationIDs.remove(plan.destination.id)
        consume(result,previous:previous)
        finishWildSourceResolutionIfReady()
        guard result.accepted,engine.pendingDirectWild?.id==plan.id else {
            directPresentationID=nil;directPresentationVariant=nil;finishVisual(receipt);owner.removeFromParent();return
        }
        navigationLocked=engine.state.terminal != nil || pendingTerminal != nil
        if plan.isFinal {
            directFinalReceipt=(plan.id,plan.generation,receipt);owner.removeFromParent();releaseFinalDirectIfReady();return
        }
        owner.run(.sequence([.wait(forDuration:plan.archetype == .juice ? 1.86:0.9),.run { [weak self,weak owner] in
            guard let self else{return}
            guard !self.disposed,!self.suspended,self.engine.state.generation==plan.generation,
                  self.engine.pendingDirectWild?.id==plan.id else {self.finishVisual(receipt);owner?.removeFromParent();return}
            let previous=self.engine.state,result=self.engine.releaseDirectWildPresentation(transactionID:plan.id,generation:plan.generation)
            self.directPresentationID=nil;self.directPresentationVariant=nil
            if result.accepted {self.consume(result,previous:previous)}
            self.finishVisual(receipt);owner?.removeFromParent()
        }]),withKey:"native-direct-wild-release")
    }

    private func startWildSpawnActions(ids:[String]) {
        let actions=engine.pendingWildSpawnActions.filter{ids.contains($0.id) && $0.generation==engine.state.generation && wildScheduledActionIDs.insert($0.id).inserted}
        guard !actions.isEmpty else{return}
        // Explicit Core262 captured original command provenance. Do not derive
        // this from kind .locked alone, delay, presentation or a pending bounce.
        for action in actions where action.sourceLevelFlow {
            if let id=action.tileID,let node=nodesByID[id],node.parent === canvasRoot,
               node.sourceGeneration==action.generation,node.sourcePhysicalMarkersCovered,
               node.beginSourceLockedSpawnMarker(id:action.id) {sourceLockedSlotMarkerNodes[action.id]=node}
        }
        let commit:(NativeWildSpawnAction)->Void = { [weak self] action in
            // Source setTimeout callbacks continue under modal timeline pause.
            guard let self else{return}
            defer {self.sourceLockedSlotMarkerNodes.removeValue(forKey:action.id)?.clearSourceLockedSpawnMarker(id:action.id)}
            guard !self.disposed,self.engine.state.generation==action.generation,
                  self.engine.pendingWildSpawnActions.contains(where:{$0.id==action.id && $0.generation==action.generation}) else{return}
            let previous=self.engine.state,result=self.engine.commitWildSpawnAction(transactionID:action.transactionID,generation:action.generation,actionID:action.id)
            if result.accepted {self.consume(result,previous:previous);self.finishWildSourceResolutionIfReady()}
        }
        let deadline=DispatchTime.now()
        for action in actions {
            // Primary retry/forced first assignment are original synchronous
            // continuations, not an invented next-frame/timeout delivery.
            if action.delayMilliseconds==0 {commit(action)}
            else {
                // app-core endgame trackAppTimeout50; level-flow locked picks
                //50+100*i; app-core waitTrackedResult remainder/forced waits.
                // These are separate from paused GSAP bounce/absorb/FX owners.
                sourceAppTimeouts.schedule(sourceID:action.id,generation:action.generation,
                    delayMilliseconds:action.delayMilliseconds,from:deadline,elapsed:{commit(action)},cancelled:{[weak self] in
                        self?.sourceLockedSlotMarkerNodes.removeValue(forKey:action.id)?.clearSourceLockedSpawnMarker(id:action.id)
                    })
            }
        }
    }
    private func startWildRecoveryCheck(id:String) {
        guard let pending=engine.pendingWildRecoveryChecks.first(where:{$0.id==id && $0.generation==engine.state.generation}),wildCommandOwners[id]==nil else{return}
        let owner=SKNode(),receipt=beginVisual();wildCommandOwners[id]=(owner,receipt);effects.addChild(owner)
        owner.run(.sequence([.wait(forDuration:Double(pending.delayMilliseconds)/1000),.run { [weak self,weak owner] in
            guard let self else{return}
            guard !self.disposed,!self.suspended,self.engine.state.generation==pending.generation,
                  self.engine.pendingWildRecoveryChecks.contains(where:{$0.id==id}) else {
                if self.wildCommandOwners.removeValue(forKey:id) != nil {self.finishVisual(receipt)};owner?.removeFromParent();return
            }
            self.wildCommandOwners.removeValue(forKey:id)
            let previous=self.engine.state,result=self.engine.commitWildRecoveryCheck(receiptID:id,generation:pending.generation)
            if result.accepted {self.consume(result,previous:previous)}
            self.finishVisual(receipt);owner?.removeFromParent()
        }]),withKey:"native-wild-recovery-check")
    }
    private func startWildSpawnVisual(_ presentation:NativeWildSpawnPresentation,node:NativeDiceNode,actionID:String) {
        finishWildSpawnVisual(presentation.tileID,interrupted:true)
        let arrival=engine.pendingWildSpawnArrivals.first{$0.tileID==presentation.tileID && $0.generation==presentation.generation}
        let receipt=beginVisual(),releaseFrames=beginSourceMotion(.spawnBounce,id:"wild-spawn:"+actionID,generation:presentation.generation)
        wildSpawnVisuals[presentation.tileID]=(receipt,presentation.generation,arrival,releaseFrames)
        node.visual.setScale(0.30)
        node.visual.run(.sequence([NativeBoardMotion.spawnBounce(direction:CGFloat(presentation.direction)),.run { [weak self,weak node] in
            guard let self,let node,!self.disposed,!self.suspended,self.engine.state.generation==presentation.generation else{return}
            self.finishWildSpawnVisual(presentation.tileID,interrupted:false,beforeLogicalArrival:{
                if presentation.sourceLevelFlowReinforcement {self.completeSourceLevelFlowBounce(node,generation:presentation.generation)}
            })
        }]),withKey:"native-wild-spawn")
    }
    private func completeSourceLevelFlowBounce(_ node:NativeDiceNode,generation:UInt64) {
        let id=node.tileID
        guard !disposed,engine.state.generation==generation,nodesByID[id] === node else{return}
        node.repairSourceLevelFlowVisual()
        sourceAppTimeouts.schedule(sourceID:"level-flow-reinforce:"+UUID().uuidString,generation:generation,
            delayMilliseconds:160,elapsed:{ [weak self,weak node] in
                guard let self,let node,!self.disposed,self.engine.state.generation==generation,
                      self.nodesByID[id] === node else{return}
                node.repairSourceLevelFlowVisual()
            })
        onLevelFlowBounceCompletion?(id,generation)
    }
    private func finishWildSpawnVisual(_ id:String,interrupted:Bool,beforeLogicalArrival:(()->Void)?=nil) {
        nodesByID[id]?.visual.removeAction(forKey:"native-wild-spawn")
        nodesByID[id]?.visual.removeAction(forKey:"native-wild-locked-bonus")
        if let bonus=wildBonusVisuals.removeValue(forKey:id) {finishVisual(bonus.0)}
        guard let captured=wildSpawnVisuals.removeValue(forKey:id) else{return}
        // Original wrapped bounce releases its single100ms frame lease before
        // openCell's done/interrupted logical promise callback.
        captured.3?()
        beforeLogicalArrival?()
        // Retire once before model callback because consume may recursively synchronize.
        if let arrival=captured.2,!disposed,!suspended,engine.state.generation==captured.1,
           engine.pendingWildSpawnArrivals.contains(where:{$0.id==arrival.id}) {
            let previous=engine.state,result=engine.finishWildSpawnArrival(transactionID:arrival.transactionID,generation:arrival.generation,arrivalID:arrival.id,interrupted:interrupted)
            if result.accepted {consume(result,previous:previous);finishWildSourceResolutionIfReady()}
        }
        finishVisual(captured.0)
    }
    private func startWildLockedBonus(ids:[String]) {
        for bonus in engine.pendingWildLockedBonusPresentations where ids.contains(bonus.tileID) && bonus.generation==engine.state.generation && wildBonusVisuals[bonus.tileID]==nil {
            guard let node=nodesByID[bonus.tileID] else{continue}
            let receipt=beginVisual();wildBonusVisuals[bonus.tileID]=(receipt,bonus.generation)
            node.visual.setScale(0.30)
            let scale=SKAction.sequence([
                NativeBoardMotion.scale(from:.init(x:0.30,y:0.30),to:.init(x:1.08,y:1.08),duration:0.16,ease:.backOut(2.1)),
                NativeBoardMotion.scale(from:.init(x:1.08,y:1.08),to:.init(x:0.96,y:0.96),duration:0.10,ease:.power2InOut),
                NativeBoardMotion.scale(from:.init(x:0.96,y:0.96),to:.init(x:1.02,y:1.02),duration:0.10,ease:.power2Out),
                NativeBoardMotion.scale(from:.init(x:1.02,y:1.02),to:.init(x:1,y:1),duration:0.12,ease:.backOut(2))])
            let direction=CGFloat(bonus.direction)
            let rotation=SKAction.sequence([
                NativeBoardMotion.rotate(from:0,to:-0.035*direction,duration:0.10,ease:.power2Out),
                NativeBoardMotion.rotate(from:-0.035*direction,to:0.021*direction,duration:0.12,ease:.power2Out),
                NativeBoardMotion.rotate(from:0.021*direction,to:0,duration:0.14,ease:.power2Out)])
            node.visual.run(.sequence([.wait(forDuration:Double(bonus.delayMilliseconds)/1000),.group([scale,rotation]),.run { [weak self] in
                guard let self,self.engine.state.generation==bonus.generation else{return}
                if let pending=self.wildBonusVisuals.removeValue(forKey:bonus.tileID) {self.finishVisual(pending.0)}
            }]),withKey:"native-wild-locked-bonus")
        }
    }
    private func finishWildSourceResolutionIfReady() {
        guard let captured=wildSourceResolution,
              engine.hasReachedWildSourceResolutionBoundary(transactionID:captured.id,generation:captured.generation) else{return}
        wildSourceResolution=nil
        sourceSpecialTransactions?.directGameplaySettled(id:captured.id,generation:captured.generation)
        finishSourceGameplay(.mergeSixResolution,id:captured.id,generation:captured.generation)
    }
    private func invalidateWildTransports() {
        retiringSourceTransports=true
        if let previous=lastGeneration {sourceAppTimeouts.cancelGeneration(previous)}
        sourceAppTimeouts.cancelAll()
        let selectedMarkers=sourceLockedSlotMarkerNodes;sourceLockedSlotMarkerNodes=[:]
        selectedMarkers.forEach{key,node in node.clearSourceLockedSpawnMarker(id:key)}
        sourceLockedBounceActionIDs.removeAll()
        retiringSourceTransports=false
        if let captured=wildSourceResolution {
            wildSourceResolution=nil;finishSourceGameplay(.mergeSixResolution,id:captured.id,generation:captured.generation)
        }
        // This is generation replacement/disposal, never Source timeline pause.
        // Explicit destruction retires native delivery without inventing arrival.
        for captured in wildSpawnVisuals.values {captured.3?()}
        wildCommandOwners.values.forEach{$0.0.removeAllActions();$0.0.removeFromParent()}
        wildCommandOwners.removeAll();wildScheduledActionIDs.removeAll();wildSpawnVisuals.removeAll();wildBonusVisuals.removeAll();directAbsorb=nil
        for node in nodesByID.values {node.visual.removeAction(forKey:"native-wild-spawn");node.visual.removeAction(forKey:"native-wild-locked-bonus")}
    }

    private func configureTntGlyphClock(_ owner: NativeTntFinale) {
        guard onTntGlyphClock != nil else { return }
        let id = UUID().uuidString,generation = engine.state.generation
        owner.onGlyphClock = { [weak self] time,finished in
            guard let self,finished || !self.disposed && self.engine.state.generation == generation else { return }
            self.onTntGlyphClock?(id,time,finished)
        }
    }

    private func coreTntFinale() {
        let owner = NativeTntFinale(textures: textures,fontName: finaleFontName,viewport: size,showsTitle: onTntGlyphClock == nil)
        configureTntGlyphClock(owner)
        owner.zPosition = 999998; effects.addChild(owner)
        let receipt = beginVisual(); onRenderingDemand?(true)
        let releaseSource=beginSourceMotion(.tntFinale,id:UUID().uuidString,generation:engine.state.generation)
        owner.play { [weak self] in releaseSource?();self?.finishVisual(receipt) }
    }

    private func coreStarFinale() {
        let owner = NativeStarFinale(textures: textures,viewport: size)
        let id = UUID().uuidString,generation = engine.state.generation
        var haptics = Set<Int>()
        let earlyBeats: [TimeInterval] = (0..<7).map { Double($0)*0.095 }
        let lateBeats: [TimeInterval] = (0..<6).map { 1.0+Double($0)*0.11 }
        let beats = earlyBeats+lateBeats
        owner.onGlyphClock = { [weak self] time,finished in
            guard let self,finished || !self.disposed && self.engine.state.generation == generation else { return }
            self.onSplashGlyphClock?("star",id,time,finished)
            if !finished { for (index,at) in beats.enumerated() where time >= at && !haptics.contains(index) {
                haptics.insert(index); self.onHaptic?("light")
            } }
        }
        owner.zPosition = 999998; effects.addChild(owner)
        let receipt = beginVisual(); onRenderingDemand?(true)
        owner.play { [weak self] in self?.finishVisual(receipt) }
    }

    @discardableResult
    private func coreJuiceFinale(onGameplayReady: (() -> Void)? = nil) -> Bool {
        let owner = NativeJuiceFinale(textures: textures,viewport: size)
        guard owner.assetReady else { owner.dispose(); return false }
        for previous in effects.children.compactMap({ $0 as? NativeJuiceFinale }) { previous.dispose() }
        let token = UUID().uuidString,generation = engine.state.generation
        let beats: [TimeInterval] = [0.2,0.27,0.34,0.52,0.78,1.04,1.325,1.425,1.525,1.625,2.225,2.405,2.585,2.725]
        var haptics = Set<Int>()
        owner.onGlyphClock = { [weak self] time,finished in
            guard let self,finished || !self.disposed && self.engine.state.generation == generation else { return }
            self.onSplashGlyphClock?("juice",token,time,finished)
            if !finished { for (index,at) in beats.enumerated() where time >= at && !haptics.contains(index) {
                haptics.insert(index); self.onHaptic?("light")
            } }
        }
        owner.onCue = { [weak self] moment,index in
            guard let self,!self.disposed,self.engine.state.generation == generation else { return }
            self.onSpecialMoment?("juice",moment,index)
        }
        owner.onGameplayReady = onGameplayReady
        owner.zPosition = 999998; effects.addChild(owner)
        let receipt = beginVisual(); onRenderingDemand?(true)
        let releaseSource=beginSourceMotion(.juiceFinale,id:token,generation:generation)
        owner.play { [weak self] in releaseSource?();self?.finishVisual(receipt) }
        return true
    }

    private func retireEffects() {
        for child in effects.children {
            if let tnt = child as? NativeTntFinale { tnt.dispose() }
            else if let star = child as? NativeStarFinale { star.dispose() }
            else if let juice = child as? NativeJuiceFinale { juice.dispose() }
            else { child.removeAllActions(); child.removeAllChildren(); child.removeFromParent() }
        }
    }

    private func startMeterRewards(ids:[String]) {
        for receipt in engine.pendingMeterRewards where ids.contains(receipt.id) && meterTimeoutIDs.insert(receipt.id).inserted {
            // Original TNT impact credits 3/4 use trackAppTimeout400/500;
            // model charge continues under GSAP pause, without renderer leases.
            sourceAppTimeouts.schedule(sourceID:"tnt-meter:"+receipt.id,generation:receipt.generation,
                delayMilliseconds:Int((receipt.delay*1000).rounded()),elapsed:{ [weak self] in
                    guard let self,!self.disposed,self.engine.state.generation==receipt.generation,
                          self.meterTimeoutIDs.remove(receipt.id) != nil,
                          self.engine.pendingMeterRewards.contains(where:{$0.id==receipt.id && $0.generation==receipt.generation}) else{return}
                    let previous=self.engine.state
                    self.consume(self.engine.commitMeterReward(receiptID:receipt.id,generation:receipt.generation),previous:previous)
                },cancelled:{ [weak self] in self?.meterTimeoutIDs.remove(receipt.id) })
        }
    }

    /// Borrow the existing actual Source app-wall transport. Global GSAP pause
    /// does not stop this finite wait; destruction cancels the captured receipt.
    func scheduleSourceConfirmedFailWait(generation:UInt64,milliseconds:Int,elapsed:@escaping()->Void,cancelled:@escaping()->Void)->()->Void {
        let receipt=sourceAppTimeouts.schedule(sourceID:"confirmed-fail-handoff:"+UUID().uuidString,
            generation:generation,delayMilliseconds:milliseconds,elapsed:elapsed,cancelled:cancelled)
        return {[weak self] in _=self?.sourceAppTimeouts.cancel(receipt)}
    }
    /// Score-free protected-star cleanup AFTER Source wall40/60 and BEFORE the
    /// real board exit. Refuse unbound pending stars; never manufacture arrival.
    @discardableResult func cleanupSourceConfirmedFailHUDStars(plan:NativeNoMovesCandidateOwner.Plan,generation:UInt64)->Bool {
        guard sourceAnimationBindingAdmissionOpen,sourceNoMovesPresentationEnabled,
            engine.state.generation==generation,sourceNoMovesGeneration==generation,
            engine.pendingSourceNoMoves==plan else{return false}
        let ids=Set(engine.pendingHUDStars.map(\.id))
        if sourceHUDStarJobsPresentationEnabled {
            guard let owner=sourceHUDStarOwner,
                owner.capturedJobs.count==engine.sourceHUDStarJobs.count,
                owner.capturedJobs.allSatisfy({engine.sourceHUDStarJobs.contains($0)}),
                ids.isSubset(of:Set(owner.capturedJobs.flatMap(\.receiptIDs))),
                engine.cancelSourceConfirmedFailHUDStars(plan:plan,generation:generation,receiptIDs:Array(ids)) else{return false}
            retireSourceHUDStarJobs()
            return sourceAnimationBindingAdmissionOpen && engine.state.generation==generation
        }
        guard ids==hudStarIDs,ids==Set(hudStarNodes.keys),ids==Set(hudStarVisualReceipts.keys),
            hudStarNodes.values.allSatisfy({$0.parent === hudStarFlights}) else{return false}
        let nodes=hudStarNodes,visuals=hudStarVisualReceipts
        guard engine.cancelSourceConfirmedFailHUDStars(plan:plan,generation:generation,receiptIDs:Array(ids)) else{return false}
        // Remove exact owned fields BEFORE action/resource/lease callbacks.
        hudStarNodes.removeAll();hudStarIDs.removeAll();hudStarVisualReceipts.removeAll()
        for node in nodes.values {node.removeAllActions();node.removeFromParent()}
        finishSourceStars()
        for receipt in visuals.values {finishVisual(receipt)}
        return sourceAnimationBindingAdmissionOpen && engine.state.generation==generation
    }
    // PRIVATE Source caller capability, defaultOFF. A family capture must come
    // from its genuine animateStarsToHudIcon call, not a Core grid reconstruction.
    var sourceHUDStarTargetScreen:CGPoint? {
        guard sourceAnimationBindingAdmissionOpen,let view,scoreArt.parent != nil else{return nil}
        return view.convert(scoreArt.convert(CGPoint.zero,to:self),from:self)
    }
    struct SourceHUDStarCallCapture {let screenOrigin:CGPoint,hudTarget:CGPoint}
    var sourceHUDStarJobsPresentationEnabled=false
    private var sourceHUDStarOwner:NativeSourceHUDStarPresentation?
    private var sourceHUDStarFeedback:NativeSourceHUDStarFeedback?
    private var sourceHUDStarScaleFeedback:NativeSourceHUDStarScaleFeedback?
    private var sourceHUDStarScaleClock:NativeSourceHUDStarScaleClockAdapter?
    var sourceHUDStarJobsAdmissionOpen:Bool{sourceHUDStarJobsPresentationEnabled && sourceHUDStarOwner?.admissionOpen==true}
    private var sourceHUDStarCapture:(([NativeHUDStarReceipt])->SourceHUDStarCallCapture?)?
    private var sourceHUDStarEpoch:UInt64=0
    private var sourceDirectHUDOrigins:[String:(UInt64,CGPoint)]=[:]
    @discardableResult func configureSourceHUDStarJobs(scope:NativeGameplaySourceContext.Scope,
        prepared:NativeSourceHUDStarTexturePreparation.Prepared,
        capture:@escaping([NativeHUDStarReceipt])->SourceHUDStarCallCapture?,
        hudFeedback:((Int)->Void)?=nil)->Bool {
        guard sourceHUDStarJobsPresentationEnabled,sourceAnimationBindingAdmissionOpen,scope.current,
              sourceHUDStarOwner==nil,hudStarIDs.isEmpty,engine.sourceHUDStarJobs.isEmpty,
              scope.hudStarTextures.accepts(prepared),scope.service.sourceFrameTransportAdmissionOpen else{return false}
        sourceHUDStarEpoch &+= 1
        let epoch=sourceHUDStarEpoch,generation=engine.state.generation
        let current:()->Bool = {[weak self,scope] in
            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceHUDStarEpoch==epoch,
                self.engine.state.generation==generation,self.sourceHUDStarJobsPresentationEnabled,
                scope.hudStarTextures.accepts(prepared) else{return false}
            let admitted=scope.current
            return admitted && self.sourceAnimationBindingAdmissionOpen && self.sourceHUDStarEpoch==epoch &&
                self.engine.state.generation==generation && self.sourceHUDStarJobsPresentationEnabled && scope.hudStarTextures.accepts(prepared)
        }
        let scaleClock=NativeSourceHUDStarScaleClockAdapter(service:scope.service)
        let scales=NativeSourceHUDStarScaleFeedback(hooks:.init(current:current,
            text:{[weak self] in self?.score.text ?? ""},
            setText:{[weak self] value in self?.score.text=value},
            readScale:{[weak self] target in
                guard let self else{return .init(x:1,y:1)}
                let node:SKNode=target == .number ? self.score:self.scoreArt
                return .init(x:Double(node.xScale),y:Double(node.yScale))
            },writeScale:{[weak self] target,value in
                guard let self,current() else{return}
                let node:SKNode=target == .number ? self.score:self.scoreArt
                node.xScale=CGFloat(value.x);node.yScale=CGFloat(value.y)
            },killOtherScaleTweens:{[weak self] target in
                guard let self,current() else{return}
                // This captured Scene has no other score/icon scale-tween
                // owner. The feedback helper cancels its exact roots above;
                // HUD drop/rise owns the parent and is never killed here.
                _ = target
            },timeline:{label,duration,paint,finished in
                guard current() else{return nil}
                return scaleClock.timeline(label:label,duration:duration,paint:paint,finished:finished)
            },wall:{[weak self] ms,callback in
                guard let self,current() else{return nil}
                let receipt=self.sourceAppTimeouts.schedule(sourceID:"source-hud-star-number-deflate",generation:generation,delayMilliseconds:ms,elapsed:callback)
                return{[weak self] in _=self?.sourceAppTimeouts.cancel(receipt)}
            }))
        guard let owner=NativeSourceHUDStarPresentation(stage:canvasRoot,viewportHeight:size.height,texture:prepared.texture,pixelSize:prepared.pixelSize,
            selectedAssetsReady:prepared.current,service:scope.service,timeouts:sourceAppTimeouts,engine:engine,
            bindings:.init(current:current,random:{scope.smokeSession.nextVisualRandom()},acquireCadence:{[weak self] in
                guard let self,current() else{return{}}
                return self.beginSourceMotion(.hudStarFlight,id:UUID().uuidString,generation:generation) ?? {}
            },onArrival:{[weak self] result in
                guard let self,current() else{return}
                // Original CC mutation already happened in Core. Do NOT route
                // through Raw consume/redraw/save/resolver per arriving star.
                guard self.sourceHUDStarFeedback?.scoreChanged()==true else{self.onPresentationFailure?("source_hud_star_feedback_frame_unbound");return}
            },onRetired:{ _ in
                guard current() else{return} // no Source save/redraw is scheduled by job cleanup itself.
            })),current(),sourceHUDStarOwner==nil else{scales.dispose();scaleClock.dispose();return false}
        let feedback=NativeSourceHUDStarFeedback(current:current,schedule:{callback in
            guard current(),let frame=scope.service.requestSourceAnimationFrame(ownerID:"source-hud-star-feedback",generation:generation,callback:callback) else{return nil}
            return{frame.cancel()}
        },paint:{[weak self] in
            guard let self,current() else{return}
            guard scales.paint(score:self.engine.state.score),current() else{self.onPresentationFailure?("source_hud_star_authored_feedback_unavailable");return}
            hudFeedback?(self.engine.state.score) // optional observer, authored painting is installed above.
        })
        guard current(),sourceHUDStarOwner==nil else{feedback.dispose();scales.dispose();scaleClock.dispose();owner.dispose();return false}
        sourceHUDStarOwner=owner;sourceHUDStarFeedback=feedback;sourceHUDStarScaleFeedback=scales;sourceHUDStarScaleClock=scaleClock;sourceHUDStarCapture=capture;engine.sourceHUDStarJobsEnabled=true;sourceDisposalSealingEnabled=true
        return true
    }
    func startSourceHUDStarJobs(ids:[String])->Bool {
        guard let owner=sourceHUDStarOwner,let capture=sourceHUDStarCapture,sourceAnimationBindingAdmissionOpen else{return false}
        let epoch=sourceHUDStarEpoch,generation=engine.state.generation
        let receipts=ids.compactMap{id in engine.pendingHUDStars.first{$0.id==id && $0.generation==generation}}
        guard receipts.count==ids.count else{return false}
        var groups:[[NativeHUDStarReceipt]]=[]
        for receipt in receipts {
            if let index=groups.firstIndex(where:{$0.first?.id.dropLast(2)==receipt.id.dropLast(2)}){groups[index].append(receipt)}else{groups.append([receipt])}
        }
        for group in groups {
            guard sourceAnimationBindingAdmissionOpen,sourceHUDStarEpoch==epoch,sourceHUDStarOwner === owner,
                  engine.state.generation==generation,let call=capture(group),sourceAnimationBindingAdmissionOpen,
                  sourceHUDStarEpoch==epoch,sourceHUDStarOwner === owner,engine.state.generation==generation else{return false}
            let sourceOrigins=group.compactMap{sourceDirectHUDOrigins[$0.id]}.filter{$0.0==generation}
            guard sourceOrigins.isEmpty || (sourceOrigins.count==group.count && sourceOrigins.allSatisfy{$0.1==sourceOrigins[0].1}) else{return false}
            let origin=sourceOrigins.first?.1 ?? call.screenOrigin // unchanged genuine supplier for other family calls.
            guard owner.start(receiptIDs:group.map(\.id),screenOrigin:origin,hudTarget:call.hudTarget) else{return false}
        }
        return true
    }
    func retireSourceHUDStarJobs() {
        sourceHUDStarEpoch &+= 1
        let owner=sourceHUDStarOwner;sourceHUDStarOwner=nil;sourceHUDStarCapture=nil
        let feedback=sourceHUDStarFeedback;sourceHUDStarFeedback=nil
        let scales=sourceHUDStarScaleFeedback;sourceHUDStarScaleFeedback=nil
        let scaleClock=sourceHUDStarScaleClock;sourceHUDStarScaleClock=nil
        engine.sourceHUDStarJobsEnabled=false
        feedback?.dispose();scales?.dispose();scaleClock?.dispose();owner?.dispose() // remove caller fields before external Core/job cleanup
    }

    private func startHUDStarFlights(ids: [String],lead: TimeInterval = 0) {
        if sourceHUDStarJobsPresentationEnabled {
            guard startSourceHUDStarJobs(ids:ids) else{onPresentationFailure?("source_hud_star_actual_call_capture_not_bound");return}
            return // Source root has its actual caller timing, no Raw Magnet lead.
        }
        guard let geometry else { return }
        let receipts = ids.compactMap { id in engine.pendingHUDStars.first { $0.id == id } }.filter { !hudStarIDs.contains($0.id) }
        guard !receipts.isEmpty else { return }
        if sourceStars==nil {sourceCallbackTime();sourceStars=sourceFrames.begin(.init(kind:.hudStarFlight,generation:engine.state.generation,id:UUID().uuidString))}
        let origins = receipts.map { receipt -> CGPoint in
            let point = geometry.center(row: receipt.origin.row,column: receipt.origin.column)
            return CGPoint(x: point.x,y: size.height-point.y)
        }
        let target = CGPoint(x: scoreArt.position.x,y: size.height-scoreArt.position.y)
        let plans = NativeHUDStarMotion.batch(origins: origins,target: target)
        for (receipt,plan) in zip(receipts,plans) {
            hudStarIDs.insert(receipt.id)
            let star = SKSpriteNode(texture: textures.texture("assets/small-star.png"))
            star.size = CGSize(width: plan.size,height: plan.size)
            let origin = plan.points[0]; star.position = CGPoint(x: origin.x,y: size.height-origin.y)
            hudStarFlights.addChild(star);hudStarNodes[receipt.id]=star
            let visualReceipt = beginVisual(); hudStarVisualReceipts[receipt.id] = visualReceipt; var arrived = false
            onRenderingDemand?(true)
            star.run(.sequence([.wait(forDuration: lead),.customAction(withDuration: plan.end) { [weak self,weak star] _,elapsed in
                guard let self,!self.disposed,self.engine.state.generation == receipt.generation,!arrived,let star,self.hudStarNodes[receipt.id] === star,self.hudStarIDs.contains(receipt.id),star.parent === self.hudStarFlights else { return }
                let pose = plan.sample(seconds: Double(elapsed))
                star.position = CGPoint(x: pose.point.x,y: self.size.height-pose.point.y)
                star.size = CGSize(width: pose.size,height: pose.size); star.zRotation = -pose.rotation
                if pose.arrived {
                    arrived = true; star.alpha = 0; star.removeFromParent(); self.hudStarIDs.remove(receipt.id);self.hudStarNodes.removeValue(forKey:receipt.id)
                    self.finishSourceStars()
                    let previous = self.engine.state
                    let result = self.engine.commitHUDStarArrival(receiptID: receipt.id,generation: receipt.generation)
                    self.consume(result,previous: previous)
                    self.onSpecialMoment?(receipt.variant,"hud-star-arrived",receipt.ordinal)
                    self.hudStarVisualReceipts.removeValue(forKey: receipt.id)
                    self.finishVisual(visualReceipt)
                }
            },.removeFromParent()]),withKey: "native-protected-hud-star")
        }
    }

    private func specialIsCurrent(_ plan: NativeSpecialMovePlan) -> Bool {
        !disposed && engine.state.generation == plan.generation && engine.pendingSpecial?.id == plan.id
            && specialPresentationID == plan.id
    }

    private func playReservedSpecial(_ plan: NativeSpecialMovePlan) {
        guard specialPresentationID != plan.id,let geometry else { return }
        specialPresentationID = plan.id;specialPresentationVariant = plan.variant
        specialPresentationIDs = Set(plan.targets.map(\.id))
        let receipt = beginVisual(); navigationLocked = true; onRenderingDemand?(true)
        if plan.archetype == .magnet {
            if sourceMagnetPullScope != nil {
                if !startSourceMagnetPull(plan,receipt:receipt) {onPresentationFailure?("source_magnet_actual_pull_not_bound")}
                return
            }
            let target = geometry.center(row: plan.destination.cell.row,column: plan.destination.cell.column)
            let pairs = plan.targets.enumerated().compactMap { index,tile -> (NativeDiceNode,NativeMagnetPullMotion)? in
                guard let node = nodesByID[tile.id] else { return nil }
                node.removeAllActions(); node.visual.removeAllActions()
                return (node,NativeMagnetPullMotion(start: node.position,destination: target,tileSize: geometry.tileSize,
                                                   baseScale: geometry.scale,index: index,count: plan.targets.count))
            }
            var arrived = Set<String>()
            let owner = SKNode(); effects.addChild(owner)
            if sourceMagnetBindings != nil {sourceMagnetPullCarriers[plan.id]=owner;sourceMagnetPullFlagOwner=(plan.id,plan.generation)}
            let duration = pairs.map { $0.1.end }.max() ?? 0
            owner.run(.sequence([.customAction(withDuration: max(0.001,duration)) { [weak self,weak owner] _,elapsed in
                guard let self,self.specialIsCurrent(plan) else { owner?.removeAllActions(); owner?.removeFromParent(); return }
                for (node,motion) in pairs where !arrived.contains(node.tileID) {
                    let pose = motion.sample(time: Double(elapsed))
                    node.position = pose.point; node.setScale(pose.scale); node.visual.zRotation = pose.rotation
                    if pose.converged { arrived.insert(node.tileID) }
                }
                if arrived.count == pairs.count {
                    owner?.removeAllActions()
                    self.onSpecialMoment?(plan.variant ?? "magnet","pull",plan.targets.count)
                    self.smoke(at: target,special: true)
                    self.specialPresentationIDs.removeAll()
                    guard self.beginSourceMagnetHelper(plan) else {self.onPresentationFailure?("source_magnet_helper_producer_missing");return}
                    let previous = self.engine.state
                    let prepared:NativeMoveResult
                    if let scope=self.sourceMagnetLazyScope {
                        prepared=self.engine.prepareSourceMagnetLazyRespawn(transactionID:plan.id,generation:plan.generation,sourceCurrent:{[weak self,scope] in
                            guard let self,self.sourceAnimationBindingAdmissionOpen,self.sourceMagnetLazyScope === scope else{return false}
                            return scope.current && self.specialIsCurrent(plan) && self.engine.sourceSpecialAbsorbMainEntered
                        })
                    } else {prepared=self.engine.prepareMagnetRespawn(transactionID:plan.id)}
                    self.consume(prepared,previous: previous)
                    if !prepared.accepted {self.sourceMagnetHelpers[plan.id]?.retire();return}
                    self.startMagnetRespawn(plan,receipt: receipt,owner: owner)

                }
            },.removeFromParent()]))
        } else if plan.archetype == .tnt {
            let blastIDs=Set(engine.state.tiles.filter {$0.id != plan.destination.id && ($0.value>0 || $0.isWild) && !$0.locked}.map(\.id))
            // The already-painted source absorb owns the same 80ms boundary.
            run(.sequence([.wait(forDuration:0.08),.run { [weak self] in
                guard let self,self.specialIsCurrent(plan) else {return}
                let previous=self.engine.state
                let activated=self.engine.commitSpecialActivation(transactionID:plan.id)
                self.consume(activated,previous:previous)
                guard activated.accepted else {return}
                if plan.variant == "laser-gun" {self.startLaserImpacts(plan,receipt:receipt)}
                else {self.playCoreTntTransaction(plan,receipt:receipt,geometry:geometry,blastIDs:blastIDs)}
            }]),withKey:"native-special-activation")
        }
    }

    private func startMagnetRespawn(_ plan: NativeSpecialMovePlan,receipt: UInt64,owner: SKNode?) {
        guard specialIsCurrent(plan) else { return }
        if sourceMagnetBindings != nil {
            if !startSourceMagnetRespawn(plan,receipt:receipt,carrier:owner) {onPresentationFailure?("source_magnet_replacement_producer_not_bound")}
            return
        }
        let count = engine.pendingMagnetRespawn?.replacements.count ?? 0
        var actions: [SKAction] = [.wait(forDuration: 0.05)]
        for index in 0..<count {
            if index > 0 { actions.append(.wait(forDuration: 0.15)) }
            actions.append(.run { [weak self] in
                guard let self,self.specialIsCurrent(plan) else { return }
                let previous = self.engine.state
                let result = self.engine.commitMagnetReplacement(transactionID: plan.id,index: index)
                self.consume(result,previous: previous)
            })
        }
        // Exact openAtCell scale timeline .56 plus source per-spawn validation
        // wait .05; only the survivor bounce is a post-commit decorative tail.
        actions += [.wait(forDuration: 0.56+0.05),.run { [weak self,weak owner] in
            guard let self,self.specialIsCurrent(plan) else { owner?.removeFromParent(); return }
            let previous = self.engine.state
            let result = self.engine.commitSpecialBoard(transactionID: plan.id)
            if result.accepted {
                if let helper=self.sourceMagnetHelpers[plan.id] {
                    helper.boardCommitted(spawnCount:count,shouldRunPostCheck:true,publish:{[weak self] in self?.sourceSpecialTransactions?.boardCommitted(id:plan.id,generation:plan.generation)})
                }else {self.sourceSpecialTransactions?.boardCommitted(id:plan.id,generation:plan.generation)}
            }
            self.specialPresentationID = nil
            self.consume(result,previous: previous)
            self.navigationLocked = self.engine.state.terminal != nil || self.pendingTerminal != nil
            self.finishVisual(receipt); owner?.removeFromParent()
        }]
        owner?.run(.sequence(actions),withKey: "captured-magnet-respawn")
    }

    private func playCoreTntTransaction(_ plan: NativeSpecialMovePlan,receipt: UInt64,geometry: NativeBoardGeometry,blastIDs:Set<String>) {
        let center = geometry.center(row: plan.destination.cell.row,column: plan.destination.cell.column)
        let blastNodes = engine.state.tiles.compactMap { tile -> NativeDiceNode? in
            guard blastIDs.contains(tile.id),tile.id != plan.source.id,tile.id != plan.destination.id,tile.value > 0 || tile.isWild,
                  !tile.locked || plan.targets.contains(where: { $0.id == tile.id }) else { return nil }
            return nodesByID[tile.id]
        }
        specialPresentationIDs.formUnion(blastNodes.map(\.tileID))
        let returnPlans = blastNodes.map { node -> (NativeDiceNode,CGPoint,Double,Double) in
            let rest = node.position,dx = rest.x-center.x,dy = rest.y-center.y,distance = hypot(dx,dy)
            let angle = distance < 1 ? CGFloat.random(in: 0..<(2 * .pi)) : atan2(dy,dx)
            let strength = geometry.tileSize*0.4*CGFloat.random(in: 1..<1.3)
            let destination = CGPoint(x: rest.x+cos(angle)*strength,y: rest.y+sin(angle)*strength)
            let backDuration = Double.random(in: 0.58..<0.7),elastic = Double.random(in: 0.14..<0.22)
            let outDuration = Double.random(in: 0.62..<0.76)
            node.removeAllActions()
            node.run(NativeBoardMotion.move(from: rest,to: destination,duration: outDuration,ease: .elasticOut(1,elastic)),withKey: "tnt-blast")
            return (node,rest,backDuration,elastic)
        }
        var returned = false
        let beginReturn: () -> Void = { [weak self] in
            guard let self,self.specialIsCurrent(plan),!returned else { return }; returned = true
            var pending = returnPlans.count
            let returnFinished: () -> Void = { [weak self] in
                guard let self,self.specialIsCurrent(plan) else { return }
                pending -= 1
                if pending <= 0 { self.specialPresentationIDs.removeAll(); self.startCoreTntImpacts(plan,receipt: receipt) }
            }
            if returnPlans.isEmpty { self.specialPresentationIDs.removeAll(); self.startCoreTntImpacts(plan,receipt: receipt) }
            for (node,rest,duration,elastic) in returnPlans {
                node.removeAction(forKey: "tnt-blast")
                node.run(.sequence([NativeBoardMotion.move(from: node.position,to: rest,duration: duration,ease: .elasticOut(0.6,elastic)),
                    .run(returnFinished)]),withKey: "tnt-return")
            }
        }
        if let variant = plan.variant,let onAuthoredTntPresentation {
            let finaleReceipt = beginVisual()
            let accepted = onAuthoredTntPresentation(variant,CGPoint(x:center.x,y:size.height-center.y),plan.generation,beginReturn) { [weak self] in
                self?.sourceSpecialTransactions?.tntVisualComplete(id:plan.id,generation:plan.generation)
                self?.finishVisual(finaleReceipt)
            }
            if !accepted { finishVisual(finaleReceipt) }
            // An unavailable renderer cannot fabricate a zero-duration phase.
            // Admission rejects this path before reservation; defensive failure
            // remains observable until background settlement cancels its plan.
            if !accepted { NSLog("[NativeTNT] authored owner unavailable %@",variant) }
        } else {
            let owner = NativeTntFinale(textures: textures,fontName: finaleFontName,viewport: size,showsTitle: onTntGlyphClock == nil)
            configureTntGlyphClock(owner); owner.zPosition = 999998; effects.addChild(owner)
            let finaleReceipt = beginVisual(); owner.play { [weak self] in
                self?.sourceSpecialTransactions?.tntVisualComplete(id:plan.id,generation:plan.generation)
                self?.finishVisual(finaleReceipt)
            }
            // Source frame 6 completes at .07 + 5*.04 + .24 = .51.
            run(.sequence([.wait(forDuration:0.51),.run(beginReturn)]),withKey:"special-tnt-frame6")
        }
    }

    private func startLaserImpacts(_ initial:NativeSpecialMovePlan,receipt:UInt64) {
        guard specialIsCurrent(initial),let geometry,let onAuthoredLaserImpact else {return}
        let previous=engine.state,reserved=engine.reserveTntTargets(transactionID:initial.id)
        consume(reserved,previous:previous)
        guard reserved.accepted,let plan=engine.pendingSpecial else {return}
        let targets=engine.pendingLaserShots.compactMap {shot->NativeLaserVisualTarget? in
            guard let tile=plan.targets.first(where:{$0.id == shot.tileID}) else {return nil}
            let point=geometry.center(row:tile.cell.row,column:tile.cell.column)
            return NativeLaserVisualTarget(tileID:tile.id,point:CGPoint(x:point.x,y:size.height-point.y),shooter:shot.shooter)
        }
        guard targets.count == plan.targets.count,!targets.isEmpty else {return}
        specialPresentationIDs=Set(plan.targets.map(\.id))
        var pendingSpawns=Set<String>(),allContacts=false,committed=false
        let completeGameplay:() -> Void = { [weak self] in
            guard let self,self.specialIsCurrent(plan),allContacts,pendingSpawns.isEmpty,!committed else {return}
            committed=true
            let previous=self.engine.state,result=self.engine.commitSpecialBoard(transactionID:plan.id)
            if result.accepted {self.sourceSpecialTransactions?.tntGameplayComplete(id:plan.id,generation:plan.generation)}
            self.specialPresentationID=nil;self.specialPresentationIDs.removeAll();self.laserSpawnCallbacks.removeAll()
            self.consume(result,previous:previous)
            self.navigationLocked=self.engine.state.terminal != nil || self.pendingTerminal != nil
            self.finishVisual(receipt)
        }
        let impact:(Int,String) -> Bool = { [weak self] index,id in
            guard let self,self.specialIsCurrent(plan),targets.indices.contains(index),targets[index].tileID == id else {return false}
            pendingSpawns.insert(id)
            self.laserSpawnCallbacks[id] = { [weak self] in
                guard let self,self.specialIsCurrent(plan) else {return}
                pendingSpawns.remove(id);completeGameplay()
            }
            let previous=self.engine.state,result=self.engine.commitSpecialImpact(transactionID:plan.id,tileID:id)
            self.consume(result,previous:previous)
            guard result.accepted else {self.laserSpawnCallbacks.removeValue(forKey:id);pendingSpawns.remove(id);return false}
            self.onSpecialMoment?("laser-gun","impact",index)
            if index==0 || index==targets.count-1 {self.onHaptic?("heavy")}
            if let tile=plan.targets.first(where:{$0.id==id}) {self.smoke(at:geometry.center(row:tile.cell.row,column:tile.cell.column),special:false)}
            return true
        }
        let visualReceipt=beginVisual()
        let mounted=onAuthoredLaserImpact(targets,plan.generation,impact,{allContacts=true;completeGameplay()}) { [weak self] in
            self?.sourceSpecialTransactions?.tntVisualComplete(id:plan.id,generation:plan.generation)
            self?.finishVisual(visualReceipt)
        }
        guard mounted else {finishVisual(visualReceipt);return}
        let beforeRelease=engine.state,released=engine.releaseTntReservation(transactionID:plan.id)
        if released.accepted {sourceSpecialTransactions?.boardCommitted(id:plan.id,generation:plan.generation)}
        consume(released,previous:beforeRelease)
    }

    private func startCoreTntImpacts(_ initial: NativeSpecialMovePlan,receipt: UInt64) {
        guard specialIsCurrent(initial) else { return }
        let beforeReserve=engine.state
        let reserved=engine.reserveTntTargets(transactionID:initial.id)
        consume(reserved,previous:beforeReserve)
        guard reserved.accepted,let plan=engine.pendingSpecial else {return}
        specialPresentationIDs=Set(plan.targets.map(\.id))
        let beforeRelease = engine.state
        let released = engine.releaseTntReservation(transactionID:plan.id)
        if released.accepted {sourceSpecialTransactions?.boardCommitted(id:plan.id,generation:plan.generation)}
        consume(released,previous:beforeRelease)
        let owner = SKNode(); effects.addChild(owner)
        let delays = plan.variant == "beach-ball" ? [0.0,0.26,0.56,0.9] : [0.0,0.2,0.4,0.6]
        let initialDelay = plan.variant == "flower" ? 0.7 : plan.variant == "barell" ? 0.2 : 0
        var actions: [SKAction] = initialDelay > 0 ? [.wait(forDuration:initialDelay)] : []
        for (index,tile) in plan.targets.enumerated() {
            if index > 0 { actions.append(.wait(forDuration:delays[index]-delays[index-1])) }
            actions.append(.run { [weak self] in
                guard let self,self.specialIsCurrent(plan) else { return }
                let previous = self.engine.state
                let result = self.engine.commitSpecialImpact(transactionID: plan.id,tileID: tile.id)
                self.consume(result,previous: previous)
                if result.accepted,let geometry = self.geometry {
                    self.onSpecialMoment?(plan.variant ?? "tnt","impact",index)
                    if index == 0 || index == plan.targets.count-1 { self.onHaptic?("heavy") }
                    self.smoke(at: geometry.center(row: tile.cell.row,column: tile.cell.column),special: false)
                }
            })
        }
        actions += [.wait(forDuration: 0.56+0.08),.run { [weak self,weak owner] in
            guard let self,self.specialIsCurrent(plan) else { owner?.removeFromParent(); return }
            let previous = self.engine.state
            let result = self.engine.commitSpecialBoard(transactionID: plan.id)
            if result.accepted {self.sourceSpecialTransactions?.tntGameplayComplete(id:plan.id,generation:plan.generation)}
            self.specialPresentationID = nil; self.specialPresentationIDs.removeAll()
            self.consume(result,previous: previous)
            self.navigationLocked = self.engine.state.terminal != nil || self.pendingTerminal != nil
            self.finishVisual(receipt); owner?.removeFromParent()
        }]
        owner.run(.sequence(actions),withKey: "tnt-captured-impacts")
    }

    override func update(_ currentTime: TimeInterval) {
        guard !sourceDisposalInProgress else {return}
        guard !disposed, !suspended else { lastFrame = nil; return }
        let rawMilliseconds=CACurrentMediaTime()*1000,configuredFPS=Double(view?.preferredFramesPerSecond ?? 60)
        if !sourceFramesAttached {
            sourceFramesAttached=true;sourceFrames.attach(rendererID:1,nowMs:rawMilliseconds,configuredFPS:configuredFPS)
        } else {sourceFrames.frame(nowMs:rawMilliseconds,configuredFPS:configuredFPS)}
        if let receipt=hudEntryReceipt {
            if receipt.generation != engine.state.generation {cancelEntry()}
            else if hudEntryReveal.renderedCallback(receipt) {startHUDDrop(receipt)}
        }
        let elapsedDelta=lastFrame.map {max(0,currentTime-$0)} ?? 0
        let delta=min(0.05,elapsedDelta)
        // GSAP's source ticker uses full elapsed time for sub500ms hitches,
        // and its default lag smoothing substitutes33ms after larger stalls.
        let fizzDelta=elapsedDelta>0.5 ? 0.033:elapsedDelta
        lastFrame = currentTime
        if !sourceFrames.isSpecialIdleSuspended {textures.advanceIdlePhases()}
        for node in nodesByID.values where node.hasAnimatedArtwork {
            node.tick(delta, suspended: sourceFrames.isSpecialIdleSuspended || engine.state.terminal != nil || exitInProgress || specialPresentationIDs.contains(node.tileID), viewportCenter: size.width / 2,fizzDelta:fizzDelta)
        }
    }

    override func didFinishUpdate() {
        if let binding=sourceMicrotaskInstallation {
            _=binding.renderedHandoff{[self] in sourceDidFinishUpdate()}
        } else {sourceDidFinishUpdate()}
    }
    private func sourceDidFinishUpdate() {
        guard !disposed, !suspended else { return }
        sourceMeterRenderEpoch &+= 1
        sourceMeterCaller?.painted(epoch:sourceMeterRenderEpoch,
            onscreen:view?.window != nil && view?.isHidden==false && view?.isPaused==false,
            contains:{[weak self] node in guard let self else{return false}
                return self.nodesByID[node.tileID] === node && node.parent === self.canvasRoot && !node.isHidden && node.alpha>0
            })
        publishFishIdleFrames()
        // The one visible ticker remains alive at source15/30/60. Individual
        // actions/resources do not create fabricated generic activity marks.
    }

    func setSuspended(_ value: Bool) {
        guard !sourceDisposalInProgress else {return }
        guard !disposed else {return}
        suspended=value;lastFrame=nil
        sourceCallbackTime();sourceFrames.visibilityChanged(hidden:value)
        for owner in regularSixPresentations.values {owner.setSuspended(value)}
        // Original pauseGame pauses the global animation timeline and stops
        // the Pixi renderer ticker; foreground GSAP transport keeps ticking.
        // It does not complete/drain accepted transactions or
        // remove HUD-star, spawn, meter, candidate or drag owners.
        isPaused=value;onRenderingDemand?(!value)
        if !value && !exitInProgress {
            synchronize();releaseFinalDirectIfReady()
            if !sourceHUDStarJobsPresentationEnabled {startHUDStarFlights(ids:engine.pendingHUDStars.map(\.id))} // Source resume retains real jobs; it never recreates earned flights.
            evaluate();publishPendingTerminal()
        }
    }

    func handleMemoryWarning() {
        guard !sourceDisposalInProgress else {return}
        guard !disposed, activeTouch == nil, !hasActions(), effects.children.isEmpty,
              !nodesByID.values.contains(where: { $0.hasPresentationActions }) else { return }
        var paths: Set<String> = ["assets/tile.png", "assets/shadow.png", "assets/paper-bg.png", "assets/close-icon.png", "assets/hud/help.png", "assets/hud/score-hud.png","assets/hud/combo-hud.png","assets/hud/extra-combo-hud.png","assets/hud/mega-combo-hud.png"]
        for node in nodesByID.values { paths.formUnion(node.resourcePaths) }
        textures.purgeUnused(retaining: paths)
    }

    func animateExit(completion: @escaping (Bool) -> Void) {
        guard !sourceDisposalInProgress else {completion(false); return }
        guard !disposed, !exitInProgress else { completion(false); return }
        cancelEntry(restoreHUD:false); cancelDrag(); cancelCandidate(); inputAdmitted = false; navigationLocked = true
        retireSourceSpawns()
        roundIndicator.exit()
        exitInProgress = true; exitCompletion = completion
        engine.setInputLock("native-board-exit",active: true)
        suspended = false; isPaused = false; onRenderingDemand?(true)
        let generation = engine.state.generation
        sourceCallbackTime();sourceExit=sourceFrames.begin(.init(kind:.boardExit,generation:generation,id:UUID().uuidString))
        let hudCapture=sourceFrames.begin(.init(kind:.hudExit,generation:generation,id:UUID().uuidString));sourceHUDExit=hudCapture
        let targets: [SKNode] = nodesByID.values.sorted { $0.tileID < $1.tileID } + ghosts.children
        let plans = NativeBoardExitPlan.make(count: targets.count)
        exitOwners = targets.count + 1
        for plan in plans {
            let node = targets[plan.tileIndex]
            node.removeAllActions()
            if let die = node as? NativeDiceNode { die.visual.removeAllActions(); die.visual.setScale(1) }
            let base = CGPoint(x: node.xScale,y: node.yScale)
            let small = CGPoint(x: base.x*0.88,y: base.y*0.88)
            let peak = CGPoint(x: base.x*plan.peak,y: base.y*plan.peak)
            node.run(.sequence([.wait(forDuration: plan.delay),
                NativeBoardMotion.scale(from: base,to: small,duration: plan.settle,ease: .backIn(1.5)),
                .group([
                    .sequence([NativeBoardMotion.scale(from: small,to: peak,duration: plan.compress,ease: .power2In),
                        NativeBoardMotion.scale(from: peak,to: .zero,duration: plan.collapse,ease: .backIn(2))]),
                    .fadeOut(withDuration: max(0.12,plan.collapse*0.68))
                ]),.run { [weak self] in self?.finishExitOwner(generation: generation) }]),withKey: "board-exit")
        }
        let start=NativeHUDTransitionMotion.Pose(offset:Double(hud.position.y),alpha:Double(hud.alpha))
        let top=Double(NativeGameplayChromePlan.make(viewport:size,safeTop:safeInsets.top).hudTop)
        hud.run(.sequence([.customAction(withDuration:NativeHUDTransitionMotion.riseDuration) { node,time in
            let pose=NativeHUDTransitionMotion.rise(at:Double(time),top:top,from:start)
            node.position.y=CGFloat(pose.offset);node.alpha=CGFloat(pose.alpha)
        },.run { [weak self] in
            guard let self else{return};self.sourceCallbackTime();self.sourceFrames.end(hudCapture)
            if self.sourceHUDExit === hudCapture {self.sourceHUDExit=nil}
            self.finishExitOwner(generation:generation)
        }]),withKey:"hud-exit")
    }

    private func finishExitOwner(generation: UInt64) {
        guard !disposed, exitInProgress, engine.state.generation == generation else { return }
        exitOwners = max(0,exitOwners-1)
        if exitOwners == 0 { finishExit(completed: true) }
    }

    private func finishExit(completed: Bool) {
        sourceCallbackTime()
        if let capture=sourceExit {sourceExit=nil;sourceFrames.end(capture)}
        if let capture=sourceHUDExit {sourceHUDExit=nil;sourceFrames.end(capture)}
        guard exitInProgress else { return }
        exitInProgress = false; exitOwners = 0
        if sourceDisposalGeneration == nil || sourceDisposalGeneration == engine.state.generation {engine.setInputLock("native-board-exit",active: false)}
        if !completed {
            roundIndicator.cancelExit()
            for node in nodesByID.values { node.removeAllActions(); node.visual.setScale(1) }
            for ghost in ghosts.children { ghost.removeAllActions(); ghost.setScale(1) }
            hud.removeAllActions(); hud.position = .zero; hud.alpha = 1
        }
        let completion = exitCompletion; exitCompletion = nil
        completion?(completed)
    }

    func retireSourceAnimationBindings() {
        retireSourceEndgameMutationLedger()
        retireSourceCanonicalSave()
        // Scope replacement retires ONLY source bindings. Authored raw board
        // exit/family owners remain alive on the current painted old surface.
        guard sourceAnimationBindingAdmissionOpen else{return}
        let previousSealing=sourceOuterTearingDown
        sourceOuterTearingDown=true // seal BEFORE every captured cancellation callback
        retireSourceHUDStarJobs()
        let initial=sourceInitialConstruction;sourceInitialConstruction=nil;sourceInitialEntryPending=false;initial?.dispose()
        retireSourceSpecialIdleBindings()
        retireSourceSixBindings()
        retireSourceSpecialTransactions()
        retireSourceMeterOpenBinding()
        defer {if !disposed {sourceOuterTearingDown=previousSealing}}
        sourceOuterTimelineDriver=nil;sourceDragTweenDriver=nil
        retireSourceStackHandoff()
        sourceContactVisualRandom=nil;sourceStackAbsorbAdmission=nil
        let companions=sourceRegularContactCompanions;sourceRegularContactCompanions=nil
        onSourceStackContactPrefix=nil;onSourceStackContactSuffix=nil
        if !sourceAcceptedStacks.isEmpty {retireSourceAcceptedStacks()}
        companions?.dispose()
        let captured=Array(nodesByID.values)
        for node in captured {node.retireSourceAnimationBindingsPreservingPaint()}
    }

    func dispose() {
        guard !disposed,!sourceDisposalInProgress else {return}
        let sourceLifetime = sourceInitialConstruction != nil || sourceMicrotaskInstallation != nil || sourceDisposalSealingEnabled || sourceOuterTimelineDriver != nil || sourceDragTweenDriver != nil || sourceRegularContactCompanions != nil || sourceSameNodeStackAbsorbsEnabled || sourceOuterTearingDown
        // A destructive request during Source scope retirement must still run
        // its full cleanup; only a recursive destructive request is coalesced.
        if !sourceLifetime && sourceOuterTearingDown {return}
        if sourceLifetime {
            sourceDisposalGeneration=lastGeneration ?? engine.state.generation
            sourceDisposalInProgress=true;sourceOuterTearingDown=true
        }
        retireSourceEndgameMutationLedger()
        let initial=sourceInitialConstruction;sourceInitialConstruction=nil;sourceInitialEntryPending=false;initial?.dispose()
        retireSourceSpecialIdleBindings()
        retireSourceSixBindings()
        sourceNoMovesDestroyed=true
        retireSourceHUDStarJobs()
        retireSourceCanonicalSave()
        retireSourceNoMoves()
        sourceMeterTearingDown=true
        retireSourceSpecialTransactions()
        retireSourceMeterOpenBinding()
        if sourceSameNodeStackAbsorbsEnabled || !sourceAcceptedStacks.isEmpty {retireSourceAcceptedStacks()}
        retireSourceStackHandoff()
        sourceRegularContactCompanions?.dispose();sourceRegularContactCompanions=nil;sourceContactVisualRandom=nil;sourceStackAbsorbAdmission=nil
        sourceOuterTimelineDriver=nil;sourceDragTweenDriver=nil;onSourceStackContactPrefix=nil;onSourceStackContactSuffix=nil
        invalidateWildTransports()
        retireRegularSixPresentations()
        finishExit(completed: false)
        cancelEntry(); cancelDrag(); cancelCandidate(); disposed = true
        retireSourceSpawns()
        sourceFrames.stop();sourceGameplay.removeAll();sourceRegularHandoffMutationReceipts.removeAll();sourcePopulation.removeAll();sourceStars=nil;onFrameTarget=nil;onSpecialIdleSuspended=nil
        if sourceDisposalGeneration == nil || sourceDisposalGeneration == engine.state.generation {engine.setInputLock("native-board-entry-handoff",active:false)};preparedEntryGeneration=nil
        specialPresentationIDs.removeAll(); specialPresentationID = nil;directPresentationID=nil;directPresentationVariant=nil;directFinalReceipt=nil
        ordinaryAbsorbs.removeAll();ordinaryPostchecks.removeAll();ordinarySpawnVisuals.removeAll();ordinaryDeferred.removeAll();ordinaryPrimaryVisuals.removeAll();ordinarySixVisual=nil
        pendingTerminal = nil; pendingTerminalGeneration = nil; visualLifetime += 1; visualOwners = 0
        removeAllActions(); retireEffects(); nodesByID.values.forEach { $0.dispose() }
        nodesByID.removeAll();meterTimeoutIDs.removeAll(); removeAllChildren(); textures.dispose()
        onFishIdleFrames?([:],engine.state.generation,true);onFishIdleFrames=nil
        onJourneyBottomDecorShake=nil;onPresentationFailure=nil;onStateChange = nil; onTerminal = nil; onGameplayEvent = nil; onGameplayReceipt = nil; onSpecialMoment = nil; onAuthoredFinale = nil;onAuthoredTntPresentation = nil;onAuthoredLaserImpact=nil;authoredTntPresentationReady = nil;authoredFinalePresentationReady=nil;onSpecialPresentationCancelled = nil; onTntGlyphClock = nil; onSplashGlyphClock = nil; onHaptic = nil
        onLevelFlowBounceCompletion=nil;onExitRequest = nil; onHelpRequest = nil; onScoreRequest = nil; onComboRequest = nil; onPointerState = nil; onRenderingDemand = nil; onBoardEntry = nil; onHUDDrop = nil
    }
}
