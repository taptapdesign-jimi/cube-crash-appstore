const fs=require('fs'),vm=require('vm'),ts=require('/Users/user/cube-crash/node_modules/typescript'),root='/tmp/native-magnet-accounting-draft';
const app=fs.readFileSync(root+'/OriginalAppCore.ts','utf8'),merge=fs.readFileSync(root+'/OriginalAppMerge.ts','utf8'),helpers=fs.readFileSync(root+'/OriginalHUDHelpers.ts','utf8');
const slice=(s,a,b)=>{const p=s.indexOf(a),e=s.indexOf(b,p);if(p<0||e<0)throw Error(a);return s.slice(p,e)};
const main=slice(app,'        // countdown moves (this happens for both normal and pulled tiles merge)','        // COLLECTIBLES: Dispatch event');
const body=slice(merge,'  // Update score - CRITICAL: Use window.CC.setScore','  // 🔥 USER REQUEST: Track longest combo after magnet pull');
const bodyStats=slice(merge,'  // Stats - track cubes cracked for magnet pull merge','  console.log(\'✅ mergePulledTilesIntoMerge6 completed');
const h=ts.transpile(slice(helpers,'export function hudSetCombo(','/**'),{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS});
const x={exports:{}};vm.createContext(x);vm.runInContext(h,x);
const rows=[];
for(const count of [1,2,3,4])for(const combo0 of [0,2,97])for(const score0 of [0,999990])for(const moves0 of [0,10]){
 const ctx={score:score0,moves:moves0,combo:combo0,STATE:{score:score0},mult:Math.min(4,count+1),isWildMagnet:true,dst:{},SCORE_CAP:999999,boardNumber:10,wasWild:true,pulledTileCount:count,
  console:{log(){},warn(){},error(){}},logger:{debug(){}},devLog(){},statsService:{incrementCubesCracked(n){ctx.cracks+=n},incrementHelpersUsed(n){ctx.helpers+=n},updateLongestCombo(){},updateHighScore(){}},cracks:0,helpers:0,
  isFirstPlayTutorialRunActive:()=>false,isArcadeHomeRunMode:()=>false,trackBoardCubesCracked(){},animateBoardHUD(){},animateScore(){},HUD:{bumpCombo(){}},updateHUD(){},window:{CC:{}},timer:0};
 ctx.window.CC={getCombo:()=>ctx.combo,getScore:()=>ctx.score,setScore:v=>ctx.score=v,setCombo:v=>ctx.combo=x.exports.hudSetCombo(v,99),killComboTimer:()=>ctx.timer=0,scheduleComboDecay:ms=>ctx.timer=ms};
 vm.createContext(ctx);vm.runInContext(ts.transpile(main,{target:ts.ScriptTarget.ES2020}),ctx,{importModuleDynamically:()=>Promise.reject(Error('stats import intentionally isolated'))});
 const mainResult={score:ctx.score,moves:ctx.moves,combo:ctx.combo,cracks:ctx.cracks,helpers:ctx.helpers,timer:ctx.timer};
 ctx.mult=4;vm.runInContext(ts.transpile(body,{target:ts.ScriptTarget.ES2020}),ctx);vm.runInContext(ts.transpile(bodyStats,{target:ts.ScriptTarget.ES2020}),ctx);
 rows.push({count,combo0,score0,moves0,main:mainResult,body:{score:ctx.score,moves:ctx.moves,combo:ctx.combo,cracks:ctx.cracks,helpers:ctx.helpers,timer:ctx.timer}});
}
fs.writeFileSync(root+'/SourceMagnetAccounting.json',JSON.stringify(rows,null,2));console.log('PASS original main/helper statement execution '+rows.length+' cases; no Native math used');
