import XCTest
import StackToSixGameplay

@MainActor final class NativeSourceRegularSixCleanupCoreTests:XCTestCase {
 private func make(enabled:Bool=true)throws->(NativeGameplayEngine,NativeOrdinaryMovePlan) {
  let e=NativeGameplayEngine(state:.init(tiles:[.init(id:"s",cell:.init(column:0,row:0),value:2),.init(id:"d",cell:.init(column:1,row:0),value:4),.init(id:"other",cell:.init(column:2,row:0),value:3)]))
  e.stagedOrdinaryMoves=true;e.stagedOrdinaryAssignments=true;e.sourceRegularSixCleanupReceiptsEnabled=enabled
  XCTAssertTrue(e.beginDrag(tileID:"s"));XCTAssertTrue(e.drop(target:.init(column:1,row:0)).accepted)
  return(e,try XCTUnwrap(e.pendingOrdinarySix))
 }
 func testSourceWatchdogRetiresOnlyDestinationBeforeActualMainAndNeverScoresOrSpawns()throws {
  let(e,p)=try make();let receipt=try XCTUnwrap(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:1)),before=e.state
  let result=e.settleSourceRegularSixCleanup(receipt,removeDestination:true)
  XCTAssertTrue(result.accepted);XCTAssertEqual(result.events.flatMap(\.tileIDs),["d"])
  XCTAssertNil(e.state.tiles.first{$0.id=="d"});XCTAssertNotNil(e.state.tiles.first{$0.id=="s"})
  XCTAssertEqual(e.state.score,before.score);XCTAssertEqual(e.state.moves,before.moves);XCTAssertEqual(e.state.rngState,before.rngState)
  XCTAssertTrue(e.sourceRegularSixDestinationDestroyed(receipt));XCTAssertEqual(e.pendingOrdinarySix,p)
  XCTAssertTrue(e.pendingOrdinaryAssignments.isEmpty);XCTAssertTrue(e.pendingHUDStars.isEmpty)
  let main=e.finishSourceSixDestroyedDestination(receipt)
  XCTAssertTrue(main.accepted);XCTAssertEqual(main.events.flatMap(\.tileIDs),["s"])
  XCTAssertEqual(e.state.tiles.map(\.id),["other"]);XCTAssertNil(e.pendingOrdinarySix)
  XCTAssertEqual(e.state.moves,before.moves);XCTAssertEqual(e.state.score,before.score);XCTAssertEqual(e.state.rngState,before.rngState)
  XCTAssertFalse(e.finishSourceSixDestroyedDestination(receipt).accepted)
 }
 func testReleaseOnlyIsNotDestinationRemovalOrPrematureMainArrival()throws {
  let(e,p)=try make();let r=try XCTUnwrap(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:1))
  XCTAssertTrue(e.settleSourceRegularSixCleanup(r,removeDestination:false).accepted)
  XCTAssertNotNil(e.state.tiles.first{$0.id=="d"});XCTAssertNotNil(e.state.tiles.first{$0.id=="s"})
  XCTAssertFalse(e.sourceRegularSixDestinationDestroyed(r));XCTAssertFalse(e.finishSourceSixDestroyedDestination(r).accepted)
  XCTAssertTrue(e.commitOrdinarySix(receiptID:p.id,generation:p.generation).accepted)
 }
 func testRawDefaultMissingClaimAndLateGenerationRefuseAllNewReceipts()throws {
  let(e,p)=try make(enabled:false)
  XCTAssertNil(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:1))
  e.sourceRegularSixCleanupReceiptsEnabled=true
  XCTAssertNil(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:0))
  let r=try XCTUnwrap(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:1))
  XCTAssertNil(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:2))
  e.restart(state:e.state)
  XCTAssertFalse(e.settleSourceRegularSixCleanup(r,removeDestination:true).accepted)
  XCTAssertFalse(e.finishSourceSixDestroyedDestination(r).accepted)
 }
 func testActualExplicitMainInterruptionRetiresWatchdogIdentityWithoutWatchdogScoring()throws {
  let(e,p)=try make();let r=try XCTUnwrap(e.registerSourceRegularSixCleanup(ownerID:p.id,generation:p.generation,token:1))
  XCTAssertTrue(e.settleSourceRegularSixCleanup(r,removeDestination:true).accepted)
  XCTAssertTrue(e.cancelSourceMergeSixAbsorb(receiptID:p.id,generation:p.generation).accepted)
  XCTAssertFalse(e.sourceRegularSixDestinationDestroyed(r));XCTAssertFalse(e.finishSourceSixDestroyedDestination(r).accepted)
  XCTAssertEqual(e.state.score,0);XCTAssertEqual(e.state.moves,50)
 }
}
