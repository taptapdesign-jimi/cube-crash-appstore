import Foundation

/// Installed only after a genuine physical cleanup claim, never by a pending
/// Native plan alone. Does not carry a Date, award, arrival or spawn permit.
public struct NativeSourceRegularSixCleanupReceipt:Equatable,Sendable {
    public let id:UUID,ownerID:String,generation:UInt64,sourceID:String,destinationID:String,token:UInt64
}
