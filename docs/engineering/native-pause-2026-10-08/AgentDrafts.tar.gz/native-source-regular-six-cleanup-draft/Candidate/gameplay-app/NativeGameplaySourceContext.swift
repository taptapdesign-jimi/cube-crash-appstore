import UIKit
import StackToSixGameplay

/// App-lived original visual RNG, smoke hot history and shard pattern pools.
/// Scene scopes borrow the existing union service; they never own its Raw roots.
@MainActor final class NativeGameplaySourceContext {
    let service: NativeSourceAnimationClockService
    let mathRandom:NativeSourceMathRandomStream
    let smokeSession: NativeSharedSmokeRootSession
    let hudStarTextures=NativeSourceHUDStarTexturePreparation()
    let sixResources: NativeRegularSixSharedResources
    let registrySession: NativeGameplaySourceRegistrySession
    let canonicalSave=NativeSourceCanonicalSaveOwner<NativeBoardState>()
    let mutationLedger=NativeSourceAppMutationLedger()
    let regularSixCleanup=NativeSourceRegularSixCleanupOwner()
    let endgameMutations:NativeSourceEndgameMutationLedger
    let contactMutations=NativeSourceContactMutationOwner()
    let specialIdleRegistry=NativeSourceSpecialIdleRegistry()
    let sourceMicrotaskTasks:NativeSourceMicrotaskAdapters?
    private var active: Scope?
    private var epoch: UInt64 = 0
    private var disposed = false

    init(service: NativeSourceAnimationClockService = .shared,
         appOriginMilliseconds: Double = CACurrentMediaTime()*1000,
         visualRandom: @escaping () -> Double = {Double.random(in: 0..<1)},
         sourceDateMilliseconds: @escaping () -> Double = {floor(Date().timeIntervalSince1970*1000)},
         sourceMicrotaskTasks:NativeSourceMicrotaskAdapters?=nil) {
        self.service = service;self.sourceMicrotaskTasks=sourceMicrotaskTasks
        registrySession = NativeGameplaySourceRegistrySession(sourceDateMilliseconds: sourceDateMilliseconds)
        endgameMutations = NativeSourceEndgameMutationLedger(sourceDateMilliseconds:sourceDateMilliseconds)
        let common=NativeSourceMathRandomStream(draw:visualRandom);mathRandom=common
        smokeSession = NativeSharedSmokeRootSession(appOriginMilliseconds: appOriginMilliseconds, visualRandom: {common.next()})
        sixResources = NativeRegularSixSharedResources(smoke: smokeSession)
    }

    func beginScene(engine:NativeGameplayEngine?=nil,retire: @escaping () -> Void) -> Scope? {
        guard !disposed else {return nil}
        epoch &+= 1
        let captured = epoch, previous = active
        active = nil
        previous?.dispose()
        // A retirement callback may have installed a newer Scene.
        guard !disposed, epoch == captured, active == nil else {return nil}
        let binding:NativeSourceAppMutationLedger.Binding?
        if let engine {
            guard let accepted=mutationLedger.bind(engine) else{return nil}
            binding=accepted
        } else {binding=nil}
        let scope = Scope(context: self, epoch: captured, mutationBinding:binding, retire: retire)
        active = scope
        scope.registries.bindParentCurrent { [weak scope] in scope?.current == true }
        return scope
    }

    private func isCurrent(_ scope: Scope) -> Bool { !disposed && active === scope && epoch == scope.epoch }
    private func release(_ scope: Scope) { if active === scope {active = nil} }
    func dispose() {
        guard !disposed else {return}; disposed = true; epoch &+= 1
        let previous = active; active = nil; previous?.dispose()
        registrySession.dispose();canonicalSave.dispose();mutationLedger.dispose();endgameMutations.dispose();contactMutations.dispose();hudStarTextures.dispose();specialIdleRegistry.dispose()
    }
    isolated deinit {active?.dispose();registrySession.dispose();canonicalSave.dispose();mutationLedger.dispose();endgameMutations.dispose();contactMutations.dispose();hudStarTextures.dispose();specialIdleRegistry.dispose()}

    @MainActor final class Scope {
        fileprivate let epoch: UInt64
        private weak var context: NativeGameplaySourceContext?
        let service: NativeSourceAnimationClockService
        let mathRandom:NativeSourceMathRandomStream
        let smokeSession: NativeSharedSmokeRootSession
        let hudStarTextures:NativeSourceHUDStarTexturePreparation
        let sixResources: NativeRegularSixSharedResources
        let registries: NativeGameplaySourceRegistrySession.Scope
        let sourceMicrotaskTasks:NativeSourceMicrotaskAdapters?
        let regularSixCleanup:NativeSourceRegularSixCleanupOwner
        let contactMutations:NativeSourceContactMutationOwner
        let specialIdle:NativeSourceSpecialIdleScope
        private let canonicalSave:NativeSourceCanonicalSaveOwner<NativeBoardState>
        private var canonicalSaveBinding:NativeSourceCanonicalSaveOwner<NativeBoardState>.Binding?
        private var canonicalSaveEpoch:UInt64=0
        private var mutationBinding:NativeSourceAppMutationLedger.Binding?
        private let endgameMutations:NativeSourceEndgameMutationLedger
        private var endgameBinding:NativeSourceEndgameMutationLedger.Binding?
        private var endgameBindingEpoch:UInt64=0
        let timeline: NativeSourceOuterTimelineAdapter
        let tween: NativeSourceDragTweenAdapter
        let smoke: NativeSharedSmokeRootRenderer
        private var retire: (() -> Void)?
        private(set) var disposed = false
        var current: Bool { !disposed && context?.isCurrent(self) == true }
        fileprivate init(context: NativeGameplaySourceContext, epoch: UInt64, mutationBinding:NativeSourceAppMutationLedger.Binding?,retire: @escaping () -> Void) {
            self.context = context; self.epoch = epoch; self.retire = retire
            self.mutationBinding=mutationBinding;sourceMicrotaskTasks=context.sourceMicrotaskTasks
            endgameMutations=context.endgameMutations;regularSixCleanup=context.regularSixCleanup
            registries = context.registrySession.beginScope(epoch: epoch)
            contactMutations=context.contactMutations;canonicalSave=context.canonicalSave
            specialIdle=NativeSourceSpecialIdleScope(registry:context.specialIdleRegistry,current:{[weak context] in
                guard let context,!context.disposed,context.epoch==epoch else{return false}
                return context.active?.epoch==epoch && !context.disposed
            })
            service = context.service; mathRandom=context.mathRandom; smokeSession = context.smokeSession; sixResources = context.sixResources;hudStarTextures=context.hudStarTextures
            timeline = NativeSourceOuterTimelineAdapter(service: service)
            tween = NativeSourceDragTweenAdapter(service: service)
            smoke = smokeSession.makeRenderer(service: service)
        }
        @discardableResult func bindEndgameMutations(current externalCurrent:@escaping()->Bool)->NativeSourceEndgameMutationLedger.Binding? {
            guard current,endgameBinding==nil else{return nil};endgameBindingEpoch &+= 1;let epoch=endgameBindingEpoch
            let binding=endgameMutations.bind(current:{[weak self] in
                guard let self,self.current,self.endgameBindingEpoch==epoch else{return false}
                let accepted=externalCurrent()
                return accepted && self.current && self.endgameBindingEpoch==epoch
            })
            guard current,endgameBindingEpoch==epoch,endgameBinding==nil else{binding?.retire();return nil}
            endgameBinding=binding;return binding
        }
        func retireEndgameMutations(_ binding:NativeSourceEndgameMutationLedger.Binding) {
            guard endgameBinding === binding else{binding.retire();return}
            endgameBinding=nil;endgameBindingEpoch &+= 1;binding.retire()
        }
        @discardableResult func installCanonicalSave(hooks:NativeSourceCanonicalSaveOwner<NativeBoardState>.Hooks)->NativeSourceCanonicalSaveOwner<NativeBoardState>.Binding? {
            guard current else{return nil};canonicalSaveEpoch &+= 1;let e=canonicalSaveEpoch
            let previous=canonicalSaveBinding;canonicalSaveBinding=nil;previous?.retire()
            guard current,canonicalSaveEpoch==e,canonicalSaveBinding==nil else{return nil}
            let sealed=NativeSourceCanonicalSaveOwner<NativeBoardState>.Hooks(current:{[weak self] in
                guard let self,self.current,self.canonicalSaveEpoch==e else{return false}
                let admitted=hooks.current()
                return admitted && self.current && self.canonicalSaveEpoch==e
            },capture:hooks.capture,stillMatches:hooks.stillMatches,write:hooks.write,wall:hooks.wall)
            guard let binding=canonicalSave.install(hooks:sealed) else{return nil}
            let admitted=current
            guard admitted,current,canonicalSaveEpoch==e,canonicalSaveBinding==nil else{binding.retire();return nil}
            canonicalSaveBinding=binding;return binding
        }
        @discardableResult func update(foreground: Bool, globalPaused: Bool, terminalSuspended: Bool) -> Bool {
            guard current else {return false}
            service.setSourceForeground(foreground)
            return service.setSourceGlobalPaused(globalPaused, terminalSuspended: terminalSuspended)
        }
        func dispose() {
            guard !disposed else {return}; disposed = true
            let mutation=mutationBinding;mutationBinding=nil
            mutation?.captureBeforeRetirement() // before ANY external cleanup
            endgameBindingEpoch &+= 1;let endgame=endgameBinding;endgameBinding=nil;endgame?.retire()
            canonicalSaveEpoch &+= 1;let save=canonicalSaveBinding;canonicalSaveBinding=nil;save?.retire()
            context?.release(self)
            specialIdle.dispose()
            registries.dispose() // seal new claims before external caller retirement
            let callback = retire; retire = nil
            // Caller first removes captured Scene bindings, then their roots.
            callback?(); timeline.dispose(); tween.dispose(); smoke.dispose()
        }
        isolated deinit {dispose()}
    }
}
