import Foundation
import SpriteKit
import CoreFoundation

/// Literal app-lived token allocator. The marker belongs to the captured tile;
/// this owner retains no tiles and installs no clock, timeout or resource.
@MainActor final class NativeSourceRegularSixCleanupOwner {
    static let marker="_ccMerge6CleanupToken"
    private(set) var nextToken:UInt64=1
    struct PhysicalFlags {let isLastMerge:Bool;let finalAllowedByResolver:Bool}
    enum WatchdogDecision:Equatable {case stale,refused,releaseOnly,removeCapturedDestination}
    @discardableResult func claim(_ tile:NativeDiceNode)->UInt64? {
        guard tile.sourceContactNodeAlive,nextToken < UInt64.max else{return nil}
        let token=nextToken;nextToken += 1
        if tile.userData==nil {tile.userData=NSMutableDictionary()}
        tile.userData?[Self.marker]=NSNumber(value:token)
        _=protect(tile,token:token);return token
    }
    func owns(_ tile:NativeDiceNode,token:UInt64)->Bool {
        guard tile.sourceContactNodeAlive,let number=tile.userData?[Self.marker] as? NSNumber,
              CFGetTypeID(number) != CFBooleanGetTypeID() else{return false}
        return number.doubleValue==Double(token)
    }
    func hasClaim(_ tile:NativeDiceNode)->Bool {
        guard tile.sourceContactNodeAlive,let number=tile.userData?[Self.marker] as? NSNumber else{return false}
        return CFGetTypeID(number) != CFBooleanGetTypeID()
    }
    @discardableResult func protect(_ tile:NativeDiceNode,token:UInt64)->Bool {
        guard owns(tile,token:token) else{return false}
        tile.sourceEventMode="none"
        // Native touch dispatch is owned by Scene. These literal Source marker
        // values are retained on this object; they do not publish input capability.
        tile.userData?["interactive"]=false;tile.userData?["interactiveChildren"]=false
        tile.userData?["cursor"]="default";return true
    }
    @discardableResult func release(_ tile:NativeDiceNode,token:UInt64)->Bool {
        guard owns(tile,token:token) else{return false}
        tile.userData?.removeObject(forKey:Self.marker);return true
    }
    func forget(_ tile:NativeDiceNode){tile.userData?.removeObject(forKey:Self.marker)}
    /// The two actual flags have mandatory physical-owner provenance. A missing
    /// supplier refuses this path; it never substitutes the old Native plan.
    func watchdog(_ tile:NativeDiceNode,token:UInt64,current:()->Bool,
                  flags:()->PhysicalFlags?)->WatchdogDecision {
        guard owns(tile,token:token) else{return .stale}
        let accepted=current()
        guard accepted,owns(tile,token:token) else{return .stale}
        let captured=flags()
        guard current(),owns(tile,token:token) else{return .stale}
        guard let captured else{return .refused}
        if captured.isLastMerge || captured.finalAllowedByResolver || tile.value != 6 || tile.isSpecial {
            return release(tile,token:token) ? .releaseOnly:.stale
        }
        return release(tile,token:token) ? .removeCapturedDestination:.stale
    }
}
