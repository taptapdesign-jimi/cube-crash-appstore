import XCTest
import SpriteKit
import UIKit
import StackToSixGameplay
@testable import Stack_to_Six

@MainActor final class NativeSourceSpecialIdleMountedTests:XCTestCase {
 private final class Key {}
 private var root:URL{Bundle.main.bundleURL.appendingPathComponent("NativeAssets.bundle")}
 func testAllLiveRegistryAndNestedCapturedSuspensionsStartEveryActualOwner(){
  let registry=NativeSourceSpecialIdleRegistry(),scope=NativeSourceSpecialIdleScope(registry:registry,current:{true})
  var starts=0,pauses=0,resumes=0,stops=0
  let keys=(0..<13).map{_ in Key()}
  for key in keys {XCTAssertTrue(scope.register(key,owner:.init(start:{starts+=1},stop:{stops+=1},pause:{pauses+=1},resume:{resumes+=1})))}
  XCTAssertEqual(starts,13);XCTAssertEqual(scope.snapshot.running,13)
  let a=scope.acquire(reason:"merge6"),b=scope.acquire(reason:"nested")
  XCTAssertEqual(pauses,13);a?();XCTAssertEqual(resumes,0)
  b?();b?();XCTAssertEqual(resumes,13)
  scope.dispose();registry.dispose();XCTAssertEqual(stops,13)
 }
 func testOldCapturedScopeRetirementPreservesNewNodeAndSuspension(){
  let registry=NativeSourceSpecialIdleRegistry(),a=NativeSourceSpecialIdleScope(registry:registry,current:{true}),c=NativeSourceSpecialIdleScope(registry:registry,current:{true})
  let old=Key(),new=Key();var oldStops=0,newStarts=0
  XCTAssertTrue(a.register(old,owner:.init(start:{},stop:{oldStops+=1},pause:{},resume:{})))
  let oldRelease=a.acquire(reason:"A")
  XCTAssertTrue(c.register(new,owner:.init(start:{newStarts+=1},stop:{},pause:{},resume:{})))
  let newRelease=c.acquire(reason:"C")
  a.dispose();oldRelease?();XCTAssertEqual(oldStops,1);XCTAssertTrue(registry.has(new));XCTAssertTrue(registry.snapshot.suspended);XCTAssertEqual(newStarts,0)
  newRelease?();XCTAssertEqual(newStarts,1);XCTAssertFalse(a.register(new,owner:.init(start:{},stop:{},pause:{},resume:{})))
  c.dispose();registry.dispose()
 }
 func testReentrantStartSuspendsAfterItsActualStartWithoutRestart(){
  let registry=NativeSourceSpecialIdleRegistry();var release:(()->Void)?,starts=0,pauses=0,resumes=0
  let key=Key()
  registry.register(key,owner:.init(start:{starts+=1;release=registry.acquire(reason:"reentry")},stop:{},pause:{pauses+=1},resume:{resumes+=1}))
  XCTAssertEqual(starts,1);XCTAssertEqual(pauses,1);XCTAssertEqual(registry.snapshot.paused,1)
  release?();release?();XCTAssertEqual(resumes,1);XCTAssertEqual(starts,1);registry.dispose()
 }
 func testActualBottlePauseKeepsPoseAndDirectArtworkRemainsPointerOwned()throws {
  let registry=NativeSourceSpecialIdleRegistry(),scope=NativeSourceSpecialIdleScope(registry:registry,current:{true}),textures=NativeBoardTextures(root:root)
  let die=NativeDiceNode(id:"idle-bottle",value:6,kind:"wild-magnet",variant:"bottle",depth:1,locked:false,textures:textures,sourceSpecialIdle:scope)
  defer{die.dispose();scope.dispose();registry.dispose();textures.dispose()}
  let art=try XCTUnwrap(die.visual.children.compactMap{$0 as? SKSpriteNode}.first)
  die.tick(1.8,suspended:false,viewportCenter:195);let pose=art.position,anchor=art.anchorPoint,rotation=art.zRotation
  let release=scope.acquire(reason:"actual-merge6")
  XCTAssertFalse(die.hasAnimatedArtwork);die.tick(10,suspended:false,viewportCenter:195)
  XCTAssertEqual(art.position,pose);XCTAssertEqual(art.anchorPoint,anchor);XCTAssertEqual(art.zRotation,rotation)
  release?();die.tick(0.3,suspended:false,viewportCenter:195)
  let sample=NativeBottleIdleMotion.sample(seconds:2.1)
  // SpriteKit stores node positions at its own renderer precision. Compare
  // original oracle through the same SKSpriteNode boundary, without widening
  // the assertion tolerance or modifying motion/runtime code.
  let originalPoseNode=SKSpriteNode()
  originalPoseNode.position=CGPoint(x:0,y:-64-sample.y)
  XCTAssertEqual(art.position.y,originalPoseNode.position.y,accuracy:1e-8)
  let held=scope.acquire(reason:"during-pointer")
  die.setDragging(true);XCTAssertEqual(art.position,.zero);XCTAssertEqual(art.anchorPoint,CGPoint(x:0.5,y:0.5))
  held?();XCTAssertEqual(art.position,.zero);XCTAssertEqual(art.anchorPoint,CGPoint(x:0.5,y:0.5))
  die.setDragging(false);XCTAssertEqual(art.position.y,-64)
 }
 func testActualNewSpaceshipAllocatesNoIdleOwnerUntilFinalRelease()throws {
  let registry=NativeSourceSpecialIdleRegistry(),scope=NativeSourceSpecialIdleScope(registry:registry,current:{true}),textures=NativeBoardTextures(root:root)
  let a=scope.acquire(reason:"A"),b=scope.acquire(reason:"B")
  let die=NativeDiceNode(id:"new-idle-ship",value:6,kind:"wild-magnet",variant:"spaceship",depth:1,locked:false,textures:textures,sourceSpecialIdle:scope)
  defer{die.dispose();scope.dispose();registry.dispose();textures.dispose()}
  XCTAssertEqual(die.sourceIdleOwnerCount,0);XCTAssertEqual(scope.snapshot.pending,1)
  die.tick(5,suspended:false,viewportCenter:195);a?();XCTAssertEqual(die.sourceIdleOwnerCount,0)
  b?();XCTAssertEqual(scope.snapshot.running,1);XCTAssertGreaterThan(die.sourceIdleOwnerCount,0)
  die.tick(1.1,suspended:false,viewportCenter:195)
  let host=try XCTUnwrap(die.visual.children.first{$0.children.contains{$0.name=="native-spaceship-engine"}})
  XCTAssertEqual(host.position,CGPoint(x:-5,y:3));XCTAssertEqual(host.zRotation,.pi/12,accuracy:1e-8)
 }
 func testActualSceneBorrowsOneExistingPopulationCadenceForAllLiveNodes()throws {
  let service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0},sourceFrameTransportEnabled:true),context=NativeGameplaySourceContext(service:service)
  let tiles=(0..<13).map{i in NativeTile(id:"special-\(i)",cell:.init(column:i%5,row:i/5),value:6,archetype:.magnet,variant:"cubero")}
  let scene=NativeBoardScene(engine:NativeGameplayEngine(state:.init(tiles:tiles)),resourceRoot:root,size:.init(width:390,height:844))
  let scope=try XCTUnwrap(context.beginScene(engine:scene.engine,retire:{[weak scene] in scene?.retireSourceAnimationBindings()}))
  scene.sourceOuterTimelineDriver=scope.timeline;scene.sourceDragTweenDriver=scope.tween
  let view=SKView(frame:.init(x:0,y:0,width:390,height:844));view.presentScene(scene);view.isPaused=true
  defer{scene.dispose();context.dispose();service.dispose();view.presentScene(nil)}
  XCTAssertTrue(scene.configureSourceSpecialIdle(scope:scope));XCTAssertEqual(scope.specialIdle.snapshot.running,13)
  XCTAssertEqual(scene.sourceFrameSnapshot.settledMotionLeaseCount,1)
  let release=try XCTUnwrap(scene.acquireSourceSpecialIdle(reason:"genuine-owner"))
  XCTAssertEqual(scope.specialIdle.snapshot.paused,13);XCTAssertEqual(scene.sourceFrameSnapshot.settledMotionLeaseCount,0)
  release();XCTAssertEqual(scope.specialIdle.snapshot.running,13);XCTAssertEqual(scene.sourceFrameSnapshot.settledMotionLeaseCount,1)
  scene.dispose();XCTAssertEqual(scope.specialIdle.registeredKeys.count,0);XCTAssertNil(scene.acquireSourceSpecialIdle(reason:"stale"))
 }
}
