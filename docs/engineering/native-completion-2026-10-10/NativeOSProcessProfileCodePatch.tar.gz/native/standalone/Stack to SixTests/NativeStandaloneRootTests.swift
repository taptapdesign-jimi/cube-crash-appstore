import XCTest
import UIKit
import StackToSixNativeState
@testable import Stack_to_Six

@MainActor final class NativeStandaloneRootTests:XCTestCase {
    func testNativeRootMountsFromNativeStoreWithoutHybridShellAndDisposesOnce()async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-root-test-\(UUID().uuidString)")
        defer {try? FileManager.default.removeItem(at:directory)}
        let store=NativeSaveStore(directory:directory)
        var seed=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false))
        seed.progression.firstPlayTutorialComplete=true;try store.save(seed)
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root,store:store)
        host.loadViewIfNeeded()
        XCTAssertTrue(host.children.first is NativeAppController)
        func containsHybrid(_ view:UIView)->Bool {
            NSStringFromClass(type(of:view)).contains("WKWebView") || view.subviews.contains(where:containsHybrid)
        }
        XCTAssertFalse(containsHybrid(host.view))
        XCTAssertFalse(host.children.contains{NSStringFromClass(type(of:$0)).hasSuffix(".GameViewController")})
        XCTAssertEqual(try store.load()?.settings,seed.settings)
        host.dispose();host.dispose();XCTAssertTrue(host.disposed);XCTAssertTrue(host.children.isEmpty)
        NotificationCenter.default.post(name:UIApplication.didBecomeActiveNotification,object:nil)
        XCTAssertTrue(host.children.isEmpty)
    }
    func testDefaultStoryboardBuildsNativeRootAndPlainUIKitSurface()throws {
        let storyboard=UIStoryboard(name:"Main",bundle:Bundle.main)
        let host=try XCTUnwrap(storyboard.instantiateInitialViewController() as? NativeStandaloneViewController)
        // Coder construction must not read or migrate any profile. Retire
        // before loading to inspect the exact default root independently.
        XCTAssertFalse(host.isViewLoaded);host.dispose();host.loadViewIfNeeded()
        XCTAssertTrue(type(of:host.view!) == UIView.self)
        XCTAssertTrue(host.children.isEmpty)
    }
    #if DEBUG && targetEnvironment(simulator)
    func testIsolatedProcessProfileCannotSelectNormalOrOtherDeviceStore()throws {
        let root=FileManager.default.temporaryDirectory,id=UUID().uuidString
        var environment=["SIMULATOR_UDID":"1018BE2D-491B-465F-8F75-3E5BEB38C22A","CC_NATIVE_QA_PROFILE_ID":id]
        let directory=try XCTUnwrap(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
        XCTAssertEqual(directory.deletingLastPathComponent(),root)
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.Stack-to-Six",temporaryDirectory:root))
        environment["SIMULATOR_UDID"]="other-device"
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
        environment["SIMULATOR_UDID"]="1018BE2D-491B-465F-8F75-3E5BEB38C22A";environment["CC_NATIVE_QA_PROFILE_ID"]="../StackToSixNative"
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
    }
    func testProcessProfileReopenRetainsDurableBytesAndDoesNotResetSettings()throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-process-profile-test-\(UUID().uuidString)")
        defer{try? FileManager.default.removeItem(at:directory)}
        let first=try NativeSimulatorQAProfile.prepare(directory:directory)
        var seed=try XCTUnwrap(first.load());seed.settings.musicEnabled=true;seed.progression.firstPlayTutorialComplete=true;try first.save(seed)
        let file=directory.appendingPathComponent("state-v1.json"),bytes=try Data(contentsOf:file)
        let reopened=try NativeSimulatorQAProfile.prepare(directory:directory)
        XCTAssertEqual(try reopened.load(),seed);XCTAssertEqual(try Data(contentsOf:file),bytes)
    }
    #endif
    func testRetiredRootCannotMountAfterLateViewLoading()async throws {
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root)
        host.dispose();host.loadViewIfNeeded()
        XCTAssertTrue(host.children.isEmpty)
    }
}
