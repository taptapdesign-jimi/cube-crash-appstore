import SpriteKit
import UIKit

/// Source distance-based touch trail: at most one burst per pointer frame.
/// Particles have finite SpriteKit actions; a bounded pool owns their reuse.
struct NativeDragTrailCadence {
    var point:CGPoint?,at=0.0,carry=0.0
    mutating func reset(at point:CGPoint,time:Double){self.point=point;at=time;carry=0}
    mutating func consume(_ next:CGPoint,time:Double,spacing:CGFloat)->(CGPoint,Double)? {
        guard let previous=point else{reset(at:next,time:time);return nil}
        let dx=next.x-previous.x,dy=next.y-previous.y,distance=hypot(dx,dy),elapsed=max(1,time-at)
        point=next;at=time
        guard distance>=0.01 else{return nil}
        let total=carry+Double(distance)
        guard total>=Double(spacing) else{carry=total;return nil}
        let offset=min(distance,max(0,spacing-CGFloat(carry))),ratio=offset/distance
        carry=total.truncatingRemainder(dividingBy:Double(spacing))
        return (CGPoint(x:previous.x+dx*ratio,y:previous.y+dy*ratio),Double(distance)/elapsed)
    }
}
@MainActor
final class NativeDragTrail:SKNode {
    private var cadence=NativeDragTrailCadence(),pool:[SKShapeNode]=[]
    private(set) var live=Set<SKShapeNode>()
    private var active=false,disposed=false
    func begin(at point:CGPoint,time:Double){active=true;cadence.reset(at:point,time:time)}
    func end(){active=false}
    func emit(at point:CGPoint,time:Double,scale:CGFloat,wild:Bool,round:Bool,reduced:Bool=false) {
        guard active,!disposed,scale>0 else{return}
        let spacing:CGFloat=wild ? (reduced ? 32:26):(reduced ? 34:28)
        guard let (origin,speed)=cadence.consume(point,time:time,spacing:spacing*scale) else{return}
        // Cadence speed threshold is measured in original board pixels.
        let fast=speed/Double(scale)>=0.65,count=wild ? (reduced ? 1:(fast ? 2:1)):(reduced ? (fast ? 3:2):(fast ? 4:3))
        for _ in 0..<count {
            // Pool ceiling bounds simultaneous owners; normal touch cadence
            // and authored lifetimes remain below this ceiling.
            guard live.count<128 else{break}
            let particle=pool.popLast() ?? SKShapeNode();particle.removeAllActions()
            let radius:CGFloat
            if wild {radius=CGFloat.random(in:8...16)*1.04}
            else {let category=Double.random(in:0..<1);radius=category<0.33 ? CGFloat.random(in:3...6):category<0.66 ? CGFloat.random(in:4...10):CGFloat.random(in:5...13)}
            let rect=CGRect(x:-radius*scale,y:-radius*scale,width:2*radius*scale,height:2*radius*scale)
            particle.path=wild && !round ? CGPath(rect:rect,transform:nil):CGPath(ellipseIn:rect,transform:nil)
            let palette:[UInt32]=wild ? [0xFFE8AE,0xFFE19A,0xFFF3D0]:[0xF4EEE7,0xFBE3C5,0xECD7C2,0xE5C7AD,0xFADEC0]
            let color=palette.randomElement()!,fill:CGFloat=wild ? 0.92:0.8
            particle.fillColor=UIColor(red:CGFloat((color>>16)&255)/255,green:CGFloat((color>>8)&255)/255,blue:CGFloat(color&255)/255,alpha:fill)
            particle.strokeColor = .clear;particle.alpha=fill;particle.zRotation=0;particle.setScale(1)
            let start:CGPoint,end:CGPoint,life:Double
            if wild {
                let angle=CGFloat.random(in:0...2*CGFloat.pi),distance=128*CGFloat.random(in:0.1...0.7)*0.9*scale
                start=CGPoint(x:origin.x+cos(angle)*distance,y:origin.y+sin(angle)*distance)
                let endAngle=angle+CGFloat.random(in:-0.5...0.5),endDistance=distance*CGFloat.random(in:1.5...2)
                end=CGPoint(x:origin.x+cos(endAngle)*endDistance,y:origin.y+sin(endAngle)*endDistance);life=Double.random(in:0.3...0.6)
            }else{
                start=CGPoint(x:origin.x+CGFloat.random(in:-40...40)*scale,y:origin.y+CGFloat.random(in:-40...40)*scale)
                end=CGPoint(x:start.x,y:start.y+CGFloat.random(in:20...35)*scale);life=Double.random(in:0.9...1.4)
            }
            particle.position=start;addChild(particle);live.insert(particle)
            particle.run(.sequence([.customAction(withDuration:life){node,time in
                let t=min(1,CGFloat(time)/CGFloat(life)),p=1-(1-t)*(1-t)
                node.position=CGPoint(x:start.x+(end.x-start.x)*p,y:start.y+(end.y-start.y)*p);node.alpha=fill*(1-p)
            },.run{[weak self,weak particle] in
                guard let self,let particle else{return};particle.removeFromParent();self.live.remove(particle)
                if !self.disposed{self.pool.append(particle)}
            }]),withKey:"native-drag-trail-tail")
        }
    }
    var hasTail:Bool {!live.isEmpty}
    func clear(){active=false;for particle in live{particle.removeAllActions();particle.removeFromParent();pool.append(particle)};live.removeAll()}
    func dispose(){guard !disposed else{return};clear();disposed=true;pool.removeAll();removeFromParent()}
}
