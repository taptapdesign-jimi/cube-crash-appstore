import UIKit
import AVFoundation

/// Native owner of the preserved v9 studio composition. One finite CA timeline;
/// only the selected original transparent HEVC loop is decoded. No web surface.
@MainActor
final class NativeStudioIntroView:UIView,CAAnimationDelegate {
    struct Character {
        let key:String,scale:CGFloat,x:CGFloat,y:CGFloat,topPivot:Bool
        init(_ key:String,_ scale:CGFloat,_ x:CGFloat=0,_ y:CGFloat=0,_ top:Bool=false){self.key=key;self.scale=scale;self.x=x;self.y=y;topPivot=top}
    }
    static let characters:[Character]=[
        .init("lik-kauc",1.1475,0,40),.init("lik-gitara",1.1,0,16),.init("lik-slikanje",1.08,20,10),
        .init("lik-cvijet",1.08,0,8),.init("lik-board",1.04,0,16),.init("lik-game",1.08),
        .init("lik-laptop",1.452,0,8),.init("lik-pas-SVG",1.12,0,0,true),.init("lik-speceraj",1.21,0,20),
        .init("lik-nogomet",1.1),.init("pas-novine",1.1,0,16)]
    static let duration=4.33
    let character:Character
    private let artwork:JimiV9Artwork,logoUnit=UIView(),logo=UIImageView(),label=UILabel(),characterView=UIView(),fallback=UIImageView()
    private let playerLayer=AVPlayerLayer()
    private var readiness:NSKeyValueObservation?
    private var player:AVQueuePlayer?,looper:AVPlayerLooper?,observers:[NSObjectProtocol]=[]
    private var completion:(()->Void)?,started=false,disposed=false,backgrounded=false
    var onCharacterCue:((String)->Void)?
    init(root:URL,character:Character?=nil) {
        artwork=JimiV9Artwork(resourceRoot:root)
        self.character=character ?? Self.characters.randomElement()!
        super.init(frame:.zero);isUserInteractionEnabled=true;accessibilityIdentifier="native.studio-intro"
        addSubview(logoUnit);logoUnit.addSubview(logo);logoUnit.addSubview(label);addSubview(characterView);characterView.addSubview(fallback)
        logo.image=artwork.image("assets/logo addons/taplogo.png");logo.contentMode = .scaleAspectFit
        label.attributedText=NSAttributedString(string:"PRESENTS",attributes:[.font:artwork.font(size:15),.kern:0.9,.foregroundColor:UIColor(red:184.0/255,green:121.0/255,blue:96.0/255,alpha:1)])
        label.textAlignment = .center
        let png=self.character.key == "lik-slikanje" ? "lik slikanje":self.character.key == "pas-novine" ? "pas novine":self.character.key == "lik-pas-SVG" ? "lik-pas":self.character.key
        fallback.image=artwork.image("assets/logo addons/\(png).png");fallback.contentMode = .scaleAspectFit
        let url=root.appendingPathComponent("assets/logo addons/optimized/\(self.character.key)-mobile-hevc.mov")
        if FileManager.default.fileExists(atPath:url.path) {
            let item=AVPlayerItem(url:url),queue=AVQueuePlayer();queue.isMuted=true;queue.actionAtItemEnd = .none
            looper=AVPlayerLooper(player:queue,templateItem:item);player=queue;playerLayer.player=queue;playerLayer.videoGravity = .resizeAspect
            characterView.layer.addSublayer(playerLayer)
            readiness=playerLayer.observe(\.isReadyForDisplay,options:[.initial,.new]) { [weak self] layer,_ in
                DispatchQueue.main.async { [weak self] in
                    guard let self,!self.disposed else{return}
                    self.fallback.isHidden=layer.isReadyForDisplay;self.playerLayer.isHidden = !layer.isReadyForDisplay
                }
            }
        }
        if self.character.topPivot {characterView.layer.anchorPoint=CGPoint(x:0.5,y:0)}
        for name in [UIApplication.willResignActiveNotification,UIApplication.didBecomeActiveNotification] {
            observers.append(NotificationCenter.default.addObserver(forName:name,object:nil,queue:.main){[weak self] note in
                MainActor.assumeIsolated{self?.setBackgrounded(note.name==UIApplication.willResignActiveNotification)}
            })
        }
    }
    required init?(coder:NSCoder){fatalError("Native original-art initializer")}
    override func layoutSubviews(){
        super.layoutSubviews()
        let width=min(bounds.width*0.806,315),charWidth=min(bounds.width*0.74,289)
        let logoAspect=logo.image.map{$0.size.height/max(1,$0.size.width)} ?? 0.5
        let imageHeight=width*logoAspect,logoHeight=imageHeight+29
        let aspect=fallback.image.map{$0.size.height/max(1,$0.size.width)} ?? 1
        let charHeight=min(bounds.height*0.54,charWidth*aspect),total=logoHeight+20+charHeight
        let top=(bounds.height-total)/2
        logoUnit.bounds=CGRect(x:0,y:0,width:width,height:logoHeight);logoUnit.center=CGPoint(x:bounds.midX,y:top+logoHeight/2)
        logo.frame=CGRect(x:0,y:0,width:width,height:imageHeight);label.frame=CGRect(x:0,y:imageHeight+14,width:width,height:15)
        characterView.bounds=CGRect(x:0,y:0,width:charWidth,height:charHeight)
        characterView.layer.position=CGPoint(x:bounds.midX+character.x,y:top+logoHeight+20+charHeight*characterView.layer.anchorPoint.y+character.y)
        fallback.frame=characterView.bounds;playerLayer.frame=characterView.bounds
    }
    static func scale(at seconds:Double,character:Bool,rest:Double=1)->Double {
        let begin=character ? 0.15:0,enter=character ? 0.55:0.45,exit=character ? 3.5:3.68
        if seconds<begin{return rest*(character ? 0.82:0.92)}
        if seconds<begin+enter {
            let p=(seconds-begin)/enter,e=character ? JimiV9Motion.Ease.backOut(1.8).value(p):(p<0.5 ? 4*p*p*p:1-pow(-2*p+2,3)/2)
            return rest*((character ? 0.82:0.92)+(character ? 0.18:0.08)*e)
        }
        if seconds<exit{return rest}
        return rest*(1-JimiV9Motion.Ease.backIn(2.2).value(min(1,(seconds-exit)/0.65)))
    }
    func start(completion:@escaping()->Void){
        guard !started,!disposed else{return};started=true;self.completion=completion;layoutIfNeeded()
        onCharacterCue?(character.key);player?.play()
        for (target,isCharacter) in [(logoUnit,false),(characterView,true)] {
            let scale=CAKeyframeAnimation(keyPath:"transform"),opacity=CAKeyframeAnimation(keyPath:"opacity")
            let samples=1040
            scale.values=(0...samples).map{index in
                let value=Self.scale(at:Self.duration*Double(index)/Double(samples),character:isCharacter,rest:isCharacter ? Double(character.scale):1)
                return NSValue(caTransform3D:CATransform3DMakeScale(value,value,1))
            }
            opacity.values=(0...samples).map{index -> NSNumber in
                let seconds=Self.duration*Double(index)/Double(samples),begin=isCharacter ? 0.15:0,enter=isCharacter ? 0.55:0.45
                return NSNumber(value:min(1,max(0,(seconds-begin)/enter)))
            }
            scale.duration=Self.duration;opacity.duration=Self.duration
            let group=CAAnimationGroup();group.animations=[scale,opacity];group.duration=Self.duration
            if !isCharacter{group.delegate=self}
            target.layer.add(group,forKey:"native-studio-intro")
        }
    }
    func animationDidStop(_ anim:CAAnimation,finished:Bool){guard finished,!disposed else{return};let done=completion;completion=nil;dispose();done?()}
    private func setBackgrounded(_ value:Bool){
        guard !disposed,backgrounded != value else{return};backgrounded=value
        for target in [logoUnit,characterView]{let layer=target.layer
            if value {let time=layer.convertTime(CACurrentMediaTime(),from:nil);layer.speed=0;layer.timeOffset=time}
            else {let paused=layer.timeOffset;layer.speed=1;layer.timeOffset=0;layer.beginTime=0;layer.beginTime=layer.convertTime(CACurrentMediaTime(),from:nil)-paused}
        }
        if value{player?.pause()}else if started{player?.play()}
    }
    func dispose(){guard !disposed else{return};disposed=true;completion=nil;onCharacterCue=nil
        for target in [logoUnit,characterView]{target.layer.removeAllAnimations()}
        readiness?.invalidate();readiness=nil;player?.pause();looper?.disableLooping();looper=nil;player?.removeAllItems();playerLayer.player=nil;player=nil
        observers.forEach(NotificationCenter.default.removeObserver);observers.removeAll();removeFromSuperview()
    }
}
