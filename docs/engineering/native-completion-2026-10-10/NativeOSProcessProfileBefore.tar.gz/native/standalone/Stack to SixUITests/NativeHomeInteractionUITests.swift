import XCTest

@MainActor
final class NativeHomeInteractionUITests: XCTestCase {
    func testRealSlowAndFastSwipesAndNavClicksKeepHomeRoute() throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"] == "1018BE2D-491B-465F-8F75-3E5BEB38C22A" else {throw XCTSkip("Dedicated QA Simulator only")}
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchArguments=["--native-gameplay","--native-qa-fresh-profile"];app.launch()
        func nav(_ index:Int)->XCUIElement {app.buttons["native.home.slide.\(index)"]}
        XCTAssertTrue(nav(0).waitForExistence(timeout:15))
        func settled(_ index:Int) {
            let target=nav(index)
            let selectionExpectation=XCTNSPredicateExpectation(predicate:NSPredicate(format:"selected == true AND hittable == true"),object:target)
            XCTAssertEqual(XCTWaiter.wait(for:[selectionExpectation],timeout:5),.completed)
            // Input admission does not cover selection; allow original finite
            // track/bounce completion before the next unrelated slow gesture.
            let done=expectation(description:"Original finite Home motion")
            DispatchQueue.main.asyncAfter(deadline:.now()+0.9){done.fulfill()};wait(for:[done],timeout:2)
            XCTAssertTrue(app.buttons["native.home.cta"].exists)
        }
        settled(0)
        app.swipeLeft(velocity:.slow);settled(1)
        app.swipeLeft(velocity:.fast);settled(2)
        app.swipeRight(velocity:.fast);settled(1)
        app.swipeRight(velocity:.slow);settled(0)
        nav(2).tap();settled(2)
        nav(0).tap();settled(0)
        XCTAssertEqual(app.webViews.count,0)
        let shot=XCTAttachment(screenshot:app.screenshot());shot.name="native-home-real-swipes-nav";shot.lifetime = .keepAlways;add(shot)
    }
}
