import XCTest
import SpriteKit
import StackToSixGameplay
@testable import Stack_to_Six

@MainActor
final class NativeIdleBubbleTests:XCTestCase {
    private struct Frame:Decodable {let time:Double,frame:Int,draws:Int,bubbles:[Bubble]}
    private struct Bubble:Decodable {let id:Int,x:Double,y:Double,scaleX:Double,scaleY:Double,alpha:Double,tint:UInt32}
    private struct Fixture:Decodable {let family:String,seed:UInt32,frames:[Frame]}
    private func family(_ name:String)->NativeIdleBubbleMotion.Family {
        switch name {case "honey":return .honey;case "bottle":return .bottle;case "fish":return .fish;case "beach-ball":return .beachBall;default:return .juice}
    }
    func testVisibleProducerMatchesUnmodifiedV9OriginalGSAPThroughPickupAndStalledFrames() throws {
        let fixtures=try JSONDecoder().decode([Fixture].self,from:Data(NativeIdleBubbleSourceOracle.json.utf8))
        XCTAssertEqual(fixtures.count,15)
        for fixture in fixtures {
            var rng=fixture.seed,draws=0
            let runtime=NativeIdleBubbleMotion.Runtime(family:family(fixture.family),random:{draws+=1;rng=rng &* 1664525 &+ 1013904223;return Double(rng)/4294967296})
            let samples=Dictionary(uniqueKeysWithValues:fixture.frames.map {($0.frame,$0)})
            var last=0.0
            for index in 0...1200 {
                let time=Double(index)/60+(index>=120 ? 0.37:0)+(index>=360 ? 0.41:0)+(index>=850 ? 0.29:0)
                runtime.advance(time-last);last=time
                if index==240 || index==720 {runtime.stopForPointer()}
                if index==270 || index==750 {runtime.restartAfterLanding()}
                XCTAssertLessThanOrEqual(runtime.bubbles.count,6)
                guard let sample=samples[index] else {continue}
                XCTAssertEqual(draws,sample.draws,"Original producer/RNG source \(fixture.family),frame\(index)")
                XCTAssertEqual(runtime.bubbles.count,sample.bubbles.count)
                for (native,gold) in zip(runtime.bubbles,sample.bubbles) {
                    let pose=native.plan.sample(seconds:runtime.elapsed-native.born)
                    XCTAssertEqual(native.id,gold.id);XCTAssertEqual(pose.tint,gold.tint)
                    // Actual GSAP rounds numeric pose properties to six digits.
                    XCTAssertEqual(pose.x,gold.x,accuracy:3e-5);XCTAssertEqual(pose.y,gold.y,accuracy:3e-5)
                    XCTAssertEqual(pose.scaleX,gold.scaleX,accuracy:3e-5);XCTAssertEqual(pose.scaleY,gold.scaleY,accuracy:3e-5)
                    XCTAssertEqual(pose.alpha,gold.alpha,accuracy:3e-5)
                }
            }
        }
    }
    func testNativeRawArchetypeNamesSelectOriginalFizzFamiliesAndCustomBranchesStayExcluded() {
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"wild-juice",variant:nil),.juice)
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"juice",variant:nil),.juice)
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"wild",variant:"fish"),.fish)
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"wild-magnet",variant:"bottle"),.bottle)
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"wild-magnet",variant:"honey"),.honey)
        XCTAssertEqual(NativeIdleBubbleMotion.family(kind:"wild-tnt",variant:"beach-ball"),.beachBall)
        XCTAssertNil(NativeIdleBubbleMotion.family(kind:"wild-juice",variant:"mushroom"))
        XCTAssertNil(NativeIdleBubbleMotion.family(kind:"wild-juice",variant:"robo-cube"))
        XCTAssertNil(NativeIdleBubbleMotion.family(kind:"wild-tnt",variant:nil))
    }

    func testVectorCarriersStayBoundedAndReuseTheSameNativeNodes() throws {
        var rng=UInt32(17)
        let field=NativeIdleBubbleField(family:.bottle,random:{rng=rng &* 1664525 &+ 1013904223;return Double(rng)/4294967296})
        let owner=SKNode();owner.addChild(field)
        let carriers=Set(field.children.map(ObjectIdentifier.init)),vectors=Set(field.children.flatMap(\.children).map(ObjectIdentifier.init))
        XCTAssertEqual(carriers.count,6);XCTAssertEqual(vectors.count,18)
        for _ in 0..<2400 {field.tick(1/60);XCTAssertLessThanOrEqual(field.activeCount,6)}
        XCTAssertEqual(Set(field.children.map(ObjectIdentifier.init)),carriers)
        XCTAssertEqual(Set(field.children.flatMap(\.children).map(ObjectIdentifier.init)),vectors)
        field.stopForPointer();XCTAssertFalse(field.isRunning);XCTAssertEqual(field.activeCount,0)
        XCTAssertTrue(field.children.allSatisfy(\.isHidden))
        field.tick(5);XCTAssertEqual(field.activeCount,0,"Pointer stop cannot create a new hidden producer")
        field.restartAfterLanding();XCTAssertTrue(field.isRunning);XCTAssertEqual(field.activeCount,1)
        field.dispose();field.dispose();field.tick(1);field.restartAfterLanding()
        XCTAssertNil(field.parent);XCTAssertTrue(field.children.isEmpty);XCTAssertFalse(field.isRunning)
    }
    func testNativePointerStopsFizzUntilActualV9ReturnTimelineFinishes() async throws {
        let root=Bundle.main.bundleURL.appendingPathComponent("NativeAssets.bundle")
        let bottle=NativeTile(id:"bottle",cell:NativeCell(column:0,row:0),value:0,archetype:.magnet,variant:"bottle")
        let engine=NativeGameplayEngine(state:NativeBoardState(columns:5,rows:9,tiles:[bottle,NativeTile(id:"a",cell:NativeCell(column:1,row:0),value:1),NativeTile(id:"b",cell:NativeCell(column:2,row:0),value:1)]))
        let scene=NativeBoardScene(engine:engine,resourceRoot:root,size:CGSize(width:390,height:844));scene.layout(size:scene.size,insets:.zero)
        let window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844)),controller=UIViewController(),renderer=SKView(frame:window.bounds)
        controller.view=renderer;window.rootViewController=controller;window.makeKeyAndVisible();renderer.presentScene(scene)
        defer {scene.dispose();renderer.presentScene(nil);window.isHidden=true}
        let node=try XCTUnwrap(scene.childNode(withName:"//native-die-bottle") as? NativeDiceNode)
        let field=try XCTUnwrap(node.visual.children.compactMap {$0 as? NativeIdleBubbleField}.first)
        XCTAssertTrue(field.isRunning)
        let returned=expectation(description:"Original0.18 position plus appended0.105 recovery actually completed")
        let resourceWakeup=node.onResourceReady
        var completed=0
        node.onResourceReady={resourceWakeup?();if field.isRunning {completed+=1;returned.fulfill()}}
        let point=scene.boardGeometry!.center(row:0,column:0)
        XCTAssertTrue(scene.beginDrag(at:point));XCTAssertFalse(field.isRunning);XCTAssertEqual(field.activeCount,0)
        let started=CACurrentMediaTime()
        XCTAssertEqual(scene.finishDrag(at:point,now:1)?.accepted,false)
        XCTAssertFalse(field.isRunning,"Pointer-up alone cannot restart the source producer")
        await fulfillment(of:[returned],timeout:3)
        XCTAssertGreaterThanOrEqual(CACurrentMediaTime()-started,0.265)
        XCTAssertEqual(completed,1);XCTAssertTrue(field.isRunning)
        XCTAssertTrue(scene.beginDrag(at:point));XCTAssertFalse(field.isRunning)
        XCTAssertEqual(scene.finishDrag(at:point,now:2)?.accepted,false)
        XCTAssertTrue(scene.beginDrag(at:point),"Second accepted pickup interrupts the previous landing owner")
        try await Task.sleep(for:.milliseconds(350))
        XCTAssertFalse(field.isRunning);XCTAssertEqual(completed,1,"Interrupted landing cannot replay an old producer")
    }


    func testSourceBubbleIndependentRootsRetireOnlyAtAppMicrotaskCheckpoint() throws {
        let fifo=NativeSourceMicrotaskFIFO(),service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0})
        let scope=try XCTUnwrap(fifo.makeMeterScope(boundProducers:NativeSourceMicrotaskFIFO.meterBoundaries,isCurrent:{true}))
        defer{scope.dispose();fifo.dispose();service.dispose()}
        var seed:UInt32=1,retired=0,poses:[NativeIdleBubbleMotion.Pose]=[]
        let plan=NativeIdleBubbleMotion.make(family:.bottle,random:{seed=seed &* 1664525 &+ 1013904223;return Double(seed)/4294967296})
        let bubble=NativeSourceFizzBubbleClock(service:service,tasks:scope,plan:plan,current:{true},paint:{poses.append($0)},retired:{retired+=1})
        defer{bubble.dispose()}
        XCTAssertTrue(bubble.start());XCTAssertEqual(bubble.activeRootCount,4)
        for ms in [200.0,500,800]{
            XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:ms)})
            let pose=try XCTUnwrap(poses.last),gold=plan.sample(seconds:ms/1000)
            XCTAssertEqual(pose.x,gold.x,accuracy:3e-5);XCTAssertEqual(pose.y,gold.y,accuracy:3e-5)
            XCTAssertEqual(pose.scaleX,gold.scaleX,accuracy:3e-5);XCTAssertEqual(pose.scaleY,gold.scaleY,accuracy:3e-5)
            XCTAssertEqual(pose.alpha,gold.alpha,accuracy:3e-5);XCTAssertEqual(pose.tint,gold.tint)
        }
        XCTAssertEqual(retired,0)
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){
            service.deliver(wallMilliseconds:1100)
            XCTAssertEqual(retired,0,"Rise callback cannot repool during the active root render")
            XCTAssertEqual(fifo.pendingCount,1)
        })
        XCTAssertEqual(retired,1);XCTAssertEqual(bubble.activeRootCount,0)
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:1400)})
        XCTAssertEqual(retired,1)
    }

    func testMountedSourceFieldUsesSharedRootsWithoutRawTickAndPointerStopRetiresOnlyItsRoots() throws {
        let fifo=NativeSourceMicrotaskFIFO(),service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0})
        let scope=try XCTUnwrap(fifo.makeMeterScope(boundProducers:NativeSourceMicrotaskFIFO.meterBoundaries,isCurrent:{true}))
        defer{scope.dispose();fifo.dispose();service.dispose()}
        var draws=0,seed:UInt32=1
        let field=NativeIdleBubbleField(sourceFamily:.bottle,service:service,tasks:scope,random:{draws+=1;seed=seed &* 1664525 &+ 1013904223;return Double(seed)/4294967296},current:{true},paintable:{true})
        let host=SKNode();host.addChild(field);defer{field.dispose()}
        let carriers=Set(field.children.map(ObjectIdentifier.init))
        XCTAssertEqual(draws,0);XCTAssertTrue(field.startSource());XCTAssertEqual(draws,12)
        XCTAssertEqual(field.activeCount,1);XCTAssertEqual(service.activeParticipantCount,5)
        field.tick(100);XCTAssertEqual(draws,12,"Raw Scene tick cannot advance Source producer")
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:500)})
        XCTAssertEqual(draws,24);XCTAssertEqual(field.activeCount,2)
        field.stopForPointer();XCTAssertEqual(service.activeParticipantCount,0);XCTAssertEqual(field.activeCount,0)
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:800)})
        XCTAssertEqual(draws,24);field.restartAfterLanding();XCTAssertEqual(draws,36)
        XCTAssertEqual(field.activeCount,1);XCTAssertEqual(Set(field.children.map(ObjectIdentifier.init)),carriers)
        field.dispose();XCTAssertEqual(service.activeParticipantCount,0);XCTAssertNil(field.parent)
        field.restartAfterLanding();XCTAssertEqual(draws,36)
    }

    func testSourceFieldHiddenLandingStartsAtomicallySuspendedOnSharedClock() throws {
        let fifo=NativeSourceMicrotaskFIFO(),service=NativeSourceAnimationClockService(wallOriginMilliseconds:0,sourceWallMillisecondsNow:{0})
        let scope=try XCTUnwrap(fifo.makeMeterScope(boundProducers:NativeSourceMicrotaskFIFO.meterBoundaries,isCurrent:{true}))
        defer{scope.dispose();fifo.dispose();service.dispose()}
        var draws=0
        let field=NativeIdleBubbleField(sourceFamily:.bottle,service:service,tasks:scope,random:{draws+=1;return 0.5},current:{true},paintable:{true})
        defer{field.dispose()}
        XCTAssertTrue(field.startSource());field.setSourceVisible(false);field.stopForPointer()
        field.restartAfterLanding();XCTAssertEqual(draws,24)
        XCTAssertFalse(service.hasActiveClock,"Hidden landing must not wake a runnable Source root")
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:500)})
        XCTAssertEqual(draws,24)
        field.setSourceVisible(true)
        XCTAssertTrue(fifo.performTask(.sourceAnimationFrameCallback){service.deliver(wallMilliseconds:950)})
        XCTAssertEqual(draws,36)
    }
}
