import XCTest
import UIKit
import StackToSixNativeState
import StackToSixGameplay
@testable import Stack_to_Six

@MainActor final class NativeStandaloneRootTests:XCTestCase {
    func testExplicitRootFreshTutorialCompletesEntryOnItsOwnSourceTransport()async throws {
        let previous=NativeSourceAnimationClockService.shared
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-source-root-guide-\(UUID().uuidString)")
        let store=NativeSaveStore(directory:directory)
        try store.save(NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false)))
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root,store:store,sourceFreshTutorialEnabled:true)
        let window=UIWindow(frame:CGRect(x:0,y:0,width:390,height:844))
        let oldWindow=UIApplication.shared.connectedScenes.compactMap{$0 as? UIWindowScene}.flatMap(\.windows).first(where:\.isKeyWindow)
        window.rootViewController=host;window.makeKeyAndVisible();host.loadViewIfNeeded()
        defer{host.dispose();window.isHidden=true;oldWindow?.makeKeyAndVisible();try? FileManager.default.removeItem(at:directory)}
        let runtime=try XCTUnwrap(host.sourceRuntime),app=try XCTUnwrap(host.children.first as? NativeAppController)
        let homeDeadline=Date().addingTimeInterval(15)
        while app.home.isHidden && Date()<homeDeadline {try await Task.sleep(for:.milliseconds(20))}
        XCTAssertFalse(app.home.isHidden)
        app.navigate(.gameplay,interrupt:true)
        let deadline=Date().addingTimeInterval(15)
        var game:NativeGameplayViewController?
        while Date()<deadline {
            game=app.children.compactMap{$0 as? NativeGameplayViewController}.first
            if game?.boardScene?.sourceTutorialPreparationReady==true {break}
            try await Task.sleep(for:.milliseconds(20))
        }
        let mounted=try XCTUnwrap(game),scene=try XCTUnwrap(mounted.boardScene)
        XCTAssertTrue(scene.sourceTutorialPreparationReady)
        XCTAssertEqual(scene.completedSourceBoardEntry?.outcome,.normal)
        XCTAssertTrue(mounted.sourceScope?.service === runtime.service)
        XCTAssertTrue(scene.sourceTutorialHUDActive)
        XCTAssertNil(mounted.engine.pendingSourceTutorialDemoActivation)
        XCTAssertEqual(mounted.engine.state.tiles.count,45)
        XCTAssertFalse(previous.hasActiveClock)
        host.dispose();XCTAssertFalse(runtime.service.hasActiveClock)
        XCTAssertTrue(NativeSourceAnimationClockService.shared === previous)
    }
    func testExplicitRootOwnsOneSourceTransportAndRestoresDefaultOnDisposal()throws {
        let previous=NativeSourceAnimationClockService.shared
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-source-root-\(UUID().uuidString)")
        defer{try? FileManager.default.removeItem(at:directory)}
        let store=NativeSaveStore(directory:directory)
        try store.save(NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false)))
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root,store:store,sourceTransportEnabled:true)
        defer{host.dispose()}
        host.loadViewIfNeeded()
        let runtime=try XCTUnwrap(host.sourceRuntime)
        XCTAssertTrue(host.children.first is NativeAppController)
        XCTAssertTrue(NativeSourceAnimationClockService.shared === runtime.service)
        XCTAssertFalse(previous.hasActiveClock)
        host.dispose();host.dispose()
        XCTAssertTrue(runtime.disposed);XCTAssertFalse(runtime.service.hasActiveClock)
        XCTAssertEqual(runtime.fifo.pendingCount,0);XCTAssertNil(host.sourceRuntime)
        XCTAssertTrue(NativeSourceAnimationClockService.shared === previous)
    }
    func testBusyRootRefusesBeforeAnyProfileAccess()throws {
        let previous=NativeSourceAnimationClockService.shared
        let blocker=try XCTUnwrap(NativeSourceApplicationRuntime.acquire())
        defer{blocker.dispose()}
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-busy-root-\(UUID().uuidString)")
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root,store:NativeSaveStore(directory:directory),sourceTransportEnabled:true)
        defer{host.dispose();try? FileManager.default.removeItem(at:directory)}
        host.loadViewIfNeeded()
        XCTAssertTrue(host.children.isEmpty);XCTAssertNil(host.sourceRuntime)
        XCTAssertFalse(FileManager.default.fileExists(atPath:directory.path))
        XCTAssertTrue(NativeSourceAnimationClockService.shared === blocker.service)
        blocker.dispose();XCTAssertTrue(NativeSourceAnimationClockService.shared === previous)
    }
    func testNativeRootMountsFromNativeStoreWithoutHybridShellAndDisposesOnce()async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-root-test-\(UUID().uuidString)")
        defer {try? FileManager.default.removeItem(at:directory)}
        let store=NativeSaveStore(directory:directory)
        var seed=NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false))
        seed.progression.firstPlayTutorialComplete=true;try store.save(seed)
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root,store:store)
        host.loadViewIfNeeded()
        XCTAssertTrue(host.children.first is NativeAppController)
        func containsHybrid(_ view:UIView)->Bool {
            NSStringFromClass(type(of:view)).contains("WKWebView") || view.subviews.contains(where:containsHybrid)
        }
        XCTAssertFalse(containsHybrid(host.view))
        XCTAssertFalse(host.children.contains{NSStringFromClass(type(of:$0)).hasSuffix(".GameViewController")})
        XCTAssertEqual(try store.load()?.settings,seed.settings)
        host.dispose();host.dispose();XCTAssertTrue(host.disposed);XCTAssertTrue(host.children.isEmpty)
        NotificationCenter.default.post(name:UIApplication.didBecomeActiveNotification,object:nil)
        XCTAssertTrue(host.children.isEmpty)
    }
    func testDefaultStoryboardBuildsNativeRootAndPlainUIKitSurface()throws {
        let storyboard=UIStoryboard(name:"Main",bundle:Bundle.main)
        let host=try XCTUnwrap(storyboard.instantiateInitialViewController() as? NativeStandaloneViewController)
        // Coder construction must not read or migrate any profile. Retire
        // before loading to inspect the exact default root independently.
        XCTAssertFalse(host.isViewLoaded);host.dispose();host.loadViewIfNeeded()
        XCTAssertTrue(type(of:host.view!) == UIView.self)
        XCTAssertTrue(host.children.isEmpty)
    }
    #if DEBUG && targetEnvironment(simulator)
    func testSourceOSCapabilityRequiresExplicitFlagDedicatedDeviceAndIsolatedProfile() {
        var environment=["SIMULATOR_UDID":"1018BE2D-491B-465F-8F75-3E5BEB38C22A","CC_NATIVE_QA_PROFILE_ID":UUID().uuidString]
        let product="com.taptapdesign.stacktosix.native"
        XCTAssertFalse(NativeSimulatorSourceQA.admitted(environment:environment,bundleIdentifier:product))
        environment["CC_NATIVE_QA_SOURCE_FRESH_TUTORIAL"]="1"
        XCTAssertTrue(NativeSimulatorSourceQA.admitted(environment:environment,bundleIdentifier:product))
        XCTAssertFalse(NativeSimulatorSourceQA.admitted(environment:environment,bundleIdentifier:"other.product"))
        environment["CC_NATIVE_QA_PROFILE_ID"]="../normal"
        XCTAssertFalse(NativeSimulatorSourceQA.admitted(environment:environment,bundleIdentifier:product))
        environment["CC_NATIVE_QA_PROFILE_ID"]=UUID().uuidString;environment["SIMULATOR_UDID"]="other-device"
        XCTAssertFalse(NativeSimulatorSourceQA.admitted(environment:environment,bundleIdentifier:product))
    }
    func testIsolatedProcessProfileCannotSelectNormalOrOtherDeviceStore()throws {
        let root=FileManager.default.temporaryDirectory,id=UUID().uuidString
        var environment=["SIMULATOR_UDID":"1018BE2D-491B-465F-8F75-3E5BEB38C22A","CC_NATIVE_QA_PROFILE_ID":id]
        let directory=try XCTUnwrap(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
        XCTAssertEqual(directory.deletingLastPathComponent(),root)
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.Stack-to-Six",temporaryDirectory:root))
        environment["SIMULATOR_UDID"]="other-device"
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
        environment["SIMULATOR_UDID"]="1018BE2D-491B-465F-8F75-3E5BEB38C22A";environment["CC_NATIVE_QA_PROFILE_ID"]="../StackToSixNative"
        XCTAssertNil(NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:"com.taptapdesign.stacktosix.native",temporaryDirectory:root))
    }
    func testProcessProfileReopenRetainsDurableBytesAndDoesNotResetSettings()throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent("native-process-profile-test-\(UUID().uuidString)")
        defer{try? FileManager.default.removeItem(at:directory)}
        let first=try NativeSimulatorQAProfile.prepare(directory:directory)
        var seed=try XCTUnwrap(first.load());seed.settings.musicEnabled=true;seed.progression.firstPlayTutorialComplete=true;try first.save(seed)
        let file=directory.appendingPathComponent("state-v1.json"),bytes=try Data(contentsOf:file)
        let reopened=try NativeSimulatorQAProfile.prepare(directory:directory)
        XCTAssertEqual(try reopened.load(),seed);XCTAssertEqual(try Data(contentsOf:file),bytes)
    }
    #endif
    func testRetiredRootCannotMountAfterLateViewLoading()async throws {
        let host=NativeStandaloneViewController(resourceRoot:NativeTestResources.root)
        host.dispose();host.loadViewIfNeeded()
        XCTAssertTrue(host.children.isEmpty)
    }
}
