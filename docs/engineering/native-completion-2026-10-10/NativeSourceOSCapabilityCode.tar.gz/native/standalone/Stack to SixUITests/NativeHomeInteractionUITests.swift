import XCTest

@MainActor
final class NativeHomeInteractionUITests: XCTestCase {
    func testExplicitSourceFreshTutorialAcrossTwoActualOSLaunches()throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"]=="1018BE2D-491B-465F-8F75-3E5BEB38C22A",
              ProcessInfo.processInfo.environment["CC_NATIVE_QA_SOURCE_OS"]=="1" else {
            throw XCTSkip("Explicit isolated Source OS evidence only")
        }
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchEnvironment["CC_NATIVE_QA_PROFILE_ID"]="AD1E2026-1010-4000-8000-000000000004"
        app.launchEnvironment["CC_NATIVE_QA_SOURCE_FRESH_TUTORIAL"]="1"
        defer{app.terminate()}
        for index in 0..<2 {
            app.launch()
            let nav=app.buttons["native.home.slide.1"]
            XCTAssertTrue(nav.waitForExistence(timeout:20));nav.tap()
            let selected=XCTNSPredicateExpectation(predicate:NSPredicate(format:"selected == true AND hittable == true"),object:nav)
            XCTAssertEqual(XCTWaiter.wait(for:[selected],timeout:5),.completed)
            app.buttons["native.home.cta"].tap()
            XCTAssertTrue(app.otherElements["native-gameplay-board"].waitForExistence(timeout:15))
            let entry=expectation(description:"Actual Source entry painted capture window")
            DispatchQueue.main.asyncAfter(deadline:.now()+5){entry.fulfill()}
            wait(for:[entry],timeout:7)
            XCTAssertTrue(app.otherElements["native.tutorial.sheet"].waitForExistence(timeout:10))
            XCTAssertEqual(app.webViews.count,0)
            let shot=XCTAttachment(screenshot:app.screenshot());shot.name="native-source-tutorial-os-entry-\(index)";shot.lifetime = .keepAlways;add(shot)
            app.terminate()
        }
    }
    func testExplicitNativeDiagnosticsCaptureAcrossActualOSForegroundAndBackground()throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"]=="1018BE2D-491B-465F-8F75-3E5BEB38C22A",
              ProcessInfo.processInfo.environment["CC_NATIVE_QA_DIAGNOSTICS_OS"]=="1" else {
            throw XCTSkip("Explicit dedicated Native diagnostics OS evidence only")
        }
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchEnvironment["CC_NATIVE_QA_PROFILE_ID"]="AD1E2026-1010-4000-8000-000000000003"
        app.launchArguments=["--cc-native-thermal-telemetry"]
        app.launch();defer{app.terminate()}
        XCTAssertTrue(app.buttons["native.home.slide.0"].waitForExistence(timeout:20))
        XCTAssertEqual(app.webViews.count,0)
        func window(_ name:String,seconds:Double) {
            print("[NATIVE_DIAGNOSTICS_OS] \(name)")
            let done=expectation(description:name)
            DispatchQueue.main.asyncAfter(deadline:.now()+seconds){done.fulfill()}
            wait(for:[done],timeout:seconds+5)
        }
        window("active-capture",seconds:6)
        XCUIDevice.shared.press(.home)
        let background=XCTNSPredicateExpectation(predicate:NSPredicate(format:"state != %d",XCUIApplication.State.runningForeground.rawValue),object:app)
        XCTAssertEqual(XCTWaiter.wait(for:[background],timeout:10),.completed)
        window("background-silence",seconds:8)
        XCTAssertTrue([XCUIApplication.State.runningBackground,.runningBackgroundSuspended].contains(app.state),"Capture must retain the same background process")
        app.activate()
        XCTAssertTrue(app.buttons["native.home.slide.0"].waitForExistence(timeout:10))
        window("resumed-capture",seconds:6)
        XCTAssertEqual(app.webViews.count,0)
        let screenshot=XCTAttachment(screenshot:app.screenshot())
        screenshot.name="native-diagnostics-os-return-home";screenshot.lifetime = .keepAlways;add(screenshot)
    }
    func testRealSlowAndFastSwipesAndNavClicksKeepHomeRoute() throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"] == "1018BE2D-491B-465F-8F75-3E5BEB38C22A" else {throw XCTSkip("Dedicated QA Simulator only")}
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchEnvironment["CC_NATIVE_QA_PROFILE_ID"]=UUID().uuidString;app.launch()
        func nav(_ index:Int)->XCUIElement {app.buttons["native.home.slide.\(index)"]}
        XCTAssertTrue(nav(0).waitForExistence(timeout:15))
        func settled(_ index:Int) {
            let target=nav(index)
            let selectionExpectation=XCTNSPredicateExpectation(predicate:NSPredicate(format:"selected == true AND hittable == true"),object:target)
            XCTAssertEqual(XCTWaiter.wait(for:[selectionExpectation],timeout:5),.completed)
            // Input admission does not cover selection; allow original finite
            // track/bounce completion before the next unrelated slow gesture.
            let done=expectation(description:"Original finite Home motion")
            DispatchQueue.main.asyncAfter(deadline:.now()+0.9){done.fulfill()};wait(for:[done],timeout:2)
            XCTAssertTrue(app.buttons["native.home.cta"].exists)
        }
        settled(0)
        app.swipeLeft(velocity:.slow);settled(1)
        app.swipeLeft(velocity:.fast);settled(2)
        app.swipeRight(velocity:.fast);settled(1)
        app.swipeRight(velocity:.slow);settled(0)
        nav(2).tap();settled(2)
        nav(0).tap();settled(0)
        XCTAssertEqual(app.webViews.count,0)
        let shot=XCTAttachment(screenshot:app.screenshot());shot.name="native-home-real-swipes-nav";shot.lifetime = .keepAlways;add(shot)
    }
    func testNativeSettingsSurviveActualOSProcessRestart() throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"] == "1018BE2D-491B-465F-8F75-3E5BEB38C22A" else {throw XCTSkip("Dedicated QA Simulator only")}
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchEnvironment["CC_NATIVE_QA_PROFILE_ID"]=UUID().uuidString
        func openSettings() {
            let nav=app.buttons["native.home.slide.2"]
            XCTAssertTrue(nav.waitForExistence(timeout:20));nav.tap()
            let cta=app.buttons["native.home.cta"]
            let selected=XCTNSPredicateExpectation(predicate:NSPredicate(format:"selected == true AND hittable == true"),object:nav)
            XCTAssertEqual(XCTWaiter.wait(for:[selected],timeout:5),.completed)
            XCTAssertTrue(cta.waitForExistence(timeout:5));cta.tap()
            XCTAssertTrue(app.otherElements["native.settings"].waitForExistence(timeout:10))
        }
        app.launch();openSettings()
        let toggle=app.buttons["native.settings.hapticsEnabled"]
        XCTAssertTrue(toggle.waitForExistence(timeout:5));XCTAssertEqual(toggle.value as? String,"Off")
        toggle.tap()
        XCTAssertEqual(toggle.value as? String,"On")
        // Back travels through the actual Settings save owner before OS exit.
        app.buttons["native.settings.back"].tap()
        XCTAssertTrue(app.buttons["native.home.slide.2"].waitForExistence(timeout:10))
        app.terminate();app.launch();openSettings()
        XCTAssertEqual(app.buttons["native.settings.hapticsEnabled"].value as? String,"On")
        XCTAssertEqual(app.webViews.count,0)
        let shot=XCTAttachment(screenshot:app.screenshot());shot.name="native-settings-os-restart";shot.lifetime = .keepAlways;add(shot)
        app.terminate()
    }

    func testPreparedGenuineGuideProfileStartsForcedTutorialAcrossTwoOSLaunches() throws {
        #if !targetEnvironment(simulator)
        throw XCTSkip("Simulator-only")
        #endif
        guard ProcessInfo.processInfo.environment["SIMULATOR_UDID"] == "1018BE2D-491B-465F-8F75-3E5BEB38C22A" else {throw XCTSkip("Dedicated QA Simulator only")}
        // This explicit evidence fixture must be populated with bytes exported
        // by the actual completed-guide transaction before selecting this test.
        guard ProcessInfo.processInfo.environment["CC_NATIVE_QA_GENUINE_GUIDE_REPLAY"] == "1" else {throw XCTSkip("Genuine producer evidence must be prepared first")}
        continueAfterFailure=false
        let app=XCUIApplication(bundleIdentifier:"com.taptapdesign.stacktosix.native")
        app.launchEnvironment["CC_NATIVE_QA_PROFILE_ID"]="AD1E2026-1010-4000-8000-000000000002"
        for index in 0..<2 {
            app.launch()
            let nav=app.buttons["native.home.slide.1"]
            XCTAssertTrue(nav.waitForExistence(timeout:20));nav.tap()
            let selected=XCTNSPredicateExpectation(predicate:NSPredicate(format:"selected == true AND hittable == true"),object:nav)
            XCTAssertEqual(XCTWaiter.wait(for:[selected],timeout:5),.completed)
            app.buttons["native.home.cta"].tap()
            XCTAssertTrue(app.otherElements["native-gameplay-board"].waitForExistence(timeout:15))
            // Capture after the existing finite board/HUD entry window;
            // element existence alone can precede the final painted pose.
            let entryWindow=expectation(description:"Existing finite board entry capture window")
            DispatchQueue.main.asyncAfter(deadline:.now()+4){entryWindow.fulfill()}
            wait(for:[entryWindow],timeout:6)
            XCTAssertTrue(app.otherElements["native.tutorial.sheet"].waitForExistence(timeout:10))
            XCTAssertEqual(app.webViews.count,0)
            let shot=XCTAttachment(screenshot:app.screenshot());shot.name="native-forced-tutorial-os-entry-\(index)";shot.lifetime = .keepAlways;add(shot)
            app.terminate()
        }
    }

}
