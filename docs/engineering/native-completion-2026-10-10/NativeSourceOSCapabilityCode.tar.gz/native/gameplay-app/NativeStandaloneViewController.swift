import UIKit
import StackToSixNativeState

/// Native application root. Archived hybrid shell is not a runtime fallback.
/// Storyboard admission remains separate from this connected, testable root.
@MainActor final class NativeStandaloneViewController:UIViewController {
    private var bootstrap:NativeBootstrap?
    private var resourceRoot:URL?
    private var store:NativeSaveStore?
    private let sourceTransportEnabled:Bool
    private let sourceFreshTutorialEnabled:Bool
    private(set) var sourceRuntime:NativeSourceApplicationRuntime?
    private let diagnosticsArguments:[String]?
    private let diagnosticsPreference:Bool?
    private let diagnosticsDirectory:URL?
    private(set) var diagnostics:NativeDiagnosticsCapture?
    private(set) var disposed=false
    init(resourceRoot:URL?=nil,store:NativeSaveStore?=nil,diagnosticsArguments:[String]?=nil,diagnosticsPreference:Bool?=nil,diagnosticsDirectory:URL?=nil,sourceTransportEnabled:Bool=false,sourceFreshTutorialEnabled:Bool=false) {
        self.resourceRoot=resourceRoot;self.store=store
        self.sourceTransportEnabled=sourceTransportEnabled || sourceFreshTutorialEnabled
        self.sourceFreshTutorialEnabled=sourceFreshTutorialEnabled
        self.diagnosticsArguments=diagnosticsArguments;self.diagnosticsPreference=diagnosticsPreference;self.diagnosticsDirectory=diagnosticsDirectory
        super.init(nibName:nil,bundle:nil)
    }
    required init?(coder:NSCoder){
        #if DEBUG && targetEnvironment(simulator)
        let admitted=NativeSimulatorSourceQA.admitted(environment:ProcessInfo.processInfo.environment,bundleIdentifier:Bundle.main.bundleIdentifier)
        sourceTransportEnabled=admitted;sourceFreshTutorialEnabled=admitted
        #else
        sourceTransportEnabled=false;sourceFreshTutorialEnabled=false
        #endif
        diagnosticsArguments=nil;diagnosticsPreference=nil;diagnosticsDirectory=nil;super.init(coder:coder)
    }
    override func loadView() {
        let root=UIView();root.backgroundColor=UIColor(red:243/255,green:238/255,blue:232/255,alpha:1)
        view=root
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        guard !disposed,Bundle.main.bundleIdentifier=="com.taptapdesign.stacktosix.native" else{return}
        startDiagnosticsIfRequested()
        do {
            if sourceTransportEnabled {
                guard let runtime=NativeSourceApplicationRuntime.acquire() else {
                    throw NSError(domain:"StackToSixNative",code:2,userInfo:[NSLocalizedDescriptionKey:"Native animation transport is busy"])
                }
                sourceRuntime=runtime
            }
            guard let root=resourceRoot ?? Bundle.main.url(forResource:"NativeAssets",withExtension:"bundle") else {
                throw NSError(domain:"StackToSixNative",code:1,userInfo:[NSLocalizedDescriptionKey:"Native artwork is missing"])
            }
            #if DEBUG && targetEnvironment(simulator)
            if store==nil,let directory=NativeSimulatorQAProfile.directory(
                environment:ProcessInfo.processInfo.environment,
                bundleIdentifier:Bundle.main.bundleIdentifier,
                temporaryDirectory:FileManager.default.temporaryDirectory) {
                store=try NativeSimulatorQAProfile.prepare(directory:directory)
            }
            #endif
            let owner=try NativeBootstrap(root:root,store:store,sourceContext:sourceRuntime?.context)
            if sourceFreshTutorialEnabled {
                owner.sourceInitialFreshStartupEnabled=true;owner.sourceBoardEntryEnabled=true
                owner.sourceTutorialActivationEnabled=true;owner.sourceTutorialIntroEnabled=true
                owner.sourceTutorialHUDEnabled=true;owner.sourceTutorialFirstStepMonitorEnabled=true
            }
            bootstrap=owner;owner.start(in:self)
        } catch {
            sourceRuntime?.dispose();sourceRuntime=nil
            let label=UILabel();label.numberOfLines=0;label.textAlignment = .center
            label.textColor = .systemRed;label.text=error.localizedDescription
            label.frame=view.bounds.insetBy(dx:24,dy:80);label.autoresizingMask=[.flexibleWidth,.flexibleHeight]
            view.addSubview(label)
        }
    }
    func dispose() {
        guard !disposed else{return};disposed=true
        diagnostics?.dispose();diagnostics=nil
        bootstrap?.dispose();bootstrap=nil;store=nil;resourceRoot=nil
        sourceRuntime?.dispose();sourceRuntime=nil
    }
    isolated deinit {dispose()}
    private func startDiagnosticsIfRequested() {
        let arguments=diagnosticsArguments ?? ProcessInfo.processInfo.arguments
        let preference=diagnosticsPreference ?? UserDefaults.standard.bool(forKey:"cc.performanceDiagnostics")
        guard NativeDiagnosticsCapture.admitted(arguments:arguments,
            bundleIdentifier:Bundle.main.bundleIdentifier,
            preferenceEnabled:preference) else{return}
        let performanceEnabled=preference || arguments.contains("--cc-performance-diagnostics")
        guard let directory=diagnosticsDirectory ?? FileManager.default.urls(for:.cachesDirectory,in:.userDomainMask).first?.appendingPathComponent("NativeOnlyDiagnostics",isDirectory:true) else{return}
        let owner=NativeDiagnosticsCapture(directory:directory,snapshot:{[weak self] in
            let process=ProcessInfo.processInfo,device=UIDevice.current
            let thermal:String
            switch process.thermalState {
            case .nominal:thermal="nominal"
            case .fair:thermal="fair"
            case .serious:thermal="serious"
            case .critical:thermal="critical"
            @unknown default:thermal="unknown"
            }
            return ["thermalState":thermal,"lowPowerMode":process.isLowPowerModeEnabled,
                "batteryPercent":device.batteryLevel>=0 ? Int((device.batteryLevel*100).rounded()):-1,
                "batteryState":device.batteryState.rawValue,
                "brightnessPercent":self?.view.window.map{Int(($0.screen.brightness*100).rounded())} ?? -1,
                "activeProcessorCount":process.activeProcessorCount,"systemUptimeSeconds":Int(process.systemUptime),
                "appVersion":Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? "unknown",
                "appBuild":Bundle.main.object(forInfoDictionaryKey:"CFBundleVersion") as? String ?? "unknown",
                "product":Bundle.main.bundleIdentifier ?? "unknown","performanceDiagnosticsEnabled":performanceEnabled,
                "nativeThermalTelemetryEnabled":true]
        })
        diagnostics=owner;owner.start(foreground:UIApplication.shared.applicationState == .active)
    }
}

#if DEBUG && targetEnvironment(simulator)
/// Actual OS Source-entry proof is admitted only with an isolated QA profile.
/// Release and ordinary icon launches retain the current migration checkpoint.
enum NativeSimulatorSourceQA {
    static func admitted(environment:[String:String],bundleIdentifier:String?)->Bool {
        environment["CC_NATIVE_QA_SOURCE_FRESH_TUTORIAL"]=="1" &&
        NativeSimulatorQAProfile.directory(environment:environment,bundleIdentifier:bundleIdentifier,
            temporaryDirectory:FileManager.default.temporaryDirectory) != nil
    }
}
/// Stable isolated QA profile across OS launches. No normal profile fallback,
/// migration or reset is permitted by this private Simulator capability.
enum NativeSimulatorQAProfile {
    static func directory(environment:[String:String],bundleIdentifier:String?,temporaryDirectory:URL)->URL? {
        guard bundleIdentifier=="com.taptapdesign.stacktosix.native",
            environment["SIMULATOR_UDID"]=="1018BE2D-491B-465F-8F75-3E5BEB38C22A",
            let raw=environment["CC_NATIVE_QA_PROFILE_ID"],let id=UUID(uuidString:raw) else{return nil}
        return temporaryDirectory.appendingPathComponent("native-process-qa-\(id.uuidString)",isDirectory:true)
    }
    static func prepare(directory:URL)throws->NativeSaveStore {
        let store=NativeSaveStore(directory:directory)
        if try store.load()==nil {
            try store.save(NativeSaveEnvelope(settings:.init(gameSoundsEnabled:false,musicEnabled:false,hapticsEnabled:false)))
        }
        return store
    }
}
#endif
