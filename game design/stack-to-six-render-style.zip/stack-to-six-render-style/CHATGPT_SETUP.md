# Connecting this style guide in ChatGPT

Add this package to your Stack to Six project. If the chat cannot open ZIP files,
extract it and add SKILL.md plus both reference PNGs directly as project files.
Add this line to your project instructions:

> When I mention "render style" while discussing character artwork, read the attached stack-to-six-render-style/SKILL.md and compare against its lik-game.png and lik-lajna.png references. Follow my request for review, prompt writing or actual image editing. Preserve elongated cartoony arms/legs and the soft, light creamy render.

Example: "Pogledaj moj render style i popravi ovu sliku."

Uploading files provides reference context; it does not automatically install a
Codex skill or change project settings. Keep the two images available for visual
comparison and image editing.
